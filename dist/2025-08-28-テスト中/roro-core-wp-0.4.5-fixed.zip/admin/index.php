<?php
// Silence is golden. Prevent directory listing.
