<?php
/**
 * Plugin Name: RORO Favorites
 * Description: ユーザーのお気に入り（イベント/スポット）をDBに完全永続化し、重複登録を防止します。REST API・ショートコード・クエリパラメータ対応。
 * Version: 1.1.2
 * Author: Project RORO
 * Text Domain: roro-favorites
 * Domain Path: /lang
 *
 * 要件:
 *  - wp_RORO_MAP_FAVORITE（ユーザーx対象の重複防止ユニーク制約）を作成（存在しなければ）
 *  - REST: GET /roro/v1/favorites, POST /roro/v1/favorites/add, DELETE /roro/v1/favorites/remove
 *  - ショートコード: [roro_favorites]
 *  - クエリパラメータ: ?roro_fav_add=spot&spot_id=123 / ?roro_fav_remove=event&event_id=45
 *  - 多言語: ja / en / zh / ko
 */

if (!defined('ABSPATH')) { exit; }

// Define plugin version constant once.  Bump the value when releasing
// new versions.  Note: the plugin header above must also be updated.
define('RORO_FAV_VERSION', '1.1.2');
define('RORO_FAV_PATH', plugin_dir_path(__FILE__));
define('RORO_FAV_URL',  plugin_dir_url(__FILE__));

// 個別クラス読み込み（依存関係の順序に注意）
require_once RORO_FAV_PATH . 'includes/class-roro-favorites-i18n.php';
require_once RORO_FAV_PATH . 'includes/class-roro-favorites-data.php';
require_once RORO_FAV_PATH . 'includes/class-roro-favorites-service.php';
require_once RORO_FAV_PATH . 'includes/class-roro-favorites-rest.php';
require_once RORO_FAV_PATH . 'includes/class-roro-favorites-admin.php';
// UI: Register [roro_favorites_list] shortcode and associated assets.  The
// UI class is separate to keep the main plugin lean; require it here
// so that its static init() runs on every page load.
require_once RORO_FAV_PATH . 'includes/class-roro-favorites-ui.php';

// 有効化: スキーマ作成
register_activation_hook(__FILE__, function () {
    // プラグイン有効化時にお気に入りテーブルを作成
    $svc = new RORO_Favorites_Service();
    $svc->install_schema();
});

// 初期化: ショートコード、スクリプト、翻訳
add_action('init', function () {
    // テキストドメイン読み込み。Po/Mo ファイルによる翻訳を有効にする
    load_plugin_textdomain('roro-favorites', false, dirname(plugin_basename(__FILE__)) . '/lang');
    // ショートコード: [roro_favorites] お気に入り一覧表示
    add_shortcode('roro_favorites', function ($atts = []) {
        $svc = new RORO_Favorites_Service();
        $lang = $svc->detect_lang();
        $messages = $svc->load_lang($lang);
        if (!is_user_logged_in()) {
            // 未ログインの場合のメッセージを直接返す
            return '<p>' . esc_html($messages['must_login']) . '</p>';
        }

        // スクリプト登録とローカライズ
        wp_register_script(
            'roro-favorites-js',
            RORO_FAV_URL . 'assets/js/favorites.js',
            ['wp-api-fetch'],
            RORO_FAV_VERSION,
            true
        );
        // RESTエンドポイントと翻訳をフロントに渡す
        wp_localize_script('roro-favorites-js', 'RORO_FAV_CONFIG', [
            'rest' => [
                'add'    => esc_url_raw(rest_url('roro/v1/favorites/add')),
                'remove' => esc_url_raw(rest_url('roro/v1/favorites/remove')),
                'nonce'  => wp_create_nonce('wp_rest'),
            ],
            'i18n' => [
                'added'   => $messages['notice_added'] ?? '',
                'removed' => $messages['notice_removed'] ?? '',
                'error'   => $messages['notice_error'] ?? '',
            ],
        ]);
        wp_enqueue_script('roro-favorites-js');

        // テンプレートに渡すデータ準備
        $data = [
            'lang'     => $lang,
            'messages' => $messages,
        ];
        ob_start();
        include RORO_FAV_PATH . 'templates/favorites-list.php';
        return ob_get_clean();
    });

    // ショートコード: [roro_favorite_button] (お気に入り追加/削除ボタン)
    add_shortcode('roro_favorite_button', function ($atts) {
        $atts = shortcode_atts([
            'type'  => '',   // event または spot
            'id'    => '',   // 対象の投稿ID
            'title' => '',   // 未使用（将来拡張用）
            'url'   => '',   // 未使用（将来拡張用）
        ], $atts, 'roro_favorite_button');

        $svc = new RORO_Favorites_Service();
        $lang = $svc->detect_lang();
        $messages = $svc->load_lang($lang);
        // 未ログイン時はログインを促す表示を返す
        if (!is_user_logged_in()) {
            return '<div class="roro-fav-hint">' . esc_html($messages['must_login']) . '</div>';
        }

        $type = sanitize_text_field($atts['type']);
        $id   = intval($atts['id']);
        // 種別またはIDが指定されていない場合は何も表示しない
        if (!$type || !$id) {
            return '';
        }

        // お気に入り済みかチェック
        $exists = $svc->is_favorite(get_current_user_id(), $type, $id);
        // ボタン用のアイコンとラベル
        $icon  = $exists ? '★' : '☆';
        $label = $exists ? ($messages['btn_remove'] ?? '') : ($messages['btn_add'] ?? '');
        $pressed = $exists ? 'true' : 'false';

        // ボタン表示用のスタイル/スクリプトを読み込む。一度だけ登録しておけば重複読み込みを防げる。
        // JS では REST API エンドポイントと翻訳メッセージを参照するので localize する
        wp_register_script(
            'roro-fav-button-js',
            RORO_FAV_URL . 'assets/js/favorite-button.js',
            [],
            RORO_FAV_VERSION,
            true
        );
        wp_register_style(
            'roro-fav-button-style',
            RORO_FAV_URL . 'assets/css/favorite-button.css',
            [],
            RORO_FAV_VERSION
        );
        // RESTエンドポイントと翻訳メッセージをJSに渡す
        wp_localize_script('roro-fav-button-js', 'RORO_FAV_CONFIG', [
            'rest' => [
                'add'    => esc_url_raw(rest_url('roro/v1/favorites/add')),
                'remove' => esc_url_raw(rest_url('roro/v1/favorites/remove')),
                'nonce'  => wp_create_nonce('wp_rest'),
            ],
            'i18n' => [
                'notice_added'   => $messages['notice_added'] ?? '',
                'notice_removed' => $messages['notice_removed'] ?? '',
                'notice_error'   => $messages['notice_error'] ?? '',
                'btn_add'        => $messages['btn_add'] ?? '',
                'btn_remove'     => $messages['btn_remove'] ?? '',
            ],
        ]);
        wp_enqueue_script('roro-fav-button-js');
        wp_enqueue_style('roro-fav-button-style');

        // ボタンHTMLを出力。 data-target/id に情報を含め、aria-pressed 属性で状態を表現
        $html  = '<button type="button" class="roro-fav-btn" data-target="' . esc_attr($type) . '" data-id="' . esc_attr($id) . '" aria-pressed="' . esc_attr($pressed) . '">';
        $html .= '<span class="roro-fav-icon">' . esc_html($icon) . '</span>';
        $html .= '<span class="roro-fav-label">' . esc_html($label) . '</span>';
        $html .= '</button>';
        return $html;
    });
});

// REST APIエンドポイント登録
add_action('rest_api_init', function () {
    (new RORO_Favorites_REST())->register_routes();
});

// 管理画面メニューの追加
add_action('admin_menu', function () {
    (new RORO_Favorites_Admin())->register_menu();
});

// クエリパラメータでの追加/削除（後方互換処理）
add_action('template_redirect', function () {
    // 未ログイン時は処理しない
    if (!is_user_logged_in()) return;

    $svc = new RORO_Favorites_Service();
    $lang = $svc->detect_lang();
    $messages = $svc->load_lang($lang);
    $redirect = remove_query_arg([ 'roro_fav_add', 'roro_fav_remove', 'spot_id', 'event_id', 'roro_fav_status' ]);

    // 追加処理
    if (isset($_GET['roro_fav_add'])) {
        $type = sanitize_text_field($_GET['roro_fav_add']);
        $id   = 0;
        if ($type === 'spot' && isset($_GET['spot_id'])) {
            $id = intval($_GET['spot_id']);
        } elseif ($type === 'event' && isset($_GET['event_id'])) {
            $id = intval($_GET['event_id']);
        }
        if ($id > 0) {
            // Nonceチェック
            if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'roro_fav_add_' . $type . '_' . $id)) {
                $redirect = add_query_arg('roro_fav_status', 'error', $redirect);
                wp_safe_redirect($redirect);
                exit;
            }
            $r = $svc->add_favorite(get_current_user_id(), $type, $id);
            if (is_wp_error($r)) {
                $redirect = add_query_arg('roro_fav_status', 'error', $redirect);
            } else {
                $redirect = add_query_arg('roro_fav_status', ($r === 'duplicate' ? 'duplicate' : 'added'), $redirect);
            }
            wp_safe_redirect($redirect);
            exit;
        }
    }

    // 削除処理
    if (isset($_GET['roro_fav_remove'])) {
        $type = sanitize_text_field($_GET['roro_fav_remove']);
        $id   = 0;
        if ($type === 'spot' && isset($_GET['spot_id'])) {
            $id = intval($_GET['spot_id']);
        } elseif ($type === 'event' && isset($_GET['event_id'])) {
            $id = intval($_GET['event_id']);
        }
        if ($id > 0) {
            // Nonceチェック
            if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'roro_fav_remove_' . $type . '_' . $id)) {
                $redirect = add_query_arg('roro_fav_status', 'error', $redirect);
                wp_safe_redirect($redirect);
                exit;
            }
            $r = $svc->remove_favorite(get_current_user_id(), $type, $id);
            $redirect = add_query_arg('roro_fav_status', (is_wp_error($r) ? 'error' : 'removed'), $redirect);
            wp_safe_redirect($redirect);
            exit;
        }
    }
});
