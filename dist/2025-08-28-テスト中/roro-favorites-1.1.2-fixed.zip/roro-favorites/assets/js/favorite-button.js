/**
 * Favorite button toggle script
 *
 * This script binds click events to elements with the class
 * `.roro-fav-btn`. When clicked, it sends an AJAX request to
 * register or remove a favorite via the REST API and updates the
 * button state (icon and label) accordingly. Optional toast
 * messages are displayed if a global toast element with ID
 * `roro-fav-toast` exists on the page. Translation strings
 * and API endpoints are provided via the RORO_FAV_CONFIG global
 * object localised from PHP.
 */
(function(){
  'use strict';

  /**
   * Show a toast message if a toast container is present.
   *
   * @param {string} msg Message to display
   */
  function toast(msg){
    var el = document.getElementById('roro-fav-toast');
    if (!el || !msg) return;
    el.textContent = msg;
    el.style.display = 'block';
    el.style.opacity = '1';
    // Fade out after a short delay
    setTimeout(function(){ el.style.opacity = '0'; }, 1500);
    setTimeout(function(){ el.style.display = 'none'; }, 1800);
  }

  /**
   * Toggle favourite status for a given button element.
   * Reads the target type and ID from data attributes and uses
   * the global RORO_FAV_CONFIG to find the correct REST endpoint
   * and nonce. Updates the button icon, label and aria-pressed
   * attribute on success and displays a toast message.
   *
   * @param {HTMLElement} btn The button element
   */
  async function toggleFavourite(btn){
    if (!btn || !window.RORO_FAV_CONFIG) return;
    var type = btn.getAttribute('data-target') || '';
    var id   = parseInt(btn.getAttribute('data-id') || '0', 10);
    if (!type || !id) return;
    var pressed = btn.getAttribute('aria-pressed') === 'true';
    var endpoint = pressed ? RORO_FAV_CONFIG.rest.remove : RORO_FAV_CONFIG.rest.add;
    var method   = pressed ? 'DELETE' : 'POST';
    var payload  = { target_type: type, target_id: id };
    try {
      var res = await fetch(endpoint, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': RORO_FAV_CONFIG.rest.nonce || ''
        },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      // Parse JSON if present; ignore errors
      try { await res.json(); } catch (_) {}
      if (pressed) {
        // Changed from favourite to not-favourite
        btn.setAttribute('aria-pressed', 'false');
        var iconEl = btn.querySelector('.roro-fav-icon');
        var labelEl = btn.querySelector('.roro-fav-label');
        if (iconEl) iconEl.textContent = '☆';
        if (labelEl) labelEl.textContent = RORO_FAV_CONFIG.i18n.btn_add || '';
        toast(RORO_FAV_CONFIG.i18n.notice_removed || '');
      } else {
        // Added to favourites
        btn.setAttribute('aria-pressed', 'true');
        var iconEl2 = btn.querySelector('.roro-fav-icon');
        var labelEl2 = btn.querySelector('.roro-fav-label');
        if (iconEl2) iconEl2.textContent = '★';
        if (labelEl2) labelEl2.textContent = RORO_FAV_CONFIG.i18n.btn_remove || '';
        toast(RORO_FAV_CONFIG.i18n.notice_added || '');
      }
    } catch(e) {
      console.error(e);
      toast(RORO_FAV_CONFIG.i18n.notice_error || 'Error');
    }
  }

  /**
   * Initialise event listeners on DOM ready.
   */
  function init(){
    var buttons = document.querySelectorAll('.roro-fav-btn');
    buttons.forEach(function(btn){
      btn.addEventListener('click', function(){ toggleFavourite(btn); });
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();