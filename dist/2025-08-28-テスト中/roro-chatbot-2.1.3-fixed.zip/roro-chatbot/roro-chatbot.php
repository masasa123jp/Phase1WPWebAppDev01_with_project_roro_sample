<?php
/**
 * Plugin Name: RORO Chatbot
 * Description: Adds a multilingual AI chat interface for pet-related Q&A. Includes a shortcode [roro_chatbot] to embed a chat window that can use OpenAI, Dify or a simple fallback when no external provider is configured. Conversation history is stored server-side and a settings page allows administrators to configure providers and API keys.
 * Version: 2.1.3
 * Author: Project RORO
 * Text Domain: roro-chatbot
 * Domain Path: /lang
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('RORO_CHAT_VERSION', '2.1.3');
define('RORO_CHAT_PATH', plugin_dir_path(__FILE__));
define('RORO_CHAT_URL',  plugin_dir_url(__FILE__));

// Load class files
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-i18n.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-database.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-provider.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-provider-openai.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-provider-dify.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-fallback.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-events.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-service.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-rest.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chat-admin.php';

// Load translations for static strings defined via __()/_e()
add_action('plugins_loaded', function() {
    load_plugin_textdomain('roro-chatbot', false, dirname(plugin_basename(__FILE__)) . '/lang');
});

// Register styles and scripts on the front end
add_action('wp_enqueue_scripts', function() {
    wp_register_style('roro-chatbot-style', RORO_CHAT_URL . 'assets/css/roro-chat.css', [], RORO_CHAT_VERSION);
    // Depend on jQuery for convenience. Use versioned handle.
    wp_register_script('roro-chatbot-js', RORO_CHAT_URL . 'assets/js/roro-chat.js', ['jquery'], RORO_CHAT_VERSION, true);
});

// Shortcode implementation: outputs chat widget markup and passes config via localized script
add_shortcode('roro_chatbot', function($atts) {
    // Provide defaults for shortcode attributes. In addition to the original
    // parameters this implementation supports width, show_header and title.
    $atts = shortcode_atts([
        'embed_url'   => '',
        'height'      => '500px',
        'width'       => '',
        'max_width'   => '720px',
        'show_header' => '1',
        'title'       => '',
    ], $atts, 'roro_chatbot');

    // Determine the embed URL.  If no embed_url is provided via the
    // shortcode, attempt to fall back to constants or options defined by
    // the roro-core plugin (RORO_DIFY_CHAT_URL or dify_chat_url).
    $embed_url_candidate = trim((string) $atts['embed_url']);
    if ($embed_url_candidate === '') {
        if (defined('RORO_DIFY_CHAT_URL') && constant('RORO_DIFY_CHAT_URL')) {
            $embed_url_candidate = constant('RORO_DIFY_CHAT_URL');
        } else {
            $core_opts = get_option('roro_core_wp_settings', array());
            if (isset($core_opts['dify_chat_url']) && $core_opts['dify_chat_url']) {
                $embed_url_candidate = $core_opts['dify_chat_url'];
            }
        }
    }
    if ($embed_url_candidate !== '') {
        $atts['embed_url'] = $embed_url_candidate;
    }

    // Load language
    $lang     = RORO_Chat_I18n::detect_lang();
    $messages = RORO_Chat_I18n::load_messages($lang);

    // EMBED MODE: When an embed URL is available, render an iframe
    if (!empty($atts['embed_url'])) {
        $height = trim((string) $atts['height']);
        if (preg_match('/^\d+$/', $height)) {
            $height .= 'px';
        }
        $width = trim((string) $atts['width']);
        if ($width !== '' && preg_match('/^\d+$/', $width)) {
            $width .= 'px';
        }
        $width = $width !== '' ? $width : '100%';
        ob_start();
        ?>
        <div class="roro-chat-embed" style="max-width:100%; margin:0 auto;">
            <?php
            // When embedding an external Dify chat page, use a more permissive iframe
            // with additional allow attributes for microphone/camera and clipboard access.
            // The width attribute is applied to the iframe tag itself; if not provided
            // the iframe will stretch to 100% width of its container. The height
            // attribute always includes a unit (px or vh) as validated above.
            ?>
            <iframe
                src="<?php echo esc_url($atts['embed_url']); ?>"
                width="<?php echo esc_attr($width); ?>"
                height="<?php echo esc_attr($height); ?>"
                style="border:0; border-radius:8px; width:100%;"
                allow="clipboard-read; clipboard-write; microphone; camera; fullscreen"
                allowfullscreen
                loading="lazy"
                referrerpolicy="no-referrer"
                onerror="this.parentNode.innerHTML='<p style=\'color:red;text-align:center;\'><?php echo esc_js(addslashes($messages['iframe_error'] ?? 'Failed to load chat. Please check the URL.')); ?></p>';"
            ></iframe>
        </div>
        <?php
        return ob_get_clean();
    }

    // NATIVE MODE: Use internal chat interface
    wp_enqueue_style('roro-chatbot-style');
    wp_enqueue_script('roro-chatbot-js');
    wp_localize_script('roro-chatbot-js', 'RORO_CHAT_CFG', [
        'restBase' => esc_url_raw(rest_url('roro/v1')),
        'nonce'    => wp_create_nonce('wp_rest'),
        'i18n'     => $messages,
        'settings' => [
            'provider' => get_option('roro_chat_provider', 'echo'),
            'model'    => get_option('roro_chat_openai_model', 'gpt-4o-mini'),
        ],
    ]);

    // Compute sizes
    $height = trim((string) $atts['height']);
    if (preg_match('/^\d+$/', $height)) {
        $height .= 'px';
    }
    $width  = trim((string) $atts['width']);
    if ($width !== '' && preg_match('/^\d+$/', $width)) {
        $width .= 'px';
    }
    $max_width = trim((string) $atts['max_width']);
    if (preg_match('/^\d+$/', $max_width)) {
        $max_width .= 'px';
    }
    if ($width !== '') {
        $container_style = 'width:' . esc_attr($width) . '; margin:0 auto;';
    } else {
        $container_style = 'max-width:' . esc_attr($max_width) . '; margin:0 auto;';
    }

    // Determine title
    $title_text = $atts['title'] !== '' ? $atts['title'] : ($messages['chat_title'] ?? 'Chatbot');

    ob_start();
    ?>
    <div class="roro-chat-wrap" style="<?php echo $container_style; ?>">
        <?php if ($atts['show_header'] !== '0') : ?>
        <div class="roro-chat-header">
            <div class="roro-chat-title"><?php echo esc_html($title_text); ?></div>
            <div class="roro-chat-provider">
                <?php echo esc_html($messages['provider'] ?? 'Provider'); ?>:
                <?php echo esc_html(strtoupper(get_option('roro_chat_provider', 'echo'))); ?>
            </div>
        </div>
        <?php endif; ?>
        <div id="roro-chat-log" class="roro-chat-log" aria-live="polite" style="height:<?php echo esc_attr($height); ?>;"></div>
        <div class="roro-chat-input">
            <input type="text" id="roro-chat-text" placeholder="<?php echo esc_attr($messages['placeholder'] ?? 'Type your question…'); ?>" />
            <button type="button" id="roro-chat-send"><?php echo esc_html($messages['send'] ?? 'Send'); ?></button>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

// Register REST API route
add_action('rest_api_init', function() {
    (new RORO_Chat_REST())->register_routes();
});

// Register settings page
add_action('admin_menu', function() {
    add_options_page(
        __('RORO Chatbot', 'roro-chatbot'),
        __('RORO Chatbot', 'roro-chatbot'),
        'manage_options',
        'roro-chatbot',
        function() {
            (new RORO_Chat_Admin())->render_settings_page();
        }
    );
});
