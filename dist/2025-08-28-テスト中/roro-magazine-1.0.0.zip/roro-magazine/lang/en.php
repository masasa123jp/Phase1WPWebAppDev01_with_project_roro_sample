<?php
$roro_mag_messages = array(
  'magazine'     => 'Online Magazine',
  'view_issue'   => 'Read this issue',
  'read_more'    => 'Read more',
  'read_less'    => 'Read less',
  'back_to_list' => 'Back to issues',
  'no_issues'    => 'No issues published yet.',
  'no_articles'  => 'No articles available.',
  'issue_key'    => 'Issue (YYYY-MM)',
  // Additional UI labels used in the slider and ad cards
  'prev'         => 'Prev',
  'next'         => 'Next',
  'sponsored'    => 'Sponsored',
  'learn_more'   => 'Learn more',
);
