<?php
/**
 * REST API controller for the MECE RORO Auth plugin.
 *
 * Exposes a handful of endpoints under the roro/v1 namespace to handle
 * authentication helper actions, breed lookup and pet management.
 * All responses are returned as associative arrays which WP REST will
 * convert to JSON.
 */
class Roro_Auth_REST {
    /**
     * Register our REST routes.  Hook this via rest_api_init.
     *
     * @return void
     */
    public function register_routes(): void {
        add_action('rest_api_init', function () {
            $namespace = 'roro/v1';
            // User login endpoint.
            register_rest_route($namespace, '/auth/login', [
                'methods'  => 'POST',
                'callback' => [$this, 'handle_login'],
                'permission_callback' => '__return_true',
                'args' => [],
            ]);

            // User registration endpoint.
            register_rest_route($namespace, '/auth/register', [
                'methods'  => 'POST',
                'callback' => [$this, 'handle_register'],
                'permission_callback' => '__return_true',
                'args' => [],
            ]);

            // Breed master list.  Publicly accessible.
            register_rest_route($namespace, '/breeds', [
                'methods'  => 'GET',
                'callback' => [$this, 'get_breeds'],
                'permission_callback' => '__return_true',
                'args' => [
                    'locale' => [
                        'type' => 'string',
                        'required' => false,
                    ],
                ],
            ]);

            // Pets CRUD (requires sign‑in).
            register_rest_route($namespace, '/pets', [
                [
                    'methods'  => 'GET',
                    'callback' => [$this, 'get_pets'],
                    'permission_callback' => '__return_true',
                ],
                [
                    'methods'  => 'POST',
                    'callback' => [$this, 'save_pets'],
                    'permission_callback' => '__return_true',
                ],
            ]);

            // Representative pet selection.
            register_rest_route($namespace, '/pets/representative', [
                'methods'  => 'POST',
                'callback' => [$this, 'set_representative_pet'],
                'permission_callback' => '__return_true',
            ]);

            // Connected social accounts.  Requires sign‑in.
            register_rest_route($namespace, '/accounts', [
                'methods'  => 'GET',
                'callback' => [$this, 'get_accounts'],
                'permission_callback' => '__return_true',
            ]);
        });
    }

    /**
     * Return the breed master list for the requested locale.
     *
     * Data files live under assets/data and are named breeds-{lang}.json.
     * If the file does not exist the English file is used as a fallback.
     *
     * @param WP_REST_Request $req
     * @return array<int,string>
     */
    public function get_breeds(WP_REST_Request $req): array {
        $locale = sanitize_text_field($req->get_param('locale') ?: get_locale());
        $lang   = substr($locale, 0, 2);
        $map = [
            'ja' => 'breeds-ja.json',
            'en' => 'breeds-en.json',
            'zh' => 'breeds-zh.json',
            'ko' => 'breeds-ko.json',
        ];
        $file = RORO_AUTH_DIR . 'assets/data/' . ($map[$lang] ?? 'breeds-en.json');
        if (!file_exists($file)) {
            $file = RORO_AUTH_DIR . 'assets/data/breeds-en.json';
        }
        $json = file_get_contents($file);
        $list = json_decode($json, true);
        return is_array($list) ? $list : [];
    }

    /**
     * Fetch the pets for the current user.
     *
     * Requires that the user is logged in.  If not, returns a 401 error.
     *
     * @return array<int,array<string,mixed>>|WP_Error
     */
    public function get_pets(): mixed {
        if (!is_user_logged_in()) {
            return new WP_Error('forbidden', Roro_Auth_I18n::t('signin_required'), ['status' => 401]);
        }
        return Roro_Auth_Pets::get_pets(get_current_user_id());
    }

    /**
     * Save the pets for the current user.
     *
     * The request body should be JSON with a `pets` property containing an
     * array of pet definitions.  A valid nonce (via the X-WP-Nonce
     * header) is required because this is a write operation.  The user
     * must be logged in.
     *
     * @param WP_REST_Request $req
     * @return array|WP_Error
     */
    public function save_pets(WP_REST_Request $req) {
        if (!is_user_logged_in()) {
            return new WP_Error('forbidden', Roro_Auth_I18n::t('signin_required'), ['status' => 401]);
        }
        // Verify nonce for CSRF.  The wp_rest nonce should be sent via header.
        $nonce = $req->get_header('X-WP-Nonce');
        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('forbidden', Roro_Auth_I18n::t('invalid_nonce'), ['status' => 403]);
        }
        $params = $req->get_json_params();
        $pets   = is_array($params['pets'] ?? null) ? $params['pets'] : [];
        Roro_Auth_Pets::save_pets(get_current_user_id(), $pets);
        return [
            'success' => true,
            'message' => Roro_Auth_I18n::t('pets_saved'),
        ];
    }

    /**
     * Set the representative pet for the current user.
     *
     * Expects a `pet_id` parameter in the request body.  Requires login
     * and a valid nonce.  Returns the new representative id on success.
     *
     * @param WP_REST_Request $req
     * @return array|WP_Error
     */
    public function set_representative_pet(WP_REST_Request $req) {
        if (!is_user_logged_in()) {
            return new WP_Error('forbidden', Roro_Auth_I18n::t('signin_required'), ['status' => 401]);
        }
        $nonce = $req->get_header('X-WP-Nonce');
        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('forbidden', Roro_Auth_I18n::t('invalid_nonce'), ['status' => 403]);
        }
        $pet_id = sanitize_text_field($req->get_param('pet_id') ?? '');
        if ($pet_id === '') {
            return new WP_Error('bad_request', Roro_Auth_I18n::t('error_required'), ['status' => 400]);
        }
        try {
            Roro_Auth_Pets::set_representative(get_current_user_id(), $pet_id);
        } catch (Throwable $e) {
            return new WP_Error('bad_request', $e->getMessage(), ['status' => 400]);
        }
        return [
            'success'   => true,
            'rep_pet_id'=> $pet_id,
        ];
    }

    /**
     * Return the list of connected social accounts for the current user.
     *
     * If the user is not logged in a 401 error is returned.  Each provider
     * entry is keyed by provider name (e.g. `google`, `line`) and the value
     * is the provider specific identifier.  A missing provider key implies
     * the account is not connected.
     *
     * @return array<string,string>|WP_Error
     */
    public function get_accounts() {
        if (!is_user_logged_in()) {
            return new WP_Error('forbidden', Roro_Auth_I18n::t('signin_required'), ['status' => 401]);
        }
        $uid = get_current_user_id();
        $accounts = (array) get_user_meta($uid, 'roro_auth_accounts', true);
        return $accounts;
    }

    /**
     * Handle user login.
     *
     * Expects a JSON body containing `username` and `password`.  On success the
     * current user and auth cookies are set and a success message is
     * returned.  On failure a WP_Error with an appropriate status code
     * is returned.  We deliberately do not expose error specifics for
     * security reasons.
     *
     * @param WP_REST_Request $req
     * @return array|WP_Error
     */
    public function handle_login(WP_REST_Request $req) {
        $params = $req->get_json_params();
        if (!is_array($params)) {
            return new WP_Error('invalid_request', Roro_Auth_I18n::t('error_required'), ['status' => 400]);
        }
        $username = sanitize_user($params['username'] ?? '');
        $password = (string)($params['password'] ?? '');
        if ($username === '' || $password === '') {
            return new WP_Error('missing_credentials', Roro_Auth_I18n::t('error_required'), ['status' => 400]);
        }
        // First, attempt to authenticate against our custom RORO customer table.  We
        // treat the username as an email address.  If a matching record is
        // found and the password hash matches then we either use the linked
        // wp_user_id for the session or create a new WordPress user on the fly.
        global $wpdb;
        $table = $wpdb->prefix . 'roro_customer';
        // Fetch customer by email
        $customer = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE email = %s", $username));
        if ($customer) {
            // Verify password hash
            if (!wp_check_password($password, $customer->password_hash)) {
                return new WP_Error('authentication_failed', Roro_Auth_I18n::t('error_login_failed'), ['status' => 401]);
            }
            // Ensure a corresponding WordPress user exists
            $wp_user_id = (int)$customer->wp_user_id;
            if (!$wp_user_id || !($wp_user = get_user_by('id', $wp_user_id))) {
                // Attempt to locate an existing WP user by email
                $wp_user = get_user_by('email', $customer->email);
                if (!$wp_user) {
                    // Create a new WP user.  We use the same password hash so
                    // that authentication via wp_authenticate also succeeds.
                    $username_for_wp = sanitize_user(current(explode('@', $customer->email)));
                    // Ensure username uniqueness
                    if (username_exists($username_for_wp)) {
                        $username_for_wp .= '_' . wp_generate_password(4, false, false);
                    }
                    $uid = wp_insert_user([
                        'user_login' => $username_for_wp,
                        'user_pass'  => $password,
                        'user_email' => $customer->email,
                        'display_name' => $customer->name ?: $username_for_wp,
                        'role'      => get_option('default_role', 'subscriber'),
                    ]);
                    if (!is_wp_error($uid)) {
                        $wp_user_id = (int)$uid;
                        $wp_user = get_user_by('id', $wp_user_id);
                        // Persist the linkage
                        $wpdb->update($table, ['wp_user_id' => $wp_user_id], ['id' => $customer->id]);
                    } else {
                        // Could not create WP user
                        return new WP_Error('registration_failed', $uid->get_error_message(), ['status' => 500]);
                    }
                } else {
                    $wp_user_id = $wp_user->ID;
                    // Update linkage
                    $wpdb->update($table, ['wp_user_id' => $wp_user_id], ['id' => $customer->id]);
                }
            }
            // Log in the user via WordPress session
            wp_set_current_user($wp_user->ID);
            wp_set_auth_cookie($wp_user->ID);
            return [
                'success' => true,
                'message' => Roro_Auth_I18n::t('login_success'),
                'user'    => [
                    'id'           => $customer->id,
                    'display_name' => $customer->name,
                    'email'        => $customer->email,
                ],
            ];
        }
        // Fall back to WordPress native authentication.  If found, also link
        // the user into the roro_customer table for future logins.
        $user = wp_authenticate($username, $password);
        if (is_wp_error($user)) {
            return new WP_Error('authentication_failed', Roro_Auth_I18n::t('error_login_failed'), ['status' => 401]);
        }
        // Ensure there is a customer record for this WordPress user.  The email
        // field is used as the unique identifier in the roro_customer table.
        $email = $user->user_email;
        $display = $user->display_name;
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE email = %s", $email));
        if (!$existing) {
            $wpdb->insert($table, [
                'wp_user_id'    => $user->ID,
                'name'          => $display ?: $user->user_login,
                'email'         => $email,
                'password_hash' => wp_hash_password($password),
                'created_at'    => current_time('mysql'),
                'updated_at'    => current_time('mysql'),
            ]);
        } else {
            // If record exists but no wp_user_id, set it
            if (!(int)$existing->wp_user_id) {
                $wpdb->update($table, ['wp_user_id' => $user->ID], ['id' => $existing->id]);
            }
        }
        // Successful WordPress login
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        return [
            'success' => true,
            'message' => Roro_Auth_I18n::t('login_success'),
            'user'    => [
                'id'           => $user->ID,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
            ],
        ];
    }

    /**
     * Handle user registration.
     *
     * Expects a JSON body containing `username`, `email` and `password`.  An
     * optional `display_name` can also be provided.  Basic validation is
     * performed on the email address and password length.  If the
     * registration succeeds the user is also logged in.  Duplicate
     * usernames or email addresses result in an error.
     *
     * @param WP_REST_Request $req
     * @return array|WP_Error
     */
    public function handle_register(WP_REST_Request $req) {
        $params = $req->get_json_params();
        if (!is_array($params)) {
            return new WP_Error('invalid_request', Roro_Auth_I18n::t('error_required'), ['status' => 400]);
        }
        $username = sanitize_user($params['username'] ?? '');
        $email    = sanitize_email($params['email'] ?? '');
        $password = (string) ($params['password'] ?? '');
        $display  = sanitize_text_field($params['display_name'] ?? '');
        // Validate required fields.
        if ($username === '' || $email === '' || $password === '') {
            return new WP_Error('missing_required', Roro_Auth_I18n::t('error_required'), ['status' => 400]);
        }
        if (!is_email($email)) {
            return new WP_Error('invalid_email', Roro_Auth_I18n::t('error_invalid_email'), ['status' => 400]);
        }
        if (strlen($password) < 8) {
            return new WP_Error('weak_password', Roro_Auth_I18n::t('error_password_policy'), ['status' => 400]);
        }
        global $wpdb;
        $table = $wpdb->prefix . 'roro_customer';
        // Check if customer already exists by email
        $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE email = %s", $email));
        if ($existing) {
            return new WP_Error('email_exists', Roro_Auth_I18n::t('error_email_exists'), ['status' => 409]);
        }
        // Create a WordPress user to leverage WP roles and capabilities.  Use the
        // provided username and email.  We still set the password here so
        // native login works, but the primary credential storage lives in
        // roro_customer.password_hash.
        if (username_exists($username) || email_exists($email)) {
            // If either username or email already exists in WP, generate a unique username.
            $username_wp = sanitize_user(current(explode('@', $email)));
            if (username_exists($username_wp)) {
                $username_wp .= '_' . wp_generate_password(4, false, false);
            }
        } else {
            $username_wp = $username;
        }
        $user_id = wp_insert_user([
            'user_login'   => $username_wp,
            'user_email'   => $email,
            'user_pass'    => $password,
            'display_name' => $display === '' ? $username : $display,
            'role'         => get_option('default_role', 'subscriber'),
        ]);
        if (is_wp_error($user_id)) {
            return new WP_Error('registration_failed', $user_id->get_error_message(), ['status' => 500]);
        }
        // Insert into roro_customer table with hashed password.  Link to the WordPress user.
        $wpdb->insert($table, [
            'wp_user_id'    => (int)$user_id,
            'name'          => $display === '' ? $username : $display,
            'email'         => $email,
            'password_hash' => wp_hash_password($password),
            'created_at'    => current_time('mysql'),
            'updated_at'    => current_time('mysql'),
        ]);
        // Automatically log in the new user
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        return [
            'success' => true,
            'message' => Roro_Auth_I18n::t('signup_success'),
            'user'    => [
                'id'           => (int)$wpdb->insert_id,
                'display_name' => $display === '' ? $username : $display,
                'email'        => $email,
            ],
        ];
    }
}