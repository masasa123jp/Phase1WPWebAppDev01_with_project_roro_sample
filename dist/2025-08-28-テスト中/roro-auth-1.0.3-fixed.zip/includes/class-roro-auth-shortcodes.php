<?php
/**
 * Shortcode handlers for the MECE RORO Auth plugin.
 *
 * Provides accessible forms for login, sign‑up and (placeholder) profile
 * editing.  Each shortcode enqueues the appropriate scripts and
 * styles and passes translation messages and API endpoints to the
 * front‑end via wp_localize_script.  The actual submit logic lives
 * inside the JavaScript files under assets/js.
 */
class Roro_Auth_Shortcodes {
    /**
     * Register shortcodes.  Called during plugin bootstrap.
     *
     * @return void
     */
    public static function register(): void {
        add_shortcode('roro_login_form', [__CLASS__, 'render_login_form']);
        add_shortcode('roro_signup_form', [__CLASS__, 'render_signup_form']);
        add_shortcode('roro_profile', [__CLASS__, 'render_profile']);
        // Backwards compatibility: support legacy shortcodes used in earlier drafts
        // of the RORO site.  Some pages may still reference `[sign_up_form]` or
        // `[signup_form]`.  Register these aliases so they point to our
        // official sign‑up form handler.  Without this alias the form would
        // render but no JavaScript or REST bindings would be loaded, causing
        // registration to silently fail.
        add_shortcode('sign_up_form', [__CLASS__, 'render_signup_form']);
        add_shortcode('signup_form', [__CLASS__, 'render_signup_form']);
        // Alias for the unified login/signup wrapper as well.
        add_shortcode('signup', [__CLASS__, 'render_signup']);
        // New unified login/sign‑up wrapper shortcode.  This handles
        // both login and sign‑up flows within a single shortcode.  If
        // a query parameter "signup" is present in the URL the sign‑up
        // form will be displayed.  Otherwise the login form is shown
        // along with a link to the sign‑up view.  See render_signup()
        // below for details.
        add_shortcode('roro_signup', [__CLASS__, 'render_signup']);
        // Provide a shorthand for the login page.  This mirrors the
        // behaviour of the unified wrapper but forces the initial
        // display to be the login form.  A link is included to switch
        // to the sign‑up view.  Use [roro_login] in page builders to
        // embed the login screen with a call‑to‑action for new users.
        add_shortcode('roro_login', [__CLASS__, 'render_login']);

        // Language switcher shortcode.  Outputs a simple set of links
        // allowing users to change the interface language.  When a
        // link is clicked a cookie is set and the user is redirected
        // to the same URL with a `roro_lang` query parameter.  See
        // render_lang_switch() for details.
        add_shortcode('roro_lang_switch', [__CLASS__, 'render_lang_switch']);
    }

    /**
     * Enqueue common assets for authentication forms.
     *
     * @return void
     */
    private static function enqueue_auth_assets(): void {
        // Style sheet shared by login and sign‑up forms.
        wp_enqueue_style(
            'roro-auth-auth-css',
            RORO_AUTH_URL . 'assets/css/auth.css',
            [],
            RORO_AUTH_VER
        );
    }

    /**
     * Render the login form.
     *
     * @return string
     */
    public static function render_login_form(): string {
        self::enqueue_auth_assets();
        // Register and enqueue login script.
        wp_register_script(
            'roro-auth-login',
            RORO_AUTH_URL . 'assets/js/login.js',
            [],
            RORO_AUTH_VER,
            true
        );
        wp_enqueue_script('roro-auth-login');
        // Localise translation messages and API endpoints to the script.
        wp_localize_script('roro-auth-login', 'RORO_AUTH', [
            'rest' => [
                'login' => rest_url('roro/v1/auth/login'),
            ],
            'i18n' => Roro_Auth_I18n::messages_for_js(),
        ]);
        ob_start();
        ?>
        <div class="roro-auth-form roro-auth-login" id="roro-login-form-wrapper">
            <h2><?php echo esc_html(Roro_Auth_I18n::t('login_title')); ?></h2>
            <form id="roro-login-form">
                <div class="roro-auth-field">
                    <!-- Use email address for authentication. We still name the field
                         "username" so the REST endpoint can accept either email or
                         username on the server side. -->
                    <label for="roro_login_email"><?php echo esc_html(Roro_Auth_I18n::t('email')); ?></label>
                    <input type="email" id="roro_login_email" name="username" required aria-required="true" />
                </div>
                <div class="roro-auth-field">
                    <label for="roro_login_password"><?php echo esc_html(Roro_Auth_I18n::t('password')); ?></label>
                    <input type="password" id="roro_login_password" name="password" required aria-required="true" />
                </div>
                <div class="roro-auth-error" role="alert" style="display:none;"></div>
                <button type="submit" class="roro-auth-submit"><?php echo esc_html(Roro_Auth_I18n::t('login_button')); ?></button>
            </form>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * Render the sign‑up form.
     *
     * @return string
     */
    public static function render_signup_form(): string {
        self::enqueue_auth_assets();
        wp_register_script(
            'roro-auth-signup',
            RORO_AUTH_URL . 'assets/js/signup.js',
            [],
            RORO_AUTH_VER,
            true
        );
        wp_enqueue_script('roro-auth-signup');
        wp_localize_script('roro-auth-signup', 'RORO_AUTH', [
            'rest' => [
                'register' => rest_url('roro/v1/auth/register'),
            ],
            'i18n' => Roro_Auth_I18n::messages_for_js(),
        ]);
        ob_start();
        ?>
        <div class="roro-auth-form roro-auth-signup" id="roro-signup-form-wrapper">
            <h2><?php echo esc_html(Roro_Auth_I18n::t('signup_title')); ?></h2>
            <form id="roro-signup-form">
                <div class="roro-auth-field">
                    <label for="roro_signup_username"><?php echo esc_html(Roro_Auth_I18n::t('username')); ?></label>
                    <input type="text" id="roro_signup_username" name="username" required aria-required="true" />
                </div>
                <div class="roro-auth-field">
                    <label for="roro_signup_email"><?php echo esc_html(Roro_Auth_I18n::t('email')); ?></label>
                    <input type="email" id="roro_signup_email" name="email" required aria-required="true" />
                </div>
                <div class="roro-auth-field">
                    <label for="roro_signup_password"><?php echo esc_html(Roro_Auth_I18n::t('password')); ?></label>
                    <input type="password" id="roro_signup_password" name="password" required aria-required="true" />
                </div>
                <div class="roro-auth-field">
                    <label for="roro_signup_display_name"><?php echo esc_html(Roro_Auth_I18n::t('display_name')); ?></label>
                    <input type="text" id="roro_signup_display_name" name="display_name" />
                </div>
                <div class="roro-auth-error" role="alert" style="display:none;"></div>
                <button type="submit" class="roro-auth-submit"><?php echo esc_html(Roro_Auth_I18n::t('signup_button')); ?></button>
            </form>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * Render the profile placeholder.  This can be expanded in a future
     * release to include an editable form and list of pets.  For now
     * it simply displays a message when the user is not logged in or
     * a generic placeholder when logged in.
     *
     * @return string
     */
    public static function render_profile(): string {
        if (!is_user_logged_in()) {
            return '<p>' . esc_html(Roro_Auth_I18n::t('signin_required')) . '</p>';
        }
        // Optionally enqueue profile assets here in the future.
        return '<p>' . esc_html(Roro_Auth_I18n::t('profile_placeholder')) . '</p>';
    }

    /**
     * Render a dedicated login view with a link to the sign‑up page.
     *
     * Unlike the unified render_signup() wrapper this method never
     * switches to the sign‑up form on its own; it always shows the
     * login form and adds a link to ?signup=1.  This makes it
     * appropriate for dedicated login pages where the default view
     * should be the login screen.
     *
     * @return string
     */
    public static function render_login(): string {
        // Enqueue the shared styles and the login script.
        self::enqueue_auth_assets();
        // Build the login form output.
        $form_html = self::render_login_form();
        // Build the sign‑up URL by appending the `signup` parameter.
        $signup_url = add_query_arg('signup', '1');
        // Fallback translations for the link text when no string is
        // defined in the language files.
        $no_account = method_exists('Roro_Auth_I18n', 't') ? Roro_Auth_I18n::t('no_account') : '';
        if (empty($no_account)) {
            $no_account = __('Don\'t have an account?', 'roro-auth');
        }
        $signup_here = method_exists('Roro_Auth_I18n', 't') ? Roro_Auth_I18n::t('signup_here') : '';
        if (empty($signup_here)) {
            $signup_here = __('Create one', 'roro-auth');
        }
        // Compose the wrapper markup.
        $html  = '<div class="roro-auth-wrapper">';
        $html .= $form_html;
        $html .= '<p class="roro-auth-switch">' . esc_html($no_account) . ' <a href="' . esc_url($signup_url) . '">' . esc_html($signup_here) . '</a></p>';
        $html .= '</div>';
        return $html;
    }

    /**
     * Render a language selection bar.  This shortcode outputs a
     * horizontal list of links for the supported languages (Japanese,
     * English, Chinese and Korean).  Clicking on a link stores the
     * selected language in a cookie (roro_lang) and then reloads the
     * current page with the appropriate `roro_lang` query parameter.
     * The currently active language is given a `current` class so
     * themes may highlight it.  Example usage: [roro_lang_switch].
     *
     * @return string HTML for the language switcher
     */
    public static function render_lang_switch(): string {
        // Determine current language from query param or locale
        $current = null;
        if (isset($_GET['roro_lang']) && is_string($_GET['roro_lang'])) {
            $cur = sanitize_key($_GET['roro_lang']);
            if (in_array($cur, ['ja','en','zh','ko'], true)) {
                $current = $cur;
            }
        }
        if (!$current) {
            // Fallback to locale detection
            $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
            $prefix = strtolower(substr($locale, 0, 2));
            $current = in_array($prefix, ['ja','en','zh','ko'], true) ? $prefix : 'en';
        }
        // Define labels for supported languages
        $langs = [
            'ja' => __('Japanese', 'roro-auth'),
            'en' => __('English', 'roro-auth'),
            'zh' => __('Chinese', 'roro-auth'),
            'ko' => __('Korean', 'roro-auth'),
        ];
        $links = [];
        foreach ($langs as $code => $label) {
            $url = add_query_arg('roro_lang', $code);
            $class = ($code === $current) ? ' current' : '';
            $links[] = '<a href="' . esc_url($url) . '" class="roro-lang-link' . $class . '" data-lang="' . esc_attr($code) . '">' . esc_html($label) . '</a>';
        }
        // Build the wrapper markup.  Inline JS sets the cookie and
        // redirects when a language link is clicked.  This avoids
        // relying on server‑side session state and works with static
        // caching plugins.
        $html  = '<div class="roro-lang-switch">' . implode(' | ', $links) . '</div>';
        $html .= '<script>(function(){document.querySelectorAll(".roro-lang-switch a").forEach(function(a){a.addEventListener("click",function(e){e.preventDefault();var lang=this.getAttribute("data-lang");document.cookie="roro_lang="+lang+"; path=/";window.location.href=this.href;});});})();</script>';
        return $html;
    }

    /**
     * Render a combined login/sign‑up wrapper.  When the current
     * request contains a `signup` query parameter the sign‑up form is
     * displayed along with a link back to the login form.  Otherwise
     * the login form is displayed along with a link to reveal the
     * sign‑up form.  This shortcode provides a single entry point for
     * authentication flows while avoiding duplicate content.  It is
     * recommended for page builders that want to present a sign‑in
     * screen with an option to create an account.
     *
     * Example usage: [roro_signup]
     *
     * @return string
     */
    public static function render_signup(): string {
        // Always enqueue shared CSS so the wrapper is styled even
        // before internal shortcodes run.
        self::enqueue_auth_assets();
        // Determine whether we should show the sign‑up form.  If the
        // `signup` query parameter exists, show the sign‑up form.
        $show_signup = isset($_GET['signup']);
        // Capture output using output buffering.  We compose the
        // appropriate form and link using the existing render_* methods.
        ob_start();
        echo '<div class="roro-auth-wrapper">';
        if ($show_signup) {
            // Render the sign‑up form; this method enqueues its own
            // JavaScript and translations.  After the form we provide a
            // link back to the login view.
            echo self::render_signup_form();
            // Build the URL without the `signup` parameter for login.
            $login_url = remove_query_arg('signup');
            // Fallback translations for the link text when no string is
            // defined in the language files.
            $have_account = method_exists('Roro_Auth_I18n', 't') ? Roro_Auth_I18n::t('have_account') : '';
            if (empty($have_account)) {
                $have_account = __('Already have an account?', 'roro-auth');
            }
            $login_here = method_exists('Roro_Auth_I18n', 't') ? Roro_Auth_I18n::t('login_here') : '';
            if (empty($login_here)) {
                $login_here = __('Sign in here', 'roro-auth');
            }
            echo '<p class="roro-auth-switch">' . esc_html($have_account) . ' <a href="' . esc_url($login_url) . '">' . esc_html($login_here) . '</a></p>';
        } else {
            // Render the login form; this method enqueues its own
            // JavaScript and translations.  After the form we provide a
            // link to the sign‑up view.
            echo self::render_login_form();
            // Build the URL with the `signup` query parameter appended.
            $signup_url = add_query_arg('signup', '1');
            // Fallback translations for the link text when no string is
            // defined in the language files.
            $no_account = method_exists('Roro_Auth_I18n', 't') ? Roro_Auth_I18n::t('no_account') : '';
            if (empty($no_account)) {
                $no_account = __('Don\'t have an account?', 'roro-auth');
            }
            $signup_here = method_exists('Roro_Auth_I18n', 't') ? Roro_Auth_I18n::t('signup_here') : '';
            if (empty($signup_here)) {
                $signup_here = __('Create one', 'roro-auth');
            }
            echo '<p class="roro-auth-switch">' . esc_html($no_account) . ' <a href="' . esc_url($signup_url) . '">' . esc_html($signup_here) . '</a></p>';
        }
        echo '</div>';
        return (string) ob_get_clean();
    }
}