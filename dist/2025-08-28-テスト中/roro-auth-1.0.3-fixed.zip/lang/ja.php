<?php
/**
 * Japanese translation messages for RORO Auth.
 */
$roro_auth_messages = array(
    'social_login_title' => 'ソーシャルログイン',
    'social_login_sub'   => 'Google または LINE でログインできます。',
    'login_title'        => 'ログイン',
    'signup_title'       => '新規ユーザー登録',
    'login_with_wp'      => 'WordPress の通常ログイン',
    'or'                 => 'または',
    'login_with_google'  => 'Googleでログイン',
    'login_with_line'    => 'LINEでログイン',
    'login_button'       => 'ログイン',
    'signup_button'      => '登録',
    'username'           => 'ユーザー名',
    'display_name'       => '表示名',
    'email'              => 'メールアドレス',
    'password'           => 'パスワード',
    'error_required'        => '必須項目が入力されていません。',
    'error_invalid_email'   => 'メールアドレスの形式が正しくありません。',
    'error_email_exists'    => 'このメールアドレスは既に登録されています。',
    'error_password_policy' => 'パスワードは8文字以上で入力してください。',
    // ログイン時のエラーメッセージをメールアドレスに合わせて修正します。
    'error_login_failed'    => 'メールアドレスまたはパスワードが正しくありません。',
    'error_username_exists' => 'このユーザー名は既に登録されています。',
    'login_success'      => 'ログインに成功しました。',
    'signup_success'     => '登録が完了しました。ログイン済みです。',
    'signup_failed'      => '登録に失敗しました。',
    'signin_required'       => 'ログインしてください。',
    'profile_placeholder'   => 'プロフィール編集機能はまだ利用できません。',
    'pets_saved'            => 'ペット情報を保存しました。',
    'invalid_nonce'         => '不正なノンスです。',
    'pet_not_found'         => '選択したペットが見つかりません。',
    'social_not_implemented'=> 'ソーシャルログインはまだ実装されていません。',

    // 新しいログイン・登録統合ショートコード用の追加キー。
    // アカウントの有無を尋ねるメッセージやリンクに利用します。
    'have_account' => 'すでにアカウントをお持ちですか？',
    'login_here'   => 'ログインはこちら',
    'no_account'   => 'アカウントをお持ちでない場合',
    'signup_here'  => '新規登録はこちら',
);