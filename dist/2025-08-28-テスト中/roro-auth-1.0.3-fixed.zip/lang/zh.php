<?php
/**
 * Simplified Chinese translation messages for RORO Auth.
 */
$roro_auth_messages = array(
    'social_login_title' => '社交登录',
    'social_login_sub'   => '使用 Google 或 LINE 登录。',
    'login_title'        => '登录',
    'signup_title'       => '创建帐户',
    'login_with_wp'      => '使用 WordPress 登录',
    'or'                 => '或',
    'login_with_google'  => '使用 Google 登录',
    'login_with_line'    => '使用 LINE 登录',
    'login_button'       => '登录',
    'signup_button'      => '注册',
    'username'           => '用户名',
    'display_name'       => '显示名称',
    'email'              => '电子邮件',
    'password'           => '密码',
    'error_required'        => '必填字段缺失。',
    'error_invalid_email'   => '邮箱格式无效。',
    'error_email_exists'    => '该邮箱已注册。',
    'error_password_policy' => '密码长度必须至少 8 位。',
    // 登录失败消息调整为电子邮件。
    'error_login_failed'    => '电子邮件或密码不正确。',
    'error_username_exists' => '该用户名已存在。',
    'login_success'         => '成功登录。',
    'signup_success'        => '注册成功，已自动登录。',
    'signup_failed'         => '注册失败。',
    'signin_required'       => '请先登录。',
    'profile_placeholder'   => '个人资料编辑功能尚未开放。',
    'pets_saved'            => '已保存宠物信息。',
    'invalid_nonce'         => '无效的 nonce。',
    'pet_not_found'         => '未找到选定的宠物。',
    'social_not_implemented'=> '社交登录尚未实现。',
);

// 用于新的综合登录/注册短代码的键。 当存在这些键时
// roro_signup 短代码将利用翻译，否则使用英文备用文字。
$roro_auth_messages['have_account'] = '已有账号？';
$roro_auth_messages['login_here']   = '登录';
$roro_auth_messages['no_account']   = '没有账号？';
$roro_auth_messages['signup_here']  = '注册账号';