<?php
/**
 * Korean translation messages for RORO Auth.
 */
$roro_auth_messages = array(
    'social_login_title' => '소셜 로그인',
    'social_login_sub'   => 'Google 또는 LINE으로 로그인하세요.',
    'login_title'        => '로그인',
    'signup_title'       => '계정 만들기',
    'login_with_wp'      => '워드프레스 로그인 사용',
    'or'                 => '또는',
    'login_with_google'  => 'Google로 계속하기',
    'login_with_line'    => 'LINE으로 계속하기',
    'login_button'       => '로그인',
    'signup_button'      => '회원가입',
    'username'           => '사용자 이름',
    'display_name'       => '표시 이름',
    'email'              => '이메일',
    'password'           => '비밀번호',
    'error_required'        => '필수 항목이 누락되었습니다.',
    'error_invalid_email'   => '잘못된 이메일 형식입니다.',
    'error_email_exists'    => '이미 등록된 이메일입니다.',
    'error_password_policy' => '비밀번호는 최소 8자 이상이어야 합니다.',
    // 로그인 실패 메시지를 이메일을 기준으로 수정합니다.
    'error_login_failed'    => '이메일 또는 비밀번호가 올바르지 않습니다.',
    'error_username_exists' => '이미 존재하는 사용자 이름입니다.',
    'login_success'         => '성공적으로 로그인했습니다.',
    'signup_success'        => '회원가입이 완료되었습니다. 자동으로 로그인됩니다.',
    'signup_failed'         => '회원가입에 실패했습니다.',
    'signin_required'       => '로그인 해주세요.',
    'profile_placeholder'   => '프로필 편집 기능은 아직 제공되지 않습니다.',
    'pets_saved'            => '반려동물 정보를 저장했습니다.',
    'invalid_nonce'         => '잘못된 nonce입니다.',
    'pet_not_found'         => '선택한 반려동물을 찾을 수 없습니다.',
    'social_not_implemented'=> '소셜 로그인이 아직 구현되지 않았습니다.',
);

// 통합 로그인/회원가입 쇼트코드에 사용되는 새 키입니다.
$roro_auth_messages['have_account'] = '이미 계정이 있으신가요？';
$roro_auth_messages['login_here']   = '로그인은 여기';
$roro_auth_messages['no_account']   = '계정이 없으신가요？';
$roro_auth_messages['signup_here']  = '회원가입하기';