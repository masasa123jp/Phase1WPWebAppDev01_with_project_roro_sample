<?php
/**
 * RORO Admin Tools
 * 管理画面にツールを追加し、簡易メンテナンス機能を提供。
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

if (class_exists('RORO_Admin_Tools', false)) return;

final class RORO_Admin_Tools {

    // ユニークなメニュースラッグ。「-page」を付けるとフロント側 URL に書き換えられる場合があるため避ける。
    private const PAGE_SLUG    = 'roro-core-tools';
    private const NONCE_ACTION = 'roro_tools_action';
    private const NONCE_FIELD  = '_roro_tools_nonce';

    public static function init(): void {
        add_action('admin_menu', [self::class, 'register_menu']);
        add_action('admin_post_roro_tools_action', [self::class, 'handle_post']);
    }

    public static function register_menu(): void {
        add_submenu_page(
            'roro-core-wp',
            __('RORO Tools', 'roro-core-wp'),
            __('Tools', 'roro-core-wp'),
            'manage_options',
            self::PAGE_SLUG,
            [self::class, 'render_page']
        );
    }

    public static function render_page(): void {
        if (!current_user_can('manage_options')) wp_die(esc_html__('Insufficient permissions.', 'roro-core-wp'));

        $updated = isset($_GET['updated']) ? sanitize_key((string) $_GET['updated']) : '';
        $php_ver  = PHP_VERSION;
        $wp_ver   = get_bloginfo('version', 'display');
        $plug_ver = defined('RORO_CORE_WP_VER') ? RORO_CORE_WP_VER : 'n/a';
        $opt_key  = class_exists('RORO_Admin_Settings') ? RORO_Admin_Settings::OPTION : 'roro_core_settings';
        $opt_val  = get_option($opt_key, []);

        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('RORO Tools', 'roro-core-wp'); ?></h1>

            <?php if ($updated): ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php echo esc_html(ucfirst($updated)) . ' ' . esc_html__('completed.', 'roro-core-wp'); ?></p>
                </div>
            <?php endif; ?>

            <h2><?php echo esc_html__('Environment', 'roro-core-wp'); ?></h2>
            <table class="widefat striped" style="max-width:780px">
                <tbody>
                <tr><th><?php echo esc_html__('PHP Version', 'roro-core-wp'); ?></th><td><?php echo esc_html($php_ver); ?></td></tr>
                <tr><th><?php echo esc_html__('WordPress Version', 'roro-core-wp'); ?></th><td><?php echo esc_html($wp_ver); ?></td></tr>
                <tr><th><?php echo esc_html__('Plugin Version', 'roro-core-wp'); ?></th><td><?php echo esc_html($plug_ver); ?></td></tr>
                <tr><th><?php echo esc_html__('Options Key', 'roro-core-wp'); ?></th><td><?php echo esc_html($opt_key); ?></td></tr>
                </tbody>
            </table>

            <h2 style="margin-top:24px"><?php echo esc_html__('Maintenance', 'roro-core-wp'); ?></h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD); ?>
                <input type="hidden" name="action" value="roro_tools_action" />
                <p>
                    <button class="button button-secondary" name="op" value="flush">
                        <?php echo esc_html__('Flush rewrite rules', 'roro-core-wp'); ?>
                    </button>
                </p>
                <p>
                    <button class="button button-secondary" name="op" value="reset_options" onclick="return confirm('<?php echo esc_attr__('Reset options to defaults?', 'roro-core-wp'); ?>');">
                        <?php echo esc_html__('Reset plugin options', 'roro-core-wp'); ?>
                    </button>
                </p>
                <p>
                    <button class="button button-secondary" name="op" value="clear_transients" onclick="return confirm('<?php echo esc_attr__('Delete all transients?', 'roro-core-wp'); ?>');">
                        <?php echo esc_html__('Clear all transients', 'roro-core-wp'); ?>
                    </button>
                </p>
            </form>

            <h2 style="margin-top:24px"><?php echo esc_html__('Current Options (excerpt)', 'roro-core-wp'); ?></h2>
            <pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;overflow:auto;max-width:780px;max-height:300px;"><?php
                echo esc_html(print_r(is_array($opt_val) ? $opt_val : (array) $opt_val, true));
            ?></pre>
        </div>
        <?php
    }

    public static function handle_post(): void {
        if (!current_user_can('manage_options')) wp_die(esc_html__('Insufficient permissions.', 'roro-core-wp'));
        check_admin_referer(self::NONCE_ACTION, self::NONCE_FIELD);

        $op = isset($_POST['op']) ? (string) $_POST['op'] : '';
        // 常に admin.php?page=slug の形式にリダイレクトすることで、フロントへの書き換えを防止します。
        $redirect = admin_url('admin.php?page=' . self::PAGE_SLUG);

        switch ($op) {
            case 'flush':
                flush_rewrite_rules(false);
                wp_safe_redirect(add_query_arg('updated', 'flush', $redirect)); exit;

            case 'reset_options':
                $opt_key  = class_exists('RORO_Admin_Settings') ? RORO_Admin_Settings::OPTION : 'roro_core_settings';
                $defaults = class_exists('RORO_Admin_Settings') ? RORO_Admin_Settings::defaults() : [];
                if (get_option($opt_key, null) === null) add_option($opt_key, $defaults);
                else update_option($opt_key, $defaults);
                wp_safe_redirect(add_query_arg('updated', 'reset', $redirect)); exit;

            case 'clear_transients':
                global $wpdb;
                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
                        $wpdb->esc_like('_transient_') . '%',
                        $wpdb->esc_like('_site_transient_') . '%'
                    )
                );
                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
                        $wpdb->esc_like('_transient_timeout_') . '%',
                        $wpdb->esc_like('_site_transient_timeout_') . '%'
                    )
                );
                wp_safe_redirect(add_query_arg('updated', 'clear_trans', $redirect)); exit;

            default:
                wp_safe_redirect($redirect); exit;
        }
    }
}
