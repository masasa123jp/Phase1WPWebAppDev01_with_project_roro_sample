<?php
/**
 * RORO Integrated DB
 * - 管理画面「DB Setup」サブメニューを追加
 * - DDL/SEED SQL を安全に実行
 * - wp_ → $wpdb->prefix に置換
 * - CREATE TABLE は dbDelta() を利用
 * - 文字列分割・正規化ユーティリティを完備
 */
declare(strict_types=1);

namespace {
defined('ABSPATH') || exit;

final class RORO_DB {
    private const NONCE_ACTION = 'roro_db_setup';
    private const NONCE_NAME   = '_roro_db_nonce';
    private const PAGE_SLUG    = 'roro-db-setup';

    public static function init(): void {
        if (!is_admin()) return;
        add_action('admin_menu', [self::class, 'add_menu']);
        add_action('admin_post_roro_db_ddl',  [self::class, 'handle_ddl']);
        add_action('admin_post_roro_db_seed', [self::class, 'handle_seed']);
    }

    /** 管理メニュー追加 */
    public static function add_menu(): void {
        add_submenu_page(
            'roro-core-wp',
            'RORO DB Setup',
            'DB Setup',
            'manage_options',
            self::PAGE_SLUG,
            [self::class, 'render_page'],
        );
    }

    /** ページ描画 */
    public static function render_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission.');
        }

        echo '<div class="wrap"><h1>RORO DB Setup</h1>';
        self::render_status_box();

        echo '<h2>Run DDL (dbDelta for CREATE TABLE)</h2>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);
        echo '<input type="hidden" name="action" value="roro_db_ddl" />';
        echo '<p><label>SQL file(s) directory (schema): <input type="text" name="dir" value="wp-content/uploads/roro/schema" size="60"></label></p>';
        submit_button('Run DDL');
        echo '</form>';

        echo '<hr/>';

        echo '<h2>Run SEED (INSERT etc.)</h2>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);
        echo '<input type="hidden" name="action" value="roro_db_seed" />';
        echo '<p><label>SQL file(s) directory (seed): <input type="text" name="dir" value="wp-content/uploads/roro/seed" size="60"></label></p>';
        submit_button('Run SEED');
        echo '</form>';

        echo '</div>';
    }

    /** ステータス表示 */
    private static function render_status_box(): void {
        global $wpdb;
        echo '<div class="notice notice-info"><p>';
        echo 'Table prefix: <code>'.esc_html($wpdb->prefix).'</code><br/>';
        echo 'Charset/Collate: <code>'.esc_html($wpdb->charset.' / '.$wpdb->collate).'</code>';
        echo '</p></div>';
    }

    /** DDL 実行 */
    private static function run_schema(string $dir): void {
        $files = self::collect_sql_files($dir);
        if (!$files) {
            add_action('admin_notices', static function () use ($dir) {
                echo '<div class="notice notice-error"><p>No SQL files in '.esc_html($dir).'</p></div>';
            });
            return;
        }
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        foreach ($files as $path) {
            $sql = file_get_contents($path);
            if ($sql === false) continue;
            $sql = self::normalize_sql($sql);
            $sql = self::apply_prefix($sql);
            $stmts = self::split_sql($sql);
            foreach ($stmts as $stmt) {
                $trim = trim($stmt);
                if ($trim === '') continue;
                if (stripos($trim, 'CREATE TABLE') === 0) {
                    dbDelta($trim);
                } else {
                    $wpdb->query($trim);
                }
            }
        }
    }

    /** SEED 実行 */
    private static function run_seed(string $dir): void {
        $files = self::collect_sql_files($dir);
        if (!$files) {
            add_action('admin_notices', static function () use ($dir) {
                echo '<div class="notice notice-error"><p>No SQL files in '.esc_html($dir).'</p></div>';
            });
            return;
        }
        global $wpdb;
        foreach ($files as $path) {
            $sql = file_get_contents($path);
            if ($sql === false) continue;
            $sql = self::normalize_sql($sql);
            $sql = self::apply_prefix($sql);
            $stmts = self::split_sql($sql);
            foreach ($stmts as $stmt) {
                $trim = trim($stmt);
                if ($trim === '') continue;
                $wpdb->query($trim);
            }
        }
    }

    /** DDL ハンドラ */
    public static function handle_ddl(): void {
        if (!current_user_can('manage_options')) wp_die('No permission.');
        check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);

        $dir = sanitize_text_field($_POST['dir'] ?? '');
        if (!$dir) wp_die('Missing directory.');
        self::run_schema($dir);

        wp_safe_redirect(add_query_arg([
            'page' => self::PAGE_SLUG,
            'ok'   => 'ddl'
        ], admin_url('admin.php')));
        exit;
    }

    /** SEED ハンドラ */
    public static function handle_seed(): void {
        if (!current_user_can('manage_options')) wp_die('No permission.');
        check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);

        $dir = sanitize_text_field($_POST['dir'] ?? '');
        if (!$dir) wp_die('Missing directory.');
        self::run_seed($dir);

        wp_safe_redirect(add_query_arg([
            'page' => self::PAGE_SLUG,
            'ok'   => 'seed'
        ], admin_url('admin.php')));
        exit;
    }

    /** ▼▼▼ ここからユーティリティ群 ▼▼▼ */

    /** ディレクトリから *.sql を収集 */
    private static function collect_sql_files(string $dir): array {
        $dir = ABSPATH . trim($dir, '/');
        if (!is_dir($dir)) return [];
        $files = glob($dir.'/*.sql') ?: [];
        natsort($files);
        return array_values($files);
    }

    /** BOM/改行を正規化 */
    private static function normalize_sql(string $sql): string {
        if (substr($sql,0,3)==="\xEF\xBB\xBF") $sql = substr($sql,3);
        return str_replace("\r\n","\n",$sql);
    }

    /** wp_ → prefix 置換 */
    private static function apply_prefix(string $sql): string {
        global $wpdb;
        if ($wpdb->prefix === 'wp_') return $sql;
        $patterns = ['/`wp_([A-Za-z0-9_]+)`/i','/\bwp_([A-Za-z0-9_]+)\b/i'];
        $repl     = ['`'.$wpdb->prefix.'$1`',$wpdb->prefix.'$1'];
        return preg_replace($patterns,$repl,$sql);
    }

    /** SQL をセミコロンで分割 */
    private static function split_sql(string $sql): array {
        $out=[]; $buf=''; $inStr=false; $quote='';
        $len=strlen($sql);
        for($i=0;$i<$len;$i++){
            $ch=$sql[$i];
            if($inStr){
                if($ch===$quote && $sql[$i-1]!=='\\') $inStr=false;
                $buf.=$ch; continue;
            }
            if($ch==="'"||$ch==='"'||$ch==='`'){ $inStr=true; $quote=$ch; $buf.=$ch; continue; }
            if($ch===';'){ $out[]=$buf; $buf=''; continue; }
            $buf.=$ch;
        }
        if(trim($buf)!=='') $out[]=$buf;
        return $out;
    }
}
}

namespace Roro {
    /**
     * Roro\Roro_DB: お気に入り追加/取得/削除のDB操作。
     * こちらは別責務なので本修正版では変更なし。
     */
}
