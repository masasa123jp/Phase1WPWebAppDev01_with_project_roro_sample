/* global jQuery */
(function($){
  'use strict';
  // ここでは秘密情報の表示切替などを行いたい場合に拡張
  // 現状はプレースホルダ。将来: 目アイコンで表示/非表示切り替え等
})(jQuery);
