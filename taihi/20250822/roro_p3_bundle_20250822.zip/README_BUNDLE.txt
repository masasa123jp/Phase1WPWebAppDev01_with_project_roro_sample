RORO Integrated Bundle (2025-08-22)
-----------------------------------
- roro-core-wp-1.6.0-rc2-with-ddl-seed.zip : Core plugin with DDL_20250822 + seeds
- roro_p3_chatbot.zip                      : P3 RC (Dify streaming + dashboard + UI)
- roro_assets_samples.zip                  : (Optional) sample images/SQL
- roro_integrations_specs.zip              : Chatbot→Map 連携 JSON スキーマ/例

手順:
  1) roro-core-wp をアップロード→有効化
  2) ツール → Roro DB Importer → schema/seed 実行
  3) roro_p3_chatbot をアップロード→有効化 → ショートコードを配置
  4) 連携JSONは spot_cards.schema.json を参照し、チャット応答に埋め込む
