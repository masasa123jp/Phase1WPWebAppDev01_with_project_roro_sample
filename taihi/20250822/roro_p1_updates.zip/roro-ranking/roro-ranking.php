<?php
/**
 * Plugin Name:       Roro Ranking
 * Description:       RORO ランキング（お気に入り集計・スコアリング・REST/ショートコード）。roro-favorites 等のテーブルを自動検出し、タイプ別ランキングを生成します。
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Project RORO
 * License:           GPL-2.0-or-later
 * Text Domain:       roro-ranking
 * Domain Path:       /languages
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_RANKING_VERSION', '1.0.0');
define('RORO_RANKING_PATH', plugin_dir_path(__FILE__));
define('RORO_RANKING_URL',  plugin_dir_url(__FILE__));
define('RORO_RANKING_BASENAME', plugin_basename(__FILE__));

// i18n
add_action('plugins_loaded', function () {
    load_plugin_textdomain('roro-ranking', false, dirname(RORO_RANKING_BASENAME) . '/languages');
});

require_once RORO_RANKING_PATH . 'includes/class-roro-ranking-admin.php';
require_once RORO_RANKING_PATH . 'includes/class-roro-ranking-service.php';
require_once RORO_RANKING_PATH . 'includes/class-roro-ranking-rest.php';
require_once RORO_RANKING_PATH . 'includes/class-roro-ranking-render.php';

register_activation_hook(__FILE__, function () {
    Roro_Ranking_Service::create_tables();
    if (!wp_next_scheduled('roro_ranking_refresh_event')) {
        wp_schedule_event(time() + 60, 'hourly', 'roro_ranking_refresh_event');
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('roro_ranking_refresh_event');
});

add_action('roro_ranking_refresh_event', function () {
    Roro_Ranking_Service::refresh_all();
});

// Admin page
add_action('admin_menu', ['Roro_Ranking_Admin', 'add_settings_page']);
add_action('admin_init', ['Roro_Ranking_Admin', 'register_settings']);

// REST
add_action('rest_api_init', ['Roro_Ranking_REST', 'register_routes']);

// Shortcode
add_shortcode('roro_ranking', ['Roro_Ranking_Render', 'shortcode']);
