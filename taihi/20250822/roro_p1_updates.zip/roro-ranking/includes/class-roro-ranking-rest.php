<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Ranking_REST {

    public static function register_routes() {
        register_rest_route('roro/v1', '/ranking', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_ranking'],
            'permission_callback' => '__return_true',
            'args' => [
                'type' => ['required'=>true],
                'period' => ['required'=>false],
                'limit' => ['required'=>false],
                'offset' => ['required'=>false],
            ],
        ]);
    }

    public static function get_ranking($request) {
        $type = sanitize_key((string)$request->get_param('type'));
        $period = (string)($request->get_param('period') ?: 'recent');
        $limit = (int)($request->get_param('limit') ?: 10);
        $offset = (int)($request->get_param('offset') ?: 0);

        $rows = Roro_Ranking_Service::get_top($type, $period, $limit, $offset);
        $out = [];
        foreach ($rows as $r) {
            $info = Roro_Ranking_Service::resolve_label_url($type, (int)$r['item_id']);
            $out[] = [
                'item_id' => (int)$r['item_id'],
                'label'   => $info['label'],
                'url'     => $info['url'],
                'cnt'     => (int)$r['cnt'],
                'score'   => (float)$r['score'],
                'updated_at' => (string)$r['updated_at'],
            ];
        }
        return rest_ensure_response(['type'=>$type, 'period'=>$period, 'items'=>$out]);
    }
}
