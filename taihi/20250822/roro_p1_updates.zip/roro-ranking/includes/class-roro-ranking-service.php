<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Ranking_Service {

    /** Create ranking table */
    public static function create_tables(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'roro_ranking';
        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            item_type VARCHAR(32) NOT NULL,
            item_id BIGINT UNSIGNED NOT NULL,
            period VARCHAR(16) NOT NULL DEFAULT 'all',
            cnt BIGINT UNSIGNED NOT NULL DEFAULT 0,
            score DOUBLE NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY uniq_type (item_type, item_id, period),
            KEY idx_score (item_type, period, score)
        ) {$charset_collate};";
        dbDelta($sql);
    }

    /** Check if table exists */
    public static function table_exists(string $table): bool {
        global $wpdb;
        $like = $wpdb->esc_like($table);
        $found = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s", $table));
        return (bool)$found;
    }

    /** Get column names for a table */
    public static function get_columns(string $table): array {
        global $wpdb;
        $cols = $wpdb->get_col("DESC {$table}", 0); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return is_array($cols) ? $cols : [];
    }

    /** Detect known favorites tables and normalize their schema */
    public static function detect_favorite_tables(): array {
        global $wpdb;
        $candidates = [
            $wpdb->prefix . 'roro_favorite',
            $wpdb->prefix . 'roro_favorites',
            $wpdb->prefix . 'roro_map_favorite',
        ];
        $out = [];
        foreach ($candidates as $t) {
            if (self::table_exists($t)) {
                $cols = self::get_columns($t);
                $out[] = [
                    'table'   => $t,
                    'columns' => $cols,
                ];
            }
        }
        return $out;
    }

    /** Refresh all rankings (periods: all / recent) */
    public static function refresh_all(): void {
        $enable_fav = (bool) get_option('roro_ranking_enable_favorites', true);
        $recent_days = (int) get_option('roro_ranking_recent_days', 7);
        $recent_boost = (float) get_option('roro_ranking_recent_boost', 1.5);
        $types = get_option('roro_ranking_types', ['spot'=>'Spots','event'=>'Events','article'=>'Articles']);

        $sources = [];
        if ($enable_fav) {
            $sources = array_merge($sources, self::build_favorites_sources());
        }

        // Aggregate counts by type/id
        $agg_all = [];
        $agg_recent = [];
        foreach ($sources as $src) {
            $rows = self::query_counts($src['table'], $src['type_column'], $src['id_column'], $src['created_column'], null);
            foreach ($rows as $r) {
                $key = $r['item_type'] . ':' . $r['item_id'];
                $agg_all[$key] = ($agg_all[$key] ?? 0) + (int)$r['cnt'];
            }
            // Recent
            $rows2 = self::query_counts($src['table'], $src['type_column'], $src['id_column'], $src['created_column'], $recent_days);
            foreach ($rows2 as $r) {
                $key = $r['item_type'] . ':' . $r['item_id'];
                $agg_recent[$key] = ($agg_recent[$key] ?? 0) + (int)$r['cnt'];
            }
        }

        // Upsert into ranking table
        global $wpdb;
        $table = $wpdb->prefix . 'roro_ranking';
        $now = current_time('mysql', 1);

        // helper upsert
        $upsert = function($type, $id, $period, $cnt, $score) use ($wpdb, $table, $now) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE item_type=%s AND item_id=%d AND period=%s", $type, $id, $period));
            if ($exists) {
                $wpdb->update($table, ['cnt'=>$cnt, 'score'=>$score, 'updated_at'=>$now], ['id'=>$exists]);
            } else {
                $wpdb->insert($table, ['item_type'=>$type, 'item_id'=>$id, 'period'=>$period, 'cnt'=>$cnt, 'score'=>$score, 'updated_at'=>$now]);
            }
        };

        // "all" period
        foreach ($agg_all as $key => $cnt) {
            list($type, $id) = explode(':', $key, 2);
            $score = (float)$cnt;
            $upsert($type, (int)$id, 'all', (int)$cnt, $score);
        }
        // "recent" period (recent_days)
        foreach ($agg_recent as $key => $cnt) {
            list($type, $id) = explode(':', $key, 2);
            $score = (float)$cnt * max(0.1, $recent_boost);
            $upsert($type, (int)$id, 'recent', (int)$cnt, $score);
        }

        update_option('roro_ranking_last_refreshed', $now);
    }

    /** Build normalized sources from detected favorites tables */
    private static function build_favorites_sources(): array {
        global $wpdb;
        $detected = self::detect_favorite_tables();
        $sources = [];
        foreach ($detected as $d) {
            $t = $d['table'];
            $cols = $d['columns'];

            // pattern A: item_type + item_id + created_at
            if (in_array('item_type', $cols, true) && in_array('item_id', $cols, true)) {
                $sources[] = [
                    'table' => $t,
                    'type_column' => 'item_type',
                    'id_column' => 'item_id',
                    'created_column' => in_array('created_at', $cols, true) ? 'created_at' : (in_array('created', $cols, true) ? 'created' : null),
                ];
                continue;
            }
            // pattern B: roro_map_favorite with spot_id / event_id
            $has_spot = in_array('spot_id', $cols, true);
            $has_event = in_array('event_id', $cols, true);
            if ($has_spot || $has_event) {
                $created = in_array('created_at', $cols, true) ? 'created_at' : (in_array('created', $cols, true) ? 'created' : null);
                if ($has_spot) $sources[] = ['table'=>$t, 'type_column'=>null, 'type_value'=>'spot', 'id_column'=>'spot_id', 'created_column'=>$created];
                if ($has_event) $sources[] = ['table'=>$t, 'type_column'=>null, 'type_value'=>'event', 'id_column'=>'event_id', 'created_column'=>$created];
                continue;
            }
        }
        return $sources;
    }

    /** Run count query against a normalized source */
    private static function query_counts(string $table, ?string $type_col, string $id_col, ?string $created_col, ?int $recent_days): array {
        global $wpdb;
        $where = 'WHERE 1=1';
        $params = [];
        if ($recent_days && $created_col) {
            $where .= " AND {$created_col} >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)";
            $params[] = $recent_days;
        }
        if ($type_col) {
            $sql = "SELECT {$type_col} AS item_type, {$id_col} AS item_id, COUNT(*) AS cnt FROM {$table} {$where} GROUP BY {$type_col}, {$id_col}";
            $q = $params ? $wpdb->prepare($sql, ...$params) : $sql;
            $rows = $wpdb->get_results($q, ARRAY_A);
        } else {
            // when type is fixed (pattern B)
            // We need to know type_value; we will infer from id_col name
            $type_value = (strpos($id_col, 'spot') !== false) ? 'spot' : ((strpos($id_col, 'event') !== false) ? 'event' : 'item');
            $sql = "SELECT %s AS item_type, {$id_col} AS item_id, COUNT(*) AS cnt FROM {$table} {$where} GROUP BY {$id_col}";
            array_unshift($params, $type_value);
            $q = $wpdb->prepare($sql, ...$params);
            $rows = $wpdb->get_results($q, ARRAY_A);
        }
        if (!is_array($rows)) return [];
        // sanitize output
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'item_type' => sanitize_key($r['item_type']),
                'item_id'   => (int)$r['item_id'],
                'cnt'       => (int)$r['cnt'],
            ];
        }
        return $out;
    }

    /** Fetch top items from ranking table */
    public static function get_top(string $type, string $period='recent', int $limit=10, int $offset=0): array {
        global $wpdb;
        $table = $wpdb->prefix . 'roro_ranking';
        $type = sanitize_key($type);
        $period = in_array($period, ['all','recent'], true) ? $period : 'recent';
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        $sql = $wpdb->prepare("SELECT item_id, cnt, score, updated_at FROM {$table} WHERE item_type=%s AND period=%s ORDER BY score DESC, cnt DESC LIMIT %d OFFSET %d", $type, $period, $limit, $offset);
        $rows = $wpdb->get_results($sql, ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    /** Resolve label & permalink for a type/id if possible */
    public static function resolve_label_url(string $type, int $id): array {
        global $wpdb;
        $label = sprintf('%s #%d', ucfirst($type), $id);
        $url = '';
        // Try known master tables
        $candidates = [];
        if ($type === 'spot') {
            $candidates = [
                $wpdb->prefix . 'roro_travel_spot_master',
                $wpdb->prefix . 'travel_spot_master',
            ];
        } elseif ($type === 'event') {
            $candidates = [
                $wpdb->prefix . 'roro_events_master',
                $wpdb->prefix . 'events_master',
            ];
        } elseif ($type === 'article') {
            // Could be WP posts (custom post type)
            $post = get_post($id);
            if ($post) {
                $label = get_the_title($post);
                $url = get_permalink($post);
                return ['label'=>$label, 'url'=>$url];
            }
        }
        foreach ($candidates as $t) {
            if (!self::table_exists($t)) continue;
            $cols = self::get_columns($t);
            $name_col = null;
            foreach (['name','title','spot_name','event_name'] as $nc) {
                if (in_array($nc, $cols, true)) { $name_col = $nc; break; }
            }
            if (!$name_col) continue;
            $row = $wpdb->get_row($wpdb->prepare("SELECT {$name_col} AS nm FROM {$t} WHERE id=%d", $id), ARRAY_A);
            if ($row && !empty($row['nm'])) {
                $label = (string)$row['nm'];
                break;
            }
        }
        return ['label'=>$label, 'url'=>$url];
    }
}
