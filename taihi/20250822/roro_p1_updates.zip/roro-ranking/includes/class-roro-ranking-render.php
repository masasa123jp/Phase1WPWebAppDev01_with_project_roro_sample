<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Ranking_Render {

    public static function shortcode($atts) {
        $atts = shortcode_atts([
            'type' => 'spot',
            'period' => 'recent',
            'limit' => 10,
            'offset' => 0,
            'show_count' => '1',
        ], $atts, 'roro_ranking');

        $type = sanitize_key($atts['type']);
        $period = in_array($atts['period'], ['recent','all'], true) ? $atts['period'] : 'recent';
        $limit = max(1, min(50, (int)$atts['limit']));
        $offset = max(0, (int)$atts['offset']);
        $show_count = $atts['show_count'] === '1';

        $rows = Roro_Ranking_Service::get_top($type, $period, $limit, $offset);
        if (!$rows) return '<p>' . esc_html__('No data.', 'roro-ranking') . '</p>';

        ob_start();
        echo '<ul class="roro-ranking roro-ranking--' . esc_attr($type) . '">';
        foreach ($rows as $r) {
            $info = Roro_Ranking_Service::resolve_label_url($type, (int)$r['item_id']);
            $label = esc_html($info['label']);
            $url = $info['url'] ? esc_url($info['url']) : '';
            echo '<li>';
            if ($url) {
                echo '<a href="' . $url . '">' . $label . '</a>';
            } else {
                echo $label;
            }
            if ($show_count) {
                echo ' <small>(' . (int)$r['cnt'] . ')</small>';
            }
            echo '</li>';
        }
        echo '</ul>';
        return ob_get_clean();
    }
}
