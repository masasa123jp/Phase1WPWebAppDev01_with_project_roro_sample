<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Ranking_Admin {

    public static function add_settings_page() {
        add_options_page(
            __('Roro Ranking', 'roro-ranking'),
            __('Roro Ranking', 'roro-ranking'),
            'manage_options',
            'roro-ranking',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {

        register_setting('roro_ranking', 'roro_ranking_enable_favorites', [
            'type' => 'boolean',
            'sanitize_callback' => fn($v) => (bool)$v,
            'default' => true,
        ]);

        register_setting('roro_ranking', 'roro_ranking_recent_days', [
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 7,
        ]);

        register_setting('roro_ranking', 'roro_ranking_recent_boost', [
            'type' => 'number',
            'sanitize_callback' => fn($v) => is_numeric($v) ? (float)$v : 1.0,
            'default' => 1.5,
        ]);

        register_setting('roro_ranking', 'roro_ranking_types', [
            'type' => 'array',
            'sanitize_callback' => function($v){
                if (!is_array($v)) return [];
                $out = [];
                foreach ($v as $k => $label) {
                    $k = sanitize_key($k);
                    $out[$k] = sanitize_text_field($label);
                }
                return $out;
            },
            'default' => [
                'spot'  => 'Spots',
                'event' => 'Events',
                'article' => 'Articles',
            ],
        ]);
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission', 'roro-ranking'));
        }
        $tables = Roro_Ranking_Service::detect_favorite_tables();
        $last = get_option('roro_ranking_last_refreshed', '');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Roro Ranking Settings', 'roro-ranking'); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields('roro_ranking'); ?>
                <h2><?php echo esc_html__('General', 'roro-ranking'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Use Favorites as Source', 'roro-ranking'); ?></th>
                        <td><label><input type="checkbox" name="roro_ranking_enable_favorites" value="1" <?php checked(get_option('roro_ranking_enable_favorites', true)); ?>> <?php echo esc_html__('Aggregate counts from detected favorite tables.', 'roro-ranking'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Recent Period (days)', 'roro-ranking'); ?></th>
                        <td><input type="number" name="roro_ranking_recent_days" value="<?php echo esc_attr(get_option('roro_ranking_recent_days', 7)); ?>" min="1" max="90"></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Recent Boost Weight', 'roro-ranking'); ?></th>
                        <td><input type="number" step="0.1" name="roro_ranking_recent_boost" value="<?php echo esc_attr(get_option('roro_ranking_recent_boost', 1.5)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Types', 'roro-ranking'); ?></th>
                        <td>
                            <?php
                            $types = get_option('roro_ranking_types', []);
                            foreach ($types as $k => $label) {
                                printf('<p><code>%s</code> — %s</p>', esc_html($k), esc_html($label));
                            }
                            ?>
                            <p class="description"><?php echo esc_html__('Types are used to group items (e.g., spot, event, article).', 'roro-ranking'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Detected Favorite Tables', 'roro-ranking'); ?></th>
                        <td>
                            <?php if ($tables): ?>
                                <ul>
                                    <?php foreach ($tables as $t): ?>
                                        <li><code><?php echo esc_html($t['table']); ?></code> — cols: <?php echo esc_html(implode(', ', $t['columns'])); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <em><?php echo esc_html__('No candidate tables detected.', 'roro-ranking'); ?></em>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <hr>
            <h2><?php echo esc_html__('Maintenance', 'roro-ranking'); ?></h2>
            <p><?php echo esc_html__('Last refreshed:', 'roro-ranking'); ?> <code><?php echo esc_html($last ? $last : '-'); ?></code></p>
            <form method="post">
                <?php wp_nonce_field('roro_ranking_refresh'); ?>
                <input type="hidden" name="roro_ranking_action" value="refresh">
                <?php submit_button(__('Rebuild Ranking Now', 'roro-ranking'), 'secondary'); ?>
            </form>
            <?php
            if (isset($_POST['roro_ranking_action']) && $_POST['roro_ranking_action'] === 'refresh' && check_admin_referer('roro_ranking_refresh')) {
                Roro_Ranking_Service::refresh_all();
                echo '<div class="updated notice"><p>' . esc_html__('Ranking rebuilt.', 'roro-ranking') . '</p></div>';
            }
            ?>
        </div>
        <?php
    }
}
