<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
delete_option('roro_ranking_enable_favorites');
delete_option('roro_ranking_recent_days');
delete_option('roro_ranking_recent_boost');
delete_option('roro_ranking_types');
delete_option('roro_ranking_last_refreshed');
