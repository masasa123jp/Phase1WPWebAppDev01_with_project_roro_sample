(function(){
  'use strict';
  // Try to obtain google.maps.Map instance created by roro-map plugin.
  function findMapInstance() {
    // 1) common globals
    if (window.RoroMap && window.RoroMap.map) return window.RoroMap.map;
    if (window.roroMap && window.roroMap.map) return window.roroMap.map;
    if (window.__roroMapInstances && window.__roroMapInstances.length) return window.__roroMapInstances[0];
    // 2) guess by DOM element id
    var el = document.getElementById('roro-map');
    if (el && el.__google_map_instance) return el.__google_map_instance;
    // unknown
    return null;
  }

  function ensureMapReady(timeoutMs, cb) {
    var start = Date.now();
    (function tick(){
      var map = findMapInstance();
      if (map) return cb(map);
      if (Date.now() - start > timeoutMs) return; // give up
      setTimeout(tick, 300);
    })();
  }

  function placeHomePin(map, lat, lng) {
    if (!window.google || !window.google.maps) return;
    var pos = new google.maps.LatLng(lat, lng);
    if (map && map.setCenter) map.setCenter(pos);
    // marker
    try {
      new google.maps.Marker({
        position: pos,
        map: map,
        title: 'Home'
      });
    } catch(e){}
  }

  function centerToCurrentLocation(map) {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(function(pos){
      var lat = pos.coords.latitude, lng = pos.coords.longitude;
      if (window.google && window.google.maps && map) {
        var ll = new google.maps.LatLng(lat, lng);
        map.setCenter(ll);
        try {
          new google.maps.Marker({position: ll, map: map, title: 'You are here'});
        } catch(e){}
      }
    }, function(err){
      // ignore
    }, {enableHighAccuracy: true, timeout: 8000});
  }

  document.addEventListener('DOMContentLoaded', function(){
    ensureMapReady(10000, function(map){
      // geolocation centering
      if (window.roroMapGeo && roroMapGeo.enableGeolocation) {
        centerToCurrentLocation(map);
      }
      // home pin via REST
      if (window.roroMapGeo && roroMapGeo.enableHomePin) {
        fetch(roroMapGeo.restUrl, {credentials:'same-origin'})
          .then(function(res){return res.json();})
          .then(function(j){
            if (j && j.ok && typeof j.lat === 'number' && typeof j.lng === 'number') {
              placeHomePin(map, j.lat, j.lng);
            }
          }).catch(function(){});
      }
    });
  });
})();
