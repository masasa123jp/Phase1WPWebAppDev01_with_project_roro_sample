<?php
/**
 * Plugin Name:       Roro Map Geo Add-on
 * Description:       roro-map の地図で「現在地センタリング」「自宅ピン（プロフィール住所のジオコード）」を追加するアドオン。
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Project RORO
 * License:           GPL-2.0-or-later
 * Text Domain:       roro-map-geo
 * Domain Path:       /languages
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_MAPG_VERSION', '1.0.0');
define('RORO_MAPG_PATH', plugin_dir_path(__FILE__));
define('RORO_MAPG_URL',  plugin_dir_url(__FILE__));
define('RORO_MAPG_BASENAME', plugin_basename(__FILE__));

add_action('plugins_loaded', function () {
    load_plugin_textdomain('roro-map-geo', false, dirname(RORO_MAPG_BASENAME) . '/languages');
});

require_once RORO_MAPG_PATH . 'includes/class-roro-mapgeo-admin.php';
require_once RORO_MAPG_PATH . 'includes/class-roro-mapgeo-service.php';
require_once RORO_MAPG_PATH . 'includes/class-roro-mapgeo-rest.php';

add_action('wp_enqueue_scripts', function () {
    // JS を常時ではなく「roro-map」関連ページで読みたい場合は条件分岐を追加
    wp_register_script('roro-map-geo', RORO_MAPG_URL . 'assets/js/roro-map-geo.js', [], RORO_MAPG_VERSION, true);
    $cfg = [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'restUrl' => esc_url_raw( get_rest_url(null, '/roro/v1/mapgeo/home') ),
        'enableGeolocation' => (bool) get_option('roro_mapg_enable_geo', true),
        'enableHomePin'     => (bool) get_option('roro_mapg_enable_home', true),
    ];
    wp_localize_script('roro-map-geo', 'roroMapGeo', $cfg);
    wp_enqueue_script('roro-map-geo');
});

// Admin
add_action('admin_menu', ['Roro_MapGeo_Admin', 'add_settings_page']);
add_action('admin_init', ['Roro_MapGeo_Admin', 'register_settings']);

// REST
add_action('rest_api_init', ['Roro_MapGeo_REST', 'register_routes']);
