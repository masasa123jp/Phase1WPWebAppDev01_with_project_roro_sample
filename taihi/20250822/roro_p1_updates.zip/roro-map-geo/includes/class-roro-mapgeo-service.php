<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_MapGeo_Service {

    /** Get lat/lng for current user home (cache usermeta) */
    public static function get_home_latlng_for_user(int $user_id): array {
        $lat = get_user_meta($user_id, 'roro_home_lat', true);
        $lng = get_user_meta($user_id, 'roro_home_lng', true);
        if ($lat && $lng) return ['lat'=>(float)$lat, 'lng'=>(float)$lng];

        // Build address from profile meta (roro-auth fields)
        $addr1 = get_user_meta($user_id, 'roro_address1', true);
        $addr2 = get_user_meta($user_id, 'roro_address2', true);
        $zip   = get_user_meta($user_id, 'roro_postal_code', true);
        $address = trim(($zip ? $zip . ' ' : '') . $addr1 . ' ' . $addr2);
        if (!$address) return [];

        $api_key = self::pick_api_key();
        if (!$api_key) return [];

        $q = urlencode($address);
        $url = "https://maps.googleapis.com/maps/api/geocode/json?address={$q}&key=" . rawurlencode($api_key);
        $res = wp_remote_get($url, ['timeout'=>20]);
        if (is_wp_error($res)) return [];
        $json = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($json) || empty($json['results'][0]['geometry']['location'])) return [];
        $loc = $json['results'][0]['geometry']['location'];
        $lat = (float)$loc['lat']; $lng = (float)$loc['lng'];
        update_user_meta($user_id, 'roro_home_lat', $lat);
        update_user_meta($user_id, 'roro_home_lng', $lng);
        return ['lat'=>$lat, 'lng'=>$lng];
    }

    /** Heuristically get Google Maps API key from roro-map or add-on setting */
    public static function pick_api_key(): string {
        $use_map_key = (bool) get_option('roro_mapg_use_map_key', true);
        $api_key = (string) get_option('roro_mapg_api_key', '');
        if ($api_key) return $api_key;

        if ($use_map_key) {
            // Try common option keys used by roro-map
            foreach (['roro_map_api_key', 'roro_map_google_api_key'] as $k) {
                $v = get_option($k, '');
                if ($v) return (string)$v;
            }
        }
        return '';
    }
}
