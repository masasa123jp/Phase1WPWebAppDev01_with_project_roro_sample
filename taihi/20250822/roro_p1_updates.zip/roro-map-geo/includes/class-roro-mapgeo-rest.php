<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_MapGeo_REST {

    public static function register_routes() {
        register_rest_route('roro/v1', '/mapgeo/home', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'get_home'],
            'permission_callback' => function() { return is_user_logged_in(); },
        ]);
    }

    public static function get_home($request) {
        $user_id = get_current_user_id();
        $loc = Roro_MapGeo_Service::get_home_latlng_for_user($user_id);
        if (!$loc) {
            return new WP_REST_Response(['ok'=>false], 200);
        }
        return rest_ensure_response(['ok'=>true, 'lat'=>$loc['lat'], 'lng'=>$loc['lng']]);
    }
}
