<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_MapGeo_Admin {
    public static function add_settings_page() {
        add_options_page(
            __('Roro Map Geo', 'roro-map-geo'),
            __('Roro Map Geo', 'roro-map-geo'),
            'manage_options',
            'roro-map-geo',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        register_setting('roro_map_geo', 'roro_mapg_enable_geo', [
            'type'=>'boolean', 'sanitize_callback'=>fn($v)=>(bool)$v, 'default'=>true
        ]);
        register_setting('roro_map_geo', 'roro_mapg_enable_home', [
            'type'=>'boolean', 'sanitize_callback'=>fn($v)=>(bool)$v, 'default'=>true
        ]);
        register_setting('roro_map_geo', 'roro_mapg_api_key', [
            'type'=>'string', 'sanitize_callback'=>'sanitize_text_field', 'default'=>''
        ]);
        register_setting('roro_map_geo', 'roro_mapg_use_map_key', [
            'type'=>'boolean', 'sanitize_callback'=>fn($v)=>(bool)$v, 'default'=>true
        ]);
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) wp_die(esc_html__('You do not have permission', 'roro-map-geo'));
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Roro Map Geo (Add-on)', 'roro-map-geo'); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields('roro_map_geo'); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><?php echo esc_html__('Enable Geolocation Centering', 'roro-map-geo'); ?></th>
                        <td><label><input type="checkbox" name="roro_mapg_enable_geo" value="1" <?php checked(get_option('roro_mapg_enable_geo', true)); ?>> <?php echo esc_html__('Use browser geolocation (if permission granted).', 'roro-map-geo'); ?></label></td></tr>
                    <tr><th scope="row"><?php echo esc_html__('Enable Home Pin', 'roro-map-geo'); ?></th>
                        <td><label><input type="checkbox" name="roro_mapg_enable_home" value="1" <?php checked(get_option('roro_mapg_enable_home', true)); ?>> <?php echo esc_html__('Geocode profile address and put a home marker.', 'roro-map-geo'); ?></label></td></tr>
                    <tr><th scope="row"><?php echo esc_html__('Geocoding API Key', 'roro-map-geo'); ?></th>
                        <td>
                            <input type="text" class="regular-text" name="roro_mapg_api_key" value="<?php echo esc_attr(get_option('roro_mapg_api_key', '')); ?>">
                            <p class="description"><?php echo esc_html__('If empty and "Use Map Key" is ON, the Google Maps API key from roro-map will be used.', 'roro-map-geo'); ?></p>
                        </td></tr>
                    <tr><th scope="row"><?php echo esc_html__('Use roro-map Key', 'roro-map-geo'); ?></th>
                        <td><label><input type="checkbox" name="roro_mapg_use_map_key" value="1" <?php checked(get_option('roro_mapg_use_map_key', true)); ?>> <?php echo esc_html__('Use API key configured in roro-map plugin.', 'roro-map-geo'); ?></label></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
