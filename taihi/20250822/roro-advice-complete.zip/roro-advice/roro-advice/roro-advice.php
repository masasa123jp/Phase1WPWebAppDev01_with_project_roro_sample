<?php
/**
 * Plugin Name:       Roro One‑Point Advice
 * Plugin URI:        https://example.com/roro-advice
 * Description:       Displays a random piece of advice from the Roro advice table.  If no
 *                    custom data exists a set of default messages will be used. A
 *                    shortcode is provided to embed the advice in posts or widgets.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-advice
 * Domain Path:       /languages
 *
 * @package RoroAdvice
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_ADVICE_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_ADVICE_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_ADVICE_DIR . 'includes/class-roro-advice.php';

function roro_advice_run() {
    $advice = new Roro_Advice_Plugin();
    $advice->run();
}
add_action( 'plugins_loaded', 'roro_advice_run' );