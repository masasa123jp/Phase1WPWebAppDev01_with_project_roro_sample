<?php
/**
 * Plugin Name: Roro Core WP
 * Plugin URI:  https://example.com
 * Description: Provides core functionality for the Roro project including database setup and common helpers.
 * Version:     1.0.0
 * Author:      Roro Team
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roro-core-wp
 * Domain Path: /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Roro_Core_WP' ) ) {
    /**
     * Main class for the core plugin.
     */
    class Roro_Core_WP {

        /**
         * Activation hook. Creates custom tables and loads initial data.
         */
        public static function activate() {
            global $wpdb;
            // Set the charset and collation for table creation.
            $charset_collate = $wpdb->get_charset_collate();

            // Table names with WordPress prefix for safety.
            $customer_table       = $wpdb->prefix . 'roro_customer';
            $pet_table            = $wpdb->prefix . 'roro_pet';
            $auth_account_table   = $wpdb->prefix . 'roro_auth_account';
            $user_link_table      = $wpdb->prefix . 'roro_user_link_wp';
            $favorite_table       = $wpdb->prefix . 'roro_map_favorite';
            $spot_table           = $wpdb->prefix . 'roro_travel_spot_master';
            $event_table          = $wpdb->prefix . 'roro_events_master';
            $advice_table         = $wpdb->prefix . 'roro_one_point_advice_master';
            $ai_conversation_table= $wpdb->prefix . 'roro_ai_conversation';
            $ai_message_table     = $wpdb->prefix . 'roro_ai_message';

            // SQL for creating tables. Note: keep SQL injection safe by using $wpdb->prefix.
            $sql  = "CREATE TABLE IF NOT EXISTS $customer_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                wp_user_id bigint(20) unsigned DEFAULT NULL,
                last_name varchar(255) NOT NULL,
                first_name varchar(255) NOT NULL,
                email varchar(255) NOT NULL,
                address varchar(255) DEFAULT '',
                phone varchar(100) DEFAULT '',
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $pet_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                customer_id bigint(20) unsigned NOT NULL,
                name varchar(255) NOT NULL,
                species varchar(100) DEFAULT '',
                breed varchar(255) DEFAULT '',
                birthday date DEFAULT NULL,
                weight float DEFAULT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY customer_id (customer_id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $auth_account_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                customer_id bigint(20) unsigned NOT NULL,
                provider varchar(50) NOT NULL,
                provider_user_id varchar(255) NOT NULL,
                access_token text DEFAULT NULL,
                refresh_token text DEFAULT NULL,
                expires_at bigint(20) DEFAULT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY customer_id (customer_id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $user_link_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                wp_user_id bigint(20) unsigned NOT NULL,
                customer_id bigint(20) unsigned NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY user_customer (wp_user_id, customer_id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $favorite_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                wp_user_id bigint(20) unsigned NOT NULL,
                spot_id bigint(20) unsigned NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY user_spot (wp_user_id, spot_id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $spot_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                name varchar(255) NOT NULL,
                latitude decimal(10,7) NOT NULL,
                longitude decimal(10,7) NOT NULL,
                category varchar(100) DEFAULT '',
                description text DEFAULT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $event_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                name varchar(255) NOT NULL,
                event_date date DEFAULT NULL,
                latitude decimal(10,7) NOT NULL,
                longitude decimal(10,7) NOT NULL,
                description text DEFAULT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $advice_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                advice text NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $ai_conversation_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                wp_user_id bigint(20) unsigned NOT NULL,
                started_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ended_at datetime DEFAULT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;";

            $sql .= "CREATE TABLE IF NOT EXISTS $ai_message_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                conversation_id bigint(20) unsigned NOT NULL,
                role varchar(20) NOT NULL,
                content text NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY conversation_id (conversation_id)
            ) $charset_collate;";

            // Use dbDelta to safely run the SQL. Requires upgrade.php.
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta( $sql );
        }

        /**
         * Deactivation hook. Currently does nothing but left for future enhancements.
         */
        public static function deactivate() {
            // Actions to perform on deactivation can be added here.
        }

        /**
         * Uninstall hook. Drops custom tables. Use with caution.
         */
        public static function uninstall() {
            global $wpdb;
            $tables = [
                'roro_customer',
                'roro_pet',
                'roro_auth_account',
                'roro_user_link_wp',
                'roro_map_favorite',
                'roro_travel_spot_master',
                'roro_events_master',
                'roro_one_point_advice_master',
                'roro_ai_conversation',
                'roro_ai_message',
            ];
            foreach ( $tables as $table ) {
                $wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $table );
            }
        }
    }
}

// Register activation/deactivation/uninstall hooks.
register_activation_hook( __FILE__, array( 'Roro_Core_WP', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Roro_Core_WP', 'deactivate' ) );
register_uninstall_hook( __FILE__, array( 'Roro_Core_WP', 'uninstall' ) );