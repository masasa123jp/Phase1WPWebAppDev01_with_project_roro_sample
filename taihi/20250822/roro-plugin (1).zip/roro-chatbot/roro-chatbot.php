<?php
/**
 * Plugin Name: Roro Chatbot
 * Plugin URI:  https://example.com
 * Description: Integrates an AI chatbot via external API (e.g. Dify) to assist users.
 * Version:     1.0.0
 * Author:      Roro Team
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roro-chatbot
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Roro_Chatbot' ) ) {
    /**
     * Main class for chatbot functionality.
     */
    class Roro_Chatbot {
        /**
         * Initialise hooks.
         */
        public static function init() {
            // Register shortcode to display chat UI.
            add_shortcode( 'roro_chatbot', array( __CLASS__, 'chatbot_shortcode' ) );
            // Enqueue scripts.
            add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
            // Register AJAX handler for sending user messages.
            add_action( 'wp_ajax_roro_chatbot_message', array( __CLASS__, 'ajax_chatbot_message' ) );
            add_action( 'wp_ajax_nopriv_roro_chatbot_message', array( __CLASS__, 'ajax_chatbot_message' ) );
            // Settings page for API key.
            add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
            add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        }

        /**
         * Enqueues JS for the chatbot interface when shortcode is present.
         */
        public static function enqueue_scripts() {
            if ( ! is_singular() ) {
                return;
            }
            global $post;
            if ( ! has_shortcode( $post->post_content, 'roro_chatbot' ) ) {
                return;
            }
            wp_enqueue_script( 'roro-chatbot-script', plugins_url( 'assets/js/roro-chatbot.js', __FILE__ ), array( 'jquery' ), '1.0.0', true );
            wp_localize_script( 'roro-chatbot-script', 'roroChatbotVars', array(
                'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
                'nonce'     => wp_create_nonce( 'roro_chatbot_nonce' ),
            ) );
        }

        /**
         * Outputs the chatbot container.
         *
         * @return string HTML markup for the chat interface.
         */
        public static function chatbot_shortcode() {
            ob_start();
            ?>
            <div id="roro-chatbot">
                <div id="roro-chatbot-messages" style="border:1px solid #ccc; padding:10px; height:200px; overflow-y:auto;"></div>
                <form id="roro-chatbot-form" method="post" style="margin-top:10px;">
                    <?php wp_nonce_field( 'roro_chatbot_nonce', 'roro_chatbot_nonce_field' ); ?>
                    <input type="text" id="roro-chatbot-input" name="message" style="width:80%;" />
                    <button type="submit" style="width:18%;">Send</button>
                </form>
            </div>
            <?php
            return ob_get_clean();
        }

        /**
         * Handles AJAX requests to send a message to the external AI API and returns the response.
         */
        public static function ajax_chatbot_message() {
            check_ajax_referer( 'roro_chatbot_nonce', 'nonce' );
            $message = isset( $_POST['message'] ) ? sanitize_text_field( $_POST['message'] ) : '';
            if ( empty( $message ) ) {
                wp_send_json_error( __( 'Message is empty.', 'roro-chatbot' ) );
            }
            // Retrieve API key from options.
            $api_key = get_option( 'roro_chatbot_api_key', '' );
            // For demonstration we simulate a response rather than call an external API.
            // In a real implementation, you'd call wp_remote_post() to your AI provider with $api_key.
            $response_text = sprintf( __( 'You said: %s', 'roro-chatbot' ), $message );
            wp_send_json_success( array( 'reply' => $response_text ) );
        }

        /**
         * Adds a settings page under Settings to store the chatbot API key.
         */
        public static function add_settings_page() {
            add_options_page( __( 'Roro Chatbot Settings', 'roro-chatbot' ), __( 'Roro Chatbot', 'roro-chatbot' ), 'manage_options', 'roro-chatbot', array( __CLASS__, 'render_settings_page' ) );
        }

        /**
         * Registers settings for API key.
         */
        public static function register_settings() {
            register_setting( 'roro_chatbot_settings', 'roro_chatbot_api_key' );
        }

        /**
         * Renders the settings page for the chatbot.
         */
        public static function render_settings_page() {
            ?>
            <div class="wrap">
                <h1><?php esc_html_e( 'Roro Chatbot Settings', 'roro-chatbot' ); ?></h1>
                <form method="post" action="options.php">
                    <?php settings_fields( 'roro_chatbot_settings' ); ?>
                    <?php do_settings_sections( 'roro_chatbot_settings' ); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="roro_chatbot_api_key"><?php esc_html_e( 'API Key', 'roro-chatbot' ); ?></label></th>
                            <td><input type="text" name="roro_chatbot_api_key" id="roro_chatbot_api_key" value="<?php echo esc_attr( get_option( 'roro_chatbot_api_key', '' ) ); ?>" class="regular-text" /></td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>
            <?php
        }
    }
}
// Initialise.
add_action( 'init', array( 'Roro_Chatbot', 'init' ) );