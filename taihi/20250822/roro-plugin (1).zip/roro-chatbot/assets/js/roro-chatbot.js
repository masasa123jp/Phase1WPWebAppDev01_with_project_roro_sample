/* global roroChatbotVars */
(function ( $ ) {
    'use strict';
    $(document).ready(function() {
        var form = $('#roro-chatbot-form');
        var input = $('#roro-chatbot-input');
        var messages = $('#roro-chatbot-messages');

        form.on('submit', function(e) {
            e.preventDefault();
            var msg = input.val();
            if ( ! msg ) {
                return;
            }
            // Append the user message to the chat display.
            messages.append('<div class="roro-msg-user"><strong>You:</strong> ' + $('<div>').text(msg).html() + '</div>');
            // Clear the input field.
            input.val('');
            // Send AJAX request.
            $.ajax({
                url: roroChatbotVars.ajaxUrl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'roro_chatbot_message',
                    nonce: roroChatbotVars.nonce,
                    message: msg
                },
                success: function(response) {
                    if ( response.success && response.data && response.data.reply ) {
                        messages.append('<div class="roro-msg-bot"><strong>Bot:</strong> ' + $('<div>').text(response.data.reply).html() + '</div>');
                    } else if ( response.data ) {
                        messages.append('<div class="roro-msg-error">' + $('<div>').text(response.data).html() + '</div>');
                    }
                    messages.scrollTop(messages.prop('scrollHeight'));
                },
                error: function() {
                    messages.append('<div class="roro-msg-error">An error occurred.</div>');
                }
            });
        });
    });
})( jQuery );