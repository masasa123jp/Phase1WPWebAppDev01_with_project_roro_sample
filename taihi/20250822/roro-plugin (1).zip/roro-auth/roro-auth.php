<?php
/**
 * Plugin Name: Roro Auth
 * Plugin URI:  https://example.com
 * Description: Handles user registration and profile synchronisation for the Roro project.
 * Version:     1.0.0
 * Author:      Roro Team
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roro-auth
 * Domain Path: /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Roro_Auth' ) ) {
    /**
     * Main class for authentication integration.
     */
    class Roro_Auth {

        /**
         * Initialise hooks.
         */
        public static function init() {
            // Hook into user registration to create a corresponding customer record.
            add_action( 'user_register', array( __CLASS__, 'handle_user_register' ), 10, 1 );

            // Register shortcode for custom registration form.
            add_shortcode( 'roro_register_form', array( __CLASS__, 'register_form_shortcode' ) );
        }

        /**
         * Handles user registration by inserting into roro_customer table and linking tables.
         *
         * @param int $user_id ID of the newly created WP user.
         */
        public static function handle_user_register( $user_id ) {
            $user = get_userdata( $user_id );
            if ( ! $user ) {
                return;
            }
            // Extract user information.
            $first_name = sanitize_text_field( $user->first_name );
            $last_name  = sanitize_text_field( $user->last_name );
            $email      = sanitize_email( $user->user_email );

            global $wpdb;
            $customer_table  = $wpdb->prefix . 'roro_customer';
            $link_table      = $wpdb->prefix . 'roro_user_link_wp';

            // Insert into customer table.
            $wpdb->insert( $customer_table, array(
                'wp_user_id' => $user_id,
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'email'      => $email,
                'address'    => '',
                'phone'      => ''
            ), array( '%d', '%s', '%s', '%s', '%s', '%s' ) );

            $customer_id = $wpdb->insert_id;

            // Insert into link table to map WP user to customer.
            $wpdb->insert( $link_table, array(
                'wp_user_id'  => $user_id,
                'customer_id' => $customer_id
            ), array( '%d', '%d' ) );
        }

        /**
         * Outputs a custom registration form. On submission, creates a WordPress user and triggers user_register.
         *
         * @return string HTML output for the registration form.
         */
        public static function register_form_shortcode() {
            if ( is_user_logged_in() ) {
                return '<p>' . esc_html__( 'You are already logged in.', 'roro-auth' ) . '</p>';
            }

            $html = '';
            // Handle form submission.
            if ( isset( $_POST['roro_register_nonce'] ) && wp_verify_nonce( $_POST['roro_register_nonce'], 'roro_register_action' ) ) {
                $username   = isset( $_POST['roro_username'] ) ? sanitize_user( $_POST['roro_username'] ) : '';
                $email      = isset( $_POST['roro_email'] ) ? sanitize_email( $_POST['roro_email'] ) : '';
                $password   = isset( $_POST['roro_password'] ) ? $_POST['roro_password'] : '';
                $first_name = isset( $_POST['roro_first_name'] ) ? sanitize_text_field( $_POST['roro_first_name'] ) : '';
                $last_name  = isset( $_POST['roro_last_name'] ) ? sanitize_text_field( $_POST['roro_last_name'] ) : '';

                // Basic validation.
                $errors = array();
                if ( empty( $username ) || username_exists( $username ) ) {
                    $errors[] = __( 'Username is empty or already taken.', 'roro-auth' );
                }
                if ( empty( $email ) || ! is_email( $email ) || email_exists( $email ) ) {
                    $errors[] = __( 'Email is invalid or already in use.', 'roro-auth' );
                }
                if ( empty( $password ) ) {
                    $errors[] = __( 'Password cannot be empty.', 'roro-auth' );
                }
                if ( ! empty( $errors ) ) {
                    foreach ( $errors as $error ) {
                        $html .= '<div class="roro-error">' . esc_html( $error ) . '</div>';
                    }
                } else {
                    // Create the WordPress user.
                    $user_id = wp_create_user( $username, $password, $email );
                    if ( is_wp_error( $user_id ) ) {
                        $html .= '<div class="roro-error">' . esc_html( $user_id->get_error_message() ) . '</div>';
                    } else {
                        // Set first and last name meta.
                        wp_update_user( array(
                            'ID'         => $user_id,
                            'first_name' => $first_name,
                            'last_name'  => $last_name
                        ) );
                        // Success message and maybe redirect.
                        $html .= '<div class="roro-success">' . esc_html__( 'Registration successful! Please log in.', 'roro-auth' ) . '</div>';
                    }
                }
            }

            // Registration form markup.
            $html .= '<form method="post" class="roro-registration-form">';
            $html .= wp_nonce_field( 'roro_register_action', 'roro_register_nonce', true, false );
            $html .= '<p><label>' . esc_html__( 'Username', 'roro-auth' ) . '<br /><input type="text" name="roro_username" required /></label></p>';
            $html .= '<p><label>' . esc_html__( 'Email', 'roro-auth' ) . '<br /><input type="email" name="roro_email" required /></label></p>';
            $html .= '<p><label>' . esc_html__( 'Password', 'roro-auth' ) . '<br /><input type="password" name="roro_password" required /></label></p>';
            $html .= '<p><label>' . esc_html__( 'First Name', 'roro-auth' ) . '<br /><input type="text" name="roro_first_name" /></label></p>';
            $html .= '<p><label>' . esc_html__( 'Last Name', 'roro-auth' ) . '<br /><input type="text" name="roro_last_name" /></label></p>';
            $html .= '<p><input type="submit" value="' . esc_attr__( 'Register', 'roro-auth' ) . '" /></p>';
            $html .= '</form>';

            return $html;
        }
    }
}

// Initialise plugin hooks.
add_action( 'init', array( 'Roro_Auth', 'init' ) );