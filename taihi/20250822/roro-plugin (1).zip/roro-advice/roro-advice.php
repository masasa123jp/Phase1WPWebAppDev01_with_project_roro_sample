<?php
/**
 * Plugin Name: Roro Advice
 * Plugin URI:  https://example.com
 * Description: Displays one‑point advice entries from the database.
 * Version:     1.0.0
 * Author:      Roro Team
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roro-advice
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Roro_Advice' ) ) {
    /**
     * Main class for one‑point advice feature.
     */
    class Roro_Advice {
        /**
         * Initialise hooks.
         */
        public static function init() {
            add_shortcode( 'roro_advice', array( __CLASS__, 'advice_shortcode' ) );
        }

        /**
         * Returns a random advice from the database.
         *
         * @return string HTML for the advice.
         */
        public static function advice_shortcode() {
            global $wpdb;
            $table = $wpdb->prefix . 'roro_one_point_advice_master';
            $advice = $wpdb->get_var( "SELECT advice FROM $table ORDER BY RAND() LIMIT 1" );
            if ( ! $advice ) {
                return '<p>' . esc_html__( 'No advice available at the moment.', 'roro-advice' ) . '</p>';
            }
            return '<div class="roro-advice">' . esc_html( $advice ) . '</div>';
        }
    }
}
// Initialise.
add_action( 'init', array( 'Roro_Advice', 'init' ) );