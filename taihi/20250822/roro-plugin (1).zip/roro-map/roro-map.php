<?php
/**
 * Plugin Name: Roro Map
 * Plugin URI:  https://example.com
 * Description: Provides Google Maps integration for displaying travel spots and events.
 * Version:     1.0.0
 * Author:      Roro Team
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roro-map
 * Domain Path: /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Roro_Map' ) ) {
    /**
     * Main class for the map plugin.
     */
    class Roro_Map {
        /**
         * Initialise hooks.
         */
        public static function init() {
            // Register REST routes for spots and events.
            add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
            // Enqueue scripts for the map shortcode.
            add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
            // Register shortcode to output map container.
            add_shortcode( 'roro_map', array( __CLASS__, 'map_shortcode' ) );
        }

        /**
         * Registers REST API routes used by the front‑end JavaScript to fetch spot/event data.
         */
        public static function register_rest_routes() {
            register_rest_route( 'roro/v1', '/spots', array(
                'methods'  => 'GET',
                'callback' => array( __CLASS__, 'get_spots' ),
                'permission_callback' => '__return_true',
            ) );
            register_rest_route( 'roro/v1', '/events', array(
                'methods'  => 'GET',
                'callback' => array( __CLASS__, 'get_events' ),
                'permission_callback' => '__return_true',
            ) );
        }

        /**
         * Returns an array of travel spots from the database.
         *
         * @return WP_REST_Response
         */
        public static function get_spots() {
            global $wpdb;
            $table = $wpdb->prefix . 'roro_travel_spot_master';
            $results = $wpdb->get_results( "SELECT id, name, latitude, longitude, category, description FROM $table", ARRAY_A );
            return rest_ensure_response( $results );
        }

        /**
         * Returns an array of events from the database.
         *
         * @return WP_REST_Response
         */
        public static function get_events() {
            global $wpdb;
            $table = $wpdb->prefix . 'roro_events_master';
            $results = $wpdb->get_results( "SELECT id, name, event_date, latitude, longitude, description FROM $table", ARRAY_A );
            return rest_ensure_response( $results );
        }

        /**
         * Enqueues front‑end scripts and styles for the map.
         */
        public static function enqueue_scripts() {
            if ( ! has_shortcode( get_post()->post_content, 'roro_map' ) ) {
                return;
            }
            // Google Maps API (leave API key placeholder; site owner should set via filter or constant).
            $api_key = apply_filters( 'roro_map_google_api_key', '' );
            if ( ! empty( $api_key ) ) {
                wp_enqueue_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?key=' . esc_attr( $api_key ), array(), null, true );
            }
            // Our map script.
            wp_enqueue_script( 'roro-map-script', plugins_url( 'assets/js/roro-map.js', __FILE__ ), array( 'jquery' ), '1.0.0', true );
            wp_localize_script( 'roro-map-script', 'roroMapVars', array(
                'spotsEndpoint' => rest_url( 'roro/v1/spots' ),
                'eventsEndpoint' => rest_url( 'roro/v1/events' ),
            ) );
        }

        /**
         * Outputs a div container that will hold the map. JavaScript will initialise it.
         *
         * @return string HTML for the map container.
         */
        public static function map_shortcode() {
            $html = '<div id="roro-map" style="width: 100%; height: 400px;"></div>';
            return $html;
        }
    }
}

// Initialise plugin hooks.
add_action( 'init', array( 'Roro_Map', 'init' ) );