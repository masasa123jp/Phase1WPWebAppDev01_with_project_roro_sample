/* global google, roroMapVars */
(function ( $ ) {
    'use strict';

    /**
     * Initialise the map once the DOM is ready.
     */
    function initMap() {
        var mapElement = document.getElementById('roro-map');
        if ( ! mapElement ) {
            return;
        }
        // Create a map centred on a default location (Tokyo) for now.
        var map = new google.maps.Map(mapElement, {
            center: { lat: 35.681236, lng: 139.767125 },
            zoom: 8
        });
        // Fetch spots.
        $.getJSON(roroMapVars.spotsEndpoint, function(spots) {
            if ( Array.isArray(spots) ) {
                spots.forEach(function(spot) {
                    var marker = new google.maps.Marker({
                        position: { lat: parseFloat(spot.latitude), lng: parseFloat(spot.longitude) },
                        map: map,
                        title: spot.name
                    });
                    var infoWindow = new google.maps.InfoWindow({
                        content: '<h4>' + spot.name + '</h4><p>' + (spot.description || '') + '</p>'
                    });
                    marker.addListener('click', function() {
                        infoWindow.open(map, marker);
                    });
                });
            }
        });
        // Fetch events.
        $.getJSON(roroMapVars.eventsEndpoint, function(events) {
            if ( Array.isArray(events) ) {
                events.forEach(function(event) {
                    var marker = new google.maps.Marker({
                        position: { lat: parseFloat(event.latitude), lng: parseFloat(event.longitude) },
                        map: map,
                        icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
                        title: event.name
                    });
                    var infoWindow = new google.maps.InfoWindow({
                        content: '<h4>' + event.name + '</h4><p>' + (event.description || '') + '</p>'
                    });
                    marker.addListener('click', function() {
                        infoWindow.open(map, marker);
                    });
                });
            }
        });
    }

    $(document).ready(function() {
        // If Google Maps library is loaded call initMap; otherwise wait.
        if ( window.google && google.maps ) {
            initMap();
        } else {
            // Wait until google maps script loads.
            var interval = setInterval(function() {
                if ( window.google && google.maps ) {
                    clearInterval(interval);
                    initMap();
                }
            }, 500);
        }
    });
})( jQuery );