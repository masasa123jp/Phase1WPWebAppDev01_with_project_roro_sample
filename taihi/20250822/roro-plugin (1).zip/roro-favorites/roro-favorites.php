<?php
/**
 * Plugin Name: Roro Favorites
 * Plugin URI:  https://example.com
 * Description: Enables users to save and manage favourite spots and events.
 * Version:     1.0.0
 * Author:      Roro Team
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: roro-favorites
 * Domain Path: /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Roro_Favorites' ) ) {
    /**
     * Main class for the favorites plugin.
     */
    class Roro_Favorites {

        /**
         * Initialise hooks.
         */
        public static function init() {
            // Register AJAX actions.
            add_action( 'wp_ajax_roro_add_favorite', array( __CLASS__, 'ajax_add_favorite' ) );
            add_action( 'wp_ajax_roro_remove_favorite', array( __CLASS__, 'ajax_remove_favorite' ) );
            // For non‑logged in users, return error quickly.
            add_action( 'wp_ajax_nopriv_roro_add_favorite', array( __CLASS__, 'ajax_nopriv' ) );
            add_action( 'wp_ajax_nopriv_roro_remove_favorite', array( __CLASS__, 'ajax_nopriv' ) );
            // Shortcode to list favorites.
            add_shortcode( 'roro_favorites', array( __CLASS__, 'favorites_shortcode' ) );
        }

        /**
         * Handles unauthorized AJAX access.
         */
        public static function ajax_nopriv() {
            wp_send_json_error( __( 'You must be logged in to perform this action.', 'roro-favorites' ), 403 );
        }

        /**
         * Adds a favorite for the current user.
         */
        public static function ajax_add_favorite() {
            check_ajax_referer( 'roro_favorites_nonce', 'nonce' );
            if ( ! is_user_logged_in() ) {
                wp_send_json_error( __( 'Not logged in.', 'roro-favorites' ), 403 );
            }
            $spot_id = isset( $_POST['spot_id'] ) ? absint( $_POST['spot_id'] ) : 0;
            if ( ! $spot_id ) {
                wp_send_json_error( __( 'Invalid spot ID.', 'roro-favorites' ) );
            }
            global $wpdb;
            $table = $wpdb->prefix . 'roro_map_favorite';
            $user_id = get_current_user_id();
            // Insert if not exists.
            $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $table (wp_user_id, spot_id) VALUES (%d, %d)", $user_id, $spot_id ) );
            wp_send_json_success();
        }

        /**
         * Removes a favorite for the current user.
         */
        public static function ajax_remove_favorite() {
            check_ajax_referer( 'roro_favorites_nonce', 'nonce' );
            if ( ! is_user_logged_in() ) {
                wp_send_json_error( __( 'Not logged in.', 'roro-favorites' ), 403 );
            }
            $spot_id = isset( $_POST['spot_id'] ) ? absint( $_POST['spot_id'] ) : 0;
            if ( ! $spot_id ) {
                wp_send_json_error( __( 'Invalid spot ID.', 'roro-favorites' ) );
            }
            global $wpdb;
            $table   = $wpdb->prefix . 'roro_map_favorite';
            $user_id = get_current_user_id();
            $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE wp_user_id = %d AND spot_id = %d", $user_id, $spot_id ) );
            wp_send_json_success();
        }

        /**
         * Outputs a list of the current user's favourite spots.
         *
         * @return string HTML for the favourites list.
         */
        public static function favorites_shortcode() {
            if ( ! is_user_logged_in() ) {
                return '<p>' . esc_html__( 'You must be logged in to view favourites.', 'roro-favorites' ) . '</p>';
            }
            global $wpdb;
            $table        = $wpdb->prefix . 'roro_map_favorite';
            $spot_table   = $wpdb->prefix . 'roro_travel_spot_master';
            $user_id      = get_current_user_id();
            $favorites    = $wpdb->get_results( $wpdb->prepare( "SELECT s.id, s.name, s.description FROM $spot_table s INNER JOIN $table f ON s.id = f.spot_id WHERE f.wp_user_id = %d", $user_id ), ARRAY_A );
            if ( empty( $favorites ) ) {
                return '<p>' . esc_html__( 'You have no favourites yet.', 'roro-favorites' ) . '</p>';
            }
            $html = '<ul class="roro-favorites-list">';
            foreach ( $favorites as $fav ) {
                $html .= '<li>' . esc_html( $fav['name'] );
                if ( ! empty( $fav['description'] ) ) {
                    $html .= ' – ' . esc_html( $fav['description'] );
                }
                $html .= '</li>';
            }
            $html .= '</ul>';
            return $html;
        }
    }
}

// Initialise hooks.
add_action( 'init', array( 'Roro_Favorites', 'init' ) );