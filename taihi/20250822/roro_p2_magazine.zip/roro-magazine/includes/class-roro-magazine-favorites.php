<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Magazine_Favorites {

    /** Toggle favorite via AJAX */
    public static function ajax_toggle_favorite() {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message'=>__('Please log in.', 'roro-magazine')], 200);
        }
        check_ajax_referer('roro_magazine_fav', 'nonce');
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        if (!$post_id || get_post_type($post_id) !== 'roro_mag_article') {
            wp_send_json_error(['message'=>__('Invalid target.', 'roro-magazine')], 400);
        }
        $user_id = get_current_user_id();

        $ok = self::toggle_favorite($user_id, 'article', $post_id);
        if (!$ok) {
            wp_send_json_error(['message'=>__('Error', 'roro-magazine')], 500);
        }
        $is_now = self::is_favorited($user_id, 'article', $post_id);
        wp_send_json_success(['favorited'=>$is_now]);
    }

    /** For non-logged-in users */
    public static function ajax_require_login() {
        wp_send_json_error(['message'=>__('Please log in.', 'roro-magazine')], 200);
    }

    /** Ensure table exists if roro-favorites plugin is not managing it */
    public static function maybe_create_table(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'roro_favorite';
        // Try to detect
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s",
            $table
        ));
        if ($exists) return;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            item_type VARCHAR(32) NOT NULL,
            item_id BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            UNIQUE KEY uniq_user_item (user_id, item_type, item_id),
            KEY idx_item (item_type, item_id, created_at),
            KEY idx_user (user_id, created_at)
        ) {$charset_collate};";
        dbDelta($sql);
    }

    /** Toggle favorite state */
    public static function toggle_favorite(int $user_id, string $item_type, int $item_id): bool {
        if (!in_array($item_type, ['article'], true)) return false;

        // If roro-favorites plugin exposes hooks, we could do:
        // do_action('roro_favorites/toggle', $user_id, $item_type, $item_id);
        // but to be self-contained, we manipulate table directly.
        global $wpdb;
        $table = $wpdb->prefix . 'roro_favorite';
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE user_id=%d AND item_type=%s AND item_id=%d", $user_id, $item_type, $item_id));
        if ($exists) {
            $wpdb->delete($table, ['id'=>(int)$exists]);
            return true;
        } else {
            return (bool) $wpdb->insert($table, [
                'user_id' => $user_id,
                'item_type' => $item_type,
                'item_id' => $item_id,
                'created_at' => current_time('mysql', 1),
            ]);
        }
    }

    /** Check favorite */
    public static function is_favorited(int $user_id, string $item_type, int $item_id): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'roro_favorite';
        $found = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND item_type=%s AND item_id=%d", $user_id, $item_type, $item_id));
        return ((int)$found) > 0;
    }
}
