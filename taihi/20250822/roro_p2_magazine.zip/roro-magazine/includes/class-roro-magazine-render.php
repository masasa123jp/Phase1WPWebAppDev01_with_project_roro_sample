<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Magazine_Render {

    public static function register_shortcodes() {
        add_shortcode('roro_magazine_grid', [__CLASS__,'shortcode_grid']);
        add_shortcode('roro_mag_article_list', [__CLASS__,'shortcode_article_list']);
        add_shortcode('roro_mag_article_view', [__CLASS__,'shortcode_article_view']);
        add_shortcode('roro_mag_lang_switch', [__CLASS__,'shortcode_lang_switch']);
    }

    /** Grid of issues */
    public static function shortcode_grid($atts) {
        $atts = shortcode_atts([
            'lang' => '',
            'columns' => 3,
            'limit' => 12,
        ], $atts, 'roro_magazine_grid');
        $lang = $atts['lang'] ? sanitize_text_field($atts['lang']) : Roro_Magazine_CPT::current_lang();
        $cols = max(1, min(6, (int)$atts['columns']));
        $limit = max(1, min(100, (int)$atts['limit']));

        $tax_query = [
            [
                'taxonomy' => Roro_Magazine_CPT::TAX_LANG,
                'field' => 'slug',
                'terms' => [$lang],
            ]
        ];

        $q = new WP_Query([
            'post_type' => 'roro_mag_issue',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'tax_query' => $tax_query,
        ]);
        if (!$q->have_posts()) return '<p>' . esc_html__('No issues.', 'roro-magazine') . '</p>';

        ob_start();
        echo '<div class="roro-mag-grid cols-' . esc_attr($cols) . '">';
        while ($q->have_posts()) { $q->the_post();
            $link = get_permalink();
            $title = get_the_title();
            $thumb = get_the_post_thumbnail(null, 'medium_large', ['loading'=>'lazy']);
            echo '<div class="roro-mag-grid__item">';
            echo '<a href="' . esc_url($link) . '">';
            echo $thumb ? $thumb : '';
            echo '<h3>' . esc_html($title) . '</h3>';
            echo '</a>';
            echo '</div>';
        }
        echo '</div>';
        wp_reset_postdata();
        return ob_get_clean();
    }

    /** List of articles in an issue */
    public static function shortcode_article_list($atts) {
        $atts = shortcode_atts([
            'issue_id' => 0,
            'lang' => '',
            'limit' => 30,
        ], $atts, 'roro_mag_article_list');

        $issue_id = absint($atts['issue_id']);
        $lang = $atts['lang'] ? sanitize_text_field($atts['lang']) : Roro_Magazine_CPT::current_lang();
        $limit = max(1, min(200, (int)$atts['limit']));

        $meta_query = [];
        if ($issue_id) {
            $meta_query[] = [
                'key' => Roro_Magazine_CPT::META_ARTICLE_ISSUE,
                'value' => $issue_id,
                'compare' => '=',
            ];
        }
        $tax_query = [
            [
                'taxonomy' => Roro_Magazine_CPT::TAX_LANG,
                'field' => 'slug',
                'terms' => [$lang],
            ]
        ];

        $q = new WP_Query([
            'post_type' => 'roro_mag_article',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => $meta_query,
            'tax_query' => $tax_query,
        ]);
        if (!$q->have_posts()) return '<p>' . esc_html__('No articles.', 'roro-magazine') . '</p>';

        ob_start();
        echo '<ul class="roro-mag-articles">';
        while ($q->have_posts()) { $q->the_post();
            $link = get_permalink();
            $title = get_the_title();
            echo '<li><a href="' . esc_url($link) . '">' . esc_html($title) . '</a></li>';
        }
        echo '</ul>';
        wp_reset_postdata();
        return ob_get_clean();
    }

    /** Single article view (with favorite button) */
    public static function shortcode_article_view($atts) {
        $atts = shortcode_atts([
            'id' => 0,
            'show_favorite' => '1',
            'lang_switch' => '1',
        ], $atts, 'roro_mag_article_view');
        $post_id = absint($atts['id']) ?: get_the_ID();
        if (!$post_id || get_post_type($post_id) !== 'roro_mag_article') return '';

        $show_fav = $atts['show_favorite'] === '1';
        $lang_sw  = $atts['lang_switch'] === '1';

        $p = get_post($post_id);
        setup_postdata($p);

        ob_start();
        echo '<article class="roro-mag-article">';
        echo '<h2>' . esc_html(get_the_title($p)) . '</h2>';
        echo apply_filters('the_content', $p->post_content);

        if ($show_fav && get_option('roro_mag_enable_fav', true)) {
            $btn_text = __('Add to Favorites', 'roro-magazine');
            if (is_user_logged_in() && Roro_Magazine_Favorites::is_favorited(get_current_user_id(), 'article', $post_id)) {
                $btn_text = __('Remove Favorite', 'roro-magazine');
            }
            printf('<p><button class="roro-mag-fav-btn" data-post="%d">%s</button></p>', $post_id, esc_html($btn_text));
        }

        if ($lang_sw) {
            echo do_shortcode('[roro_mag_lang_switch id="' . $post_id . '"]');
        }

        echo '</article>';
        wp_reset_postdata();
        return ob_get_clean();
    }

    /** Language switch links */
    public static function shortcode_lang_switch($atts) {
        $atts = shortcode_atts(['id'=>0], $atts, 'roro_mag_lang_switch');
        $post_id = absint($atts['id']) ?: get_the_ID();
        if (!$post_id) return '';

        $posts = Roro_Magazine_CPT::get_translations($post_id);
        if (!$posts) return '';

        // Current lang
        $cur_terms = wp_get_post_terms($post_id, Roro_Magazine_CPT::TAX_LANG, ['fields'=>'slugs']);
        $cur = is_wp_error($cur_terms) || empty($cur_terms) ? '' : $cur_terms[0];

        $labels = ['ja'=>'日本語','en'=>'English','zh'=>'中文','ko'=>'한국어'];
        $out = '<p class="roro-mag-lang-switch">';
        foreach ($posts as $p) {
            $slugs = wp_get_post_terms($p->ID, Roro_Magazine_CPT::TAX_LANG, ['fields'=>'slugs']);
            $lang = is_wp_error($slugs) || empty($slugs) ? '' : $slugs[0];
            $label = $labels[$lang] ?? strtoupper($lang);
            $cls = $lang === $cur ? ' class="is-current"' : '';
            $out .= sprintf('<a href="%s"%s>%s</a> ', esc_url(get_permalink($p)), $cls, esc_html($label));
        }
        $out .= '</p>';
        return $out;
    }
}
