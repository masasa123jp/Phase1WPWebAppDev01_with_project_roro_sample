<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Magazine_REST {

    public static function register_routes() {
        register_rest_route('roro/v1', '/mag/issues', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_issues'],
            'permission_callback' => '__return_true',
            'args' => [
                'lang' => ['required'=>false],
                'limit' => ['required'=>false],
            ],
        ]);

        register_rest_route('roro/v1', '/mag/articles', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_articles'],
            'permission_callback' => '__return_true',
            'args' => [
                'issue_id' => ['required'=>false],
                'lang' => ['required'=>false],
                'limit' => ['required'=>false],
            ],
        ]);

        register_rest_route('roro/v1', '/mag/article/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_article'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function get_issues($request) {
        $lang = sanitize_text_field((string)$request->get_param('lang') ?: '');
        $limit = (int)($request->get_param('limit') ?: 20);
        $args = [
            'post_type'=>'roro_mag_issue',
            'posts_per_page'=> max(1, min(100, $limit)),
            'orderby'=>'date','order'=>'DESC',
        ];
        if ($lang) {
            $args['tax_query'] = [[
                'taxonomy'=>Roro_Magazine_CPT::TAX_LANG,
                'field'=>'slug',
                'terms'=>[$lang],
            ]];
        }
        $q = new WP_Query($args);
        $items = [];
        while ($q->have_posts()) { $q->the_post();
            $items[] = [
                'id'=>get_the_ID(),
                'title'=>get_the_title(),
                'permalink'=>get_permalink(),
                'excerpt'=>get_the_excerpt(),
                'date'=>get_the_date('c'),
                'issue_date'=>get_post_meta(get_the_ID(), Roro_Magazine_CPT::META_ISSUE_DATE, true),
                'thumbnail'=>get_the_post_thumbnail_url(get_the_ID(), 'medium'),
            ];
        }
        wp_reset_postdata();
        return rest_ensure_response($items);
    }

    public static function get_articles($request) {
        $lang = sanitize_text_field((string)$request->get_param('lang') ?: '');
        $limit = (int)($request->get_param('limit') ?: 50);
        $issue_id = (int)($request->get_param('issue_id') ?: 0);
        $args = [
            'post_type'=>'roro_mag_article',
            'posts_per_page'=> max(1, min(200, $limit)),
            'orderby'=>'date','order'=>'DESC',
        ];
        $meta_query = [];
        if ($issue_id) {
            $meta_query[] = ['key'=>Roro_Magazine_CPT::META_ARTICLE_ISSUE, 'value'=>$issue_id, 'compare'=>'='];
        }
        if ($meta_query) $args['meta_query'] = $meta_query;
        if ($lang) {
            $args['tax_query'] = [[
                'taxonomy'=>Roro_Magazine_CPT::TAX_LANG,
                'field'=>'slug',
                'terms'=>[$lang],
            ]];
        }
        $q = new WP_Query($args);
        $items = [];
        while ($q->have_posts()) { $q->the_post();
            $items[] = [
                'id'=>get_the_ID(),
                'title'=>get_the_title(),
                'permalink'=>get_permalink(),
                'excerpt'=>get_the_excerpt(),
                'date'=>get_the_date('c'),
                'issue_id'=> (int) get_post_meta(get_the_ID(), Roro_Magazine_CPT::META_ARTICLE_ISSUE, true),
                'thumbnail'=>get_the_post_thumbnail_url(get_the_ID(), 'medium'),
            ];
        }
        wp_reset_postdata();
        return rest_ensure_response($items);
    }

    public static function get_article($request) {
        $id = (int)$request['id'];
        $p = get_post($id);
        if (!$p || $p->post_type !== 'roro_mag_article') {
            return new WP_REST_Response(['message'=>'Not found'], 404);
        }
        setup_postdata($p);
        $data = [
            'id'=>$id,
            'title'=>get_the_title($p),
            'content'=>apply_filters('the_content', $p->post_content),
            'permalink'=>get_permalink($p),
            'excerpt'=>get_the_excerpt($p),
            'date'=>get_the_date('c', $p),
            'issue_id'=> (int) get_post_meta($id, Roro_Magazine_CPT::META_ARTICLE_ISSUE, true),
            'thumbnail'=>get_the_post_thumbnail_url($id, 'large'),
            'translations'=>[],
        ];
        $trs = Roro_Magazine_CPT::get_translations($id);
        foreach ($trs as $tp) {
            $slugs = wp_get_post_terms($tp->ID, Roro_Magazine_CPT::TAX_LANG, ['fields'=>'slugs']);
            $lang = is_wp_error($slugs) || empty($slugs) ? '' : $slugs[0];
            $data['translations'][] = [
                'id'=>$tp->ID,
                'lang'=>$lang,
                'title'=>get_the_title($tp),
                'permalink'=>get_permalink($tp),
            ];
        }
        wp_reset_postdata();
        return rest_ensure_response($data);
    }
}
