<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Magazine_CPT {

    // Taxonomy name for language
    const TAX_LANG = 'roro_lang';
    // Meta for translation group
    const META_GROUP = '_roro_translation_group';
    // Meta for Issue date (YYYY-MM or YYYY-MM-DD)
    const META_ISSUE_DATE = '_roro_issue_date';
    // Meta for Article -> Issue relation
    const META_ARTICLE_ISSUE = '_roro_article_issue_id';

    /** Register CPT & Taxonomy */
    public static function register_cpt_tax() {
        // Slugs from settings (with fallback)
        $issue_slug   = get_option('roro_mag_issue_slug', 'mag-issue');
        $article_slug = get_option('roro_mag_article_slug', 'mag-article');

        // Issue
        register_post_type('roro_mag_issue', [
            'label' => __('Magazine Issues', 'roro-magazine'),
            'labels' => [
                'singular_name' => __('Magazine Issue', 'roro-magazine'),
            ],
            'public' => true,
            'has_archive' => true,
            'menu_position' => 20,
            'menu_icon' => 'dashicons-book',
            'show_in_rest' => true,
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'revisions'],
            'rewrite' => ['slug' => $issue_slug],
        ]);

        // Article
        register_post_type('roro_mag_article', [
            'label' => __('Magazine Articles', 'roro-magazine'),
            'labels' => [
                'singular_name' => __('Magazine Article', 'roro-magazine'),
            ],
            'public' => true,
            'has_archive' => true,
            'menu_position' => 21,
            'menu_icon' => 'dashicons-media-document',
            'show_in_rest' => true,
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'revisions'],
            'rewrite' => ['slug' => $article_slug],
        ]);

        // Language taxonomy
        register_taxonomy(self::TAX_LANG, ['roro_mag_issue','roro_mag_article'], [
            'label' => __('Language', 'roro-magazine'),
            'public' => false,
            'show_ui' => true,
            'hierarchical' => false,
            'show_in_rest' => true,
            'meta_box_cb' => null, // custom UI (meta box) below
        ]);
    }

    /** Ensure default language terms exist */
    public static function ensure_default_languages() {
        foreach (['ja'=>'日本語','en'=>'English','zh'=>'中文','ko'=>'한국어'] as $slug=>$name) {
            if (!term_exists($slug, self::TAX_LANG)) {
                wp_insert_term($name, self::TAX_LANG, ['slug'=>$slug, 'description'=>$name]);
            }
        }
    }

    /** Meta boxes */
    public static function register_meta_boxes() {
        add_meta_box('roro_issue_meta', __('Issue Meta', 'roro-magazine'), [__CLASS__,'box_issue_meta'], 'roro_mag_issue', 'side');
        add_meta_box('roro_article_meta', __('Article Meta', 'roro-magazine'), [__CLASS__,'box_article_meta'], 'roro_mag_article', 'side');
        add_meta_box('roro_lang_meta', __('Language / Translations', 'roro-magazine'), [__CLASS__,'box_language_meta'], ['roro_mag_issue','roro_mag_article'], 'side');
    }

    public static function box_issue_meta($post) {
        wp_nonce_field('roro_mag_issue_meta', 'roro_mag_issue_meta_nonce');
        $date = get_post_meta($post->ID, self::META_ISSUE_DATE, true);
        echo '<p><label>' . esc_html__('Issue Date (YYYY-MM or YYYY-MM-DD)', 'roro-magazine') . '<br>';
        printf('<input type="text" name="roro_issue_date" value="%s" class="widefat" placeholder="2025-06">', esc_attr($date));
        echo '</label></p>';
    }

    public static function box_article_meta($post) {
        wp_nonce_field('roro_mag_article_meta', 'roro_mag_article_meta_nonce');
        $issue_id = (int) get_post_meta($post->ID, self::META_ARTICLE_ISSUE, true);
        // dropdown issues
        $issues = get_posts([
            'post_type'=>'roro_mag_issue',
            'posts_per_page'=>-1,
            'orderby'=>'date',
            'order'=>'DESC',
            'suppress_filters'=>false,
        ]);
        echo '<p><label>' . esc_html__('Issue', 'roro-magazine') . '<br>';
        echo '<select name="roro_article_issue_id" class="widefat">';
        echo '<option value="0">-</option>';
        foreach ($issues as $i) {
            printf('<option value="%d" %s>%s</option>', (int)$i->ID, selected($issue_id, $i->ID, false), esc_html(get_the_title($i)));
        }
        echo '</select></label></p>';
    }

    public static function box_language_meta($post) {
        wp_nonce_field('roro_mag_lang_meta', 'roro_mag_lang_meta_nonce');
        $group = get_post_meta($post->ID, self::META_GROUP, true);
        if (!$group) $group = wp_generate_uuid4();
        $cur_terms = wp_get_post_terms($post->ID, self::TAX_LANG, ['fields'=>'slugs']);
        $cur_lang = is_wp_error($cur_terms) || empty($cur_terms) ? '' : $cur_terms[0];
        $langs = ['ja'=>'日本語','en'=>'English','zh'=>'中文','ko'=>'한국어'];

        echo '<p><label>' . esc_html__('Language', 'roro-magazine') . '<br>';
        echo '<select name="roro_lang" class="widefat">';
        echo '<option value="">-</option>';
        foreach ($langs as $slug=>$name) {
            printf('<option value="%s" %s>%s</option>', esc_attr($slug), selected($cur_lang, $slug, false), esc_html($name));
        }
        echo '</select></label></p>';

        echo '<p><label>' . esc_html__('Translation Group ID', 'roro-magazine') . '<br>';
        printf('<input type="text" name="roro_translation_group" value="%s" class="widefat">', esc_attr($group));
        echo '</label></p>';

        // helper links
        echo '<p class="description">' . esc_html__('Posts with the same Translation Group are considered translations of each other.', 'roro-magazine') . '</p>';
    }

    /** Save */
    public static function save_meta($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if ('revision' === $post->post_type) return;

        // Issue meta
        if ($post->post_type === 'roro_mag_issue') {
            if (!isset($_POST['roro_mag_issue_meta_nonce']) || !wp_verify_nonce($_POST['roro_mag_issue_meta_nonce'], 'roro_mag_issue_meta')) return;
            $date = isset($_POST['roro_issue_date']) ? sanitize_text_field($_POST['roro_issue_date']) : '';
            if ($date) {
                update_post_meta($post_id, self::META_ISSUE_DATE, $date);
            } else {
                delete_post_meta($post_id, self::META_ISSUE_DATE);
            }
        }

        // Article meta
        if ($post->post_type === 'roro_mag_article') {
            if (!isset($_POST['roro_mag_article_meta_nonce']) || !wp_verify_nonce($_POST['roro_mag_article_meta_nonce'], 'roro_mag_article_meta')) return;
            $issue_id = isset($_POST['roro_article_issue_id']) ? absint($_POST['roro_article_issue_id']) : 0;
            if ($issue_id) {
                update_post_meta($post_id, self::META_ARTICLE_ISSUE, $issue_id);
            } else {
                delete_post_meta($post_id, self::META_ARTICLE_ISSUE);
            }
        }

        // Language / Group (both post types)
        if (isset($_POST['roro_mag_lang_meta_nonce']) && wp_verify_nonce($_POST['roro_mag_lang_meta_nonce'], 'roro_mag_lang_meta')) {
            $lang = isset($_POST['roro_lang']) ? sanitize_text_field($_POST['roro_lang']) : '';
            if ($lang) {
                wp_set_post_terms($post_id, [$lang], self::TAX_LANG, false);
            } else {
                wp_set_post_terms($post_id, [], self::TAX_LANG, false);
            }
            $group = isset($_POST['roro_translation_group']) ? sanitize_text_field($_POST['roro_translation_group']) : '';
            if ($group) {
                update_post_meta($post_id, self::META_GROUP, $group);
            } else {
                delete_post_meta($post_id, self::META_GROUP);
            }
        }
    }

    /** Helper: current language selection for frontend */
    public static function current_lang(?string $fallback=null): string {
        // Priority: shortcode attr > site option > WP locale head
        if ($fallback && in_array($fallback, ['ja','en','zh','ko'], true)) return $fallback;
        $opt = get_option('roro_mag_default_lang', 'ja');
        if ($opt) return $opt;
        $loc = get_locale();
        if (strpos($loc, 'ja') === 0) return 'ja';
        if (strpos($loc, 'zh') === 0) return 'zh';
        if (strpos($loc, 'ko') === 0) return 'ko';
        return 'en';
    }

    /** Get translations for a post (array of post objects) */
    public static function get_translations(int $post_id): array {
        $group = get_post_meta($post_id, self::META_GROUP, true);
        if (!$group) return [];
        $posts = get_posts([
            'post_type' => get_post_type($post_id),
            'posts_per_page' => -1,
            'post__not_in' => [$post_id],
            'meta_query' => [
                [
                    'key' => self::META_GROUP,
                    'value' => $group,
                    'compare' => '=',
                ],
            ],
            'suppress_filters'=>false,
        ]);
        return $posts;
    }
}
