<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Magazine_Admin {

    public static function add_settings_page() {
        add_options_page(
            __('Roro Magazine', 'roro-magazine'),
            __('Roro Magazine', 'roro-magazine'),
            'manage_options',
            'roro-magazine',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        register_setting('roro_magazine', 'roro_mag_default_lang', [
            'type'=>'string',
            'sanitize_callback'=> function($v){
                $v = strtolower(sanitize_text_field($v));
                return in_array($v, ['ja','en','zh','ko'], true) ? $v : 'ja';
            },
            'default'=>'ja',
        ]);

        register_setting('roro_magazine', 'roro_mag_issue_slug', [
            'type'=>'string',
            'sanitize_callback'=>'sanitize_title',
            'default'=>'mag-issue',
        ]);

        register_setting('roro_magazine', 'roro_mag_article_slug', [
            'type'=>'string',
            'sanitize_callback'=>'sanitize_title',
            'default'=>'mag-article',
        ]);

        register_setting('roro_magazine', 'roro_mag_enable_fav', [
            'type'=>'boolean',
            'sanitize_callback'=>fn($v)=>(bool)$v,
            'default'=>true,
        ]);
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) wp_die(esc_html__('You do not have permission', 'roro-magazine'));
        ?>
        <div class="wrap">
          <h1><?php echo esc_html__('Roro Magazine Settings', 'roro-magazine'); ?></h1>
          <form method="post" action="options.php">
            <?php settings_fields('roro_magazine'); ?>
            <table class="form-table" role="presentation">
              <tr>
                <th scope="row"><?php echo esc_html__('Default Language', 'roro-magazine'); ?></th>
                <td>
                  <select name="roro_mag_default_lang">
                    <?php
                    $cur = get_option('roro_mag_default_lang', 'ja');
                    foreach (['ja'=>'日本語','en'=>'English','zh'=>'中文','ko'=>'한국어'] as $k=>$label) {
                      printf('<option value="%s" %s>%s</option>', esc_attr($k), selected($cur, $k, false), esc_html($label));
                    }
                    ?>
                  </select>
                </td>
              </tr>
              <tr>
                <th scope="row"><?php echo esc_html__('Issue Slug', 'roro-magazine'); ?></th>
                <td><input type="text" name="roro_mag_issue_slug" value="<?php echo esc_attr(get_option('roro_mag_issue_slug', 'mag-issue')); ?>" class="regular-text"></td>
              </tr>
              <tr>
                <th scope="row"><?php echo esc_html__('Article Slug', 'roro-magazine'); ?></th>
                <td><input type="text" name="roro_mag_article_slug" value="<?php echo esc_attr(get_option('roro_mag_article_slug', 'mag-article')); ?>" class="regular-text"></td>
              </tr>
              <tr>
                <th scope="row"><?php echo esc_html__('Enable Favorites', 'roro-magazine'); ?></th>
                <td><label><input type="checkbox" name="roro_mag_enable_fav" value="1" <?php checked(get_option('roro_mag_enable_fav', true)); ?>> <?php echo esc_html__('Allow users to favorite magazine articles.', 'roro-magazine'); ?></label></td>
              </tr>
            </table>
            <?php submit_button(); ?>
          </form>
        </div>
        <?php
    }

    /** Helper: get default language */
    public static function default_lang(): string {
        $v = get_option('roro_mag_default_lang', 'ja');
        return in_array($v, ['ja','en','zh','ko'], true) ? $v : 'ja';
    }
}
