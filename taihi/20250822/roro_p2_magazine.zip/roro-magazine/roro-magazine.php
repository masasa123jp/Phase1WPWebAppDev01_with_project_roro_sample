<?php
/**
 * Plugin Name:       Roro Magazine
 * Description:       雑誌コンテンツの管理（Issue/Article の CRUD）、お気に入り連携、本文の多言語対応（ja/en/zh/ko）。ショートコード・REST API・管理画面設定を提供。
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Project RORO
 * License:           GPL-2.0-or-later
 * Text Domain:       roro-magazine
 * Domain Path:       /languages
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_MAG_VERSION', '1.0.0');
define('RORO_MAG_PATH', plugin_dir_path(__FILE__));
define('RORO_MAG_URL',  plugin_dir_url(__FILE__));
define('RORO_MAG_BASENAME', plugin_basename(__FILE__));

// i18n
add_action('plugins_loaded', function () {
    load_plugin_textdomain('roro-magazine', false, dirname(RORO_MAG_BASENAME) . '/languages');
});

// includes
require_once RORO_MAG_PATH . 'includes/class-roro-magazine-admin.php';
require_once RORO_MAG_PATH . 'includes/class-roro-magazine-cpt.php';
require_once RORO_MAG_PATH . 'includes/class-roro-magazine-favorites.php';
require_once RORO_MAG_PATH . 'includes/class-roro-magazine-render.php';
require_once RORO_MAG_PATH . 'includes/class-roro-magazine-rest.php';

// bootstrap
add_action('init', ['Roro_Magazine_CPT', 'register_cpt_tax']);
add_action('init', ['Roro_Magazine_Render', 'register_shortcodes']);
add_action('rest_api_init', ['Roro_Magazine_REST', 'register_routes']);
add_action('admin_menu', ['Roro_Magazine_Admin', 'add_settings_page']);
add_action('admin_init', ['Roro_Magazine_Admin', 'register_settings']);
add_action('add_meta_boxes', ['Roro_Magazine_CPT', 'register_meta_boxes']);
add_action('save_post', ['Roro_Magazine_CPT', 'save_meta'], 10, 2);

// assets
add_action('wp_enqueue_scripts', function () {
    wp_register_script('roro-magazine', RORO_MAG_URL . 'assets/js/roro-magazine.js', ['jquery'], RORO_MAG_VERSION, true);
    wp_localize_script('roro-magazine', 'roroMagazine', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('roro_magazine_fav'),
        'strings' => [
            'add' => __('Add to Favorites', 'roro-magazine'),
            'remove' => __('Remove Favorite', 'roro-magazine'),
            'loginRequired' => __('Please log in.', 'roro-magazine'),
            'done' => __('Done', 'roro-magazine'),
            'error' => __('Error', 'roro-magazine'),
        ],
    ]);
    wp_enqueue_script('roro-magazine');
    wp_enqueue_style('roro-magazine-style', RORO_MAG_URL . 'assets/css/roro-magazine.css', [], RORO_MAG_VERSION);
});

// AJAX (favorites toggle for article)
add_action('wp_ajax_roro_mag_toggle_fav', ['Roro_Magazine_Favorites', 'ajax_toggle_favorite']);
add_action('wp_ajax_nopriv_roro_mag_toggle_fav', ['Roro_Magazine_Favorites', 'ajax_require_login']);

register_activation_hook(__FILE__, function () {
    // Register CPT/Tax first then flush rewrites
    Roro_Magazine_CPT::register_cpt_tax();
    // Ensure favorites table exists (for article) if roro-favorites 不在の場合
    Roro_Magazine_Favorites::maybe_create_table();
    // Ensure languages terms exist
    Roro_Magazine_CPT::ensure_default_languages();
    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
