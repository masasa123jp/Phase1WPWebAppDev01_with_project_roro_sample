(function($){
  'use strict';
  function toggle(btn){
    if (!roroMagazine) return;
    var $b = $(btn);
    var postId = parseInt($b.data('post'), 10);
    if (!postId) return;
    $b.prop('disabled', true);

    $.ajax({
      url: roroMagazine.ajaxUrl,
      type: 'POST',
      dataType: 'json',
      data: {
        action: 'roro_mag_toggle_fav',
        nonce: roroMagazine.nonce,
        post_id: postId
      }
    }).done(function(res){
      if (res && res.success && res.data) {
        if (res.data.favorited) {
          $b.text(roroMagazine.strings.remove);
        } else {
          $b.text(roroMagazine.strings.add);
        }
      } else if (res && res.data && res.data.message) {
        alert(res.data.message);
      } else {
        alert(roroMagazine.strings.error);
      }
    }).fail(function(){
      alert(roroMagazine.strings.error);
    }).always(function(){
      $b.prop('disabled', false);
    });
  }

  $(document).on('click', '.roro-mag-fav-btn', function(e){
    e.preventDefault();
    toggle(this);
  });
})(jQuery);
