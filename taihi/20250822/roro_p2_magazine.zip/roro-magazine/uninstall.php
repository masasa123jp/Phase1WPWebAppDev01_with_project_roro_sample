<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
delete_option('roro_mag_default_lang');
delete_option('roro_mag_issue_slug');
delete_option('roro_mag_article_slug');
delete_option('roro_mag_enable_fav');
// ポストやタクソノミーはユーザー資産のため削除しません。
