<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Chatbot_Service {

    /** Create DB tables */
    public static function create_tables(): void {
        global $wpdb;
        $conv = $wpdb->prefix . 'roro_ai_conversation';
        $msg  = $wpdb->prefix . 'roro_ai_message';
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql1 = "CREATE TABLE {$conv} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            session_key VARCHAR(64) NOT NULL,
            provider VARCHAR(32) NOT NULL DEFAULT 'pseudo',
            meta LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            UNIQUE KEY uniq_session (session_key),
            KEY idx_user (user_id, id)
        ) {$charset};";
        dbDelta($sql1);

        $sql2 = "CREATE TABLE {$msg} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conv_id BIGINT UNSIGNED NOT NULL,
            role VARCHAR(16) NOT NULL,
            content LONGTEXT NOT NULL,
            meta LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            KEY idx_conv (conv_id, id)
        ) {$charset};";
        dbDelta($sql2);
    }

    /** Create a conversation */
    public static function create_conversation(?int $user_id, string $provider=''): array {
        global $wpdb;
        $provider = $provider ?: get_option('roro_chat_provider', 'pseudo');
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $now = current_time('mysql', 1);
        $session = 'sess_' . wp_generate_uuid4();
        $meta = ['steps'=>[], 'external'=>[]];
        $wpdb->insert($conv_table, [
            'user_id' => $user_id ?: null,
            'session_key' => $session,
            'provider' => $provider,
            'meta' => wp_json_encode($meta),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $id = (int)$wpdb->insert_id;
        return ['id'=>$id, 'session_key'=>$session, 'provider'=>$provider];
    }

    /** Load conversation row */
    public static function get_conversation(int $conv_id): ?array {
        global $wpdb;
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$conv_table} WHERE id=%d", $conv_id), ARRAY_A);
        return $row ?: null;
    }

    /** Append message */
    public static function add_message(int $conv_id, string $role, string $content, array $meta=[]): int {
        global $wpdb;
        $msg_table = $wpdb->prefix . 'roro_ai_message';
        $wpdb->insert($msg_table, [
            'conv_id' => $conv_id,
            'role' => sanitize_key($role),
            'content' => wp_kses_post($content),
            'meta' => wp_json_encode($meta ?: new stdClass()),
            'created_at' => current_time('mysql', 1),
        ]);
        $id = (int)$wpdb->insert_id;
        // touch conversation
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $wpdb->update($conv_table, ['updated_at'=>current_time('mysql',1)], ['id'=>$conv_id]);
        return $id;
    }

    /** Get history */
    public static function get_history(int $conv_id, int $limit=50): array {
        global $wpdb;
        $msg_table = $wpdb->prefix . 'roro_ai_message';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT role, content, meta, created_at FROM {$msg_table} WHERE conv_id=%d ORDER BY id ASC LIMIT %d", $conv_id, max(1, min(500, $limit))), ARRAY_A);
        if (!$rows) return [];
        foreach ($rows as &$r) {
            $r['meta'] = $r['meta'] ? json_decode($r['meta'], true) : [];
        }
        return $rows;
    }

    /** Send user message and get assistant reply */
    public static function send_and_reply(int $conv_id, string $user_text, array $ctx=[]): array {
        $conv = self::get_conversation($conv_id);
        if (!$conv) return ['error'=>'conversation_not_found'];
        $provider = $conv['provider'] ?: get_option('roro_chat_provider','pseudo');

        // Save user message
        self::add_message($conv_id, 'user', $user_text, ['ctx'=>$ctx]);

        // Router
        if ($provider === 'dify') {
            $res = self::reply_via_dify($conv, $user_text);
        } else {
            $res = self::reply_via_pseudo($conv, $user_text, $ctx);
        }

        // Save assistant message
        if (empty($res['error'])) {
            $meta = ['provider'=>$provider, 'recommendations'=>$res['recommendations'] ?? []];
            self::add_message($conv_id, 'assistant', $res['reply_html'], $meta);
        }

        return $res;
    }

    /** Dify provider */
    private static function reply_via_dify(array $conv, string $user_text): array {
        $base = rtrim(get_option('roro_chat_dify_base','https://api.dify.ai'), '/');
        $ep   = '/' . ltrim(get_option('roro_chat_dify_endpoint','/v1/chat-messages'), '/');
        $url  = $base . $ep;
        $key  = get_option('roro_chat_dify_api_key','');
        $app  = get_option('roro_chat_dify_app_id','');

        if (!$key || !$url) {
            return ['error'=>'dify_not_configured', 'reply_html'=>'<p>Provider not configured.</p>'];
        }

        // Build payload (generic Dify chat-messages style)
        $payload = [
            'inputs' => new stdClass(),
            'query'  => $user_text,
            'user'   => get_current_user_id() ? ('wp-' . get_current_user_id()) : ('anon-' . self::session_hash()),
            'response_mode' => 'blocking',
        ];
        // カンバセーションIDがあればメタから送る
        $meta = $conv['meta'] ? json_decode($conv['meta'], true) : [];
        if (!empty($meta['external']['dify_conversation_id'])) {
            $payload['conversation_id'] = $meta['external']['dify_conversation_id'];
        }
        if ($app) {
            $payload['app_id'] = $app;
        }

        $args = [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ];
        $resp = wp_remote_post($url, $args);
        if (is_wp_error($resp)) {
            return ['error'=>'http_error', 'reply_html'=>'<p>Network error.</p>'];
        }
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        $answer = '';
        if (isset($body['answer'])) $answer = (string)$body['answer'];
        elseif (isset($body['data'])) $answer = is_string($body['data']) ? $body['data'] : wp_json_encode($body['data']);
        elseif (isset($body['message'])) $answer = (string)$body['message'];
        else $answer = wp_remote_retrieve_body($resp);

        if (!empty($body['conversation_id'])) {
            $meta['external']['dify_conversation_id'] = $body['conversation_id'];
            self::update_conv_meta((int)$conv['id'], $meta);
        }

        $reply_html = wpautop(esc_html($answer));
        return ['reply_html'=>$reply_html, 'recommendations'=>[]];
    }

    private static function session_hash(): string {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        return substr(md5($ip . '|' . $ua . '|' . time()), 0, 12);
    }

    /** Pseudo provider: guided dialog + WP検索＆地図/ランキング推薦 */
    private static function reply_via_pseudo(array $conv, string $user_text, array $ctx=[]): array {
        // 1) 簡易ガイドフロー
        $meta = $conv['meta'] ? json_decode($conv['meta'], true) : ['steps'=>[]];
        $steps = $meta['steps'] ?? [];
        $state = [
            'pet_type' => $steps['pet_type'] ?? null,   // dog/cat
            'pet_age'  => $steps['pet_age'] ?? null,    // puppy/adult/senior
            'topic'    => $steps['topic'] ?? null,      // heat, travel, training, event
        ];

        $lower = strtolower(wp_strip_all_tags($user_text));
        foreach (['dog','cat','puppy','kitten','senior','travel','trip','heat','summer','cool','training','walk','event','festival','park'] as $kw) {
            if (strpos($lower, $kw) !== false) {
                if (in_array($kw, ['dog','puppy'])) $state['pet_type'] = 'dog';
                if (in_array($kw, ['cat','kitten'])) $state['pet_type'] = 'cat';
                if ($kw === 'puppy')  $state['pet_age'] = 'puppy';
                if ($kw === 'senior') $state['pet_age'] = 'senior';
                if (in_array($kw, ['travel','trip']))          $state['topic'] = 'travel';
                if (in_array($kw, ['heat','summer','cool']))    $state['topic'] = 'heat';
                if ($kw === 'training')                         $state['topic'] = 'training';
                if (in_array($kw, ['event','festival','park'])) $state['topic'] = 'event';
            }
        }
        $jp = [
            '犬'=>'dog','猫'=>'cat','子犬'=>'puppy','子猫'=>'kitten','老犬'=>'senior','老猫'=>'senior',
            '旅行'=>'travel','おでかけ'=>'travel','熱中症'=>'heat','夏'=>'heat','涼'=>'heat','しつけ'=>'training','イベント'=>'event','公園'=>'event'
        ];
        foreach ($jp as $k=>$v) { if (mb_stripos($user_text, $k) !== false) {
            if (in_array($v, ['dog','cat'])) $state['pet_type'] = $v;
            if ($v === 'puppy')  $state['pet_age'] = 'puppy';
            if ($v === 'senior') $state['pet_age'] = 'senior';
            if (in_array($v, ['travel','heat','training','event'])) $state['topic'] = $v;
        }}

        if (!$state['pet_type']) {
            $reply = 'わんちゃん・ねこちゃん、どちら向けの情報をご希望ですか？（例：「犬」「猫」）';
            $meta['steps']['pet_type'] = null;
            self::update_conv_meta((int)$conv['id'], $meta);
            return ['reply_html'=>'<p>'.$reply.'</p>', 'recommendations'=>[]];
        }
        if (!$state['pet_age']) {
            $reply = '年齢層も教えてください。（例：「子犬／成犬／シニア」）';
            $meta['steps']['pet_type'] = $state['pet_type'];
            $meta['steps']['pet_age'] = null;
            self::update_conv_meta((int)$conv['id'], $meta);
            return ['reply_html'=>'<p>'.$reply.'</p>', 'recommendations'=>[]];
        }
        if (!$state['topic']) {
            $reply = '知りたいテーマは？（「熱中症対策」「おでかけ」「しつけ」「イベント」など）';
            $meta['steps']['pet_type'] = $state['pet_type'];
            $meta['steps']['pet_age'] = $state['pet_age'];
            $meta['steps']['topic'] = null;
            self::update_conv_meta((int)$conv['id'], $meta);
            return ['reply_html'=>'<p>'.$reply.'</p>', 'recommendations'=>[]];
        }

        // Save state
        $meta['steps'] = $state;
        self::update_conv_meta((int)$conv['id'], $meta);

        // 2) 雑誌記事（CPT）検索
        $map = ['dog'=>'犬', 'cat'=>'猫', 'puppy'=>'子犬', 'senior'=>'シニア', 'heat'=>'熱中症', 'travel'=>'おでかけ', 'training'=>'しつけ', 'event'=>'イベント'];
        $terms = [];
        foreach (['pet_type','pet_age','topic'] as $k) { if (!empty($state[$k]) && !empty($map[$state[$k]])) $terms[] = $map[$state[$k]]; }
        $q = implode(' ', $terms);
        $posts = get_posts([
            'post_type'=>'roro_mag_article',
            's' => $q ?: $user_text,
            'posts_per_page'=>5,
            'suppress_filters'=>false,
        ]);
        $recs = [];
        foreach ($posts as $p) {
            $thumb = get_the_post_thumbnail_url($p, 'medium') ?: '';
            $recs[] = [
                'type'  => 'article',
                'id'    => (int)$p->ID,
                'title' => get_the_title($p),
                'url'   => get_permalink($p),
                'thumb' => $thumb,
            ];
        }

        // 2.5) 位置情報があれば roro-map 経由で周辺スポット/イベントを取得
        $lat = isset($ctx['lat']) ? (float)$ctx['lat'] : null;
        $lng = isset($ctx['lng']) ? (float)$ctx['lng'] : null;
        if ($lat && $lng) {
            $extra = self::recommend_from_map_rest($lat, $lng, $state['topic'] ?? '', 6);
            if (!$extra) { $extra = self::recommend_from_map_db($lat, $lng, $state['topic'] ?? '', 6); }
            // ランキングとブレンド
            $extra = self::blend_with_ranking($extra, 'spot',  '30d');
            $extra = self::blend_with_ranking($extra, 'event', '30d');
            $recs = array_merge($recs, $extra);
        }

        // 3) 返信整形
        $lines = [];
        $lines[] = sprintf('【条件】%s / %s / %s',
            $state['pet_type']==='dog'?'犬':'猫',
            ($state['pet_age']==='puppy' ? '子犬' : ($state['pet_age']==='senior' ? 'シニア' : '成犬')),
            ['heat'=>'熱中症','travel'=>'おでかけ','training'=>'しつけ','event'=>'イベント'][$state['topic']]
        );
        if ($recs) {
            $lines[] = 'おすすめを表示しました。下のカードから記事・スポット・イベントをご確認ください。';
        } else {
            $lines[] = '該当するおすすめが見つかりませんでした。別のキーワードでもお試しください。';
        }
        $reply_html = '<p>' . esc_html(implode("\n", $lines)) . '</p>';
        return ['reply_html'=>$reply_html, 'recommendations'=>$recs];
    }

    /** REST 連携：roro-map が提供する /map/events, /map/spots を試行 */
    private static function recommend_from_map_rest(float $lat, float $lng, string $topic, int $limit): array {
        $endpoints = [
            'event'    => '/roro/v1/map/events',
            'travel'   => '/roro/v1/map/spots',
            'heat'     => '/roro/v1/map/spots',
            'training' => '/roro/v1/map/spots',
        ];
        $base = get_rest_url();
        $out  = [];
        foreach ($endpoints as $k=>$ep) {
            if ($topic && $k!==$topic) continue;
            $url = add_query_arg(['lat'=>$lat,'lng'=>$lng,'limit'=>$limit], $base . ltrim($ep,'/'));
            $res = wp_remote_get($url, ['timeout'=>10]);
            if (is_wp_error($res)) continue;
            $arr = json_decode(wp_remote_retrieve_body($res), true);
            if (!is_array($arr) || empty($arr['items'])) continue;
            foreach ($arr['items'] as $it) {
                $out[] = [
                    'type'  => (strpos($ep,'events')!==false ? 'event' : 'spot'),
                    'id'    => isset($it['id']) ? (int)$it['id'] : 0,
                    'title' => isset($it['title']) ? $it['title'] : (isset($it['name'])?$it['name']:''),
                    'url'   => isset($it['url']) ? $it['url'] : home_url('/'),
                    'thumb' => isset($it['thumb']) ? $it['thumb'] : '',
                    'distance_km' => isset($it['distance_km']) ? (float)$it['distance_km'] : null,
                ];
            }
        }
        return array_slice($out, 0, $limit);
    }

    /** DB フォールバック：roro_map が無い環境でも稼働させる近傍検索 */
    private static function recommend_from_map_db(float $lat, float $lng, string $topic, int $limit): array {
        global $wpdb;
        $out = [];
        $spot_table  = $wpdb->prefix . 'roro_travel_spot_master';
        $event_table = $wpdb->prefix . 'roro_events_master';
        $has_spot  = self::table_exists($spot_table);
        $has_event = self::table_exists($event_table);
        if (!$has_spot && !$has_event) return [];
        $limit = max(1, min(20, (int)$limit));
        // Haversine formula (km)
        if ($has_spot && $topic !== 'event') {
            $sql = "SELECT id, name, lat, lng,
                    (6371 * ACOS(COS(RADIANS(%f)) * COS(RADIANS(lat)) * COS(RADIANS(lng) - RADIANS(%f)) + SIN(RADIANS(%f)) * SIN(RADIANS(lat)))) AS dist
                    FROM {$spot_table}
                    ORDER BY dist ASC
                    LIMIT %d";
            $rows = $wpdb->get_results($wpdb->prepare($sql, $lat, $lng, $lat, $limit), ARRAY_A);
            foreach ($rows ?: [] as $r) {
                $out[] = [
                    'type'  => 'spot',
                    'id'    => (int)$r['id'],
                    'title' => $r['name'],
                    'url'   => home_url('/map?spot='.(int)$r['id']),
                    'thumb' => '',
                    'distance_km' => round((float)$r['dist'], 1),
                ];
            }
        }
        if ($has_event && ($topic === 'event' || !$has_spot)) {
            $sql = "SELECT id, name, lat, lng,
                    (6371 * ACOS(COS(RADIANS(%f)) * COS(RADIANS(lat)) * COS(RADIANS(lng) - RADIANS(%f)) + SIN(RADIANS(%f)) * SIN(RADIANS(lat)))) AS dist
                    FROM {$event_table}
                    ORDER BY dist ASC
                    LIMIT %d";
            $rows = $wpdb->get_results($wpdb->prepare($sql, $lat, $lng, $lat, $limit), ARRAY_A);
            foreach ($rows ?: [] as $r) {
                $out[] = [
                    'type'  => 'event',
                    'id'    => (int)$r['id'],
                    'title' => $r['name'],
                    'url'   => home_url('/map?event='.(int)$r['id']),
                    'thumb' => '',
                    'distance_km' => round((float)$r['dist'], 1),
                ];
            }
        }
        return $out;
    }

    private static function table_exists(string $table): bool {
        global $wpdb;
        $like = $wpdb->esc_like($table);
        $t = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $like));
        return !empty($t);
    }

    /** ランキング情報でスコア付与して並べ替え */
    private static function blend_with_ranking(array $items, string $type, string $period): array {
        if (!$items) return $items;
        $url = add_query_arg(['type'=>$type,'period'=>$period], get_rest_url(null, '/roro/v1/ranking'));
        $res = wp_remote_get($url, ['timeout'=>10]);
        if (is_wp_error($res)) return $items;
        $rank = json_decode(wp_remote_retrieve_body($res), true);
        if (empty($rank['items']) || !is_array($rank['items'])) return $items;
        $score = [];
        foreach ($rank['items'] as $r) {
            $rid = isset($r['item_id']) ? (int)$r['item_id'] : null;
            if ($rid) $score[$rid] = isset($r['score']) ? (float)$r['score'] : 0.0;
        }
        foreach ($items as &$it) {
            if (!isset($it['score'])) $it['score'] = 0.0;
            if (isset($score[(int)$it['id']])) $it['score'] += (float)$score[(int)$it['id']];
        }
        usort($items, function($a,$b){
            $sa = $a['score'] ?? 0.0; $sb = $b['score'] ?? 0.0;
            if ($sa == $sb) {
                // distance があれば距離優先
                $da = $a['distance_km'] ?? 9999; $db = $b['distance_km'] ?? 9999;
                return ($da <=> $db);
            }
            return ($sb <=> $sa);
        });
        return $items;
    }

    /** Update conversation meta (merge) */
    private static function update_conv_meta(int $conv_id, array $meta): void {
        global $wpdb;
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $wpdb->update($conv_table, [
            'meta' => wp_json_encode($meta),
        ], ['id'=>$conv_id]);
    }
}
