(function(){
  'use strict';
  function h(html){ return html; } // server-side escapes
  function el(sel, root){ return (root||document).querySelector(sel); }
  function ce(tag, cls){ const e=document.createElement(tag); if(cls)e.className=cls; return e; }

  function restBase(){
    // roroChat.restUrl: .../wp-json/roro/v1/chat
    var url = (roroChat && roroChat.restUrl) || '';
    var i = url.lastIndexOf('/chat');
    return (i > 0) ? url.slice(0, i) : url.replace(/\/chat.*$/, '');
  }

  function appendMsg(body, role, html){
    const wrap = ce('div', 'roro-chat__msg roro-chat__msg--' + role);
    const bubble = ce('div', 'roro-chat__bubble');
    bubble.innerHTML = h(html);
    wrap.appendChild(bubble);
    body.appendChild(wrap);
    body.scrollTop = body.scrollHeight;
  }

  function recCard(rec){
    const item = ce('div', 'roro-chat__card');
    const head = ce('div', 'roro-chat__card__head');
    const badge = ce('span', 'roro-badge roro-badge--' + rec.type); badge.textContent = rec.type;
    head.appendChild(badge);
    if (typeof rec.distance_km === 'number') {
      const dist = ce('span', 'roro-chip roro-chip--distance'); dist.textContent = rec.distance_km.toFixed(1) + 'km';
      head.appendChild(dist);
    }
    const title = ce('div', 'roro-chat__card__title'); title.textContent = rec.title || '';
    const foot = ce('div', 'roro-chat__card__foot');
    const a = ce('a'); a.href = rec.url || '#'; a.textContent = roroChat.strings.seeOnMap; a.target = '_blank';
    foot.appendChild(a);
    item.appendChild(head);
    item.appendChild(title);
    item.appendChild(foot);
    return item;
  }

  function appendRecommendations(body, recs){
    if (!recs || !recs.length) return;
    const wrap = ce('div', 'roro-chat__recs');
    const title = ce('div', 'roro-chat__recs__title'); title.textContent = roroChat.strings.recommended;
    wrap.appendChild(title);
    const grid = ce('div', 'roro-chat__grid');
    recs.forEach(function(r){ grid.appendChild(recCard(r)); });
    wrap.appendChild(grid);
    body.appendChild(wrap);
  }

  function buildChips(box, onPick){
    if (!roroChat.topics || !Array.isArray(roroChat.topics)) return;
    roroChat.topics.forEach(function(t){
      const b = ce('button', 'roro-chip'); b.type='button'; b.textContent = t.label;
      b.addEventListener('click', function(){ onPick(t); });
      box.appendChild(b);
    });
  }

  function init(root){
    const body = el('.js-chat-body', root);
    const input = el('.js-chat-input', root);
    const sendBtn = el('.js-chat-send', root);
    const chipsBox = el('.js-chat-chips', root);
    let convId = null;
    let geo = null;

    buildChips(chipsBox, function(t){
      // send chip as quick message
      input.value = t.label;
      send();
    });

    function ensureGeo(){
      if (geo !== null) return Promise.resolve(geo);
      // 1) roro-map-geo の自宅座標
      return fetch(restBase() + '/mapgeo/home', {
        method:'GET', credentials:'same-origin', headers:{'X-WP-Nonce': roroChat.restNonce}
      }).then(r=>r.json()).then(function(j){
        if (j && j.ok && typeof j.lat === 'number' && typeof j.lng === 'number') { geo = {lat:j.lat, lng:j.lng}; return geo; }
        // 2) ブラウザ Geolocation
        return new Promise(function(res){
          if (!navigator.geolocation) return res(null);
          navigator.geolocation.getCurrentPosition(
            p=>res({lat:p.coords.latitude, lng:p.coords.longitude}),
            _=>res(null),
            { maximumAge: 60000, timeout: 3000 }
          );
        });
      }).catch(function(){ return null; });
    }

    function ensureConversation(){
      if (convId) return Promise.resolve(convId);
      return fetch(roroChat.restUrl + '/new', {
        method:'POST',
        headers: {'X-WP-Nonce': roroChat.restNonce}
      }).then(r=>r.json()).then(function(j){
        if (j && j.ok && j.id) { convId = j.id; return convId; }
        throw new Error('conv create failed');
      });
    }

    function send(){
      const text = (input.value || '').trim();
      if (!text) return;
      appendMsg(body, 'user', text.replace(/[&<>]/g, s=>({ '&':'&amp;','<':'&lt;','>':'&gt;' }[s])));
      input.value = '';
      const wait = ce('div','roro-chat__msg roro-chat__msg--assistant');
      const bubble = ce('div','roro-chat__bubble'); bubble.textContent = roroChat.strings.thinking; wait.appendChild(bubble); body.appendChild(wait); body.scrollTop=body.scrollHeight;

      Promise.resolve(geo || ensureGeo()).then(()=>ensureConversation()).then(function(){
        const payload = {message:text, nonce: roroChat.restNonce};
        if (geo && typeof geo.lat === 'number' && typeof geo.lng === 'number') {
          payload.lat = geo.lat; payload.lng = geo.lng;
        }
        return fetch(roroChat.restUrl + '/' + convId + '/send', {
          method:'POST',
          headers: {'Content-Type':'application/json','X-WP-Nonce': roroChat.restNonce},
          credentials: 'same-origin',
          body: JSON.stringify(payload)
        });
      }).then(r=>r.json()).then(function(j){
        wait.remove();
        if (j && j.ok) {
          appendMsg(body, 'assistant', j.reply_html || '');
          appendRecommendations(body, j.recommendations || []);
        } else {
          appendMsg(body, 'assistant', '<p>' + roroChat.strings.error + '</p>');
        }
      }).catch(function(){
        wait.remove();
        appendMsg(body, 'assistant', '<p>' + roroChat.strings.error + '</p>');
      });
    }

    sendBtn.addEventListener('click', function(e){ e.preventDefault(); send(); });
    input.addEventListener('keydown', function(e){ if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
  }

  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.roro-chat').forEach(init);
  });
})();
