<?php
/**
 * アンインストール時のクリーンアップ
 * - 本プラグインのオプションのみ削除（テーブルは保持：運用データ保全のため）
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
delete_option( 'roro_map_settings' );
