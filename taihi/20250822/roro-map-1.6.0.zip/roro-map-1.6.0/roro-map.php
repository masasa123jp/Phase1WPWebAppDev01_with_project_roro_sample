<?php
/**
 * Plugin Name: Roro Map
 * Description: イベント／スポットの地図表示、周辺推薦、ホーム位置管理（Leaflet/Google切替対応）。roro-favorites と連携して「お気に入り」登録も可能。
 * Version: 1.6.0
 * Author: Roro Project
 * Text Domain: roro-map
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RORO_MAP_VERSION', '1.6.0' );
define( 'RORO_MAP_FILE', __FILE__ );
define( 'RORO_MAP_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_MAP_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_MAP_DIR . 'includes/class-roro-map-admin.php';
require_once RORO_MAP_DIR . 'includes/class-roro-map-rest.php';
require_once RORO_MAP_DIR . 'includes/class-roro-map-render.php';

/**
 * 有効化フック：カスタムテーブルの作成（存在しない場合のみ）
 * - roro_events: イベントの簡易テーブル（デモ用途／本番は既存MASTERを使う想定）
 * - roro_spots : スポットの簡易テーブル（同上）
 */
register_activation_hook( __FILE__, function () {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $events = $wpdb->prefix . 'roro_events';
    $spots  = $wpdb->prefix . 'roro_spots';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $sql_events = "CREATE TABLE IF NOT EXISTS {$events} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT NULL,
        category VARCHAR(50) NULL,
        address VARCHAR(255) NULL,
        lat DECIMAL(10,6) NOT NULL,
        lng DECIMAL(10,6) NOT NULL,
        starts_at DATETIME NULL,
        ends_at DATETIME NULL,
        PRIMARY KEY (id),
        KEY idx_lat (lat),
        KEY idx_lng (lng),
        KEY idx_cat (category)
    ) {$charset_collate};";

    $sql_spots = "CREATE TABLE IF NOT EXISTS {$spots} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        description TEXT NULL,
        category VARCHAR(50) NULL,
        address VARCHAR(255) NULL,
        lat DECIMAL(10,6) NOT NULL,
        lng DECIMAL(10,6) NOT NULL,
        PRIMARY KEY (id),
        KEY idx_lat (lat),
        KEY idx_lng (lng),
        KEY idx_cat (category)
    ) {$charset_collate};";

    dbDelta( $sql_events );
    dbDelta( $sql_spots );
});

/**
 * 初期化：管理画面・REST・ショートコード
 */
add_action( 'plugins_loaded', function () {
    ( new Roro_Map_Admin )->register();
    ( new Roro_Map_REST )->register_routes();
    ( new Roro_Map_Render )->register();
});
