<?php
/**
 * 管理画面（設定）クラス
 * - プロバイダ切替（leaflet / google / none）
 * - API キー（Google）
 * - 初期中心座標、ズーム
 * - ジオロケーション許可
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Roro_Map_Admin {
    const OPTION_KEY = 'roro_map_settings';

    public function register() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    public function add_menu() {
        add_options_page(
            __( 'Roro Map Settings', 'roro-map' ),
            __( 'Roro Map', 'roro-map' ),
            'manage_options',
            'roro-map-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    public function register_settings() {
        register_setting( 'roro_map_settings_group', self::OPTION_KEY, [ $this, 'sanitize' ] );

        add_settings_section( 'rms_main', __( 'Map Provider & Defaults', 'roro-map' ), '__return_false', 'roro-map-settings' );

        add_settings_field( 'provider', __( 'Provider', 'roro-map' ), [ $this, 'field_provider' ], 'roro-map-settings', 'rms_main' );
        add_settings_field( 'google_api_key', __( 'Google Maps API Key', 'roro-map' ), [ $this, 'field_text' ], 'roro-map-settings', 'rms_main', [ 'key' => 'google_api_key' ] );
        add_settings_field( 'default_center_lat', __( 'Default Center Lat', 'roro-map' ), [ $this, 'field_text' ], 'roro-map-settings', 'rms_main', [ 'key' => 'default_center_lat' ] );
        add_settings_field( 'default_center_lng', __( 'Default Center Lng', 'roro-map' ), [ $this, 'field_text' ], 'roro-map-settings', 'rms_main', [ 'key' => 'default_center_lng' ] );
        add_settings_field( 'default_zoom', __( 'Default Zoom', 'roro-map' ), [ $this, 'field_text' ], 'roro-map-settings', 'rms_main', [ 'key' => 'default_zoom' ] );
        add_settings_field( 'enable_geolocation', __( 'Enable Browser Geolocation', 'roro-map' ), [ $this, 'field_checkbox' ], 'roro-map-settings', 'rms_main', [ 'key' => 'enable_geolocation' ] );
    }

    public function sanitize( $opts ) {
        $out = (array) get_option( self::OPTION_KEY, [] );
        $out['provider']            = in_array( $opts['provider'] ?? 'leaflet', [ 'leaflet', 'google', 'none' ], true ) ? $opts['provider'] : 'leaflet';
        $out['google_api_key']      = sanitize_text_field( $opts['google_api_key'] ?? '' );
        $out['default_center_lat']  = is_numeric( $opts['default_center_lat'] ?? '' ) ? $opts['default_center_lat'] : '35.682839'; // Tokyo
        $out['default_center_lng']  = is_numeric( $opts['default_center_lng'] ?? '' ) ? $opts['default_center_lng'] : '139.759455';
        $out['default_zoom']        = absint( $opts['default_zoom'] ?? 12 );
        $out['enable_geolocation']  = ! empty( $opts['enable_geolocation'] ) ? 1 : 0;
        return $out;
    }

    public function field_provider() {
        $opt = (array) get_option( self::OPTION_KEY, [] );
        $val = $opt['provider'] ?? 'leaflet';
        ?>
        <select name="<?php echo esc_attr( self::OPTION_KEY ); ?>[provider]">
            <option value="leaflet" <?php selected( $val, 'leaflet' ); ?>>Leaflet (default)</option>
            <option value="google"  <?php selected( $val, 'google' ); ?>>Google Maps</option>
            <option value="none"    <?php selected( $val, 'none' ); ?>>None (List-only)</option>
        </select>
        <?php
    }

    public function field_text( $args ) {
        $key = $args['key'];
        $opt = (array) get_option( self::OPTION_KEY, [] );
        $val = esc_attr( $opt[ $key ] ?? '' );
        printf( '<input type="text" name="%s[%s]" value="%s" class="regular-text" />', esc_attr( self::OPTION_KEY ), esc_attr( $key ), $val );
    }

    public function field_checkbox( $args ) {
        $key = $args['key'];
        $opt = (array) get_option( self::OPTION_KEY, [] );
        $val = ! empty( $opt[ $key ] );
        printf( '<label><input type="checkbox" name="%s[%s]" value="1" %s /> %s</label>',
            esc_attr( self::OPTION_KEY ), esc_attr( $key ), checked( $val, true, false ), esc_html__( 'Enable', 'roro-map' ) );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Roro Map Settings', 'roro-map' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'roro_map_settings_group' );
                do_settings_sections( 'roro-map-settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}
