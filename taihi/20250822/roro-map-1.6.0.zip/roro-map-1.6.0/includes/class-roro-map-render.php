<?php
/**
 * フロント側描画（ショートコード）とスクリプトenqueue
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Roro_Map_Render {

    public function register() {
        add_shortcode( 'roro_map', [ $this, 'shortcode_map' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_front' ] );
    }

    public function enqueue_front() {
        $opt = (array) get_option( Roro_Map_Admin::OPTION_KEY, [] );
        $provider = $opt['provider'] ?? 'leaflet';

        // Leaflet（デフォルト）
        if ( 'leaflet' === $provider ) {
            wp_enqueue_style( 'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
            wp_enqueue_script( 'leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true );
        }

        // Google Maps
        if ( 'google' === $provider ) {
            $key = isset( $opt['google_api_key'] ) ? trim( $opt['google_api_key'] ) : '';
            if ( $key ) {
                // callback は roroMapGoogleInit で受ける（JS側で定義）
                wp_enqueue_script( 'google-maps', sprintf( 'https://maps.googleapis.com/maps/api/js?key=%s&callback=roroMapGoogleInit', rawurlencode( $key ) ), [], null, true );
            }
        }

        // 共通CSS/JS
        wp_enqueue_style( 'roro-map-css', RORO_MAP_URL . 'assets/css/roro-map.css', [], RORO_MAP_VERSION );
        wp_enqueue_script( 'roro-map-js', RORO_MAP_URL . 'assets/js/roro-map.js', [ 'jquery' ], RORO_MAP_VERSION, true );

        // お気に入り用 Nonce（roro-favorites の Ajax と同じアクション名で発行）
        $fav_nonce = wp_create_nonce( 'roro_fav_toggle' );
        wp_localize_script( 'roro-map-js', 'roroMapData', array(
            'restUrl'   => esc_url_raw( rest_url( 'roro/v1' ) ),
            'ajaxUrl'   => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
            'favNonce'  => $fav_nonce,
            'provider'  => $provider,
            'defaults'  => array(
                'lat'  => ( $opt['default_center_lat'] ?? '35.682839' ),
                'lng'  => ( $opt['default_center_lng'] ?? '139.759455' ),
                'zoom' => intval( $opt['default_zoom'] ?? 12 ),
                'geolocation' => ! empty( $opt['enable_geolocation'] ),
            ),
        ) );
    }

    public function shortcode_map( $atts ) {
        // 地図とリストのコンテナを出力
        ob_start();
        ?>
        <div class="roro-map-wrap">
            <div id="roro-map-canvas" class="roro-map-canvas" aria-label="<?php esc_attr_e( 'Map area', 'roro-map' ); ?>"></div>
            <div class="roro-map-side">
                <div class="roro-map-filters" role="toolbar">
                    <button class="chip" data-cat="all"><?php esc_html_e( 'All', 'roro-map' ); ?></button>
                    <button class="chip" data-cat="event"><?php esc_html_e( 'Events', 'roro-map' ); ?></button>
                    <button class="chip" data-cat="spot"><?php esc_html_e( 'Spots', 'roro-map' ); ?></button>
                </div>
                <ul id="roro-map-list" class="roro-map-list" aria-live="polite"></ul>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
