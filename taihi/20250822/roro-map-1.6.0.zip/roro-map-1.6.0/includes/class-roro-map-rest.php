<?php
/**
 * REST API ルート定義
 * - GET /roro/v1/map/events
 * - GET /roro/v1/map/spots
 * - GET/POST /roro/v1/mapgeo/home  …ユーザーの「自宅」座標の取得/更新
 * - GET /roro/v1/map/recommendations …自宅近傍のイベント/スポット推薦
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Roro_Map_REST {

    public function register_routes() {
        add_action( 'rest_api_init', function () {
            register_rest_route( 'roro/v1', '/map/events', array(
                'methods'  => WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_events' ),
                'permission_callback' => '__return_true',
                'args' => $this->common_args()
            ) );

            register_rest_route( 'roro/v1', '/map/spots', array(
                'methods'  => WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_spots' ),
                'permission_callback' => '__return_true',
                'args' => $this->common_args()
            ) );

            register_rest_route( 'roro/v1', '/mapgeo/home', array(
                array(
                    'methods'  => WP_REST_Server::READABLE,
                    'callback' => array( $this, 'get_home' ),
                    'permission_callback' => '__return_true',
                ),
                array(
                    'methods'  => WP_REST_Server::CREATABLE,
                    'callback' => array( $this, 'set_home' ),
                    'permission_callback' => function () {
                        return is_user_logged_in();
                    }
                )
            ) );

            register_rest_route( 'roro/v1', '/map/recommendations', array(
                'methods'  => WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_recommendations' ),
                'permission_callback' => '__return_true',
                'args' => array_merge( $this->common_args(), array(
                    'limit' => array(
                        'type' => 'integer',
                        'default' => 10,
                    )
                ) )
            ) );
        } );
    }

    private function common_args() {
        return array(
            'lat' => array( 'type' => 'number', 'required' => false ),
            'lng' => array( 'type' => 'number', 'required' => false ),
            'radius' => array( 'type' => 'number', 'default' => 5000 ), // meters
            'category' => array( 'type' => 'string', 'required' => false ),
            'q' => array( 'type' => 'string', 'required' => false ),
            'limit' => array( 'type' => 'integer', 'default' => 50 ),
        );
    }

    /** DB テーブル名の自動検出（MASTERが存在すればそちらを優先） */
    private function tables() {
        global $wpdb;
        $events_candidates = array( $wpdb->prefix . 'roro_events_master', $wpdb->prefix . 'roro_events' );
        $spots_candidates  = array( $wpdb->prefix . 'roro_travel_spot_master', $wpdb->prefix . 'roro_spots' );
        $exists = function( $table ) use ( $wpdb ) {
            return ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
        };
        $events = current( array_filter( $events_candidates, $exists ) );
        $spots  = current( array_filter( $spots_candidates, $exists ) );
        return array( 'events' => $events, 'spots' => $spots );
    }

    /** Haversine 近傍条件の SQL 断片（おおよそ）。index利用のため bounding box + 距離式の両方を用意 */
    private function where_geo( $lat, $lng, $radius_m, $lat_col = 'lat', $lng_col = 'lng' ) {
        global $wpdb;
        if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
            return array( 'sql' => '1=1', 'params' => array() );
        }
        $earth = 6371000; // meters
        $lat = floatval( $lat );
        $lng = floatval( $lng );
        $radius = floatval( $radius_m );
        $lat_delta = rad2deg( $radius / $earth );
        $lng_delta = rad2deg( $radius / ( $earth * cos( deg2rad( $lat ) ) ) );

        $sql = "({$lat_col} BETWEEN %f AND %f) AND ({$lng_col} BETWEEN %f AND %f)";
        $params = array( $lat - $lat_delta, $lat + $lat_delta, $lng - $lng_delta, $lng + $lng_delta );
        return array( 'sql' => $wpdb->prepare( $sql, $params ), 'params' => array() );
    }

    public function get_events( WP_REST_Request $req ) {
        global $wpdb;
        $t = $this->tables();
        if ( empty( $t['events'] ) ) {
            return new WP_REST_Response( array(), 200 );
        }
        $lat = $req->get_param( 'lat' );
        $lng = $req->get_param( 'lng' );
        $radius = $req->get_param( 'radius' );
        $category = $req->get_param( 'category' );
        $q = $req->get_param( 'q' );
        $limit = max( 1, min( 200, intval( $req->get_param( 'limit' ) ) ) );

        $where = array();
        $params = array();
        $geo = $this->where_geo( $lat, $lng, $radius, 'lat', 'lng' );
        if ( $geo['sql'] ) $where[] = $geo['sql'];
        if ( $category ) { $where[] = 'category = %s'; $params[] = $category; }
        if ( $q ) { $where[] = '(title LIKE %s OR description LIKE %s)'; $params[] = '%' . $wpdb->esc_like( $q ) . '%'; $params[] = '%' . $wpdb->esc_like( $q ) . '%'; }
        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
        $sql = "SELECT id, title, description, category, address, lat, lng, starts_at, ends_at FROM {$t['events']} {$where_sql} ORDER BY starts_at DESC LIMIT %d";
        $params[] = $limit;
        $results = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
        return new WP_REST_Response( $results, 200 );
    }

    public function get_spots( WP_REST_Request $req ) {
        global $wpdb;
        $t = $this->tables();
        if ( empty( $t['spots'] ) ) {
            return new WP_REST_Response( array(), 200 );
        }
        $lat = $req->get_param( 'lat' );
        $lng = $req->get_param( 'lng' );
        $radius = $req->get_param( 'radius' );
        $category = $req->get_param( 'category' );
        $q = $req->get_param( 'q' );
        $limit = max( 1, min( 200, intval( $req->get_param( 'limit' ) ) ) );

        $where = array();
        $params = array();
        $geo = $this->where_geo( $lat, $lng, $radius, 'lat', 'lng' );
        if ( $geo['sql'] ) $where[] = $geo['sql'];
        if ( $category ) { $where[] = 'category = %s'; $params[] = $category; }
        if ( $q ) { $where[] = '(name LIKE %s OR description LIKE %s OR address LIKE %s)'; $like = '%' . $wpdb->esc_like( $q ) . '%'; $params[] = $like; $params[] = $like; $params[] = $like; }
        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
        $sql = "SELECT id, name, description, category, address, lat, lng FROM {$t['spots']} {$where_sql} ORDER BY id DESC LIMIT %d";
        $params[] = $limit;
        $results = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
        return new WP_REST_Response( $results, 200 );
    }

    public function get_home( WP_REST_Request $req ) {
        $user_id = get_current_user_id();
        $lat = $user_id ? get_user_meta( $user_id, 'roro_home_lat', true ) : '';
        $lng = $user_id ? get_user_meta( $user_id, 'roro_home_lng', true ) : '';
        return new WP_REST_Response( array(
            'user_id' => $user_id,
            'lat' => is_numeric( $lat ) ? (float) $lat : null,
            'lng' => is_numeric( $lng ) ? (float) $lng : null,
        ), 200 );
    }

    public function set_home( WP_REST_Request $req ) {
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'unauthorized', __( 'Login required.', 'roro-map' ), array( 'status' => 401 ) );
        }
        $lat = $req->get_param( 'lat' );
        $lng = $req->get_param( 'lng' );
        if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
            return new WP_Error( 'invalid_params', __( 'Invalid coordinates.', 'roro-map' ), array( 'status' => 400 ) );
        }
        $user_id = get_current_user_id();
        update_user_meta( $user_id, 'roro_home_lat', (float) $lat );
        update_user_meta( $user_id, 'roro_home_lng', (float) $lng );
        return new WP_REST_Response( array( 'ok' => true ), 200 );
    }

    public function get_recommendations( WP_REST_Request $req ) {
        // ホーム座標があればそこを基準に、なければデフォルト（設定値）を使用
        $settings = (array) get_option( Roro_Map_Admin::OPTION_KEY, array() );
        $lat = $req->get_param( 'lat' );
        $lng = $req->get_param( 'lng' );
        if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
            $user = get_current_user_id();
            if ( $user ) {
                $lat = get_user_meta( $user, 'roro_home_lat', true );
                $lng = get_user_meta( $user, 'roro_home_lng', true );
            }
        }
        if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
            $lat = $settings['default_center_lat'] ?? '35.682839';
            $lng = $settings['default_center_lng'] ?? '139.759455';
        }
        $limit = max( 1, min( 50, intval( $req->get_param( 'limit' ) ) ) );

        // まずイベント、次にスポットから取得して結合
        $events = $this->get_events( new WP_REST_Request( 'GET', '/roro/v1/map/events' ) );
        $spots  = $this->get_spots( new WP_REST_Request( 'GET', '/roro/v1/map/spots' ) );
        $e = ( $events instanceof WP_REST_Response ) ? $events->get_data() : array();
        $s = ( $spots  instanceof WP_REST_Response ) ? $spots->get_data()  : array();

        // 上位limit件に切り詰め（簡易）
        $out = array();
        foreach ( $e as $row ) {
            $out[] = array(
                'id' => (int) $row['id'],
                'type' => 'event',
                'title' => $row['title'],
                'lat' => (float) $row['lat'],
                'lng' => (float) $row['lng'],
                'address' => $row['address'],
                'category' => $row['category'],
                'starts_at' => $row['starts_at'],
                'ends_at' => $row['ends_at'],
                'url' => home_url('/map/?type=event&id=' . (int)$row['id']),
            );
            if ( count( $out ) >= $limit ) break;
        }
        if ( count( $out ) < $limit ) {
            foreach ( $s as $row ) {
                $out[] = array(
                    'id' => (int) $row['id'],
                    'type' => 'spot',
                    'title' => $row['name'],
                    'lat' => (float) $row['lat'],
                    'lng' => (float) $row['lng'],
                    'address' => $row['address'],
                    'category' => $row['category'],
                    'url' => home_url('/map/?type=spot&id=' . (int)$row['id']),
                );
                if ( count( $out ) >= $limit ) break;
            }
        }
        return new WP_REST_Response( $out, 200 );
    }
}
