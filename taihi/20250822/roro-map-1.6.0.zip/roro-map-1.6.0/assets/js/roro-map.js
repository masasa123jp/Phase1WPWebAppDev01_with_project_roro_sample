(function(){
  'use strict';

  const cfg = window.roroMapData || {};
  const rest = cfg.restUrl || '';
  const ajaxUrl = cfg.ajaxUrl || '';
  let currentCat = 'all'; // all|event|spot

  function el(tag, cls, html){
    const e = document.createElement(tag);
    if(cls) e.className = cls;
    if(html != null) e.innerHTML = html;
    return e;
  }

  function favButton(item){
    const btn = el('button','roro-fav-btn','❤');
    btn.setAttribute('aria-label','お気に入り切替');
    btn.addEventListener('click', async (ev) => {
      ev.preventDefault();
      const form = new URLSearchParams();
      form.set('action','roro_fav_toggle');
      form.set('nonce', cfg.favNonce||'');
      form.set('item_id', item.id);
      form.set('item_type', item.type);
      try{
        const res = await fetch(ajaxUrl, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: form });
        const data = await res.json();
        if(!res.ok || !data.success){
          alert((data.data && data.data.message) || 'Failed');
          return;
        }
        btn.classList.toggle('is-on');
      }catch(e){ console.error(e); alert('Network error'); }
    });
    return btn;
  }

  function renderList(items){
    const ul = document.getElementById('roro-map-list');
    ul.innerHTML='';
    if(!items || !items.length){
      ul.appendChild(el('li','empty','近くのスポットやイベントが見つかりません。'));
      return;
    }
    items.forEach(item => {
      if(currentCat !== 'all' && item.type !== currentCat) return;
      const li = el('li','card');
      const head = el('div','card-head');
      head.appendChild(el('span','badge badge-'+item.type, item.type));
      head.appendChild(el('h4','title', (item.title||'No title')));
      const body = el('div','card-body');
      if(item.address) body.appendChild(el('div','address','📍 '+item.address));
      if(item.category) body.appendChild(el('div','category','🏷 '+item.category));
      const act = el('div','card-act');
      act.appendChild(favButton(item));
      li.appendChild(head); li.appendChild(body); li.appendChild(act);
      ul.appendChild(li);
    });
  }

  async function fetchJSON(url){
    const res = await fetch(url);
    if(!res.ok) throw new Error('HTTP '+res.status);
    return await res.json();
  }

  async function loadNear(lat,lng){
    // 近傍の推奨をまとめ取得（イベント優先＋スポット）
    const u = new URL(rest.replace(/\/$/,'') + '/map/recommendations');
    u.searchParams.set('lat', lat);
    u.searchParams.set('lng', lng);
    u.searchParams.set('limit', 50);
    const rec = await fetchJSON(u.toString());
    renderList(rec);
    drawMarkers(rec);
  }

  function drawMarkers(items){
    const canvas = document.getElementById('roro-map-canvas');
    if(cfg.provider === 'none'){
      canvas.innerHTML = '<div class="placeholder">地図は無効（一覧のみ表示）</div>';
      return;
    }
    if(cfg.provider === 'leaflet' && window.L){
      const map = L.map(canvas).setView([cfg.defaults.lat, cfg.defaults.lng], cfg.defaults.zoom||12);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap' }).addTo(map);
      items.forEach(it => {
        if(typeof it.lat !== 'number' || typeof it.lng !== 'number') return;
        L.marker([it.lat,it.lng]).addTo(map).bindPopup(`<b>${(it.title||'')}</b><br>${it.address||''}`);
      });
      return;
    }
    if(cfg.provider === 'google' && window.google && window.google.maps){
      window.roroMapGoogleInit = function(){}; // 既に初期化済み
      const map = new google.maps.Map(canvas, { center: {lat: Number(cfg.defaults.lat), lng: Number(cfg.defaults.lng)}, zoom: Number(cfg.defaults.zoom)||12 });
      items.forEach(it => {
        if(typeof it.lat !== 'number' || typeof it.lng !== 'number') return;
        const marker = new google.maps.Marker({ position: {lat: it.lat, lng: it.lng}, map });
        const iw = new google.maps.InfoWindow({ content:`<b>${(it.title||'')}</b><br>${it.address||''}` });
        marker.addListener('click', () => iw.open({ anchor: marker, map }));
      });
      return;
    }
    // ここまで来るのはライブラリ未読込。フォールバック
    canvas.innerHTML = '<div class="placeholder">地図ライブラリの読込に失敗しました（一覧のみ）。</div>';
  }

  async function init(){
    // フィルタ chips
    document.querySelectorAll('.roro-map-filters .chip').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        document.querySelectorAll('.roro-map-filters .chip').forEach(b=>b.classList.remove('is-on'));
        btn.classList.add('is-on');
        currentCat = btn.dataset.cat || 'all';
        // 再描画（直近の items は関数スコープ外なので、必要に応じて再取得）
        const ul = document.getElementById('roro-map-list');
        const items = Array.from(ul.querySelectorAll('li.card')).map(li=>{
          return {
            id: Number(li.dataset.id||0),
            type: (li.querySelector('.badge')||{}).textContent || 'event',
            title: (li.querySelector('.title')||{}).textContent || '',
            address: (li.querySelector('.address')||{}).textContent || '',
            category: (li.querySelector('.category')||{}).textContent || ''
          };
        });
        renderList(items); // 既存DOMから再構成
      });
    });

    let lat = Number(cfg.defaults.lat), lng = Number(cfg.defaults.lng);
    try{
      // 1) ユーザーの「自宅」座標（REST）
      const home = await fetchJSON((cfg.restUrl||'').replace(/\/$/,'') + '/mapgeo/home');
      if(home && typeof home.lat === 'number' && typeof home.lng === 'number'){
        lat = home.lat; lng = home.lng;
      }else if (cfg.defaults.geolocation && navigator.geolocation){
        // 2) 端末の現在地（許可されていれば）
        await new Promise((resolve,reject)=>{
          navigator.geolocation.getCurrentPosition(p=>{ lat=p.coords.latitude; lng=p.coords.longitude; resolve(); }, reject, { enableHighAccuracy:true, timeout:5000 });
        });
      }
    }catch(e){ console.warn('geo/home failed',e); }

    await loadNear(lat,lng);
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  }else{
    init();
  }
})();