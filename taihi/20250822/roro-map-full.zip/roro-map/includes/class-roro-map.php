<?php

/**
 * Map functionality for the Roro project.
 *
 * This class registers a shortcode that outputs a container for your map and
 * enqueues a JavaScript file that handles the front‑end map logic. To
 * integrate with Google Maps or other providers, modify the enqueue method
 * to register the appropriate API scripts and implement the JavaScript
 * accordingly.
 *
 * @since 1.0.0
 */
class Roro_Map_Plugin {
    /**
     * Register shortcode and enqueue scripts.
     */
    public function run() {
        add_shortcode( 'roro_map', array( $this, 'render_map' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    /**
     * Output the map container. You may output additional controls here.
     *
     * @return string HTML for the map container.
     */
    public function render_map() {
        $id = 'roro-map-container-' . wp_rand( 1000, 9999 );
        return '<div id="' . esc_attr( $id ) . '" class="roro-map-container" style="width:100%;height:400px;"></div>';
    }

    /**
     * Enqueue front‑end JavaScript and styles.
     */
    public function enqueue_scripts() {
        // Enqueue our own script that handles map initialisation.
        wp_enqueue_script( 'roro-map-js', RORO_MAP_URL . 'assets/js/map.js', array( 'jquery' ), '1.0.0', true );
        // Optionally enqueue CSS for styling the map container.
        wp_enqueue_style( 'roro-map-css', RORO_MAP_URL . 'assets/css/map.css', array(), '1.0.0' );
    }
}