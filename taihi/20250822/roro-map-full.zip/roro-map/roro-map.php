<?php
/**
 * Plugin Name:       Roro Map
 * Plugin URI:        https://example.com/roro-map
 * Description:       Displays Roro-specific locations and events on an interactive map.
 *                    This plugin registers a shortcode to output a map container and
 *                    enqueues the necessary JavaScript. Extend the included class
 *                    to fetch data from your database and integrate with mapping
 *                    APIs such as Google Maps.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-map
 * Domain Path:       /languages
 *
 * @package RoroMap
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_MAP_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_MAP_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_MAP_DIR . 'includes/class-roro-map.php';

function roro_map_run() {
    $map = new Roro_Map_Plugin();
    $map->run();
}
add_action( 'plugins_loaded', 'roro_map_run' );