<?php
/**
 * Plugin Name:       Roro Chatbot
 * Plugin URI:        https://example.com/roro-chatbot
 * Description:       Integrates an AI chatbot into your WordPress site via a shortcode.
 *                    This skeleton implementation defines the shortcode and
 *                    necessary AJAX callbacks. To complete the integration you
 *                    should connect to your chosen AI provider using wp_remote_post()
 *                    and handle authentication securely.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-chatbot
 * Domain Path:       /languages
 *
 * @package RoroChatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_CHATBOT_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_CHATBOT_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_CHATBOT_DIR . 'includes/class-roro-chatbot.php';

function roro_chatbot_run() {
    $bot = new Roro_Chatbot_Plugin();
    $bot->run();
}
add_action( 'plugins_loaded', 'roro_chatbot_run' );