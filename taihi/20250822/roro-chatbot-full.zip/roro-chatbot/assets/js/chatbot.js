/* global roroChatbot, jQuery */
( function ( $ ) {
    'use strict';
    $( function () {
        var $chatbot = $( '.roro-chatbot' );
        if ( ! $chatbot.length ) {
            return;
        }
        $chatbot.on( 'submit', '.roro-chatbot-form', function ( e ) {
            e.preventDefault();
            var $form    = $( this );
            var message  = $form.find( '.roro-chatbot-input' ).val();
            if ( ! message ) {
                return;
            }
            // Append user message to chat box
            var $messages = $chatbot.find( '.roro-chatbot-messages' );
            $messages.append( '<div class="roro-chatbot-message user-message">' + message + '</div>' );
            $form.find( '.roro-chatbot-input' ).val( '' );
            // Send to server
            $.post( roroChatbot.ajaxUrl, {
                action: 'roro_chat',
                nonce:  roroChatbot.nonce,
                message: message
            }, function ( response ) {
                if ( response.success ) {
                    $messages.append( '<div class="roro-chatbot-message bot-message">' + response.data.reply + '</div>' );
                } else {
                    $messages.append( '<div class="roro-chatbot-message error-message">' + response.data.message + '</div>' );
                }
            } );
        } );
    } );
} )( jQuery );