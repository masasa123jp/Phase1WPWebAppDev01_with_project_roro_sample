<?php

/**
 * Chatbot integration for Roro.
 *
 * This class registers a shortcode that renders a simple chat interface and
 * handles AJAX requests to send and receive messages. Replace the stubbed
 * call in handle_chat_request() with actual integration to an AI provider via
 * wp_remote_post().
 *
 * @since 1.0.0
 */
class Roro_Chatbot_Plugin {
    /**
     * Register shortcode and AJAX endpoints.
     */
    public function run() {
        add_shortcode( 'roro_chatbot', array( $this, 'render_chatbot' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_ajax_roro_chat', array( $this, 'handle_chat_request' ) );
        add_action( 'wp_ajax_nopriv_roro_chat', array( $this, 'handle_chat_request' ) );
    }

    /**
     * Enqueue front‑end assets.
     */
    public function enqueue_scripts() {
        wp_enqueue_script( 'roro-chatbot-js', RORO_CHATBOT_URL . 'assets/js/chatbot.js', array( 'jquery' ), '1.0.0', true );
        wp_localize_script( 'roro-chatbot-js', 'roroChatbot', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'roro_chat_action' ),
        ) );
        wp_enqueue_style( 'roro-chatbot-css', RORO_CHATBOT_URL . 'assets/css/chatbot.css', array(), '1.0.0' );
    }

    /**
     * Render the chatbot container.
     *
     * @return string HTML output.
     */
    public function render_chatbot() {
        ob_start();
        ?>
        <div class="roro-chatbot">
            <div class="roro-chatbot-messages"></div>
            <form class="roro-chatbot-form">
                <input type="text" name="message" class="roro-chatbot-input" placeholder="<?php esc_attr_e( 'Type your message…', 'roro-chatbot' ); ?>" />
                <button type="submit">Send</button>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Handle AJAX requests to send a chat message.
     */
    public function handle_chat_request() {
        check_ajax_referer( 'roro_chat_action', 'nonce' );
        $message = sanitize_text_field( $_POST['message'] ?? '' );
        if ( empty( $message ) ) {
            wp_send_json_error( array( 'message' => __( 'Empty message.', 'roro-chatbot' ) ), 400 );
        }
        // Here you would call your AI provider with wp_remote_post(). For now we just echo the message back.
        $response = sprintf( __( 'You said: %s', 'roro-chatbot' ), $message );
        // Optionally store conversation in a custom table.
        wp_send_json_success( array( 'reply' => $response ) );
    }
}