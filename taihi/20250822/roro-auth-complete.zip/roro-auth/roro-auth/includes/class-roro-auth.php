<?php

/**
 * Authentication integration for the Roro platform.
 *
 * This class hooks into WordPress user actions such as registration and login
 * to keep data in sync with the Roro-specific tables. It also registers
 * shortcodes for frontend forms. The actual storage logic has been left
 * intentionally minimal; you should extend the methods with calls to your
 * custom tables via $wpdb->insert/update() or your own data abstraction.
 *
 * @since 1.0.0
 */
class Roro_Auth_Plugin {
    /**
     * Register hooks and shortcodes.
     */
    public function run() {
        add_action( 'user_register', array( $this, 'on_user_register' ), 10, 1 );
        add_action( 'wp_login', array( $this, 'on_user_login' ), 10, 2 );

        add_shortcode( 'roro_register_form', array( $this, 'render_registration_form' ) );
        add_shortcode( 'roro_login_form', array( $this, 'render_login_form' ) );
    }

    /**
     * Synchronise newly created users to the Roro system.
     *
     * @param int $user_id ID of the newly registered user.
     */
    public function on_user_register( $user_id ) {
        // Synchronise the new WordPress user into our Roro customer table.
        $user = get_user_by( 'ID', $user_id );
        if ( ! $user ) {
            return;
        }
        global $wpdb;
        $table = $wpdb->prefix . 'roro_customer';
        // Check if an entry already exists for this WP user.
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE wp_user_id = %d", $user_id ) );
        if ( ! $exists ) {
            $wpdb->insert(
                $table,
                array(
                    'wp_user_id' => $user_id,
                    'name'       => $user->display_name ? $user->display_name : $user->user_login,
                    'email'      => $user->user_email,
                ),
                array( '%d', '%s', '%s' )
            );
        }
    }

    /**
     * Handle user login events.
     *
     * @param string $user_login Username.
     * @param WP_User $user User object.
     */
    public function on_user_login( $user_login, $user ) {
        // Ensure the Roro customer entry exists on login.
        $user_id = $user->ID;
        global $wpdb;
        $table = $wpdb->prefix . 'roro_customer';
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE wp_user_id = %d", $user_id ) );
        if ( ! $exists ) {
            $wpdb->insert(
                $table,
                array(
                    'wp_user_id' => $user_id,
                    'name'       => $user->display_name ? $user->display_name : $user_login,
                    'email'      => $user->user_email,
                ),
                array( '%d', '%s', '%s' )
            );
        }
    }

    /**
     * Render a simple registration form.
     *
     * @return string HTML output.
     */
    public function render_registration_form() {
        if ( is_user_logged_in() ) {
            return '<p>' . esc_html__( 'You are already registered.', 'roro-auth' ) . '</p>';
        }

        if ( isset( $_POST['roro_register_nonce'] ) && wp_verify_nonce( $_POST['roro_register_nonce'], 'roro_register_action' ) ) {
            // Process registration. For a production plugin you should add validation and error handling.
            $username = sanitize_user( $_POST['username'] ?? '' );
            $email    = sanitize_email( $_POST['email'] ?? '' );
            $password = $_POST['password'] ?? '';
            $user_id  = wp_create_user( $username, $password, $email );
            if ( ! is_wp_error( $user_id ) ) {
                // Optionally log the user in and redirect.
                wp_set_current_user( $user_id );
                wp_set_auth_cookie( $user_id );
                $this->on_user_register( $user_id );
                return '<p>' . esc_html__( 'Registration successful.', 'roro-auth' ) . '</p>';
            } else {
                return '<p>' . esc_html( $user_id->get_error_message() ) . '</p>';
            }
        }

        ob_start();
        ?>
        <form method="post" class="roro-register-form">
            <p>
                <label for="roro-username"><?php esc_html_e( 'Username', 'roro-auth' ); ?></label><br />
                <input type="text" name="username" id="roro-username" required />
            </p>
            <p>
                <label for="roro-email"><?php esc_html_e( 'Email', 'roro-auth' ); ?></label><br />
                <input type="email" name="email" id="roro-email" required />
            </p>
            <p>
                <label for="roro-password"><?php esc_html_e( 'Password', 'roro-auth' ); ?></label><br />
                <input type="password" name="password" id="roro-password" required />
            </p>
            <?php wp_nonce_field( 'roro_register_action', 'roro_register_nonce' ); ?>
            <p><input type="submit" value="<?php echo esc_attr__( 'Register', 'roro-auth' ); ?>" /></p>
        </form>
        <?php
        return ob_get_clean();
    }

    /**
     * Render a simple login form.
     *
     * @return string HTML output.
     */
    public function render_login_form() {
        if ( is_user_logged_in() ) {
            return '<p>' . esc_html__( 'You are already logged in.', 'roro-auth' ) . '</p>';
        }

        if ( isset( $_POST['roro_login_nonce'] ) && wp_verify_nonce( $_POST['roro_login_nonce'], 'roro_login_action' ) ) {
            $creds = array(
                'user_login'    => sanitize_user( $_POST['username'] ?? '' ),
                'user_password' => $_POST['password'] ?? '',
                'remember'      => true,
            );
            $user = wp_signon( $creds, false );
            if ( ! is_wp_error( $user ) ) {
                $this->on_user_login( $creds['user_login'], $user );
                return '<p>' . esc_html__( 'Login successful.', 'roro-auth' ) . '</p>';
            } else {
                return '<p>' . esc_html( $user->get_error_message() ) . '</p>';
            }
        }

        ob_start();
        ?>
        <form method="post" class="roro-login-form">
            <p>
                <label for="roro-login-username"><?php esc_html_e( 'Username', 'roro-auth' ); ?></label><br />
                <input type="text" name="username" id="roro-login-username" required />
            </p>
            <p>
                <label for="roro-login-password"><?php esc_html_e( 'Password', 'roro-auth' ); ?></label><br />
                <input type="password" name="password" id="roro-login-password" required />
            </p>
            <?php wp_nonce_field( 'roro_login_action', 'roro_login_nonce' ); ?>
            <p><input type="submit" value="<?php echo esc_attr__( 'Login', 'roro-auth' ); ?>" /></p>
        </form>
        <?php
        return ob_get_clean();
    }
}