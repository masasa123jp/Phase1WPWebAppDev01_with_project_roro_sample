<?php
/**
 * Plugin Name:       Roro Authentication
 * Plugin URI:        https://example.com/roro-auth
 * Description:       Handles registration and login synchronization between WordPress and
 *                    the Roro platform. This plugin demonstrates how to hook into
 *                    WordPress user actions and synchronise data to a custom database
 *                    schema. It includes basic shortcodes for registration and login
 *                    forms. Security best practices such as nonce verification and
 *                    sanitization are observed where applicable.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-auth
 * Domain Path:       /languages
 *
 * @package RoroAuth
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_AUTH_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_AUTH_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_AUTH_DIR . 'includes/class-roro-auth.php';

// Initialize plugin after all plugins loaded.
function roro_auth_run() {
    $roro_auth = new Roro_Auth_Plugin();
    $roro_auth->run();
}
add_action( 'plugins_loaded', 'roro_auth_run' );