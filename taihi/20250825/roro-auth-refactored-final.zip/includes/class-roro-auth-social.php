<?php
/**
 * Stub implementation for social account management.
 *
 * In a future release this file can be expanded to handle linking and
 * unlinking of Google or LINE accounts.  For now it simply registers
 * a shortcode that informs the user that social logins are not yet
 * available.  Keeping a class definition here prevents fatal errors
 * if themes or other plugins reference Roro_Auth_Social.
 */
class Roro_Auth_Social {
    /**
     * Register the shortcode on init.  Called automatically when
     * the file is included by the main plugin.
     */
    public static function init(): void {
        add_shortcode('roro_social_links', [__CLASS__, 'render_stub']);
    }

    /**
     * Shortcode callback which returns a placeholder message.
     *
     * @return string
     */
    public static function render_stub(): string {
        if (!is_user_logged_in()) {
            return '<p>' . esc_html(Roro_Auth_I18n::t('signin_required')) . '</p>';
        }
        return '<p>' . esc_html(Roro_Auth_I18n::t('social_not_implemented')) . '</p>';
    }
}

// Initialise immediately to register the shortcode.
Roro_Auth_Social::init();