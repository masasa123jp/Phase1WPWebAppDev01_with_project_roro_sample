<?php
/**
 * Stub LINE provider for RORO Auth.
 *
 * Renders a disabled LINE login button via shortcode.  A complete
 * implementation would handle OAuth flows and user linking.  Until
 * then this stub prevents errors when shortcodes are used.
 */
class Roro_Auth_Provider_Line {
    public static function init(): void {
        add_shortcode('roro_line_login_button', [__CLASS__, 'render_button']);
    }
    public static function render_button(): string {
        $label = esc_html(Roro_Auth_I18n::t('login_with_line'));
        $title = esc_attr(Roro_Auth_I18n::t('provider_disabled'));
        $html  = '<button type="button" class="roro-btn roro-btn--line" disabled aria-disabled="true" title="' . $title . '">';
        $html .= '<span class="roro-label">' . $label . '</span>';
        $html .= '</button>';
        $html .= '<div class="roro-help">' . esc_html(Roro_Auth_I18n::t('provider_not_supported')) . '</div>';
        return $html;
    }
}

Roro_Auth_Provider_Line::init();