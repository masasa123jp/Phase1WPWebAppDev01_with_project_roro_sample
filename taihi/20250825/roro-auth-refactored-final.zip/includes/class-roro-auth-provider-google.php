<?php
/**
 * Stub Google provider for RORO Auth.
 *
 * Provides a shortcode that renders a disabled Google login button.  The
 * intention is to swap this stub out for a full implementation in a
 * future release.  Including this file prevents fatal errors when
 * referenced by themes or other plugins.
 */
class Roro_Auth_Provider_Google {
    /**
     * Hook into WordPress.  Registers the shortcode.
     */
    public static function init(): void {
        add_shortcode('roro_google_login_button', [__CLASS__, 'render_button']);
    }

    /**
     * Render a disabled Google login button.
     *
     * @return string
     */
    public static function render_button(): string {
        $label = esc_html(Roro_Auth_I18n::t('login_with_google'));
        $title = esc_attr(Roro_Auth_I18n::t('provider_disabled'));
        $html  = '<button type="button" class="roro-btn roro-btn--google" disabled aria-disabled="true" title="' . $title . '">';
        $html .= '<span class="roro-label">' . $label . '</span>';
        $html .= '</button>';
        $html .= '<div class="roro-help">' . esc_html(Roro_Auth_I18n::t('provider_not_supported')) . '</div>';
        return $html;
    }
}

Roro_Auth_Provider_Google::init();