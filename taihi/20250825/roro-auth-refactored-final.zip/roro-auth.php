<?php
/**
 * Plugin Name: RORO Auth (Refactored)
 * Description: Provides user authentication, registration and profile management with support for multiple languages.  Shortcodes render accessible forms for login, sign‑up and profile editing and REST endpoints handle the server side logic.  Basic social login scaffolding is included for future expansion.
 * Version: 1.0.0
 * Author: Project RORO
 * Text Domain: roro-auth
 * Domain Path: /lang
 */

// Abort if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants for easy path and URL access.
if (!defined('RORO_AUTH_REF_VER')) {
    define('RORO_AUTH_REF_VER', '1.0.0');
}
if (!defined('RORO_AUTH_REF_DIR')) {
    define('RORO_AUTH_REF_DIR', plugin_dir_path(__FILE__));
}
if (!defined('RORO_AUTH_REF_URL')) {
    define('RORO_AUTH_REF_URL', plugin_dir_url(__FILE__));
}

// Bootstrap functions and classes.
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-i18n.php';
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-pets.php';
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-rest.php';
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-shortcodes.php';

// Optionally load social login scaffolding.  These files safely declare their own classes.
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-social.php';
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-provider-google.php';
require_once RORO_AUTH_REF_DIR . 'includes/class-roro-auth-provider-line.php';

/**
 * Initialise the plugin.
 *
 * We hook into plugins_loaded rather than directly executing logic so that other plugins
 * (for example, RORO Core WP) can load first.  During initialisation we:
 *  - Load our translation arrays to make __() style calls available via Roro_Auth_I18n::t().
 *  - Register REST endpoints for authentication, registration and profile management.
 *  - Register shortcodes for rendering login, sign‑up and profile forms.
 */
add_action('plugins_loaded', function () {
    // Load i18n messages into memory.  This call will detect the current locale
    // and merge in the appropriate language file.  It falls back to English.
    Roro_Auth_I18n::load_messages();

    // Register REST endpoints.
    (new Roro_Auth_REST())->register_routes();

    // Register shortcodes for forms.  These shortcodes also enqueue scripts
    // and styles as necessary.
    Roro_Auth_Shortcodes::register();
});

/**
 * When the plugin is activated we can perform one‑time setup tasks.  Currently
 * there is no migration logic required, however this hook is kept for future
 * expansion (such as creating custom database tables or options).
 */
register_activation_hook(__FILE__, function () {
    // Placeholder for future migration tasks.
});

/**
 * Clean up on deactivation.  We deliberately do not remove any user data here.  
 * Authentication cookies and transients expire naturally.
 */
register_deactivation_hook(__FILE__, function () {
    // Nothing to do on deactivation at this time.
});