<?php
/**
 * Plugin Name: RORO Map Filters & Events
 * Description: カテゴリ/期間/距離フィルタのREST、イベント詳細テンプレ、主催者送信UIを実装。
 * Version: 1.0.0
 * Author: Project RORO
 * Text Domain: roro
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) { exit; }

class RORO_Map_Filters {
    const CPT_EVENT = 'roro_event';
    const CPT_PLACE = 'roro_place';

    public function __construct() {
        add_action('init', [$this, 'load_textdomain']);
        add_action('init', [$this, 'register_cpt']);
        add_action('rest_api_init', [$this, 'register_rest']);
        add_shortcode('roro_map', [$this, 'sc_map']);
        add_shortcode('roro_event_submit', [$this, 'sc_submit']);
        add_shortcode('roro_event_detail', [$this, 'sc_detail']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
    }

    public function load_textdomain() {
        load_plugin_textdomain('roro', false, dirname(plugin_basename(__FILE__)).'/languages');
    }

    public function register_cpt() {
        register_post_type(self::CPT_EVENT, [
            'label' => __('Event', 'roro'),
            'public' => true,
            'has_archive' => true,
            'show_in_rest' => true,
            'supports' => ['title','editor','thumbnail','excerpt'],
        ]);
        register_post_type(self::CPT_PLACE, [
            'label' => __('Place', 'roro'),
            'public' => true,
            'has_archive' => true,
            'show_in_rest' => true,
            'supports' => ['title','editor','thumbnail','excerpt'],
        ]);
        // Meta for geo/time
        register_post_meta(self::CPT_EVENT, 'roro_start', ['type'=>'string','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'sanitize_text_field']);
        register_post_meta(self::CPT_EVENT, 'roro_end',   ['type'=>'string','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'sanitize_text_field']);
        foreach ([self::CPT_EVENT,self::CPT_PLACE] as $cpt) {
            register_post_meta($cpt, 'roro_lat', ['type'=>'number','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'floatval']);
            register_post_meta($cpt, 'roro_lng', ['type'=>'number','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'floatval']);
            register_post_meta($cpt, 'roro_cat', ['type'=>'string','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'sanitize_text_field']);
        }
    }

    public function enqueue() {
        $h='roro-map-ui';
        wp_register_script($h, plugins_url('assets/js/roro-map-ui.js', __FILE__), ['wp-i18n'], '1.0.0', true);
        wp_localize_script($h, 'roroMap', [
            'rest' => esc_url_raw(rest_url('roro/v1')),
            'nonce'=> wp_create_nonce('wp_rest'),
        ]);
        wp_set_script_translations($h, 'roro', plugin_dir_path(__FILE__).'languages');
    }

    public function register_rest() {
        register_rest_route('roro/v1', '/map/search', [
            'methods'  => 'GET',
            'callback' => [$this, 'rest_search'],
            'permission_callback' => '__return_true',
            'args' => [
                'lat'=>['required'=>false], 'lng'=>['required'=>false],
                'distance'=>['required'=>false, 'default'=>50],
                'category'=>['required'=>false, 'default'=>''],
                'from'=>['required'=>false], 'to'=>['required'=>false],
                'type'=>['required'=>false, 'default'=>'all'], // event|place|all
                'page'=>['required'=>false, 'default'=>1],
            ]
        ]);
        register_rest_route('roro/v1', '/events', [
            'methods'=>'POST',
            'callback'=>[$this,'rest_create_event'],
            'permission_callback'=>function(){ return is_user_logged_in(); },
            'args'=>[
                'title'=>['required'=>true], 'content'=>['required'=>false],
                'roro_start'=>['required'=>true], 'roro_end'=>['required'=>true],
                'roro_lat'=>['required'=>true], 'roro_lng'=>['required'=>true],
                'roro_cat'=>['required'=>false],
            ],
        ]);
    }

    public function sc_map($atts=[]) {
        wp_enqueue_script('roro-map-ui');
        ob_start(); ?>
        <div class="roro-map-filter" data-rest="<?php echo esc_attr(rest_url('roro/v1')); ?>">
            <label><?php echo esc_html(__('Category', 'roro')); ?>
                <input type="text" id="roro-cat">
            </label>
            <label><?php echo esc_html(__('Date range', 'roro')); ?>
                <input type="date" id="roro-from"> – <input type="date" id="roro-to">
            </label>
            <label><?php echo esc_html(__('Distance (km)', 'roro')); ?>
                <input type="number" id="roro-distance" value="50" min="1" max="300">
            </label>
            <label><?php echo esc_html(__('Type', 'roro')); ?>
                <select id="roro-type">
                    <option value="all"><?php echo esc_html(__('All types', 'roro')); ?></option>
                    <option value="event"><?php echo esc_html(__('Event', 'roro')); ?></option>
                    <option value="place"><?php echo esc_html(__('Place', 'roro')); ?></option>
                </select>
            </label>
            <button id="roro-apply" class="button button-primary"><?php echo esc_html(__('Apply filters', 'roro')); ?></button>
            <button id="roro-clear" class="button"><?php echo esc_html(__('Clear filters', 'roro')); ?></button>
            <div id="roro-results" role="list" aria-live="polite"></div>
        </div>
        <?php return ob_get_clean();
    }

    public function sc_submit() {
        if (!is_user_logged_in()) {
            return '<p>'.esc_html(__('You must be logged in.', 'roro')).'</p>';
        }
        wp_enqueue_script('roro-map-ui');
        ob_start(); ?>
        <form id="roro-event-submit" class="roro-event-submit" novalidate>
            <h3><?php echo esc_html(__('Submit event', 'roro')); ?></h3>
            <label><?php echo esc_html(__('Title', 'roro')); ?><input type="text" name="title" required></label>
            <label><?php echo esc_html(__('Description', 'roro')); ?><textarea name="content"></textarea></label>
            <label><?php echo esc_html(__('Start date', 'roro')); ?><input type="datetime-local" name="roro_start" required></label>
            <label><?php echo esc_html(__('End date', 'roro')); ?><input type="datetime-local" name="roro_end" required></label>
            <label><?php echo esc_html(__('Category', 'roro')); ?><input type="text" name="roro_cat"></label>
            <label><?php echo esc_html(__('Latitude', 'roro')); ?><input type="number" name="roro_lat" step="0.000001" required></label>
            <label><?php echo esc_html(__('Longitude', 'roro')); ?><input type="number" name="roro_lng" step="0.000001" required></label>
            <button class="button button-primary" type="submit"><?php echo esc_html(__('Create', 'roro')); ?></button>
            <span class="status" aria-live="polite"></span>
        </form>
        <?php return ob_get_clean();
    }

    public function sc_detail($atts=[]) {
        $atts = shortcode_atts(['id'=>0], $atts);
        $post = get_post(intval($atts['id']));
        if (!$post || $post->post_type !== self::CPT_EVENT) {
            return '<p>'.esc_html(__('Event not found.', 'roro')).'</p>';
        }
        $start = get_post_meta($post->ID, 'roro_start', true);
        $end   = get_post_meta($post->ID, 'roro_end', true);
        $lat   = get_post_meta($post->ID, 'roro_lat', true);
        $lng   = get_post_meta($post->ID, 'roro_lng', true);
        $cat   = get_post_meta($post->ID, 'roro_cat', true);
        ob_start(); ?>
        <article class="roro-event-detail">
            <h2><?php echo esc_html(get_the_title($post)); ?></h2>
            <p><?php echo esc_html($cat); ?></p>
            <p><?php echo esc_html(sprintf(__('From %1$s to %2$s', 'roro'), $start, $end)); ?></p>
            <p><?php echo esc_html(sprintf(__('Lat: %1$s, Lng: %2$s', 'roro'), $lat, $lng)); ?></p>
            <div class="content"><?php echo wp_kses_post(apply_filters('the_content', $post->post_content)); ?></div>
        </article>
        <?php return ob_get_clean();
    }

    public function rest_create_event(WP_REST_Request $req) {
        $uid = get_current_user_id();
        if (!current_user_can('edit_posts')) {
            // Allow logged-in organizers with limited caps as well
        }
        $title = sanitize_text_field($req['title']);
        $content = wp_kses_post($req['content']);
        $p = wp_insert_post([
            'post_type' => self::CPT_EVENT,
            'post_title'=> $title,
            'post_content'=> $content,
            'post_status'=> 'publish',
            'post_author'=> $uid,
        ], true);
        if (is_wp_error($p)) { return $p; }
        foreach (['roro_start','roro_end','roro_lat','roro_lng','roro_cat'] as $m) {
            update_post_meta($p, $m, sanitize_text_field($req[$m]));
        }
        return ['ok'=>true,'id'=>$p,'message'=>__('Event saved', 'roro')];
    }

    public function rest_search(WP_REST_Request $req) {
        $lat = $req->get_param('lat'); $lng = $req->get_param('lng');
        $distance = floatval($req->get_param('distance'));
        $cat = sanitize_text_field($req->get_param('category'));
        $from = $req->get_param('from'); $to = $req->get_param('to');
        $type = sanitize_key($req->get_param('type'));
        $page = max(1, intval($req->get_param('page')));

        $types = ($type==='event'||$type==='place') ? [$type] : ['event','place'];
        $per  = 20;
        $items = [];

        foreach ($types as $t) {
            $cpt = $t==='event' ? self::CPT_EVENT : self::CPT_PLACE;
            $args = [
                'post_type' => $cpt,
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'suppress_filters' => false,
                'meta_query' => [],
            ];
            if ($cat) {
                $args['meta_query'][] = ['key'=>'roro_cat','value'=>$cat,'compare'=>'LIKE'];
            }
            $posts = get_posts($args);
            foreach ($posts as $p) {
                $plat = floatval(get_post_meta($p->ID,'roro_lat',true));
                $plng = floatval(get_post_meta($p->ID,'roro_lng',true));
                $km = ($lat && $lng) ? $this->haversine($lat,$lng,$plat,$plng) : null;

                if ($distance && $km !== null && $km > $distance) { continue; }

                if ($t==='event' && ($from || $to)) {
                    $start = strtotime(get_post_meta($p->ID,'roro_start',true) ?: 'now');
                    $end   = strtotime(get_post_meta($p->ID,'roro_end',true)   ?: 'now');
                    if ($from && $start < strtotime($from)) { continue; }
                    if ($to   && $end   > strtotime($to))   { continue; }
                }
                $items[] = [
                    'id'=>$p->ID,
                    'type'=>$t,
                    'title'=>get_the_title($p),
                    'excerpt'=>wp_strip_all_tags(get_the_excerpt($p)),
                    'lat'=>$plat, 'lng'=>$plng,
                    'distance_km'=>$km,
                    'category'=>get_post_meta($p->ID,'roro_cat',true),
                    'url'=>get_permalink($p),
                ];
            }
        }
        // Simple pagination after filtering
        usort($items, function($a,$b){
            $da = $a['distance_km'] ?? 0; $db = $b['distance_km'] ?? 0;
            return $da <=> $db;
        });
        $total = count($items);
        $items = array_slice($items, ($page-1)*$per, $per);
        return [
            'items'=>$items,
            'total'=>$total,
            'page'=>$page,
            'per_page'=>$per,
        ];
    }

    private function haversine($lat1,$lon1,$lat2,$lon2) {
        $R=6371; $dLat=deg2rad($lat2-$lat1); $dLon=deg2rad($lon2-$lon1);
        $a=sin($dLat/2)*sin($dLat/2)+cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLon/2)*sin($dLon/2);
        return $R*2*atan2(sqrt($a), sqrt(1-$a));
    }
}
new RORO_Map_Filters();
