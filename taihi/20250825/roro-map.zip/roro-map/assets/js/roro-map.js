// roro-map.js: イベント地図の描画用スクリプト
var map;  // Google Map オブジェクト（グローバル変数として保持）
function initMap() {
    // マップ初期設定
    var defaultCenter = { lat: 35.681236, lng: 139.767125 };  // デフォルトの中心座標（東京駅）
    var defaultZoom = 12;
    // 必要に応じて設定オブジェクトから初期中心座標やズームを取得
    if (window.roroMapConfig && window.roroMapConfig.initialCenter) {
        defaultCenter = window.roroMapConfig.initialCenter;
    }
    if (window.roroMapConfig && window.roroMapConfig.initialZoom) {
        defaultZoom = window.roroMapConfig.initialZoom;
    }
    // Googleマップオブジェクトの作成
    map = new google.maps.Map(document.getElementById('roro-events-map'), {
        center: defaultCenter,
        zoom: defaultZoom
    });

    // 設定オブジェクトにイベントリストがあればマーカーを追加
    if (window.roroMapConfig && window.roroMapConfig.events) {
        window.roroMapConfig.events.forEach(function(evt) {
            new google.maps.Marker({
                position: evt.latLng,
                map: map,
                title: evt.title || ''
            });
        });
    }

    // Geolocation機能: フラグがtrueの場合のみ現在地に地図中心を切り替え
    if (window.roroMapConfig && window.roroMapConfig.enableGeolocation) {
        // フォールバック用の座標（東京駅）
        var fallbackPos = { lat: 35.681236, lng: 139.767125 };  /* Geolocation非対応やユーザー拒否時の代替座標 */
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    // 現在地の取得に成功: 地図の中心を現在地に設定
                    var currentPos = { lat: position.coords.latitude, lng: position.coords.longitude };
                    map.setCenter(currentPos);
                },
                function(error) {
                    // 現在地の取得に失敗またはユーザーが許可しなかった: フォールバック座標を設定
                    map.setCenter(fallbackPos);
                }
            );
        } else {
            // ブラウザがGeolocation API未対応: フォールバック座標を設定
            map.setCenter(fallbackPos);
        }
    }
}
