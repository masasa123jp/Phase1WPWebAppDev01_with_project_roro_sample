/* global RORO_MAP, wp */
(function () {
  const { __ } = wp.i18n;
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));

  async function query(params) {
    const url = new URL(RORO_MAP.rest);
    Object.entries(params).forEach(([k, v]) => { if (v) url.searchParams.set(k, v); });
    const res = await fetch(url.toString(), { credentials: 'same-origin' });
    if (!res.ok) throw new Error('search');
    return res.json();
  }

  function card(item) {
    const d = item.distance != null ? ` · ${item.distance.toFixed(1)} ${__('km', 'roro')}` : '';
    const time = [item.start, item.end].filter(Boolean).join(' – ');
    return `
      <article class="roro-card">
        <h3><a href="${item.permalink}">${item.title}</a></h3>
        <p class="roro-meta">${item.category || ''}${d}</p>
        <p class="roro-time">${time}</p>
        <p>${item.excerpt || ''}</p>
      </article>
    `;
  }

  function busy(el, on) { el.setAttribute('aria-busy', on ? 'true' : 'false'); }

  async function init() {
    const form = $('#roro-map-form');
    const results = $('#roro-map-results');
    if (!form || !results) return;

    // 測位（距離フィルタ用：ユーザー許可があれば初期値）
    navigator.geolocation?.getCurrentPosition(
      (pos) => {
        form.dataset.lat = String(pos.coords.latitude);
        form.dataset.lng = String(pos.coords.longitude);
      },
      () => { /* ignore */ },
      { maximumAge: 600000, timeout: 2000 }
    );

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      busy(results, true);
      results.textContent = RORO_MAP.strings.loading;
      const fd = new FormData(form);
      const params = Object.fromEntries(fd.entries());
      if (form.dataset.lat && form.dataset.lng) {
        params.lat = form.dataset.lat;
        params.lng = form.dataset.lng;
      }
      try {
        const json = await query(params);
        if (!json.items?.length) {
          results.textContent = RORO_MAP.strings.noResults;
        } else {
          results.innerHTML = json.items.map(card).join('');
        }
      } catch (err) {
        results.textContent = __('Search failed.', 'roro');
      } finally {
        busy(results, false);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
