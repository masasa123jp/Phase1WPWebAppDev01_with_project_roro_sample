/* global jQuery, RORO_MAP_I18N, navigator */
(function($){
  'use strict';

  var $form = $('.roro-map-filters');
  var $res  = $('#roro-map-results');

  function renderItem(item) {
    var $card = $('<article/>', { class: 'roro-card', role: 'listitem' });
    $('<h3/>').text(item.title).appendTo($card);
    $('<p/>').text(item.date_text || '').appendTo($card);
    $('<p/>').text(item.address || '').appendTo($card);
    var $a = $('<a/>', { href: item.permalink, text: 'Details' });
    $card.append($a);
    return $card;
  }

  function fetchCategories() {
    $.getJSON('/wp-json/roro/v1/event-categories')
      .done(function (json) {
        var $cat = $form.find('select[name="category"]').empty();
        $('<option/>', { value: '', text: RORO_MAP_I18N.category }).appendTo($cat);
        (json.items || []).forEach(function (c) {
          $('<option/>', { value: c.id, text: c.name }).appendTo($cat);
        });
      });
  }

  function search(params) {
    $res.empty();
    $('<p/>').text('...').appendTo($res);

    // Geolocation (optional)
    var geoPromise = $.Deferred().resolve({lat:null,lng:null}).promise();
    if (navigator.geolocation) {
      geoPromise = $.Deferred(function (dfd) {
        navigator.geolocation.getCurrentPosition(function(pos){
          dfd.resolve({lat: pos.coords.latitude, lng: pos.coords.longitude});
        }, function(){
          dfd.resolve({lat:null,lng:null});
        });
      }).promise();
    }

    geoPromise.then(function (g) {
      var q = {
        q: params.q || '',
        category: params.category || '',
        from: params.from || '',
        to: params.to || '',
        distance_km: params.distance || 10
      };
      if (g.lat && g.lng) {
        q.lat = g.lat; q.lng = g.lng;
      }
      $.getJSON('/wp-json/roro/v1/events', q)
        .done(function(json){
          $res.empty();
          if (!json.items || json.items.length === 0) {
            $('<p/>').text(RORO_MAP_I18N.noResults).appendTo($res);
            return;
          }
          json.items.forEach(function(it){
            $res.append(renderItem(it));
          });
        })
        .fail(function(){
          $res.empty().append($('<p/>').text('Error'));
        });
    });
  }

  $form.on('submit', function(e){
    e.preventDefault();
    var fd = new FormData(this);
    search({
      q: fd.get('q'),
      category: fd.get('category'),
      distance: fd.get('distance'),
      from: fd.get('from'),
      to: fd.get('to')
    });
  });

  $(function(){
    fetchCategories();
  });

})(jQuery);
