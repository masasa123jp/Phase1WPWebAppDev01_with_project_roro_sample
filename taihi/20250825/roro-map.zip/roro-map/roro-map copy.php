<?php
/**
 * Plugin Name: Roro Map
 * Description: 位置情報に基づくお店・イベントの検索UI（カテゴリ/期間/距離フィルタ）、主催者入力UI、イベント詳細テンプレ。
 * Version: 0.6.0
 * Text Domain: roro
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_MAP_DIR', plugin_dir_path(__FILE__));
define('RORO_MAP_URL', plugin_dir_url(__FILE__));

require_once RORO_MAP_DIR . 'includes/class-roro-map-rest.php';
require_once RORO_MAP_DIR . 'includes/class-roro-map-admin.php';

add_action('init', function () {
    load_plugin_textdomain('roro', false, dirname(plugin_basename(__FILE__)) . '/languages');

    // CPT: イベント（必要最小限）
    register_post_type('roro_event', [
        'labels' => [
            'name' => __('Events', 'roro'),
            'singular_name' => __('Event', 'roro'),
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
    ]);
});

add_action('rest_api_init', function () {
    (new Roro_Map_REST())->register_routes();
});

add_action('wp_enqueue_scripts', function () {
    wp_register_script('roro-map-search', RORO_MAP_URL . 'assets/js/map-search.js', ['wp-i18n'], '0.6.0', true);
    wp_localize_script('roro-map-search', 'RORO_MAP', [
        'rest' => esc_url_raw(rest_url('roro/v1/map/search')),
        'strings' => [
            'search' => __('Search', 'roro'),
            'loading' => __('Loading...', 'roro'),
            'noResults' => __('No results found.', 'roro'),
            'distanceUnitKm' => __('km', 'roro'),
        ],
    ]);
    wp_set_script_translations('roro-map-search', 'roro');
});

// ショートコード：検索フォーム + 結果プレースホルダ
add_shortcode('roro_map', function () {
    wp_enqueue_script('roro-map-search');
    ob_start(); ?>
    <form id="roro-map-form" class="roro-map-form" aria-label="<?php echo esc_attr__('Search events and places', 'roro'); ?>">
      <label><?php echo esc_html__('Category', 'roro'); ?>
        <select name="category">
          <option value=""><?php echo esc_html__('All', 'roro'); ?></option>
          <option value="event"><?php echo esc_html__('Event', 'roro'); ?></option>
          <option value="shop"><?php echo esc_html__('Shop', 'roro'); ?></option>
          <option value="park"><?php echo esc_html__('Park', 'roro'); ?></option>
        </select>
      </label>
      <label><?php echo esc_html__('Period', 'roro'); ?>
        <select name="period">
          <option value="any"><?php echo esc_html__('Anytime', 'roro'); ?></option>
          <option value="today"><?php echo esc_html__('Today', 'roro'); ?></option>
          <option value="week"><?php echo esc_html__('This week', 'roro'); ?></option>
          <option value="month"><?php echo esc_html__('This month', 'roro'); ?></option>
        </select>
      </label>
      <label><?php echo esc_html__('Distance', 'roro'); ?>
        <select name="distance">
          <option value="0"><?php echo esc_html__('Anywhere', 'roro'); ?></option>
          <option value="5">5km</option>
          <option value="10">10km</option>
          <option value="25">25km</option>
          <option value="50">50km</option>
        </select>
      </label>
      <button type="submit" class="button button-primary"><?php echo esc_html__('Search', 'roro'); ?></button>
    </form>
    <div id="roro-map-results" class="roro-map-results" aria-live="polite" aria-busy="false"></div>
    <?php return ob_get_clean();
});

