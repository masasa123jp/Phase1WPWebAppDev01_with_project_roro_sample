<?php
/**
 * 地図検索／フィルタリング機能。
 *
 * カテゴリ・期間・距離の条件を受け取り、イベント一覧の取得に反映する。
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Roro_Map_Filter {

    public static function init() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'register_rest' ) );
    }

    public static function enqueue_scripts() {
        // フロントエンド用の JS/CSS を読み込み。多言語対応のラベルは localized script で渡す。
        wp_enqueue_script(
            'roro-map-search',
            plugins_url( '../assets/js/map-search.js', __FILE__ ),
            array( 'jquery' ),
            '1.0.0',
            true
        );
        wp_localize_script(
            'roro-map-search',
            'roroMapLabels',
            array(
                'search'    => __( '検索', 'roro-map' ),
                'category'  => __( 'カテゴリ', 'roro-map' ),
                'distance'  => __( '距離', 'roro-map' ),
                'period'    => __( '期間', 'roro-map' ),
                'noResult'  => __( '該当するイベントはありません。', 'roro-map' ),
            )
        );
    }

    public static function register_rest() {
        register_rest_route( 'roro-map/v1', '/events', array(
            'methods'  => 'GET',
            'callback' => array( __CLASS__, 'get_events' ),
            'permission_callback' => '__return_true',
        ) );
    }

    /**
     * フィルタ条件に基づいてイベントを取得。
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function get_events( WP_REST_Request $request ) {
        $category = sanitize_text_field( $request['category'] ?? '' );
        $distance = floatval( $request['distance'] ?? 0 );
        $start    = sanitize_text_field( $request['start'] ?? '' );
        $end      = sanitize_text_field( $request['end'] ?? '' );

        $args = array(
            'post_type'      => 'roro_event',
            'posts_per_page' => -1,
        );

        // カテゴリで絞り込み
        if ( $category ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'roro_event_cat',
                    'field'    => 'slug',
                    'terms'    => $category,
                ),
            );
        }

        // 日付範囲で絞り込み
        if ( $start || $end ) {
            $args['meta_query'][] = array(
                'key'     => 'event_date',
                'value'   => array( $start, $end ),
                'compare' => 'BETWEEN',
                'type'    => 'DATE',
            );
        }

        // 位置情報／距離はカスタムフィールドに保存されていると仮定し、近い順に絞り込む例
        if ( $distance ) {
            // geodata ライブラリや SQL の Haversine 式を使って距離計算を行う処理を実装する
            // ここでは簡略化のためコメントのみ
        }

        $query = new WP_Query( $args );
        $events = array();
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $events[] = array(
                    'id'       => get_the_ID(),
                    'title'    => get_the_title(),
                    'permalink'=> get_permalink(),
                    'date'     => get_post_meta( get_the_ID(), 'event_date', true ),
                    'category' => $category,
                    // 座標や説明など他の項目も追加可能
                );
            }
        }
        wp_reset_postdata();

        return rest_ensure_response( $events );
    }
}

Roro_Map_Filter::init();
