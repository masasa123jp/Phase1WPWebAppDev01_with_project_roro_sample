<?php
/**
 * イベントマップ（roro-map）
 * - Google Maps APIキーと現在地検出フラグは roro-core-wp の設定から読込
 * - ハイライト（?highlight_event / ?highlight_spot）に対応
 */
defined('ABSPATH') || exit;

$opt = (array) get_option('roro_core_settings', []);
$api_key = isset($opt['map_api_key']) ? (string)$opt['map_api_key'] : '';
$enable_geo = !empty($opt['enable_geolocation']) ? true : false;

// 表示用のイベント配列（ここでは例。実際はRESTで動的取得でもOK）
$events = apply_filters('roro_map_events_bootstrap', []); // 期待: [ ['id'=>..., 'type'=>'event','latLng'=>['lat'=>..,'lng'=>..],'title'=>'...'], ... ]

wp_enqueue_script('roro-map-js', plugins_url('../assets/js/roro-map.js', __FILE__), [], '1.1.0', true);
wp_localize_script('roro-map-js', 'roroMapConfig', [
    'enableGeolocation' => $enable_geo ? true : false,
    'initialCenter'     => ['lat'=>35.681236,'lng'=>139.767125],
    'initialZoom'       => 12,
    'events'            => $events,
]);

?>
<div id="roro-events-map" style="width:100%;height:540px;"></div>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr($api_key); ?>&callback=initMap" async defer></script>
