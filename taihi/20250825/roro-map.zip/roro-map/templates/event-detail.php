<?php
/**
 * イベント詳細テンプレート。
 *
 * テーマ互換用にテンプレートパーツとして読み込まれる想定。
 * i18n を考慮し、タイトルや開催日時などを翻訳可能にする。
 */

get_header(); ?>

<div class="roro-event-detail">
    <?php while ( have_posts() ) : the_post(); ?>
        <h1><?php the_title(); ?></h1>
        <p class="event-date">
            <?php
            $date = get_post_meta( get_the_ID(), 'event_date', true );
            echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $date ) ) );
            ?>
        </p>
        <div class="event-content">
            <?php the_content(); ?>
        </div>
        <a class="button" href="<?php echo esc_url( get_post_type_archive_link( 'roro_event' ) ); ?>">
            <?php esc_html_e( 'イベント一覧へ戻る', 'roro-map' ); ?>
        </a>
    <?php endwhile; ?>
</div>

<?php get_footer();
