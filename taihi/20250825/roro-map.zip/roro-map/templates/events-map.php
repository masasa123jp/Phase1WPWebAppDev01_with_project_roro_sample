<?php
/**
 * イベントマップ表示用テンプレート (roro-map)
 * Googleマップ上にイベント情報を表示
 */
?>
<div id="roro-events-map" style="width: 100%; height: 500px;"></div>
<?php
    // PHPからJSへ設定値(enable_geolocation)を渡す
    $enable_geolocation = get_option('roro_core_enable_geolocation', 0);
?>
<script type="text/javascript">
    // 現在地検出機能のフラグをJavaScriptに設定
    window.roroMapConfig = window.roroMapConfig || {};
    window.roroMapConfig.enableGeolocation = <?php echo ($enable_geolocation ? 'true' : 'false'); ?>;
</script>
<?php
    // （以下、Google Maps APIおよびマップ描画用のJSを読み込む）
    // ※ 実際の実装では、wp_enqueue_scriptを用いてスクリプトを読み込みます
?>
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async defer></script>
<script src="<?php echo plugins_url('assets/js/roro-map.js', __FILE__); ?>"></script>
