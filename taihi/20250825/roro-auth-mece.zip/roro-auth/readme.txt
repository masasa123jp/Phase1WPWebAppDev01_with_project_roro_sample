=== RORO Auth (MECE Integrated) ===
Contributors: roro-team
Tags: social, login, oauth, google, line
Requires at least: 6.1
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.6.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

OAuth2 social login for Google and LINE. Multi-language JS (ja/en/zh/ko).
Clean MECE separation (utils, providers, admin, main).

== Shortcodes ==
[roro_auth_buttons redirect_to="https://example.com/after-login"]

== Installation ==
1. Upload the plugin folder `roro-auth` to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' screen.
3. Go to Settings > RORO Auth and configure Provider credentials.
4. Add `[roro_auth_buttons]` to your login page or any page.

== Changelog ==
= 1.6.1 =
* Initial MECE-integrated release.
