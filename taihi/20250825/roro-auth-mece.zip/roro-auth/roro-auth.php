<?php
/**
 * Plugin Name: RORO Auth (MECE Integrated)
 * Plugin URI:  https://example.com/roro
 * Description: Google/LINE OAuth2 Social Login with multi-language JS, robust state/nonce, admin settings, and clean MECE module separation.
 * Version:     1.6.1
 * Author:      RORO Team
 * License:     GPLv2 or later
 * Text Domain: roro-auth
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) exit;

defined('RORO_AUTH_FILE') || define('RORO_AUTH_FILE', __FILE__);
defined('RORO_AUTH_DIR')  || define('RORO_AUTH_DIR', plugin_dir_path(__FILE__));
defined('RORO_AUTH_URL')  || define('RORO_AUTH_URL', plugin_dir_url(__FILE__));
defined('RORO_AUTH_VER')  || define('RORO_AUTH_VER', '1.6.1');
defined('RORO_AUTH_OPT')  || define('RORO_AUTH_OPT', 'roro_auth_settings');

// --- includes ---
require_once RORO_AUTH_DIR . 'includes/class-roro-auth-utils.php';
require_once RORO_AUTH_DIR . 'includes/class-roro-auth.php';
require_once RORO_AUTH_DIR . 'includes/class-roro-auth-admin.php';
require_once RORO_AUTH_DIR . 'includes/providers/class-roro-auth-provider.php';
require_once RORO_AUTH_DIR . 'includes/providers/class-roro-auth-google.php';
require_once RORO_AUTH_DIR . 'includes/providers/class-roro-auth-line.php';

// Activation: ensure options exist
register_activation_hook(RORO_AUTH_FILE, function () {
    $defaults = RORO_Auth_Utils::default_settings();
    $saved = get_option(RORO_AUTH_OPT);
    if (!is_array($saved)) $saved = array();
    update_option(RORO_AUTH_OPT, array_merge($defaults, $saved));
});

// Bootstrap
add_action('plugins_loaded', function () {
    // i18n (for wp-admin PHP strings). Note: front-end uses JS i18n files.
    load_plugin_textdomain('roro-auth', false, dirname(plugin_basename(__FILE__)) . '/languages');

    RORO_Auth::instance();     // main
    RORO_Auth_Admin::instance(); // admin
});
