<?php
if (!defined('ABSPATH')) exit;

class RORO_Auth {
    private static $instance;
    private $settings;
    private $providers = array();

    public static function instance(): self {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->settings = RORO_Auth_Utils::get_settings();

        // Providers registry
        $this->providers['google'] = new RORO_Auth_Google();
        $this->providers['line']   = new RORO_Auth_LINE();

        add_action('init', array($this, 'register_shortcodes'));
        add_action('init', array($this, 'maybe_route'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    /** Front assets */
    public function enqueue_assets() {
        wp_register_style('roro-auth', RORO_AUTH_URL . 'assets/css/roro-auth.css', array(), RORO_AUTH_VER);
        wp_enqueue_style('roro-auth');

        wp_register_script('roro-auth', RORO_AUTH_URL . 'assets/js/roro-auth.js', array('jquery'), RORO_AUTH_VER, true);

        // Pass runtime info + minimal messages (button labels from per-language JS will override if present)
        wp_localize_script('roro-auth', 'RORO_AUTH_LOC', array(
            'base'       => home_url('/'),
            'login_ep'   => home_url('/'),
            'query_key'  => 'roro_auth',
            'redirect_param' => 'redirect_to',
            'i18n_lang'  => RORO_Auth_Utils::current_lang(),
        ));
        wp_enqueue_script('roro-auth');

        // Per-language JS (window.RORO_AUTH_I18N[lang] = {...})
        $lang = RORO_Auth_Utils::current_lang();
        $map = array('ja'=>'ja','en'=>'en','zh'=>'zh','ko'=>'ko');
        $suffix = isset($map[$lang]) ? $map[$lang] : 'en';
        wp_enqueue_script('roro-auth-i18n', RORO_AUTH_URL . 'assets/js/i18n/' . $suffix . '.js', array('roro-auth'), RORO_AUTH_VER, true);
    }

    /** Shortcode to render login buttons */
    public function register_shortcodes() {
        add_shortcode('roro_auth_buttons', array($this, 'shortcode_buttons'));
    }

    public function shortcode_buttons($atts = array(), $content = ''): string {
        $atts = shortcode_atts(array(
            'redirect_to' => isset($_GET['redirect_to']) ? esc_url_raw($_GET['redirect_to']) : home_url('/'),
        ), $atts, 'roro_auth_buttons');

        ob_start();
        $redirect = esc_url($atts['redirect_to']);
        ?>
        <div class="roro-auth-buttons" data-redirect="<?php echo esc_attr($redirect); ?>">
            <div class="roro-auth-title" data-i18n="social_login_title">Social Login</div>
            <div class="roro-auth-sub" data-i18n="social_login_sub">Sign in with Google or LINE.</div>

            <?php if ($this->providers['google']->is_enabled($this->settings)) : ?>
                <button type="button" class="roro-auth-btn roro-auth-google" data-provider="google" data-i18n="login_with_google">Continue with Google</button>
            <?php endif; ?>

            <?php if ($this->providers['line']->is_enabled($this->settings)) : ?>
                <button type="button" class="roro-auth-btn roro-auth-line" data-provider="line" data-i18n="login_with_line">Continue with LINE</button>
            <?php endif; ?>

            <div class="roro-auth-or" data-i18n="or">or</div>
            <a class="roro-auth-wp" href="<?php echo esc_url( wp_login_url($redirect) ); ?>" data-i18n="login_with_wp">Use WordPress Login</a>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    /** Handle routing: ?roro_auth=login|callback */
    public function maybe_route() {
        if (empty($_GET['roro_auth'])) return;
        $action = sanitize_key($_GET['roro_auth']);
        $provider_key = isset($_GET['provider']) ? sanitize_key($_GET['provider']) : '';

        if (!isset($this->providers[$provider_key])) {
            status_header(400);
            wp_die(esc_html__('Unsupported provider', 'roro-auth'));
        }
        $provider = $this->providers[$provider_key];
        $settings = $this->settings;

        if ($action === 'login') {
            // Determine redirect target from param (default home)
            $redirect_to = isset($_GET['redirect_to']) ? esc_url_raw($_GET['redirect_to']) : home_url('/');
            $allowed = array();
            if (!empty($settings['allowed_redirect_hosts'])) {
                $allowed = array_map('trim', explode(',', $settings['allowed_redirect_hosts']));
            }
            $redirect_to = RORO_Auth_Utils::safe_redirect_to($redirect_to, $allowed);

            if (!$provider->is_enabled($settings)) {
                status_header(403);
                wp_die(esc_html__('Provider is disabled', 'roro-auth'));
            }
            $url = $provider->auth_url($settings, $redirect_to);
            wp_redirect($url);
            exit;
        }

        if ($action === 'callback') {
            $result = $provider->handle_callback($settings, $_GET);
            if (!$result['ok']) {
                status_header(403);
                wp_die(esc_html__('Login failed: ', 'roro-auth') . esc_html($result['error']));
            }

            $email = $result['email'];
            $name  = $result['name'];
            $redirect = isset($result['redirect']) ? $result['redirect'] : home_url('/');

            // Find or create WP user
            $user = get_user_by('email', $email);
            if (!$user) {
                $username = sanitize_user(current(explode('@', $email)));
                if (username_exists($username)) $username .= '_' . wp_generate_password(4, false);
                $user_id = wp_create_user($username, wp_generate_password(20, true, true), $email);
                if (is_wp_error($user_id)) {
                    status_header(500);
                    wp_die(esc_html__('Could not create user', 'roro-auth'));
                }
                if ($name) {
                    wp_update_user(array('ID' => $user_id, 'display_name' => $name));
                }
                $role = !empty($settings['new_user_role']) ? $settings['new_user_role'] : 'subscriber';
                $u = new WP_User($user_id);
                $u->set_role($role);
                $user = get_user_by('id', $user_id);
            }

            // Sign in
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID, true);
            do_action('wp_login', $user->user_login, $user);

            wp_safe_redirect($redirect);
            exit;
        }
    }
}
