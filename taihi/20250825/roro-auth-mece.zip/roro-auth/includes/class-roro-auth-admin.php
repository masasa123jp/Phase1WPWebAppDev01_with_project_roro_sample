<?php
if (!defined('ABSPATH')) exit;

class RORO_Auth_Admin {
    private static $instance;

    public static function instance(): self {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function menu() {
        add_options_page(
            __('RORO Auth Settings', 'roro-auth'),
            __('RORO Auth', 'roro-auth'),
            'manage_options',
            'roro-auth',
            array($this, 'render_page')
        );
    }

    public function register_settings() {
        register_setting('roro-auth', RORO_AUTH_OPT, array($this, 'sanitize'));

        add_settings_section('roro-auth-sec', __('Providers', 'roro-auth'), function () {
            echo '<p>' . esc_html__('Enable providers and set credentials. Remember to configure callback URLs on each provider console.', 'roro-auth') . '</p>';
        }, 'roro-auth');

        add_settings_field('enabled_providers', __('Enable Providers', 'roro-auth'), function () {
            $opt = RORO_Auth_Utils::get_settings();
            ?>
            <label><input type="checkbox" name="<?php echo esc_attr(RORO_AUTH_OPT); ?>[enabled_providers][google]" value="1" <?php checked(!empty($opt['enabled_providers']['google'])); ?>> Google</label><br>
            <label><input type="checkbox" name="<?php echo esc_attr(RORO_AUTH_OPT); ?>[enabled_providers][line]" value="1" <?php checked(!empty($opt['enabled_providers']['line'])); ?>> LINE</label>
            <?php
        }, 'roro-auth', 'roro-auth-sec');

        add_settings_field('google_client_id', 'Google Client ID', function () {
            $opt = RORO_Auth_Utils::get_settings();
            printf('<input type="text" class="regular-text" name="%s[google_client_id]" value="%s" />', esc_attr(RORO_AUTH_OPT), esc_attr($opt['google_client_id']));
        }, 'roro-auth', 'roro-auth-sec');

        add_settings_field('google_client_secret', 'Google Client Secret', function () {
            $opt = RORO_Auth_Utils::get_settings();
            printf('<input type="text" class="regular-text" name="%s[google_client_secret]" value="%s" />', esc_attr(RORO_AUTH_OPT), esc_attr($opt['google_client_secret']));
        }, 'roro-auth', 'roro-auth-sec');

        add_settings_field('line_channel_id', 'LINE Channel ID', function () {
            $opt = RORO_Auth_Utils::get_settings();
            printf('<input type="text" class="regular-text" name="%s[line_channel_id]" value="%s" />', esc_attr(RORO_AUTH_OPT), esc_attr($opt['line_channel_id']));
        }, 'roro-auth', 'roro-auth-sec');

        add_settings_field('line_channel_secret', 'LINE Channel Secret', function () {
            $opt = RORO_Auth_Utils::get_settings();
            printf('<input type="text" class="regular-text" name="%s[line_channel_secret]" value="%s" />', esc_attr(RORO_AUTH_OPT), esc_attr($opt['line_channel_secret']));
        }, 'roro-auth', 'roro-auth-sec');

        add_settings_field('new_user_role', __('New User Role', 'roro-auth'), function () {
            $opt = RORO_Auth_Utils::get_settings();
            wp_dropdown_roles($opt['new_user_role']);
            echo '<p class="description">' . esc_html__('Role assigned to newly created social users.', 'roro-auth') . '</p>';
        }, 'roro-auth', 'roro-auth-sec');

        add_settings_field('allowed_redirect_hosts', __('Allowed Redirect Hosts', 'roro-auth'), function () {
            $opt = RORO_Auth_Utils::get_settings();
            printf('<input type="text" class="regular-text" name="%s[allowed_redirect_hosts]" value="%s" placeholder="example.com, foo.bar" />', esc_attr(RORO_AUTH_OPT), esc_attr($opt['allowed_redirect_hosts']));
            echo '<p class="description">' . esc_html__('Comma-separated hostnames allowed as redirect_to targets.', 'roro-auth') . '</p>';
        }, 'roro-auth', 'roro-auth-sec');
    }

    public function sanitize($in): array {
        $out = RORO_Auth_Utils::default_settings();
        if (!is_array($in)) return $out;

        $out['enabled_providers']['google'] = !empty($in['enabled_providers']['google']) ? 1 : 0;
        $out['enabled_providers']['line']   = !empty($in['enabled_providers']['line'])   ? 1 : 0;

        $out['google_client_id']     = isset($in['google_client_id'])     ? sanitize_text_field($in['google_client_id'])     : '';
        $out['google_client_secret'] = isset($in['google_client_secret']) ? sanitize_text_field($in['google_client_secret']) : '';
        $out['line_channel_id']      = isset($in['line_channel_id'])      ? sanitize_text_field($in['line_channel_id'])      : '';
        $out['line_channel_secret']  = isset($in['line_channel_secret'])  ? sanitize_text_field($in['line_channel_secret'])  : '';

        $role = isset($in['new_user_role']) ? sanitize_text_field($in['new_user_role']) : 'subscriber';
        $out['new_user_role'] = get_role($role) ? $role : 'subscriber';

        $out['allowed_redirect_hosts'] = isset($in['allowed_redirect_hosts']) ? sanitize_text_field($in['allowed_redirect_hosts']) : '';

        return $out;
    }

    public function render_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('RORO Auth Settings', 'roro-auth'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('roro-auth');
                do_settings_sections('roro-auth');
                submit_button();
                ?>
                <hr />
                <h2><?php echo esc_html__('Callback URLs', 'roro-auth'); ?></h2>
                <p><strong>Google Redirect URI:</strong> <code><?php echo esc_html(RORO_Auth_Utils::redirect_uri('google')); ?></code></p>
                <p><strong>LINE Redirect URI:</strong>   <code><?php echo esc_html(RORO_Auth_Utils::redirect_uri('line')); ?></code></p>
            </form>
        </div>
        <?php
    }
}
