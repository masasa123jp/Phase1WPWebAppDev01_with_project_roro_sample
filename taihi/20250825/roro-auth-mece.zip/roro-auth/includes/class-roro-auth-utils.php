<?php
if (!defined('ABSPATH')) exit;

/**
 * Utility & i18n helpers
 */
class RORO_Auth_Utils {
    /** Default settings */
    public static function default_settings(): array {
        return array(
            'enabled_providers' => array(
                'google' => 0,
                'line'   => 0,
            ),
            'google_client_id'     => '',
            'google_client_secret' => '',
            'line_channel_id'      => '',
            'line_channel_secret'  => '',
            // Optional: user role for new social users
            'new_user_role'        => 'subscriber',
            // Optional: allowed redirect hosts (comma separated list)
            'allowed_redirect_hosts'=> '',
        );
    }

    /** Get settings merged with defaults */
    public static function get_settings(): array {
        $saved = get_option(RORO_AUTH_OPT);
        if (!is_array($saved)) $saved = array();
        return array_merge(self::default_settings(), $saved);
    }

    /** Current language code (ja|en|zh|ko). Simple heuristic for front-end i18n. */
    public static function current_lang(): string {
        // Allow explicit override via ?roro_lang=xx (dev/test)
        if (isset($_GET['roro_lang'])) {
            $code = sanitize_key($_GET['roro_lang']);
            if (in_array($code, array('ja','en','zh','ko'), true)) return $code;
        }
        // Infer from WP locale
        $loc = get_locale();
        $loc = is_string($loc) ? strtolower($loc) : 'ja';
        if (strpos($loc, 'ja') === 0) return 'ja';
        if (strpos($loc, 'zh') === 0) return 'zh';
        if (strpos($loc, 'ko') === 0) return 'ko';
        return 'en';
    }

    /** Make secure state payload and store nonce transient */
    public static function make_state(string $provider, string $redirect_to): string {
        $nonce = wp_generate_password(16, false, false);
        $payload = array(
            'p' => $provider,
            'r' => $redirect_to,
            't' => time(),
            'n' => $nonce,
        );
        // Store transient mapping for 10 minutes
        set_transient('roro_auth_state_' . $nonce, $payload, 10 * MINUTE_IN_SECONDS);
        // Encode compactly
        return rawurlencode(base64_encode(wp_json_encode($payload)));
    }

    /** Validate returned state and retrieve payload */
    public static function parse_state(string $state): ?array {
        $decoded = json_decode(base64_decode(rawurldecode($state)), true);
        if (!is_array($decoded) || empty($decoded['n'])) return null;
        $saved = get_transient('roro_auth_state_' . $decoded['n']);
        if (!$saved) return null;
        // optional expiry check
        if (empty($decoded['t']) || (time() - intval($decoded['t'])) > 10 * MINUTE_IN_SECONDS) {
            return null;
        }
        // one-time use
        delete_transient('roro_auth_state_' . $decoded['n']);
        return $decoded;
    }

    /** Sanitize and constrain redirect_to */
    public static function safe_redirect_to(string $url, array $allowed_hosts = array()): string {
        $url = esc_url_raw($url);
        if (!$url) return home_url('/');

        // Only allow same host or whitelisted host
        $host = wp_parse_url($url, PHP_URL_HOST);
        $home_host = wp_parse_url(home_url('/'), PHP_URL_HOST);
        if ($host === $home_host || $host === null) return $url;

        $allowed_hosts = array_filter(array_map('trim', $allowed_hosts));
        if (in_array($host, $allowed_hosts, true)) return $url;

        return home_url('/');
    }

    /** Build redirect URI used by providers */
    public static function redirect_uri(string $provider): string {
        return add_query_arg(array(
            'roro_auth' => 'callback',
            'provider'  => $provider,
        ), home_url('/'));
    }
}
