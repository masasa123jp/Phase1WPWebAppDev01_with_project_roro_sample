<?php
if (!defined('ABSPATH')) exit;

class RORO_Auth_LINE extends RORO_Auth_Provider {
    public function is_enabled(array $settings): bool {
        return !empty($settings['enabled_providers']['line'])
            && !empty($settings['line_channel_id'])
            && !empty($settings['line_channel_secret']);
    }

    public function auth_url(array $settings, string $redirect_to): string {
        $client_id = $settings['line_channel_id'];
        $state = RORO_Auth_Utils::make_state('line', $redirect_to);
        $params = array(
            'response_type' => 'code',
            'client_id'     => $client_id,
            'redirect_uri'  => RORO_Auth_Utils::redirect_uri('line'),
            'state'         => $state,
            'scope'         => 'openid profile email',
            'nonce'         => wp_create_nonce('roro_line_nonce'),
        );
        return 'https://access.line.me/oauth2/v2.1/authorize?' . http_build_query($params, '', '&');
    }

    public function handle_callback(array $settings, array $query): array {
        if (empty($query['code']) || empty($query['state'])) {
            return array('ok' => false, 'error' => 'missing_code_state');
        }
        $state = RORO_Auth_Utils::parse_state($query['state']);
        if (!$state || $state['p'] !== 'line') {
            return array('ok' => false, 'error' => 'state_invalid');
        }

        $token_res = wp_remote_post('https://api.line.me/oauth2/v2.1/token', array(
            'timeout' => 15,
            'body' => array(
                'grant_type'    => 'authorization_code',
                'code'          => $query['code'],
                'redirect_uri'  => RORO_Auth_Utils::redirect_uri('line'),
                'client_id'     => $settings['line_channel_id'],
                'client_secret' => $settings['line_channel_secret'],
            ),
            'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
        ));
        if (is_wp_error($token_res)) {
            return array('ok' => false, 'error' => 'token_exchange_failed');
        }
        $data = json_decode(wp_remote_retrieve_body($token_res), true);
        if (empty($data['access_token'])) {
            return array('ok' => false, 'error' => 'token_missing');
        }

        $ui = wp_remote_get('https://api.line.me/v2/profile', array(
            'headers' => array('Authorization' => 'Bearer ' . $data['access_token']),
            'timeout' => 15,
        ));
        $email = ''; $name = '';
        if (!is_wp_error($ui)) {
            $prof = json_decode(wp_remote_retrieve_body($ui), true);
            $name = isset($prof['displayName']) ? sanitize_text_field($prof['displayName']) : '';
            // Note: LINE email requires additional permissions; fallback to no-email flow
        }

        // For LINE, email may not be provided; synthesize unique username if needed
        // We will create a user like line_{sub}@example.invalid if email is missing
        $email_claim = '';
        if (!empty($data['id_token'])) {
            $parts = explode('.', $data['id_token']);
            if (count($parts) >= 2) {
                $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
                if (is_array($payload)) {
                    $email_claim = isset($payload['email']) ? sanitize_email($payload['email']) : '';
                    if (!$name && !empty($payload['name'])) $name = sanitize_text_field($payload['name']);
                    $sub = isset($payload['sub']) ? preg_replace('/[^a-z0-9_]/i','',$payload['sub']) : '';
                    if (!$email_claim && $sub) $email_claim = "line_{$sub}@example.invalid";
                }
            }
        }

        if (!$email_claim) $email_claim = 'line_' . wp_generate_password(10, false) . '@example.invalid';
        return array('ok' => true, 'email' => $email_claim, 'name' => $name, 'redirect' => $state['r']);
    }
}
