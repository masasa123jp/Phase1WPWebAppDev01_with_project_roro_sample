<?php
if (!defined('ABSPATH')) exit;

class RORO_Auth_Google extends RORO_Auth_Provider {
    public function is_enabled(array $settings): bool {
        return !empty($settings['enabled_providers']['google'])
            && !empty($settings['google_client_id'])
            && !empty($settings['google_client_secret']);
    }

    public function auth_url(array $settings, string $redirect_to): string {
        $client_id = $settings['google_client_id'];
        $state = RORO_Auth_Utils::make_state('google', $redirect_to);
        $params = array(
            'client_id'     => $client_id,
            'redirect_uri'  => RORO_Auth_Utils::redirect_uri('google'),
            'response_type' => 'code',
            'scope'         => 'openid email profile',
            'state'         => $state,
            'include_granted_scopes' => 'true',
            'prompt'        => 'consent',
        );
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params, '', '&');
    }

    public function handle_callback(array $settings, array $query): array {
        if (empty($query['code']) || empty($query['state'])) {
            return array('ok' => false, 'error' => 'missing_code_state');
        }
        $state = RORO_Auth_Utils::parse_state($query['state']);
        if (!$state || $state['p'] !== 'google') {
            return array('ok' => false, 'error' => 'state_invalid');
        }

        $token_res = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'timeout' => 15,
            'body' => array(
                'code'          => $query['code'],
                'client_id'     => $settings['google_client_id'],
                'client_secret' => $settings['google_client_secret'],
                'redirect_uri'  => RORO_Auth_Utils::redirect_uri('google'),
                'grant_type'    => 'authorization_code',
            ),
        ));
        if (is_wp_error($token_res)) {
            return array('ok' => false, 'error' => 'token_exchange_failed');
        }
        $data = json_decode(wp_remote_retrieve_body($token_res), true);
        if (empty($data['id_token']) && empty($data['access_token'])) {
            return array('ok' => false, 'error' => 'token_missing');
        }

        // Prefer id_token (JWT) then fallback to userinfo
        $email = '';
        $name  = '';
        if (!empty($data['id_token'])) {
            $parts = explode('.', $data['id_token']);
            if (count($parts) >= 2) {
                $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
                if (is_array($payload)) {
                    $email = isset($payload['email']) ? sanitize_email($payload['email']) : '';
                    $name  = isset($payload['name'])  ? sanitize_text_field($payload['name'])  : '';
                }
            }
        }
        if (!$email && !empty($data['access_token'])) {
            $ui = wp_remote_get('https://www.googleapis.com/oauth2/v2/userinfo', array(
                'headers' => array('Authorization' => 'Bearer ' . $data['access_token']),
                'timeout' => 15,
            ));
            if (!is_wp_error($ui)) {
                $prof = json_decode(wp_remote_retrieve_body($ui), true);
                $email = isset($prof['email']) ? sanitize_email($prof['email']) : $email;
                $name  = isset($prof['name'])  ? sanitize_text_field($prof['name'])  : $name;
            }
        }

        if (!$email) return array('ok' => false, 'error' => 'email_missing');

        return array('ok' => true, 'email' => $email, 'name' => $name, 'redirect' => $state['r']);
    }
}
