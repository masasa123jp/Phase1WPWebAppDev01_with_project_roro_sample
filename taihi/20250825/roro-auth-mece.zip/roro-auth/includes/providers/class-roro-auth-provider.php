<?php
if (!defined('ABSPATH')) exit;

abstract class RORO_Auth_Provider {
    abstract public function is_enabled(array $settings): bool;
    abstract public function auth_url(array $settings, string $redirect_to): string;
    abstract public function handle_callback(array $settings, array $query): array;
}
