window.RORO_AUTH_I18N = window.RORO_AUTH_I18N || {};
window.RORO_AUTH_I18N['ko'] = {
  "social_login_title": "소셜 로그인",
  "social_login_sub": "Google 또는 LINE으로 로그인하세요.",
  "login_with_google": "Google로 계속",
  "login_with_line": "LINE으로 계속",
  "login_with_wp": "워드프레스 로그인 사용",
  "or": "또는"
};
