window.RORO_AUTH_I18N = window.RORO_AUTH_I18N || {};
window.RORO_AUTH_I18N['ja'] = {
  "social_login_title": "ソーシャルログイン",
  "social_login_sub": "Google または LINE でログインできます。",
  "login_with_google": "Googleでログイン",
  "login_with_line": "LINEでログイン",
  "login_with_wp": "WordPress の通常ログイン",
  "or": "または"
};
