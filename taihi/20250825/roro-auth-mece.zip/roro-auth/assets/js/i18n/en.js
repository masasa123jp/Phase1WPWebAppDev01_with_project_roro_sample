window.RORO_AUTH_I18N = window.RORO_AUTH_I18N || {};
window.RORO_AUTH_I18N['en'] = {
  "social_login_title": "Social Login",
  "social_login_sub": "Sign in with Google or LINE.",
  "login_with_google": "Continue with Google",
  "login_with_line": "Continue with LINE",
  "login_with_wp": "Use WordPress Login",
  "or": "or"
};
