window.RORO_AUTH_I18N = window.RORO_AUTH_I18N || {};
window.RORO_AUTH_I18N['zh'] = {
  "social_login_title": "社交登录",
  "social_login_sub": "使用 Google 或 LINE 登录。",
  "login_with_google": "使用 Google 登录",
  "login_with_line": "使用 LINE 登录",
  "login_with_wp": "使用 WordPress 登录",
  "or": "或"
};
