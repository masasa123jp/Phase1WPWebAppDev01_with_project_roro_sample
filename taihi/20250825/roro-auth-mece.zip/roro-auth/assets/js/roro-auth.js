(function($){
  // Minimal i18n helper from window.RORO_AUTH_I18N
  function t(key){
    try {
      var lang = (window.RORO_AUTH_LOC && window.RORO_AUTH_LOC.i18n_lang) || 'en';
      var dict = (window.RORO_AUTH_I18N && window.RORO_AUTH_I18N[lang]) || {};
      return dict[key] || key;
    } catch(e){ return key; }
  }

  function applyI18N($wrap){
    $wrap.find('[data-i18n]').each(function(){
      var k = $(this).data('i18n');
      if (k) $(this).text(t(k));
    });
  }

  $(function(){
    $('.roro-auth-buttons').each(function(){
      var $wrap = $(this);
      applyI18N($wrap);
    });

    $(document).on('click', '.roro-auth-btn', function(){
      var provider = $(this).data('provider');
      var redirectTo = $(this).closest('.roro-auth-buttons').data('redirect') || (window.location && window.location.href) || '/';
      // go to ?roro_auth=login&provider={provider}&redirect_to={url}
      var base = (window.RORO_AUTH_LOC && window.RORO_AUTH_LOC.login_ep) || '/';
      var url = new URL(base, window.location.origin);
      url.searchParams.set('roro_auth', 'login');
      url.searchParams.set('provider', provider);
      url.searchParams.set('redirect_to', redirectTo);
      window.location.assign(url.toString());
    });
  });
})(jQuery);
