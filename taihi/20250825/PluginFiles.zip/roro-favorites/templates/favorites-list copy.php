<?php
/**
 * お気に入り一覧テンプレート
 * - 地図画面へのジャンプ（/map?highlight_event={id}）導線を追加
 * - 追加/削除をREST経由でAJAX即時反映（assets/js/favorites.js）
 */
if (!defined('ABSPATH')) { exit; }

// 翻訳テキストはText Domain: roro-favorites を想定
$nonce = wp_create_nonce('wp_rest'); // REST用ノンス
$user_id = get_current_user_id();
if (!$user_id) {
  echo '<div class="roro-fav-error">'.esc_html__('Please log in to see your favorites.', 'roro-favorites').'</div>';
  return;
}

// サーバー側で一覧を取得（既存のサービス層またはWP_Query/直SQLでも可）
if (!class_exists('RORO_Favorites_Service')) {
  echo '<div class="roro-fav-error">'.esc_html__('Service not available.', 'roro-favorites').'</div>';
  return;
}
$service = new RORO_Favorites_Service();
$list = $service->get_user_favorites($user_id, [
  'target' => null, // null=全種別（event/spot 両方）
  'limit'  => 200,
  'offset' => 0,
]);

// RESTノンスをJSへ渡す
wp_enqueue_script('roro-favorites-js', plugins_url('../assets/js/favorites.js', __FILE__), [], '1.0.0', true);
wp_localize_script('roro-favorites-js', 'RORO_FAV_CONFIG', [
  'rest'  => [
    'add'    => esc_url_raw( rest_url('roro/v1/favorites/add') ),
    'remove' => esc_url_raw( rest_url('roro/v1/favorites/remove') ),
    'nonce'  => $nonce,
  ],
  'i18n' => [
    'added'    => __('Added to favorites', 'roro-favorites'),
    'removed'  => __('Removed from favorites', 'roro-favorites'),
    'error'    => __('Operation failed. Please try again.', 'roro-favorites'),
    'view_map' => __('Open on Map', 'roro-favorites'),
  ],
]);

?>
<div class="roro-fav-wrap">
  <h2 class="roro-fav-title"><?php echo esc_html__('My Favorites', 'roro-favorites'); ?></h2>

  <?php if (empty($list)) : ?>
    <p class="roro-fav-empty"><?php echo esc_html__('No favorites yet.', 'roro-favorites'); ?></p>
  <?php else: ?>
    <ul class="roro-fav-list" style="list-style:none;padding:0;margin:0;">
      <?php foreach ($list as $row): 
        // $row 例）['id'=>fav_id, 'target'=>'event', 'target_id'=>123, 'title'=>'...', 'lat'=>..., 'lng'=>..., 'date'=>..., ...]
        $targetType = isset($row['target']) ? $row['target'] : 'event';
        $targetId   = intval($row['target_id'] ?? 0);
        $title      = $row['title'] ?? '';
        $lat        = isset($row['lat']) ? floatval($row['lat']) : null;
        $lng        = isset($row['lng']) ? floatval($row['lng']) : null;
        $map_url    = add_query_arg(['highlight_'.$targetType => $targetId], home_url('/map/')); // 例: /map/?highlight_event=123
      ?>
      <li class="roro-fav-item" data-target="<?php echo esc_attr($targetType); ?>" data-id="<?php echo esc_attr($targetId); ?>" style="border:1px solid #eee;border-radius:10px;padding:12px;margin:12px 0;">
        <div class="roro-fav-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
          <div class="roro-fav-meta">
            <span class="roro-fav-kind" style="font-size:12px;color:#666;"><?php echo esc_html( strtoupper($targetType) ); ?></span>
            <h3 class="roro-fav-title" style="margin:.25rem 0 0 0;"><?php echo esc_html($title); ?></h3>
          </div>
          <div class="roro-fav-actions" style="display:flex;gap:8px;align-items:center;">
            <!-- 地図で見る -->
            <a class="roro-fav-openmap button" href="<?php echo esc_url($map_url); ?>" title="<?php echo esc_attr__('Open on Map', 'roro-favorites'); ?>">
              🗺️ <?php echo esc_html__('Open on Map', 'roro-favorites'); ?>
            </a>
            <!-- 解除（☆/★はCSS/JSで切替） -->
            <button type="button"
              class="roro-fav-toggle button button-secondary"
              data-target="<?php echo esc_attr($targetType); ?>"
              data-id="<?php echo esc_attr($targetId); ?>"
              aria-pressed="true"
              title="<?php echo esc_attr__('Remove from favorites', 'roro-favorites'); ?>">
              ★
            </button>
          </div>
        </div>

        <?php if ($lat && $lng): ?>
          <div class="roro-fav-geo" style="font-size:12px;color:#999;margin-top:6px;">
            <?php echo esc_html(sprintf('Lat: %.5f / Lng: %.5f', $lat, $lng)); ?>
          </div>
        <?php endif; ?>
      </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <div id="roro-fav-toast" style="position:fixed;right:16px;bottom:16px;display:none;background:#111;color:#fff;padding:10px 14px;border-radius:8px;">OK</div>
</div>
