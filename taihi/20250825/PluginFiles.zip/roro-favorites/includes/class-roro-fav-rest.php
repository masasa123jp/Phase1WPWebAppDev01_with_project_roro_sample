<?php
/**
 * Plugin Name: Roro Favorites
 * Description: お気に入りの種別横断一覧（並び替え/絞り込み）と A11y トースト/フォーカス管理。
 * Version: 0.4.0
 * Text Domain: roro
 */
if (!defined('ABSPATH')) { exit; }
define('RORO_FAV_DIR', plugin_dir_path(__FILE__));
define('RORO_FAV_URL', plugin_dir_url(__FILE__));
require_once RORO_FAV_DIR . 'includes/class-roro-fav-rest.php';

add_action('wp_enqueue_scripts', function () {
    wp_register_script('roro-favs', RORO_FAV_URL . 'assets/js/favs.js', ['wp-i18n'], '0.4.0', true);
    wp_set_script_translations('roro-favs', 'roro');
});

add_shortcode('roro_favorites', function () {
    if (!is_user_logged_in()) {
        return '<p>' . esc_html__('Please sign in to view favorites.', 'roro') . '</p>';
    }
    wp_enqueue_script('roro-favs');
    ob_start(); ?>
    <div class="roro-favs" data-endpoint="<?php echo esc_attr(rest_url('roro/v1/favorites')); ?>">
      <div class="roro-favs__controls">
        <label><?php echo esc_html__('Type', 'roro'); ?>
          <select data-key="type">
            <option value=""><?php echo esc_html__('All', 'roro'); ?></option>
            <option value="post"><?php echo esc_html__('Post', 'roro'); ?></option>
            <option value="roro_event"><?php echo esc_html__('Event', 'roro'); ?></option>
          </select>
        </label>
        <label><?php echo esc_html__('Sort', 'roro'); ?>
          <select data-key="sort">
            <option value="added_desc"><?php echo esc_html__('Newest', 'roro'); ?></option>
            <option value="added_asc"><?php echo esc_html__('Oldest', 'roro'); ?></option>
            <option value="title_asc"><?php echo esc_html__('Title (A–Z)', 'roro'); ?></option>
          </select>
        </label>
      </div>
      <div class="roro-favs__list" aria-live="polite" aria-busy="false"></div>
      <div class="roro-toast" role="status" aria-atomic="true"></div>
    </div>
    <?php return ob_get_clean();
});
