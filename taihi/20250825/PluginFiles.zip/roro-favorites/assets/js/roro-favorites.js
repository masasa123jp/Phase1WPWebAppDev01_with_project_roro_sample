/* global jQuery, RORO_FAV_I18N */
(function($){
  'use strict';
  var $list = $('#fav-list');
  var $filter = $('#fav-filter');
  var $sort = $('#fav-sort');

  function load() {
    $.getJSON('/wp-json/roro/v1/favorites', {
      type: $filter.val() === 'all' ? '' : $filter.val()
    })
      .done(function(json){
        var items = json.items || [];
        // sort
        items.sort(function(a, b){
          var s = $sort.val();
          if (s === 'date_asc')  return (a.saved_at || 0) - (b.saved_at || 0);
          if (s === 'title_asc') return (a.title || '').localeCompare(b.title || '');
          return (b.saved_at || 0) - (a.saved_at || 0); // date_desc
        });

        $list.empty();
        if (items.length === 0) {
          $('<p/>').text(RORO_FAV_I18N.noItems).appendTo($list);
          return;
        }
        items.forEach(function(it){
          var $row = $('<article/>', { role:'listitem', class:'roro-fav__row' });
          $('<h3/>').text(it.title).appendTo($row);
          if (it.type) $('<span/>').text(it.type).appendTo($row);
          if (it.permalink) $('<a/>', { href: it.permalink, text: 'Open' }).appendTo($row);
          $list.append($row);
        });
      });
  }

  $filter.on('change', load);
  $sort.on('change', load);
  $(load);
})(jQuery);
