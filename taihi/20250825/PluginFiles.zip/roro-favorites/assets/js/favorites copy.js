/**
 * roro-favorites: お気に入り 追加/削除 をREST経由でAJAX反映
 * - ボタン ★ / ☆ のトグル
 * - トースト表示
 * - 多言語文言は RORO_FAV_CONFIG.i18n に注入済み
 */
(function(){
  'use strict';

  // トーストユーティリティ
  function toast(msg) {
    var el = document.getElementById('roro-fav-toast');
    if (!el) return;
    el.textContent = msg;
    el.style.display = 'block';
    el.style.opacity = '1';
    setTimeout(function(){ el.style.opacity = '0'; }, 1600);
    setTimeout(function(){ el.style.display = 'none'; }, 2000);
  }

  // RESTコールの共通処理
  async function callApi(url, payload) {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': (RORO_FAV_CONFIG && RORO_FAV_CONFIG.rest && RORO_FAV_CONFIG.rest.nonce) || ''
      },
      body: JSON.stringify(payload || {})
    });
    if (!res.ok) {
      const txt = await res.text().catch(()=> '');
      throw new Error(txt || ('HTTP '+ res.status));
    }
    return res.json().catch(()=> ({}));
  }

  // トグルクリック（★=登録済み→削除、☆=未登録→追加）
  async function onToggleClick(ev) {
    const btn = ev.currentTarget;
    const li  = btn.closest('.roro-fav-item');
    if (!li) return;
    const target = li.getAttribute('data-target') || 'event';
    const id     = parseInt(li.getAttribute('data-id') || '0', 10);
    if (!id) return;

    // 現在の状態（★=true, ☆=false）をaria-pressedで判定
    const pressed = btn.getAttribute('aria-pressed') === 'true';

    try {
      if (pressed) {
        await callApi(RORO_FAV_CONFIG.rest.remove, { target, id });
        btn.setAttribute('aria-pressed', 'false');
        btn.textContent = '☆';
        btn.title = RORO_FAV_CONFIG.i18n.added || 'Added';
        toast(RORO_FAV_CONFIG.i18n.removed || 'Removed');
        // リストから項目を消したい場合はここでDOM削除も可
        // li.parentNode.removeChild(li);
      } else {
        await callApi(RORO_FAV_CONFIG.rest.add, { target, id });
        btn.setAttribute('aria-pressed', 'true');
        btn.textContent = '★';
        btn.title = RORO_FAV_CONFIG.i18n.removed || 'Removed';
        toast(RORO_FAV_CONFIG.i18n.added || 'Added');
      }
    } catch (e) {
      console.error(e);
      toast(RORO_FAV_CONFIG.i18n.error || 'Error');
    }
  }

  function bind() {
    document.querySelectorAll('.roro-fav-toggle').forEach(function(btn){
      btn.addEventListener('click', onToggleClick);
      // 初期は登録済みを想定（★）。未登録行では☆にして aria-pressed=false にしておくこと
      if (!btn.hasAttribute('aria-pressed')) btn.setAttribute('aria-pressed', 'true');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind);
  } else {
    bind();
  }
})();
