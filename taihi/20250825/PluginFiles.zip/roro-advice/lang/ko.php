<?php
$roro_adv_messages = array(
  'advice'   => '한마디 팁',
  'no_advice'=> '추천할 팁이 없습니다.'
);