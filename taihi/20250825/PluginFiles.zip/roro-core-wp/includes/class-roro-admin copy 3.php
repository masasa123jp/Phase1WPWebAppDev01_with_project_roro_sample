<?php
/**
 * 共通設定（roro-core-wp）
 * - 地図：現在地検出ON/OFF
 * - チャット：モード切替（Dify埋め込み / Dify API / OpenAI API）＋キー・エンドポイント
 * - 将来拡張のためセクション分割
 *
 * Text Domain: roro-core-wp
 */
declare(strict_types=1);
defined('ABSPATH') || exit;

if (!class_exists('Roro_Core_Admin')):

final class Roro_Core_Admin {

    /** 設定オプション配列のキー */
    const OPT_KEY = 'roro_core_settings';

    public static function boot(): void {
        add_action('admin_menu', [__CLASS__, 'add_menu']);
    }

    /** 管理メニュー追加 */
    public static function add_menu(): void {
        add_menu_page(
            __('RORO Settings', 'roro-core-wp'),   // ページタイトル
            __('RORO Settings', 'roro-core-wp'),   // メニュータイトル
            'manage_options',                      // 権限
            'roro-core-settings',                  // スラッグ
            [__CLASS__, 'render'],                 // コールバック
            'dashicons-admin-generic',             // アイコン
            65
        );
    }

    /** 設定ページ表示・保存 */
    public static function render(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions.', 'roro-core-wp'));
        }

        $opts = (array) get_option(self::OPT_KEY, [
            'enable_geolocation' => 0,
            'chat_mode'          => 'dify_embed', // dify_embed|dify_api|openai_api
            'dify_embed'         => '',
            'dify_api_base'      => '',
            'dify_api_key'       => '',
            'openai_api_key'     => '',
            'map_api_key'        => '',
        ]);

        // 保存処理
        if (isset($_POST['roro_submit'])) {
            check_admin_referer('roro_core_settings');

            // 地図
            $opts['enable_geolocation'] = isset($_POST['enable_geolocation']) ? 1 : 0;
            $opts['map_api_key']        = isset($_POST['map_api_key']) ? sanitize_text_field((string)$_POST['map_api_key']) : '';

            // チャット
            $chat_mode = sanitize_text_field($_POST['chat_mode'] ?? 'dify_embed');
            if (!in_array($chat_mode, ['dify_embed','dify_api','openai_api'], true)) {
                $chat_mode = 'dify_embed';
            }
            $opts['chat_mode']    = $chat_mode;
            $opts['dify_embed']   = wp_kses_post((string)($_POST['dify_embed_script'] ?? ''));
            $opts['dify_api_base']= esc_url_raw((string)($_POST['dify_api_base'] ?? ''));

            // APIキーは「********」の場合は既存値を維持
            $dify_key = (string)($_POST['dify_api_key'] ?? '');
            if ($dify_key !== '********') {
                $opts['dify_api_key'] = sanitize_text_field($dify_key);
            }
            $openai_key = (string)($_POST['openai_api_key'] ?? '');
            if ($openai_key !== '********') {
                $opts['openai_api_key'] = sanitize_text_field($openai_key);
            }

            update_option(self::OPT_KEY, $opts, false);
            echo '<div class="updated"><p>'.esc_html__('Saved settings.', 'roro-core-wp').'</p></div>';
        }

        // 表示用（キー伏字）
        $dify_api_key_mask  = empty($opts['dify_api_key'])  ? '' : '********';
        $openai_api_key_mask= empty($opts['openai_api_key'])? '' : '********';

        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('RORO Settings', 'roro-core-wp'); ?></h1>
            <form method="post">
                <?php wp_nonce_field('roro_core_settings'); ?>

                <h2 class="title"><?php echo esc_html__('Map', 'roro-core-wp'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Geolocation', 'roro-core-wp'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_geolocation" value="1" <?php checked(1, (int)$opts['enable_geolocation']); ?> />
                                <?php echo esc_html__('Detect user location and center the map.', 'roro-core-wp'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('If unchecked, the map will use a default center.', 'roro-core-wp'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Google Maps API Key', 'roro-core-wp'); ?></th>
                        <td>
                            <input type="text" name="map_api_key" value="<?php echo esc_attr((string)$opts['map_api_key']); ?>" class="regular-text" />
                            <p class="description"><?php echo esc_html__('Do not hardcode keys. Store them here.', 'roro-core-wp'); ?></p>
                        </td>
                    </tr>
                </table>

                <h2 class="title"><?php echo esc_html__('Chatbot', 'roro-core-wp'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Mode', 'roro-core-wp'); ?></th>
                        <td>
                            <select name="chat_mode">
                                <option value="dify_embed" <?php selected($opts['chat_mode'],'dify_embed'); ?>>Dify (Embed UI)</option>
                                <option value="dify_api"   <?php selected($opts['chat_mode'],'dify_api'); ?>>Dify API</option>
                                <option value="openai_api" <?php selected($opts['chat_mode'],'openai_api'); ?>>OpenAI API</option>
                            </select>
                            <p class="description"><?php echo esc_html__('Switch between embedding Dify UI or calling APIs from server side.', 'roro-core-wp'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Dify Embed Script', 'roro-core-wp'); ?></th>
                        <td>
                            <textarea name="dify_embed_script" rows="4" style="width:100%;"><?php echo esc_textarea((string)$opts['dify_embed']); ?></textarea>
                            <p class="description"><?php echo esc_html__('Paste the Dify embed snippet. Output will be sanitized.', 'roro-core-wp'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Dify API Base', 'roro-core-wp'); ?></th>
                        <td>
                            <input type="url" name="dify_api_base" value="<?php echo esc_attr((string)$opts['dify_api_base']); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Dify API Key', 'roro-core-wp'); ?></th>
                        <td>
                            <input type="text" name="dify_api_key" value="<?php echo esc_attr($dify_api_key_mask); ?>" class="regular-text" />
                            <p class="description"><?php echo esc_html__('Enter "********" to keep current value.', 'roro-core-wp'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('OpenAI API Key', 'roro-core-wp'); ?></th>
                        <td>
                            <input type="text" name="openai_api_key" value="<?php echo esc_attr($openai_api_key_mask); ?>" class="regular-text" />
                        </td>
                    </tr>
                </table>

                <?php submit_button(__('Save Changes', 'roro-core-wp'), 'primary', 'roro_submit'); ?>
            </form>
        </div>
        <?php
    }
}

endif;
Roro_Core_Admin::boot();
