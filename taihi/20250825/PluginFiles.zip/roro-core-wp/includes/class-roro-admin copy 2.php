<?php
// ... クラス定義の中の render_settings_page() 保存/表示部に追加

// 保存時
$opts = (array) get_option('roro_core_settings', []);
if (isset($_POST['roro_submit'])) {
  check_admin_referer('roro_core_settings');
  // 既存項目に加えてチャット設定
  $chat_mode     = sanitize_text_field($_POST['chat_mode'] ?? 'dify_embed'); // dify_embed|dify_api|openai_api
  $dify_embed    = wp_kses_post($_POST['dify_embed_script'] ?? '');          // 埋め込みスニペット（<script>...可）※表示時は注意
  $dify_api_base = esc_url_raw($_POST['dify_api_base'] ?? '');
  $dify_api_key  = sanitize_text_field($_POST['dify_api_key'] ?? '');
  $openai_api_key= sanitize_text_field($_POST['openai_api_key'] ?? '');

  $opts['chat_mode']       = $chat_mode;
  $opts['dify_embed']      = $dify_embed;
  $opts['dify_api_base']   = $dify_api_base;
  if ($dify_api_key !== '********') { $opts['dify_api_key'] = $dify_api_key; } // 画面で "********" のままなら保存し直さない
  if ($openai_api_key !== '********') { $opts['openai_api_key'] = $openai_api_key; }

  update_option('roro_core_settings', $opts, false);
  echo '<div class="updated"><p>'.esc_html__('Saved.', 'roro-core-wp').'</p></div>';
}

// 表示
$chat_mode     = $opts['chat_mode'] ?? 'dify_embed';
$dify_embed    = $opts['dify_embed'] ?? '';
$dify_api_base = $opts['dify_api_base'] ?? '';
$dify_api_key  = !empty($opts['dify_api_key']) ? '********' : '';
$openai_api_key= !empty($opts['openai_api_key']) ? '********' : '';

?>
<h2><?php echo esc_html__('Chatbot Settings', 'roro-core-wp'); ?></h2>
<table class="form-table">
  <tr>
    <th><?php echo esc_html__('Mode', 'roro-core-wp'); ?></th>
    <td>
      <select name="chat_mode">
        <option value="dify_embed" <?php selected($chat_mode,'dify_embed'); ?>>Dify (Embed UI)</option>
        <option value="dify_api"   <?php selected($chat_mode,'dify_api'); ?>>Dify API</option>
        <option value="openai_api" <?php selected($chat_mode,'openai_api'); ?>>OpenAI API</option>
      </select>
      <p class="description"><?php echo esc_html__('Switch between embedding Dify UI or calling APIs from server side.', 'roro-core-wp'); ?></p>
    </td>
  </tr>
  <tr>
    <th><?php echo esc_html__('Dify Embed Script', 'roro-core-wp'); ?></th>
    <td>
      <textarea name="dify_embed_script" rows="4" style="width:100%;"><?php echo esc_textarea($dify_embed); ?></textarea>
      <p class="description"><?php echo esc_html__('Paste the Dify embed snippet (it will be sanitized when output).', 'roro-core-wp'); ?></p>
    </td>
  </tr>
  <tr>
    <th><?php echo esc_html__('Dify API Base', 'roro-core-wp'); ?></th>
    <td><input type="url" name="dify_api_base" value="<?php echo esc_attr($dify_api_base); ?>" class="regular-text" /></td>
  </tr>
  <tr>
    <th><?php echo esc_html__('Dify API Key', 'roro-core-wp'); ?></th>
    <td><input type="text" name="dify_api_key" value="<?php echo esc_attr($dify_api_key); ?>" class="regular-text" />
      <p class="description"><?php echo esc_html__('Enter "********" to keep current value.', 'roro-core-wp'); ?></p></td>
  </tr>
  <tr>
    <th><?php echo esc_html__('OpenAI API Key', 'roro-core-wp'); ?></th>
    <td><input type="text" name="openai_api_key" value="<?php echo esc_attr($openai_api_key); ?>" class="regular-text" /></td>
  </tr>
</table>
