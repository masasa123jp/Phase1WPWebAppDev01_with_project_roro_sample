<?php
/**
 * 管理画面の設定ページを生成するクラス (roro-core-wp)
 */
class Roro_Core_Admin {
    /**
     * コンストラクタ - 管理メニューと設定の初期化
     */
    public function __construct() {
        // 管理メニューに設定ページを追加
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }

    /**
     * 管理メニューに「RoRo Core 設定」ページを追加
     */
    public function add_admin_menu() {
        add_menu_page(
            'RoRo Core 設定',            // ページタイトル
            'RoRo Core 設定',            // メニュータイトル
            'manage_options',           // 権限
            'roro-core-settings',       // メニュースラッグ
            array($this, 'render_settings_page'), // ページコールバック関数
            'dashicons-location-alt',   // アイコン (例: 地図アイコン)
            65                          // メニューの位置
        );
    }

    /**
     * 設定ページのHTMLを出力
     */
    public function render_settings_page() {
        // フォーム送信時にenable_geolocation設定を保存
        if (isset($_POST['roro_core_settings_submit'])) {
            // セキュリティチェック (nonceと権限)
            if (!isset($_POST['roro_core_settings_nonce']) || !wp_verify_nonce($_POST['roro_core_settings_nonce'], 'roro_core_settings_action')) {
                echo '<div class="error"><p>不正なリクエストです。</p></div>';
            } else {
                $enable_geo = isset($_POST['enable_geolocation']) ? 1 : 0;
                update_option('roro_core_enable_geolocation', $enable_geo);
                echo '<div class="updated"><p>設定を保存しました。</p></div>';
            }
        }

        // 現在の設定値を取得してチェックボックスの状態を決める
        $enable_geo_val = get_option('roro_core_enable_geolocation', 0);
        ?>
        <div class="wrap">
            <h1>RoRo Core 設定</h1>
            <form method="post" action="">
                <?php wp_nonce_field('roro_core_settings_action', 'roro_core_settings_nonce'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">現在地検出機能を有効化</th>
                        <td>
                            <label for="enable_geolocation">
                                <input type="checkbox" id="enable_geolocation" name="enable_geolocation" value="1" <?php checked(1, $enable_geo_val); ?> />
                                有効にする
                            </label>
                            <p class="description">ユーザーの現在地を検出して地図の初期中央位置に設定します。</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('設定を保存', 'primary', 'roro_core_settings_submit'); ?>
            </form>
        </div>
        <?php
    }
}
