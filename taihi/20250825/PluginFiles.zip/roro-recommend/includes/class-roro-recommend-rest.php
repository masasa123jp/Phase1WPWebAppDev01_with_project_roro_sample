<?php
/**
 * /roro/v1/recommend/today?limit=3
 * カード配列を返却（マップCTA付き）
 */
defined('ABSPATH') || exit;

if (!class_exists('RORO_Recommend_REST')):
final class RORO_Recommend_REST {

  public function register_routes(): void {
    register_rest_route('roro/v1','/recommend/today',[
      'methods'=>\WP_REST_Server::READABLE,
      'callback'=>[$this,'today'],
      'permission_callback'=>'__return_true',
      'args'=>['limit'=>['type'=>'integer','required'=>false]]
    ]);
  }

  public function today(\WP_REST_Request $req){
    $limit = max(1, (int)$req->get_param('limit'));
    $svc = new \RORO_Recommend_Service();
    $res = $svc->pick_today(get_current_user_id(), ['limit'=>$limit]);
    return new \WP_REST_Response($res, 200);
  }
}
endif;
