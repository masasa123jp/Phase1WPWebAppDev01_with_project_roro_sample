<?php
if (!defined('ABSPATH')) { exit; }

/**
 * 今日のおすすめ生成ロジック
 * - 代表ペットの犬種カテゴリ（A〜H）を参照
 * - 近隣（都道府県/市区）イベントを優先
 * - 過去に提示したIDを除外（重複回避）
 */
final class RORO_Recommend_Service {

  /** 今日のおすすめを返す（1件 or 複数カード） */
  public function pick_today(int $user_id, array $opts = []) : array {
    global $wpdb;

    $customer = $this->get_customer($user_id);
    if (!$customer) return ['items'=>[]];

    $lang = $this->ui_lang();
    $category = $this->pet_category($customer['default_pet_id']); // A〜H or null

    // 地域（都道府県 or city）が取れれば利用
    $pref = $customer['prefecture'] ?? null;
    $city = $customer['address2'] ?? null; // 実DBに合わせて調整

    // 過去提示を取得（直近30日）
    $seen = $this->seen_item_ids($customer['id'], 30);

    // 候補: 直近開催のイベント（本日以降）を検索
    $now = current_time('mysql');
    $sql = "SELECT id, title, description, start_time, latitude, longitude, address, city, category
              FROM RORO_EVENTS_MASTER
             WHERE start_time >= %s";
    $params = [$now];

    if ($pref) {
      $sql .= " AND (prefecture=%s OR prefecture IS NULL)"; $params[] = $pref;
    }
    if ($category) {
      // イベントのcategoryカラムが犬種カテゴリに対応していない場合は、今は無条件
      // ここでは例として category 文字列に A〜H を含む実装に合わせる
      $sql .= " AND (category IS NULL OR category='' OR category LIKE %s)";
      $params[] = '%'.$wpdb->esc_like($category).'%';
    }

    $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    if (!is_array($rows)) $rows = [];

    // 既視を除外
    $candidates = array_values(array_filter($rows, function($r) use ($seen){ return !in_array(intval($r['id']), $seen, true); }));

    // まだ無ければ少し緩める（pref条件外も含める）
    if (!$candidates && $rows) $candidates = $rows;

    // シャッフルして上位を採用（カード複数の将来拡張も考慮）
    shuffle($candidates);
    $take = array_slice($candidates, 0, max(1, intval($opts['limit'] ?? 1)));

    // ログに記録（重複回避用）
    foreach ($take as $it) {
      $this->log_recommend($customer['id'], 'event', intval($it['id']));
    }

    // 表示用カード
    $cards = array_map(function($it) use ($lang){
      return [
        'type'  => 'event',
        'id'    => intval($it['id']),
        'title' => $it['title'],
        'desc'  => $it['description'],
        'when'  => $it['start_time'],
        'lat'   => floatval($it['latitude']),
        'lng'   => floatval($it['longitude']),
        'address'=> $it['address'],
        'city'  => $it['city'],
        'cta'   => home_url( add_query_arg(['highlight_event'=>intval($it['id'])], '/map/') ),
      ];
    }, $take);

    return ['items'=>$cards, 'lang'=>$lang];
  }

  private function get_customer(int $user_id) : ?array {
    global $wpdb;
    if (!$user_id) $user_id = get_current_user_id();
    $row = $wpdb->get_row($wpdb->prepare(
      "SELECT c.* FROM RORO_CUSTOMER c 
        JOIN RORO_USER_LINK_WP l ON c.id=l.customer_id
       WHERE l.wp_user_id=%d", $user_id
    ), ARRAY_A);
    if (!$row) return null;
    return [
      'id' => intval($row['id']),
      'prefecture' => $row['prefecture'] ?? null,
      'address2'   => $row['address2'] ?? null,
      'default_pet_id' => intval($row['default_pet_id'] ?? 0),
      'language_code'  => $row['language_code'] ?? 'ja',
    ];
  }

  private function ui_lang() : string {
    $lg = substr(get_locale(), 0, 2);
    return in_array($lg, ['ja','en','zh','ko'], true) ? $lg : 'ja';
  }

  private function pet_category(int $pet_id) : ?string {
    if ($pet_id<=0) return null;
    global $wpdb;
    $cat = $wpdb->get_var( $wpdb->prepare("SELECT category FROM RORO_PET WHERE id=%d", $pet_id) );
    if (!$cat) return null;
    $cat = strtoupper( (string) $cat );
    return in_array($cat, ['A','B','C','D','E','F','G','H'], true) ? $cat : null;
  }

  /** 既視（ログ）の取得 */
  private function seen_item_ids(int $customer_id, int $days = 30) : array {
    global $wpdb;
    $since = gmdate('Y-m-d H:i:s', time() - $days*86400);
    $ids = $wpdb->get_col( $wpdb->prepare(
      "SELECT target_id FROM RORO_RECOMMENDATION_LOG 
        WHERE customer_id=%d AND created_at >= %s", $customer_id, $since
    ));
    return array_map('intval', $ids ?: []);
  }

  /** ログ書き込み */
  private function log_recommend(int $customer_id, string $type, int $id) : void {
    global $wpdb;
    $wpdb->insert('RORO_RECOMMENDATION_LOG', [
      'customer_id'=>$customer_id,
      'target'     =>$type,
      'target_id'  =>$id,
      'created_at' => current_time('mysql', 1),
    ], ['%d','%s','%d','%s']);
  }
}
