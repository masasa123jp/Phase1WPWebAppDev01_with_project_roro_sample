<?php
/**
 * レコメンド機能の管理と A/B テスト分岐。
 *
 * 重複表示回避期間やキャッシュ制御も含む。
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Roro_Recommend_Manager {

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ) );
        add_shortcode( 'roro_recommendations', array( __CLASS__, 'render_recommendations' ) );
    }

    public static function add_admin_menu() {
        add_menu_page(
            __( 'Recommendation', 'roro-recommend' ),
            __( 'Recommendation', 'roro-recommend' ),
            'manage_options',
            'roro-recommend',
            array( __CLASS__, 'render_admin_page' ),
            'dashicons-thumbs-up'
        );
    }

    public static function render_admin_page() {
        $segment = get_option( 'roro_recommend_segment', 'A' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'おすすめ管理', 'roro-recommend' ); ?></h1>
            <form method="post" action="">
                <?php settings_fields( 'roro-recommend' ); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'A/B テストセグメント', 'roro-recommend' ); ?></th>
                        <td>
                            <label><input type="radio" name="roro_recommend_segment" value="A" <?php checked( $segment, 'A' ); ?>> A</label>
                            <label><input type="radio" name="roro_recommend_segment" value="B" <?php checked( $segment, 'B' ); ?>> B</label>
                            <p class="description"><?php esc_html_e( '表示パターンを切替えます。', 'roro-recommend' ); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /**
     * 推薦カード UI の表示。
     *
     * @return string
     */
    public static function render_recommendations() {
        $segment = get_option( 'roro_recommend_segment', 'A' );
        $recommendations = self::get_recommendations( $segment );

        ob_start();
        ?>
        <div class="roro-recommend-carousel">
            <?php foreach ( $recommendations as $item ) : ?>
                <div class="recommend-card">
                    <a href="<?php echo esc_url( $item['link'] ); ?>">
                        <img src="<?php echo esc_url( $item['image'] ); ?>" alt="">
                        <h3><?php echo esc_html( $item['title'] ); ?></h3>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        <script>
        (function($){
            // カルーセルの初期化（簡易）
            var index = 0;
            var cards = $('.recommend-card');
            function showCards() {
                cards.hide();
                cards.slice(index, index + 3).show();
            }
            showCards();
            $('.roro-recommend-carousel').on('click', function(){
                index = (index + 1) % cards.length;
                showCards();
            });
        })(jQuery);
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * 推薦データ取得。
     *
     * @param string $segment セグメント A/B
     * @return array
     */
    private static function get_recommendations( $segment ) {
        // デモ用に静的データを返す。実装では DB クエリや API で取得し、重複表示回避やキャッシュを考慮する。
        $data = array(
            array(
                'title' => __( 'クールマット', 'roro-recommend' ),
                'link'  => '#',
                'image' => plugins_url( '../assets/img/product_cooling_mat.png', __FILE__ ),
            ),
            array(
                'title' => __( 'レインコートとブーツ', 'roro-recommend' ),
                'link'  => '#',
                'image' => plugins_url( '../assets/img/product_raincoat_boots.png', __FILE__ ),
            ),
            array(
                'title' => __( 'UV カットウェア', 'roro-recommend' ),
                'link'  => '#',
                'image' => plugins_url( '../assets/img/product_uv_clothes.png', __FILE__ ),
            ),
        );
        // セグメントに応じて配列をシャッフルする例
        if ( 'B' === $segment ) {
            shuffle( $data );
        }
        return $data;
    }
}

Roro_Recommend_Manager::init();
