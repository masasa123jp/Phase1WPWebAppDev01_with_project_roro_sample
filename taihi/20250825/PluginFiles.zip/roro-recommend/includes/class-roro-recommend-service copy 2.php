<?php
/**
 * 今日のおすすめ（イベント中心）
 * - 代表ペットのカテゴリ（A〜H）・地域（prefecture）・過去提示履歴で重複回避
 * Text Domain: roro-recommend
 */
defined('ABSPATH') || exit;

if (!class_exists('RORO_Recommend_Service')):
final class RORO_Recommend_Service {

  public function pick_today(int $user_id, array $opt=[]): array {
    global $wpdb;

    $customer = $this->get_customer($user_id);
    if (!$customer) return ['items'=>[]];

    $pref = $customer['prefecture'] ?? null;
    $cat  = $this->pet_category((int)$customer['default_pet_id']);
    $seen = $this->seen_ids((int)$customer['id'], 30); // 30日重複回避

    $now = current_time('mysql');
    $sql = "SELECT id, title, description, start_time, latitude, longitude, address, city, category
              FROM RORO_EVENTS_MASTER
             WHERE start_time >= %s";
    $params = [$now];
    if ($pref) {
      $sql .= " AND (prefecture=%s OR prefecture IS NULL)"; $params[]=$pref;
    }
    if ($cat) {
      $sql .= " AND (category IS NULL OR category='' OR category LIKE %s)";
      $params[]='%'.$wpdb->esc_like($cat).'%';
    }
    $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) ?: [];

    // 重複除外
    $rows = array_values(array_filter($rows, fn($r)=> !in_array((int)$r['id'], $seen, true)));

    // 候補が無ければ条件緩和
    if (!$rows) {
      $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, title, description, start_time, latitude, longitude, address, city, category
           FROM RORO_EVENTS_MASTER WHERE start_time >= %s", $now
      ), ARRAY_A) ?: [];
    }
    shuffle($rows);

    $take = array_slice($rows, 0, max(1, (int)($opt['limit'] ?? 3)));
    foreach ($take as $t) {
      $this->log_recommend((int)$customer['id'], 'event', (int)$t['id']);
    }

    $cards = array_map(function($it){
      return [
        'type'  => 'event',
        'id'    => (int)$it['id'],
        'title' => (string)$it['title'],
        'desc'  => (string)$it['description'],
        'when'  => (string)$it['start_time'],
        'lat'   => (float)$it['latitude'],
        'lng'   => (float)$it['longitude'],
        'address'=>(string)$it['address'],
        'city'  => (string)$it['city'],
        'cta'   => home_url( add_query_arg(['highlight_event'=>(int)$it['id']], '/map/') ),
      ];
    }, $take);

    return ['items'=>$cards];
  }

  private function get_customer(int $user_id): ?array {
    global $wpdb;
    if (!$user_id) $user_id = get_current_user_id();
    $row = $wpdb->get_row($wpdb->prepare(
      "SELECT c.* FROM RORO_CUSTOMER c JOIN RORO_USER_LINK_WP l ON c.id=l.customer_id WHERE l.wp_user_id=%d",
      $user_id
    ), ARRAY_A);
    if (!$row) return null;
    return [
      'id'=>(int)$row['id'],
      'prefecture'=>$row['prefecture'] ?? null,
      'default_pet_id'=>(int)($row['default_pet_id'] ?? 0),
    ];
  }

  private function pet_category(int $pet_id): ?string {
    if ($pet_id<=0) return null;
    global $wpdb;
    $cat = $wpdb->get_var($wpdb->prepare("SELECT category FROM RORO_PET WHERE id=%d", $pet_id));
    $cat = strtoupper((string)$cat);
    return in_array($cat, ['A','B','C','D','E','F','G','H'], true) ? $cat : null;
  }

  private function seen_ids(int $customer_id, int $days): array {
    global $wpdb;
    $since = gmdate('Y-m-d H:i:s', time() - $days*86400);
    $ids = $wpdb->get_col($wpdb->prepare(
      "SELECT target_id FROM RORO_RECOMMENDATION_LOG WHERE customer_id=%d AND created_at >= %s",
      $customer_id, $since
    ));
    return array_map('intval', $ids ?: []);
  }

  private function log_recommend(int $customer_id, string $type, int $id): void {
    global $wpdb;
    $wpdb->insert('RORO_RECOMMENDATION_LOG', [
      'customer_id'=>$customer_id,
      'target'=>$type,
      'target_id'=>$id,
      'created_at'=>current_time('mysql',1),
    ], ['%d','%s','%d','%s']);
  }
}
endif;
