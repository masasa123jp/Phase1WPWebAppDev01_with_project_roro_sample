<?php
if (!defined('ABSPATH')) { exit; }

/**
 * /roro/v1/map/search?category=event|shop|park&period=today|week|month|any&distance=10&lat=...&lng=...
 * - Haversine で距離フィルタ
 * - 期間フィルタは roro_start/roro_end メタを使用
 */
class Roro_Map_REST {
    public function register_routes() {
        register_rest_route('roro/v1', '/map/search', [
            'methods'  => 'GET',
            'callback' => [$this, 'search'],
            'permission_callback' => '__return_true',
            'args' => [
                'category' => ['type'=>'string','required'=>false],
                'period'   => ['type'=>'string','required'=>false],
                'distance' => ['type'=>'number','required'=>false],
                'lat'      => ['type'=>'number','required'=>false],
                'lng'      => ['type'=>'number','required'=>false],
            ],
        ]);
    }

    public function search(WP_REST_Request $req) {
        $category = sanitize_text_field($req->get_param('category') ?: '');
        $period   = sanitize_text_field($req->get_param('period') ?: 'any');
        $distance = floatval($req->get_param('distance') ?: 0);
        $lat      = floatval($req->get_param('lat') ?: 0);
        $lng      = floatval($req->get_param('lng') ?: 0);

        $meta_query = [];
        // 期間の前後連携（開始 <= now <= 終了 などを簡易で）
        $now = current_time('Y-m-d\TH:i');
        if ($period === 'today') {
            $start = date('Y-m-d\T00:00', current_time('timestamp'));
            $end   = date('Y-m-d\T23:59', current_time('timestamp'));
            $meta_query[] = ['key'=>'roro_start','value'=>$end,'compare'=>'<=','type'=>'CHAR'];
            $meta_query[] = ['key'=>'roro_end','value'=>$start,'compare'=>'>=','type'=>'CHAR'];
        } elseif ($period === 'week') {
            $start = date('Y-m-d\T00:00', strtotime('monday this week', current_time('timestamp')));
            $end   = date('Y-m-d\T23:59', strtotime('sunday this week', current_time('timestamp')));
            $meta_query[] = ['key'=>'roro_end','value'=>$start,'compare'=>'>=','type'=>'CHAR'];
            $meta_query[] = ['key'=>'roro_start','value'=>$end,'compare'=>'<=','type'=>'CHAR'];
        } elseif ($period === 'month') {
            $start = date('Y-m-01\T00:00', current_time('timestamp'));
            $end   = date('Y-m-t\T23:59', current_time('timestamp'));
            $meta_query[] = ['key'=>'roro_end','value'=>$start,'compare'=>'>=','type'=>'CHAR'];
            $meta_query[] = ['key'=>'roro_start','value'=>$end,'compare'=>'<=','type'=>'CHAR'];
        }

        $args = [
            'post_type' => 'roro_event',
            'posts_per_page' => 50,
            'meta_query' => $meta_query ?: [],
        ];
        if ($category) {
            $args['meta_query'][] = ['key'=>'roro_category','value'=>$category,'compare'=>'='];
        }
        $q = new WP_Query($args);
        $items = [];
        foreach ($q->posts as $p) {
            $lat2 = (float) get_post_meta($p->ID, 'roro_lat', true);
            $lng2 = (float) get_post_meta($p->ID, 'roro_lng', true);
            $dist = ($lat && $lng && $lat2 && $lng2) ? $this->haversine($lat, $lng, $lat2, $lng2) : null;
            if ($distance > 0 && $dist !== null && $dist > $distance) {
                continue;
            }
            $items[] = [
                'id'    => $p->ID,
                'title' => get_the_title($p),
                'excerpt' => wp_strip_all_tags(get_the_excerpt($p)),
                'permalink' => get_permalink($p),
                'category'  => get_post_meta($p->ID, 'roro_category', true),
                'start'     => get_post_meta($p->ID, 'roro_start', true),
                'end'       => get_post_meta($p->ID, 'roro_end', true),
                'lat'       => $lat2,
                'lng'       => $lng2,
                'distance'  => $dist, // km
            ];
        }
        return ['items' => $items];
    }

    protected function haversine($lat1,$lon1,$lat2,$lon2) {
        $R = 6371; // km
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat/2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) ** 2;
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        return $R * $c;
    }
}
