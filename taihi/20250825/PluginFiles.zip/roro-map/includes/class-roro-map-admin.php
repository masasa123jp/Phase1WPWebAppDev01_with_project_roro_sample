<?php
if (!defined('ABSPATH')) { exit; }

/**
 * 主催者入力 UI（イベント投稿にメタボックス）
 * - 主催者名、連絡先、開始/終了日時、緯度経度、カテゴリ（event/park/shop）
 */
class Roro_Map_Admin {
    public function __construct() {
        add_action('add_meta_boxes', [$this, 'box']);
        add_action('save_post_roro_event', [$this, 'save']);
    }
    public function box() {
        add_meta_box('roro_event_meta', __('Event Details', 'roro'), [$this, 'render'], 'roro_event', 'normal', 'high');
    }
    public function render(WP_Post $post) {
        wp_nonce_field('roro_event_meta', 'roro_event_meta_nonce');
        $m = function ($k, $d='') use ($post) { return get_post_meta($post->ID, $k, true) ?: $d; };
        ?>
        <p><label><?php echo esc_html__('Organizer', 'roro'); ?>
            <input type="text" name="roro_org_name" class="widefat" value="<?php echo esc_attr($m('roro_org_name')); ?>">
        </label></p>
        <p><label><?php echo esc_html__('Contact', 'roro'); ?>
            <input type="text" name="roro_org_contact" class="widefat" value="<?php echo esc_attr($m('roro_org_contact')); ?>">
        </label></p>
        <p><label><?php echo esc_html__('Start date/time', 'roro'); ?>
            <input type="datetime-local" name="roro_start" value="<?php echo esc_attr($m('roro_start')); ?>">
        </label>
        <label><?php echo esc_html__('End date/time', 'roro'); ?>
            <input type="datetime-local" name="roro_end" value="<?php echo esc_attr($m('roro_end')); ?>">
        </label></p>
        <p><label><?php echo esc_html__('Latitude', 'roro'); ?>
            <input type="text" name="roro_lat" value="<?php echo esc_attr($m('roro_lat')); ?>">
        </label>
        <label><?php echo esc_html__('Longitude', 'roro'); ?>
            <input type="text" name="roro_lng" value="<?php echo esc_attr($m('roro_lng')); ?>">
        </label></p>
        <p><label><?php echo esc_html__('Category', 'roro'); ?>
            <select name="roro_category">
                <?php
                $cat = $m('roro_category', 'event');
                foreach (['event','shop','park'] as $c) {
                    printf('<option value="%1$s"%2$s>%3$s</option>',
                        esc_attr($c),
                        selected($cat, $c, false),
                        esc_html(ucfirst($c))
                    );
                }
                ?>
            </select>
        </label></p>
        <?php
    }
    public function save($post_id) {
        if (!isset($_POST['roro_event_meta_nonce']) || !wp_verify_nonce($_POST['roro_event_meta_nonce'], 'roro_event_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (!current_user_can('edit_post', $post_id)) { return; }

        $fields = ['roro_org_name','roro_org_contact','roro_start','roro_end','roro_lat','roro_lng','roro_category'];
        foreach ($fields as $f) {
            $val = isset($_POST[$f]) ? sanitize_text_field($_POST[$f]) : '';
            update_post_meta($post_id, $f, $val);
        }
    }
}
new Roro_Map_Admin();
