<?php
/**
 * Admin meta box for event organizer fields
 *
 * @package roro-map
 */

defined('ABSPATH') || exit;

if (!class_exists('RORO_Map_Organizer_Admin')) {
    class RORO_Map_Organizer_Admin {

        public static function init() {
            add_action('add_meta_boxes', [__CLASS__, 'add_box']);
            add_action('save_post', [__CLASS__, 'save'], 10, 2);
        }

        public static function add_box() {
            add_meta_box(
                'roro_event_organizer',
                __('Event details (RORO)', 'roro'),
                [__CLASS__, 'render'],
                'roro_event', // CPT 名は適宜
                'normal',
                'default'
            );
        }

        public static function render($post) {
            wp_nonce_field('roro_event_organizer', '_wpnonce_roro_event');
            $when = get_post_meta($post->ID, '_roro_event_datetime', true);
            $addr = get_post_meta($post->ID, '_roro_event_address', true);
            $host = get_post_meta($post->ID, '_roro_event_host', true);
            ?>
            <p>
                <label for="roro_event_datetime"><?php echo esc_html__('Date & Time', 'roro'); ?></label><br/>
                <input type="text" id="roro_event_datetime" name="roro_event_datetime" value="<?php echo esc_attr($when); ?>" class="widefat"/>
            </p>
            <p>
                <label for="roro_event_address"><?php echo esc_html__('Address', 'roro'); ?></label><br/>
                <input type="text" id="roro_event_address" name="roro_event_address" value="<?php echo esc_attr($addr); ?>" class="widefat"/>
            </p>
            <p>
                <label for="roro_event_host"><?php echo esc_html__('Organizer', 'roro'); ?></label><br/>
                <input type="text" id="roro_event_host" name="roro_event_host" value="<?php echo esc_attr($host); ?>" class="widefat"/>
            </p>
            <?php
        }

        public static function save($post_id, $post) {
            if (!isset($_POST['_wpnonce_roro_event']) || !wp_verify_nonce($_POST['_wpnonce_roro_event'], 'roro_event_organizer')) {
                return;
            }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
            if (!current_user_can('edit_post', $post_id)) return;

            $fields = [
                '_roro_event_datetime' => 'roro_event_datetime',
                '_roro_event_address'  => 'roro_event_address',
                '_roro_event_host'     => 'roro_event_host',
            ];
            foreach ($fields as $meta_key => $post_key) {
                if (isset($_POST[$post_key])) {
                    update_post_meta($post_id, $meta_key, sanitize_text_field(wp_unslash($_POST[$post_key])));
                }
            }
        }
    }

    RORO_Map_Organizer_Admin::init();
}
