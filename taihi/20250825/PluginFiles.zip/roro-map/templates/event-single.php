<?php
/**
 * Event single template (simple)
 *
 * @package roro-map
 */

defined('ABSPATH') || exit;

global $post;
$event_id = get_the_ID();
$when  = get_post_meta($event_id, '_roro_event_datetime', true);
$addr  = get_post_meta($event_id, '_roro_event_address', true);
$host  = get_post_meta($event_id, '_roro_event_host', true);

?>
<article class="roro-event">
  <h1><?php echo esc_html(get_the_title()); ?></h1>
  <?php if ($when): ?>
    <p><strong><?php echo esc_html__('Date & Time', 'roro'); ?>:</strong> <?php echo esc_html($when); ?></p>
  <?php endif; ?>
  <?php if ($addr): ?>
    <p><strong><?php echo esc_html__('Address', 'roro'); ?>:</strong> <?php echo esc_html($addr); ?></p>
  <?php endif; ?>
  <?php if ($host): ?>
    <p><strong><?php echo esc_html__('Organizer', 'roro'); ?>:</strong> <?php echo esc_html($host); ?></p>
  <?php endif; ?>
  <div class="roro-event__content">
    <?php the_content(); ?>
  </div>
</article>
