<?php
/**
 * Events archive with filters (keyword/category/date-range/distance)
 *
 * @package roro-map
 */

defined('ABSPATH') || exit;

wp_enqueue_script(
    'roro-map-search',
    plugins_url('../assets/js/roro-map-search.js', __FILE__),
    ['jquery'],
    '1.0',
    true
);
wp_localize_script('roro-map-search', 'RORO_MAP_I18N', [
    'search'    => __('Search', 'roro'),
    'category'  => __('Category', 'roro'),
    'distance'  => __('Distance', 'roro'),
    'from'      => __('From', 'roro'),
    'to'        => __('To', 'roro'),
    'noResults' => __('No events found.', 'roro'),
]);

?>
<div class="roro-map-archive" role="region" aria-label="<?php echo esc_attr__('Event search', 'roro'); ?>">
  <form class="roro-map-filters" aria-describedby="roro-search-hint">
    <input type="search" name="q" placeholder="<?php echo esc_attr__('Keyword', 'roro'); ?>" />
    <select name="category" aria-label="<?php echo esc_attr__('Category', 'roro'); ?>"></select>
    <select name="distance">
      <option value="5">5km</option>
      <option value="10">10km</option>
      <option value="25">25km</option>
      <option value="50">50km</option>
    </select>
    <input type="date" name="from" />
    <input type="date" name="to" />
    <button type="submit" class="button button-primary"><?php echo esc_html__('Search', 'roro'); ?></button>
    <p id="roro-search-hint" class="screen-reader-text"><?php echo esc_html__('Use filters to narrow results.', 'roro'); ?></p>
  </form>

  <div id="roro-map-results" role="list"></div>
</div>
