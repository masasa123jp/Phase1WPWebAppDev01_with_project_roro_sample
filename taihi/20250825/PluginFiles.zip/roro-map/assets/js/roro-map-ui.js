/* global roroMap, wp */
(function(){
  const { __ } = wp.i18n;
  const rest = roroMap.rest;
  const root = document.querySelector('.roro-map-filter');
  if (!root) return;

  const results = root.querySelector('#roro-results');
  const btnApply = root.querySelector('#roro-apply');
  const btnClear = root.querySelector('#roro-clear');

  let currentPage = 1;

  function readFilters() {
    return {
      category: root.querySelector('#roro-cat').value.trim(),
      from: root.querySelector('#roro-from').value,
      to: root.querySelector('#roro-to').value,
      distance: root.querySelector('#roro-distance').value || 50,
      type: root.querySelector('#roro-type').value
    };
  }

  async function locate() {
    return new Promise((resolve) => {
      if (!navigator.geolocation) return resolve(null);
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => resolve(null),
        { enableHighAccuracy: true, timeout: 5000 }
      );
    });
  }

  async function search(page=1) {
    currentPage = page;
    const f = readFilters();
    const geo = await locate();
    const params = new URLSearchParams();
    if (geo) { params.set('lat', geo.lat); params.set('lng', geo.lng); }
    Object.entries(f).forEach(([k,v])=> v && params.set(k,v));
    params.set('page', page);
    results.textContent = __('Loading...', 'roro');
    try {
      const res = await fetch(`${rest}/map/search?${params.toString()}`);
      const json = await res.json();
      render(json);
    } catch (e) {
      results.textContent = __('Network error', 'roro');
    }
  }

  function render(data) {
    results.innerHTML = '';
    const items = data.items || [];
    if (!items.length) {
      results.textContent = __('No results', 'roro');
      return;
    }
    items.forEach(it => {
      const div = document.createElement('div');
      div.className = 'roro-card';
      div.setAttribute('role', 'listitem');
      div.innerHTML = `
        <h4>${escapeHtml(it.title)} <small>[${escapeHtml(it.type)}]</small></h4>
        <p>${escapeHtml(it.excerpt||'')}</p>
        ${it.distance_km != null ? `<p>${__('Distance (km)', 'roro')}: ${it.distance_km.toFixed(1)}</p>` : ''}
        <a class="button" href="${it.url}">${__('Open', 'roro')}</a>
      `;
      results.appendChild(div);
    });
  }

  btnApply.addEventListener('click', () => search(1));
  btnClear.addEventListener('click', () => {
    root.querySelectorAll('input').forEach(i=>i.value='');
    root.querySelector('#roro-type').value='all';
    search(1);
  });

  // Event submit
  const form = document.getElementById('roro-event-submit');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const data = Object.fromEntries(fd.entries());
      form.querySelector('.status').textContent = __('Loading...', 'roro');
      try {
        const res = await fetch(`${rest}/events`, {
          method:'POST',
          headers: {'X-WP-Nonce': roroMap.nonce, 'Content-Type':'application/json'},
          body: JSON.stringify(data)
        });
        const json = await res.json();
        form.querySelector('.status').textContent = json.message || __('Unknown error', 'roro');
        if (json.ok) form.reset();
      } catch(e) {
        form.querySelector('.status').textContent = __('Network error', 'roro');
      }
    });
  }

  function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }
})();
