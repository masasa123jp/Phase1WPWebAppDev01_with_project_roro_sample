/**
 * roro-map: イベント地図描画 + お気に入り連携
 * - クエリの highlight_event / highlight_spot を検出し、該当マーカーを強調表示
 * - マーカー辞書を保持して id→Marker を素早く参照
 *
 * 依存:
 *  - window.roroMapConfig.events: [{ id, type:'event'|'spot', latLng:{lat,lng}, title, ... }]
 */
var roroMap = (function(){
  'use strict';

  var map, markersByKey = Object.create(null), infoWin;

  function getQueryParam(name) {
    var m = location.search.match(new RegExp('[?&]'+name+'=([^&]+)'));
    return m ? decodeURIComponent(m[1]) : null;
  }

  function createMarker(e) {
    var marker = new google.maps.Marker({
      position: e.latLng,
      map: map,
      title: e.title || ''
    });
    var key = (e.type || 'event') + ':' + String(e.id);
    markersByKey[key] = marker;

    // クリック時に情報ウィンドウを開く（タイトルのみ簡易表示。必要に応じて拡張）
    marker.addListener('click', function(){
      if (!infoWin) infoWin = new google.maps.InfoWindow();
      infoWin.setContent('<div style="min-width:200px;"><strong>' + (e.title||'') + '</strong></div>');
      infoWin.open(map, marker);
    });
  }

  function highlight(key) {
    var m = markersByKey[key];
    if (!m) return false;
    // バウンス＆ズーム
    map.setCenter(m.getPosition());
    map.setZoom(15);
    m.setAnimation(google.maps.Animation.BOUNCE);
    setTimeout(function(){ m.setAnimation(null); }, 1600);
    google.maps.event.trigger(m, 'click'); // 情報ウィンドウも開く
    return true;
  }

  function init() {
    var cfg = window.roroMapConfig || {};
    var center = cfg.initialCenter || { lat: 35.681236, lng: 139.767125 }; // 東京駅
    var zoom   = cfg.initialZoom   || 12;
    map = new google.maps.Map(document.getElementById('roro-events-map'), { center:center, zoom:zoom });

    (cfg.events || []).forEach(createMarker);

    // クエリ → マーカー強調
    var hid = getQueryParam('highlight_event');
    if (hid) highlight('event:'+hid);
    var hid2 = getQueryParam('highlight_spot');
    if (hid2) highlight('spot:'+hid2);

    // 現在地のON/OFF（roro-core設定）に関しては別ファイルで追加済みのためここでは割愛
  }

  // Google Maps コールバック
  window.initMap = init;
  return { init:init, highlight:highlight };
})();
