/**
 * roro-map.js
 * - roroMapConfig.enableGeolocation が true のときのみ現在地を中心にする
 * - ?highlight_event=ID / ?highlight_spot=ID で対象マーカーをバウンス＋InfoWindow表示
 */
(function(){
  'use strict';
  var map, infoWin, markersByKey = Object.create(null);

  function qp(name){
    var m = location.search.match(new RegExp('[?&]'+name+'=([^&]+)'));
    return m ? decodeURIComponent(m[1]) : null;
  }

  function createMarker(entry){
    var m = new google.maps.Marker({
      position: entry.latLng,
      map: map,
      title: entry.title || ''
    });
    var key = (entry.type || 'event') + ':' + String(entry.id);
    markersByKey[key] = m;
    m.addListener('click', function(){
      if (!infoWin) infoWin = new google.maps.InfoWindow();
      var html = '<div style="min-width:200px;"><strong>'+(entry.title||'')+'</strong></div>';
      infoWin.setContent(html);
      infoWin.open(map, m);
    });
  }

  function highlight(key){
    var m = markersByKey[key];
    if (!m) return false;
    map.setCenter(m.getPosition());
    map.setZoom(15);
    m.setAnimation(google.maps.Animation.BOUNCE);
    setTimeout(function(){ m.setAnimation(null); }, 1500);
    google.maps.event.trigger(m, 'click');
    return true;
  }

  window.initMap = function(){
    var cfg = window.roroMapConfig || {};
    var center = cfg.initialCenter || {lat:35.681236, lng:139.767125};
    var zoom   = cfg.initialZoom   || 12;

    map = new google.maps.Map(document.getElementById('roro-events-map'), {
      center: center, zoom: zoom
    });

    (cfg.events || []).forEach(createMarker);

    // ハイライト
    var hid = qp('highlight_event'); if (hid) highlight('event:'+hid);
    var hid2= qp('highlight_spot');  if (hid2) highlight('spot:'+hid2);

    // 現在地（設定ON時のみ）
    if (cfg.enableGeolocation) {
      var fallback = center;
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(pos){
          map.setCenter({lat:pos.coords.latitude, lng:pos.coords.longitude});
        }, function(){
          map.setCenter(fallback);
        });
      } else {
        map.setCenter(fallback);
      }
    }
  };
})();
