<?php
/**
 * REST: /roro/v1/chat
 * - Nonce検証（X-WP-Nonce: wp_rest）
 * - 空入力の排除
 */
defined('ABSPATH') || exit;

if (!class_exists('RORO_Chat_REST')):
final class RORO_Chat_REST {

  public function register_routes(): void {
    register_rest_route('roro/v1', '/chat', [
      'methods'  => \WP_REST_Server::CREATABLE,
      'callback' => [$this, 'chat'],
      'permission_callback' => '__return_true',
      'args'=>[
        'message'=>['type'=>'string','required'=>true],
        'conversation_id'=>['type'=>'integer','required'=>false],
      ]
    ]);
  }

  public function chat(\WP_REST_Request $req){
    if (!wp_verify_nonce($req->get_header('x-wp-nonce'), 'wp_rest')) {
      return new \WP_REST_Response(['error'=>'invalid_nonce'], 403);
    }
    $msg = (string)$req->get_param('message');
    $cid = (int)$req->get_param('conversation_id');
    $uid = get_current_user_id();

    $svc = new \RORO_Chat_Service();
    $res = $svc->handle_user_message($msg, $cid, $uid);
    if (!empty($res['error'])) {
      return new \WP_REST_Response($res, 400);
    }
    return new \WP_REST_Response($res, 200);
  }
}
endif;
