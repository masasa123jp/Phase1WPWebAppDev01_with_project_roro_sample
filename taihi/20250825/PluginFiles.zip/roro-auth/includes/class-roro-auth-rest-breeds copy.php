<?php
/**
 * 犬種候補を返す REST API エンドポイント。
 *
 * GET /wp-json/roro-auth/v1/breeds?search=<文字列>
 * returns: [{"id":1,"name":"Shiba Inu"}, ...]
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Roro_Auth_REST_Breeds {

    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route( 'roro-auth/v1', '/breeds', array(
            'methods'  => 'GET',
            'callback' => array( __CLASS__, 'get_breed_candidates' ),
            'permission_callback' => '__return_true', // 認証不要
        ) );
    }

    /**
     * 犬種候補を返す。
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function get_breed_candidates( WP_REST_Request $request ) {
        $search = sanitize_text_field( $request->get_param( 'search' ) );
        global $wpdb;

        // DDL に存在する breed テーブルを検索する想定。LIKE 検索で候補を返す。
        $sql    = "SELECT id, name FROM {$wpdb->prefix}roro_breed_master WHERE name LIKE %s ORDER BY name LIMIT 10";
        $like   = '%' . $wpdb->esc_like( $search ) . '%';
        $result = $wpdb->get_results( $wpdb->prepare( $sql, $like ), ARRAY_A );

        return rest_ensure_response( $result );
    }
}

Roro_Auth_REST_Breeds::init();
