<?php
if (!defined('ABSPATH')) { exit; }

/**
 * 認可フローの CSRF 対策（state）と OIDC nonce を集中管理。
 * 永続化は transient（TTL 15 分）＋クッキーの併用。
 */
class Roro_Auth_State {
    const STATE_TTL = 15 * MINUTE_IN_SECONDS;
    const COOKIE    = 'roro_auth_state'; // state をクッキーでも保持し多重タブでも検証しやすく

    public static function issue(string $provider, string $redirect_to = ''): array {
        if (!in_array($provider, ['google', 'line'], true)) {
            throw new InvalidArgumentException(__('Unsupported provider.', 'roro'));
        }
        $state = wp_generate_password(32, false, false);
        $nonce = wp_generate_password(32, false, false); // OIDC Nonce
        $payload = [
            'provider'    => $provider,
            'issued_at'   => time(),
            'redirect_to' => $redirect_to ?: home_url('/'),
            'nonce'       => $nonce,
            // 将来の PKCE 対応を見越して code_verifier も持てるように
            'code_verifier' => wp_generate_password(64, false, false),
        ];
        set_transient('roro_auth_state_' . $state, $payload, self::STATE_TTL);
        // タブ間共有のためクッキーにも控えを入れる（HttpOnly ではないが機密値は state のキー自体）
        setcookie(self::COOKIE, $state, time() + self::STATE_TTL, COOKIEPATH ?: '/', COOKIE_DOMAIN ?: '', is_ssl(), false);
        return ['state' => $state, 'nonce' => $nonce, 'code_verifier' => $payload['code_verifier']];
    }

    public static function consume(string $state): array {
        $payload = get_transient('roro_auth_state_' . $state);
        if (!$payload) {
            throw new RuntimeException(__('Invalid or expired state.', 'roro')); // i18n エラーメッセージ
        }
        delete_transient('roro_auth_state_' . $state);
        // クッキーも消しておく（将来の UX により残す選択もありうる）
        if (isset($_COOKIE[self::COOKIE]) && $_COOKIE[self::COOKIE] === $state) {
            setcookie(self::COOKIE, '', time() - 3600, COOKIEPATH ?: '/', COOKIE_DOMAIN ?: '', is_ssl(), false);
        }
        return $payload;
    }
}
