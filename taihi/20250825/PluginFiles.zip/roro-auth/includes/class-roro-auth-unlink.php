<?php
/**
 * ソーシャル連携解除の UI および処理。
 *
 * ユーザーアカウントに紐付けられた SNS アカウントを一覧し、解除する機能を提供します。
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Roro_Auth_Unlink {

    /**
     * プラグイン初期化: メニュー登録と Ajax ハンドラー登録。
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
        add_action( 'wp_ajax_roro_unlink_account', array( __CLASS__, 'handle_unlink_ajax' ) );
    }

    /**
     * 設定画面に連携解除タブを追加。
     */
    public static function add_settings_page() {
        add_users_page(
            __( '連携済みアカウント', 'roro-auth' ),
            __( 'SNS 連携', 'roro-auth' ),
            'read',
            'roro-auth-unlink',
            array( __CLASS__, 'render_unlink_page' )
        );
    }

    /**
     * 連携解除画面の出力。
     */
    public static function render_unlink_page() {
        if ( ! current_user_can( 'read' ) ) {
            return;
        }
        // nonce 生成
        $nonce = wp_create_nonce( 'roro-unlink-nonce' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'SNS 連携解除', 'roro-auth' ); ?></h1>
            <p><?php esc_html_e( '連携済みアカウントを解除できます。', 'roro-auth' ); ?></p>
            <ul>
                <?php
                $user_id = get_current_user_id();
                $linked = get_user_meta( $user_id, 'roro_linked_accounts', true );
                if ( ! empty( $linked ) ) :
                    foreach ( $linked as $provider => $account ) :
                        ?>
                        <li>
                            <?php echo esc_html( ucfirst( $provider ) . ': ' . $account ); ?>
                            <button class="button unlink-btn"
                                    data-provider="<?php echo esc_attr( $provider ); ?>"
                                    data-nonce="<?php echo esc_attr( $nonce ); ?>">
                                <?php esc_html_e( '解除', 'roro-auth' ); ?>
                            </button>
                        </li>
                        <?php
                    endforeach;
                else :
                    ?>
                    <li><?php esc_html_e( '連携されているアカウントはありません。', 'roro-auth' ); ?></li>
                    <?php
                endif;
                ?>
            </ul>
        </div>
        <script type="text/javascript">
            (function($){
                $('.unlink-btn').on('click', function(){
                    var provider = $(this).data('provider');
                    var nonce    = $(this).data('nonce');
                    if ( confirm('<?php echo esc_js( __( '本当に解除しますか？', 'roro-auth' ) ); ?>') ) {
                        $.post(ajaxurl, {
                            action: 'roro_unlink_account',
                            provider: provider,
                            _wpnonce: nonce
                        }).done(function(response){
                            alert(response.data.message);
                            location.reload();
                        }).fail(function(){
                            alert('<?php echo esc_js( __( '解除に失敗しました。', 'roro-auth' ) ); ?>');
                        });
                    }
                });
            })(jQuery);
        </script>
        <?php
    }

    /**
     * Ajax ハンドラー: アカウント連携解除。
     */
    public static function handle_unlink_ajax() {
        check_ajax_referer( 'roro-unlink-nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'ログイン状態が無効です。', 'roro-auth' ) ) );
        }
        $provider = sanitize_text_field( $_POST['provider'] ?? '' );
        if ( empty( $provider ) ) {
            wp_send_json_error( array( 'message' => __( 'プロバイダーが指定されていません。', 'roro-auth' ) ) );
        }
        $user_id = get_current_user_id();
        $linked  = get_user_meta( $user_id, 'roro_linked_accounts', true );
        if ( isset( $linked[ $provider ] ) ) {
            unset( $linked[ $provider ] );
            update_user_meta( $user_id, 'roro_linked_accounts', $linked );
            wp_send_json_success( array( 'message' => __( '解除しました。', 'roro-auth' ) ) );
        }
        wp_send_json_error( array( 'message' => __( '指定のアカウントは連携されていません。', 'roro-auth' ) ) );
    }
}

Roro_Auth_Unlink::init();
