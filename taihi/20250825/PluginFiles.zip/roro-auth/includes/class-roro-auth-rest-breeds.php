<?php
/**
 * Breed master REST (for dropdown)
 *
 * @package roro-auth
 */

defined('ABSPATH') || exit;

if (!class_exists('RORO_Breed_REST')) {
    class RORO_Breed_REST {

        public static function init() {
            add_action('rest_api_init', [__CLASS__, 'routes']);
        }

        public static function routes() {
            register_rest_route('roro/v1', '/breeds', [
                [
                    'methods'  => WP_REST_Server::READABLE,
                    'callback' => [__CLASS__, 'get_breeds'],
                    'permission_callback' => '__return_true',
                    'args' => [
                        'species' => [
                            'type' => 'string',
                            'required' => true,
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                    ],
                ],
            ]);
        }

        public static function get_breeds(WP_REST_Request $req) {
            global $wpdb;
            $species = $req->get_param('species');
            $tbl = $wpdb->prefix . 'RORO_BREED_MASTER';
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT id, breed_name FROM {$tbl} WHERE species = %s ORDER BY breed_name ASC",
                $species
            ), ARRAY_A);

            $items = [];
            foreach ($rows as $r) {
                $items[] = [
                    'id'   => (int) $r['id'],
                    'name' => $r['breed_name'],
                ];
            }
            return new WP_REST_Response([
                'items' => $items,
            ], 200);
        }
    }

    RORO_Breed_REST::init();
}
