<?php
/**
 * Profile update handler (validation + messages + pet entry hooks)
 *
 * @package roro-auth
 */

defined('ABSPATH') || exit;

if (!class_exists('RORO_Auth_Profile')) {
    class RORO_Auth_Profile {

        public static function init() {
            add_shortcode('roro_profile_form', [__CLASS__, 'render_profile']);
            add_action('admin_post_roro_profile_update', [__CLASS__, 'handle_update']);
            add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
            add_action('wp_ajax_roro_set_default_pet', [__CLASS__, 'ajax_set_default_pet']);
        }

        public static function enqueue_assets() {
            if (is_user_logged_in()) {
                wp_register_script(
                    'roro-profile',
                    plugins_url('../assets/js/roro-profile.js', __FILE__),
                    ['jquery'],
                    '1.1',
                    true
                );
                wp_localize_script('roro-profile', 'RORO_PROFILE_I18N', [
                    'selectBreed' => __('Select breed', 'roro'),
                    'loading'     => __('Loading...', 'roro'),
                    'saved'       => __('Saved', 'roro'),
                    'failed'      => __('Failed', 'roro'),
                ]);
                wp_enqueue_script('roro-profile');
            }
        }

        public static function render_profile() {
            if (!is_user_logged_in()) {
                return '<p>' . esc_html__('Please sign in to edit your profile.', 'roro') . '</p>';
            }
            $uid = get_current_user_id();
            $display_name = get_the_author_meta('display_name', $uid);
            $locale = get_user_locale($uid);

            $default_pet_id = (int) get_user_meta($uid, 'roro_default_pet_id', true);
            $pets = self::get_user_pets($uid);

            ob_start();
            ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="roro-profile-form" novalidate>
                <input type="hidden" name="action" value="roro_profile_update">
                <?php wp_nonce_field('roro_profile_update', '_wpnonce'); ?>
                <h2><?php echo esc_html__('Profile', 'roro'); ?></h2>

                <label for="display_name"><?php echo esc_html__('Display name', 'roro'); ?></label>
                <input id="display_name" name="display_name" type="text" required value="<?php echo esc_attr($display_name); ?>" aria-required="true"/>

                <label for="locale"><?php echo esc_html__('Preferred language', 'roro'); ?></label>
                <select id="locale" name="locale">
                    <option value="ja" <?php selected('ja', substr($locale,0,2)); ?>><?php echo esc_html__('Japanese', 'roro'); ?></option>
                    <option value="en" <?php selected('en', substr($locale,0,2)); ?>><?php echo esc_html__('English', 'roro'); ?></option>
                    <option value="zh" <?php selected('zh', substr($locale,0,2)); ?>><?php echo esc_html__('Chinese', 'roro'); ?></option>
                    <option value="ko" <?php selected('ko', substr($locale,0,2)); ?>><?php echo esc_html__('Korean', 'roro'); ?></option>
                </select>

                <h3><?php echo esc_html__('Pets', 'roro'); ?></h3>
                <div id="roro-pets" data-default-pet-id="<?php echo esc_attr($default_pet_id); ?>">
                    <?php
                    if ($pets) {
                        foreach ($pets as $p) {
                            echo '<div class="roro-pet" data-pet-id="' . esc_attr($p->id) . '">';
                            echo '<div class="roro-pet__row">';
                            echo '<span class="roro-pet__name">' . esc_html($p->name) . '</span>';
                            echo '<span class="roro-pet__type">' . esc_html($p->species) . '</span>';
                            echo '<span class="roro-pet__breed">' . esc_html($p->breed) . '</span>';
                            echo '<button type="button" class="button set-default" data-pet-id="' . esc_attr($p->id) . '">';
                            echo esc_html__('Set as representative', 'roro') . '</button>';
                            echo '</div></div>';
                        }
                    } else {
                        echo '<p>' . esc_html__('No pets yet.', 'roro') . '</p>';
                    }
                    ?>
                </div>

                <p><button type="submit" class="button button-primary"><?php echo esc_html__('Save', 'roro'); ?></button></p>

            </form>
            <?php
            return ob_get_clean();
        }

        /**
         * 更新処理
         */
        public static function handle_update() {
            if (!is_user_logged_in()) {
                wp_die(esc_html__('You must be signed in.', 'roro'));
            }
            check_admin_referer('roro_profile_update');
            $uid = get_current_user_id();

            $display_name = isset($_POST['display_name']) ? sanitize_text_field(wp_unslash($_POST['display_name'])) : '';
            $locale       = isset($_POST['locale']) ? sanitize_text_field(wp_unslash($_POST['locale'])) : 'ja';

            // バリデーション
            if ($display_name === '') {
                self::redirect_with_message(__('Display name is required.', 'roro'), 'error');
            }
            if (!in_array($locale, ['ja','en','zh','ko'], true)) {
                self::redirect_with_message(__('Invalid language.', 'roro'), 'error');
            }

            // 更新
            wp_update_user([
                'ID' => $uid,
                'display_name' => $display_name,
            ]);

            // ロケールを user_meta に反映（WP 標準格納に合わせる）
            update_user_meta($uid, 'locale', $locale);

            self::redirect_with_message(__('Profile updated.', 'roro'), 'updated');
        }

        public static function ajax_set_default_pet() {
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => __('Please sign in.', 'roro')], 401);
            }
            $uid = get_current_user_id();
            $pid = isset($_POST['pet_id']) ? absint($_POST['pet_id']) : 0;

            // 簡易: 所有確認（実運用では RORO_PET テーブルを参照）
            if (!$pid) {
                wp_send_json_error(['message' => __('Invalid pet.', 'roro')], 400);
            }
            update_user_meta($uid, 'roro_default_pet_id', $pid);
            wp_send_json_success(['message' => __('Representative pet saved.', 'roro')]);
        }

        private static function get_user_pets(int $user_id) {
            global $wpdb;
            $tbl = $wpdb->prefix . 'RORO_PET';
            // 簡易: name/species/breed がある前提
            return $wpdb->get_results($wpdb->prepare(
                "SELECT id, name, species, breed FROM {$tbl} WHERE user_id = %d ORDER BY id DESC",
                $user_id
            ));
        }

        private static function redirect_with_message(string $msg, string $type = 'updated') {
            $url = wp_get_referer() ?: home_url('/');
            $url = add_query_arg([
                'roro_msg'  => rawurlencode($msg),
                'roro_type' => rawurlencode($type),
            ], $url);
            wp_safe_redirect($url);
            exit;
        }
    }

    RORO_Auth_Profile::init();
}
