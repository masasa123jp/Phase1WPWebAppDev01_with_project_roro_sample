<?php
/**
 * LINE OAuth2 Provider for RORO
 *
 * @package roro-auth
 */

defined('ABSPATH') || exit;

if (!class_exists('RORO_Auth_Provider_LINE')) {

    class RORO_Auth_Provider_LINE {

        const OPT_CLIENT_ID     = 'roro_line_channel_id';
        const OPT_CLIENT_SECRET = 'roro_line_channel_secret';
        const OPT_REDIRECT_URI  = 'roro_line_redirect_uri';
        const TRANS_PREFIX      = 'roro_line_state_';
        const STATE_TTL         = 15 * MINUTE_IN_SECONDS;

        public static function init() {
            add_action('init', [__CLASS__, 'route']);
            add_shortcode('roro_line_login_button', [__CLASS__, 'render_button']);
        }

        public static function route() {
            if (isset($_GET['roro_line_auth']) && $_GET['roro_line_auth'] === '1') {
                self::start_authorize();
                exit;
            }
            if (isset($_GET['roro_line_callback']) && $_GET['roro_line_callback'] === '1') {
                self::handle_callback();
                exit;
            }
        }

        public static function render_button($atts = []) {
            $enabled = self::is_configured();
            $login_url = esc_url(add_query_arg([
                'roro_line_auth' => '1',
            ], wp_login_url()));

            $label = esc_html__('Continue with LINE', 'roro');
            $title = $enabled
                ? esc_attr__('Sign in using LINE', 'roro')
                : esc_attr__('LINE sign-in is not available. Ask administrator.', 'roro');

            $disabled_attr = $enabled ? '' : ' aria-disabled="true" disabled';

            $html  = '<button type="button" class="roro-btn roro-btn--line"';
            $html .= ' onclick="if(!this.disabled){window.location.href=\'' . $login_url . '\'}"';
            $html .= ' title="' . $title . '"' . $disabled_attr . '>';
            $html .= '<span class="roro-icon roro-icon--line" aria-hidden="true"></span>';
            $html .= '<span class="roro-label">' . $label . '</span>';
            $html .= '</button>';

            if (!$enabled) {
                $html .= '<div class="roro-help">' . esc_html__('LINE credentials are not configured.', 'roro') . '</div>';
            }
            return $html;
        }

        private static function start_authorize() {
            if (!self::is_configured()) {
                wp_die(esc_html__('LINE sign-in is not configured.', 'roro'));
            }
            $client_id = trim(get_option(self::OPT_CLIENT_ID, ''));
            $redirect  = self::get_redirect_uri();

            $state = wp_generate_password(20, false, false);
            $nonce = wp_generate_password(20, false, false);

            set_transient(self::TRANS_PREFIX . $state, [
                'time'  => time(),
                'nonce' => $nonce,
                'redirect_to' => isset($_GET['redirect_to']) ? esc_url_raw($_GET['redirect_to']) : home_url('/'),
            ], self::STATE_TTL);

            $scope = implode(' ', ['openid', 'profile', 'email']);

            $auth_url = add_query_arg([
                'response_type' => 'code',
                'client_id'     => rawurlencode($client_id),
                'redirect_uri'  => rawurlencode($redirect),
                'scope'         => rawurlencode($scope),
                'state'         => rawurlencode($state),
                'nonce'         => rawurlencode($nonce),
            ], 'https://access.line.me/oauth2/v2.1/authorize');

            wp_safe_redirect($auth_url);
            exit;
        }

        private static function handle_callback() {
            $error = isset($_GET['error']) ? sanitize_text_field(wp_unslash($_GET['error'])) : '';
            if (!empty($error)) {
                self::fail_and_redirect(self::translate_oauth_error($error));
            }

            $code  = isset($_GET['code']) ? sanitize_text_field(wp_unslash($_GET['code'])) : '';
            $state = isset($_GET['state']) ? sanitize_text_field(wp_unslash($_GET['state'])) : '';

            if (empty($code) || empty($state)) {
                self::fail_and_redirect(__('Missing authorization code or state.', 'roro'));
            }

            $data = get_transient(self::TRANS_PREFIX . $state);
            delete_transient(self::TRANS_PREFIX . $state);
            if (!$data || empty($data['nonce'])) {
                self::fail_and_redirect(__('Invalid or expired state. Please try again.', 'roro'));
            }

            $token = self::exchange_token($code);
            if (is_wp_error($token)) {
                self::fail_and_redirect(sprintf(__('Failed to exchange token: %s', 'roro'), $token->get_error_message()));
            }

            // id_token の nonce 検証（簡易）
            if (empty($token['id_token'])) {
                self::fail_and_redirect(__('id_token is missing.', 'roro'));
            }
            $payload = self::decode_jwt_body($token['id_token']);
            if (empty($payload['nonce']) || $payload['nonce'] !== $data['nonce']) {
                self::fail_and_redirect(__('Nonce mismatch. Please try again.', 'roro'));
            }

            // プロフィール（メール取得には追加同意が必要、なければ空もあり）
            $user = self::fetch_profile($token['access_token']);
            if (is_wp_error($user)) {
                self::fail_and_redirect(sprintf(__('Failed to fetch profile: %s', 'roro'), $user->get_error_message()));
            }

            $email = '';
            if (!empty($token['id_token'])) {
                // email は id_token に含まれる場合あり
                $pl = self::decode_jwt_body($token['id_token']);
                $email = sanitize_email($pl['email'] ?? '');
            }
            if (empty($email)) {
                // メールなしでもログイン許容（要件次第）：UIDベース
                $email = sprintf('line_%s@invalid.example', sanitize_key($user['userId'] ?? wp_generate_uuid4()));
            }

            $wp_user_id = self::find_or_create_user([
                'email' => $email,
                'name'  => $user['displayName'] ?? '',
                'sub'   => $user['userId'] ?? '',
            ], 'line', $user['userId'] ?? '');

            if (is_wp_error($wp_user_id)) {
                self::fail_and_redirect(sprintf(__('Sign-in failed: %s', 'roro'), $wp_user_id->get_error_message()));
            }

            wp_set_current_user($wp_user_id);
            wp_set_auth_cookie($wp_user_id);
            do_action('roro_auth_social_login', $wp_user_id, 'line', $user);

            $redirect_to = !empty($data['redirect_to']) ? $data['redirect_to'] : admin_url();
            wp_safe_redirect($redirect_to);
            exit;
        }

        private static function is_configured(): bool {
            $cid = trim(get_option(self::OPT_CLIENT_ID, ''));
            $sec = trim(get_option(self::OPT_CLIENT_SECRET, ''));
            return $cid !== '' && $sec !== '';
        }

        private static function get_redirect_uri(): string {
            $uri = trim(get_option(self::OPT_REDIRECT_URI, ''));
            if ($uri !== '') {
                return $uri;
            }
            return add_query_arg(['roro_line_callback' => '1'], wp_login_url());
        }

        private static function exchange_token(string $code) {
            $client_id     = trim(get_option(self::OPT_CLIENT_ID, ''));
            $client_secret = trim(get_option(self::OPT_CLIENT_SECRET, ''));
            $redirect_uri  = self::get_redirect_uri();

            $res = wp_remote_post('https://api.line.me/oauth2/v2.1/token', [
                'timeout' => 20,
                'body'    => [
                    'grant_type'    => 'authorization_code',
                    'code'          => $code,
                    'client_id'     => $client_id,
                    'client_secret' => $client_secret,
                    'redirect_uri'  => $redirect_uri,
                ],
            ]);
            if (is_wp_error($res)) {
                return $res;
            }
            $code = (int) wp_remote_retrieve_response_code($res);
            if ($code < 200 || $code >= 300) {
                return new WP_Error('roro_line_token_http', __('Token endpoint responded with error.', 'roro'));
            }
            $json = json_decode(wp_remote_retrieve_body($res), true);
            if (!is_array($json) || empty($json['access_token'])) {
                return new WP_Error('roro_line_token_body', __('No access_token in token response.', 'roro'));
            }
            return $json;
        }

        private static function fetch_profile(string $access_token) {
            $res = wp_remote_get('https://api.line.me/v2/profile', [
                'timeout' => 15,
                'headers' => [
                    'Authorization' => 'Bearer ' . $access_token,
                ],
            ]);
            if (is_wp_error($res)) {
                return $res;
            }
            $code = (int) wp_remote_retrieve_response_code($res);
            if ($code < 200 || $code >= 300) {
                return new WP_Error('roro_line_profile_http', __('Profile endpoint responded with error.', 'roro'));
            }
            $json = json_decode(wp_remote_retrieve_body($res), true);
            if (!is_array($json)) {
                return new WP_Error('roro_line_profile_body', __('Invalid profile response.', 'roro'));
            }
            return $json;
        }

        private static function find_or_create_user(array $info, string $provider, string $sub) {
            $email = sanitize_email($info['email']);
            if (!$email) {
                // メールがない場合の暫定対応
                $email = sprintf('line_%s@invalid.example', sanitize_key($sub ?: wp_generate_uuid4()));
            }
            $user = get_user_by('email', $email);
            if (!$user) {
                $login = sanitize_user(current(explode('@', $email)), true);
                if (username_exists($login)) {
                    $login = $login . '_' . wp_generate_password(4, false, false);
                }
                $uid = wp_insert_user([
                    'user_login'   => $login,
                    'user_email'   => $email,
                    'display_name' => sanitize_text_field($info['name'] ?? $login),
                    'user_pass'    => wp_generate_password(20, true, true),
                ]);
                if (is_wp_error($uid)) {
                    return $uid;
                }
                $user = get_user_by('id', $uid);
            }
            update_user_meta($user->ID, 'roro_social_' . $provider . '_sub', sanitize_text_field($sub));
            update_user_meta($user->ID, 'roro_social_' . $provider . '_last_login', time());
            return $user->ID;
        }

        private static function decode_jwt_body(string $jwt): array {
            $parts = explode('.', $jwt);
            if (count($parts) !== 3) {
                return [];
            }
            $body = strtr($parts[1], '-_', '+/');
            $body = base64_decode($body);
            $json = json_decode($body, true);
            return is_array($json) ? $json : [];
        }

        private static function translate_oauth_error(string $code): string {
            switch ($code) {
                case 'access_denied':
                    return __('Access denied on LINE consent screen.', 'roro');
                default:
                    return sprintf(__('LINE OAuth error: %s', 'roro'), $code);
            }
        }

        private static function fail_and_redirect(string $message) {
            $login_url = wp_login_url();
            $login_url = add_query_arg([
                'roro_social_error' => rawurlencode($message),
            ], $login_url);
            wp_safe_redirect($login_url);
            exit;
        }
    }

    RORO_Auth_Provider_LINE::init();
}
