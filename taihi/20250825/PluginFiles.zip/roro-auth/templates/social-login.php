<?php
/**
 * Social login UI (Google / LINE)
 *
 * @package roro-auth
 */

defined('ABSPATH') || exit;

$err = isset($_GET['roro_social_error']) ? sanitize_text_field(wp_unslash($_GET['roro_social_error'])) : '';
if ($err) {
    echo '<div class="notice notice-error" role="alert" tabindex="-1">'
       . esc_html($err)
       . '</div>';
}

echo do_shortcode('[roro_google_login_button]');
echo do_shortcode('[roro_line_login_button]');

echo '<p class="description" lang="ja">' . esc_html__('You can link or unlink in My Page later.', 'roro') . '</p>';
