<?php
/**
 * Profile template wrapper
 *
 * @package roro-auth
 */

defined('ABSPATH') || exit;

// 成功/失敗メッセージ（i18n）
if (isset($_GET['roro_msg'])) {
    $type = isset($_GET['roro_type']) ? sanitize_text_field(wp_unslash($_GET['roro_type'])) : 'updated';
    $msg  = sanitize_text_field(wp_unslash($_GET['roro_msg']));
    $cls  = $type === 'error' ? 'notice-error' : 'notice-success';
    echo '<div class="notice ' . esc_attr($cls) . '" role="status" tabindex="-1">' . esc_html($msg) . '</div>';
}

// プロフィールフォーム
echo do_shortcode('[roro_profile_form]');

// 連携一覧
echo '<hr/>';
echo '<h3>' . esc_html__('Connected accounts', 'roro') . '</h3>';
echo do_shortcode('[roro_social_links]');
