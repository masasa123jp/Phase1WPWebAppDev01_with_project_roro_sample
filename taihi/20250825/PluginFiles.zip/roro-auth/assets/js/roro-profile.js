/* global jQuery, ajaxurl, RORO_PROFILE_I18N */
(function ($) {
  'use strict';

  // 代表ペット切り替え
  $(document).on('click', '.roro-profile-form .set-default', function () {
    var $btn = $(this);
    var petId = $btn.data('pet-id');
    $btn.prop('disabled', true);
    var loading = $('<span/>', {
      class: 'roro-loading',
      text: RORO_PROFILE_I18N.loading
    });
    $btn.after(loading);

    $.post(ajaxurl, {
      action: 'roro_set_default_pet',
      pet_id: petId,
      _ajax_nonce: $('#_wpnonce').val() // 同画面での nonce 使い回し
    })
      .done(function (res) {
        alert(res && res.data && res.data.message ? res.data.message : RORO_PROFILE_I18N.saved);
      })
      .fail(function () {
        alert(RORO_PROFILE_I18N.failed);
      })
      .always(function () {
        $btn.prop('disabled', false);
        loading.remove();
      });
  });

  // 犬種ドロップダウン（例：将来のフォーム要素追加を想定）
  // $('[name="species"]').on('change', function(){ ... REST: /roro/v1/breeds?species=dog ... });

})(jQuery);
