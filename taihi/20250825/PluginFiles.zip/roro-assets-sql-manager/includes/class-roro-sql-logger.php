<?php
/**
 * SQL マネージャ向けログ UI の微調整（任意）。
 *
 * 既に対応済みのため、必要に応じてカラム名の変更や翻訳キー追加のみを行います。
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Roro_SQL_Logger {

    public static function init() {
        add_filter( 'roro_sql_logger_columns', array( __CLASS__, 'filter_columns' ) );
    }

    public static function filter_columns( $columns ) {
        // 列ラベルの翻訳対応
        $columns['query']      = __( 'クエリ', 'roro-assets-sql-manager' );
        $columns['duration']   = __( '実行時間 (ms)', 'roro-assets-sql-manager' );
        $columns['executed_at'] = __( '実行日時', 'roro-assets-sql-manager' );
        return $columns;
    }
}

Roro_SQL_Logger::init();
