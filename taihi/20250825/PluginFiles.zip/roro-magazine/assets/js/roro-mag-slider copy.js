/**
 * バニラJSスライダー
 * - RORO_MAG_SLIDER.slides = [{type:'page'|'ad', html:'...'}]
 */
(function(){
  'use strict';
  var conf = window.RORO_MAG_SLIDER || { slides:[], height:520 };
  var root = document.currentScript && document.currentScript.parentElement;
  // currentScript が body 直下扱いになる実装もあるためセレクタで拾う
  var slider = document.querySelector('.roro-mag-slider');
  if (!slider) return;

  var track = slider.querySelector('.roro-mag-track');
  var vp    = slider.querySelector('.roro-mag-viewport');
  var btnPrev = slider.querySelector('.roro-mag-prev');
  var btnNext = slider.querySelector('.roro-mag-next');

  // スライドを構築
  (conf.slides || []).forEach(function(s){
    var d = document.createElement('div');
    d.className = 'roro-mag-slide';
    d.innerHTML = s.html || '';
    track.appendChild(d);
  });

  var total = track.children.length;
  var idx = 0;
  function update() {
    track.style.transform = 'translate3d('+(-100*idx)+'%,0,0)';
    btnPrev.disabled = (idx<=0);
    btnNext.disabled = (idx>=total-1);
  }

  btnPrev.addEventListener('click', function(){ if (idx>0){ idx--; update(); }});
  btnNext.addEventListener('click', function(){ if (idx<total-1){ idx++; update(); }});

  // 高さ調整
  slider.style.height = (parseInt(conf.height||520,10))+'px';
  update();
})();
