/**
 * 雑誌スライダーの操作性改善スクリプト。
 *
 * スワイプ閾値やキーボード操作、フォーカスリングをサポートします。
 */
( function( $ ) {
    const container   = $( '.roro-magazine-slider' );
    const slides      = container.find( '.slide' );
    let currentIndex  = 0;
    let startX        = 0;

    function showSlide( index ) {
        slides.removeClass( 'active' );
        slides.eq( index ).addClass( 'active' ).focus();
    }

    container.on( 'touchstart', function( e ) {
        startX = e.originalEvent.touches[0].clientX;
    } );

    container.on( 'touchend', function( e ) {
        const endX = e.originalEvent.changedTouches[0].clientX;
        const diff = endX - startX;
        const threshold = 50; // スワイプと判定する閾値
        if ( diff > threshold && currentIndex > 0 ) {
            currentIndex--;
        } else if ( diff < -threshold && currentIndex < slides.length - 1 ) {
            currentIndex++;
        }
        showSlide( currentIndex );
    } );

    // キーボード操作: 左右キーでスライド切り替え
    container.on( 'keydown', function( e ) {
        if ( e.key === 'ArrowLeft' && currentIndex > 0 ) {
            currentIndex--;
            showSlide( currentIndex );
            e.preventDefault();
        }
        if ( e.key === 'ArrowRight' && currentIndex < slides.length - 1 ) {
            currentIndex++;
            showSlide( currentIndex );
            e.preventDefault();
        }
    } );

    // 初期化
    showSlide( currentIndex );
} )( jQuery );
