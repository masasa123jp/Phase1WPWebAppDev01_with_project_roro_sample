<?php
/**
 * [roro_mag_issue issue="latest|ID|slug" lang="ja|en|zh|ko" height="520"]
 * スライダーUI（JS/CSS）でページをめくり表示、広告カードを差し込み
 */
defined('ABSPATH') || exit;

if (!class_exists('RORO_Mag_Shortcode')):
final class RORO_Mag_Shortcode {

  public static function boot(): void {
    add_shortcode('roro_mag_issue', [__CLASS__, 'shortcode']);
    add_action('wp_enqueue_scripts', [__CLASS__, 'register_assets']);
  }

  public static function register_assets(): void {
    wp_register_style('roro-mag-slider-css', plugins_url('../assets/css/roro-mag-slider.css', __FILE__), [], '1.0.0');
    wp_register_script('roro-mag-slider-js', plugins_url('../assets/js/roro-mag-slider.js', __FILE__), [], '1.0.0', true);
  }

  public static function shortcode($atts): string {
    $atts = shortcode_atts([
      'issue' => 'latest',
      'lang'  => 'ja',
      'height'=> '520',
    ], $atts, 'roro_mag_issue');

    $post = null;
    if ($atts['issue']==='latest') {
      $q = new WP_Query([
        'post_type'=>'roro_mag_issue','post_status'=>'publish',
        'posts_per_page'=>1,'orderby'=>'date','order'=>'DESC'
      ]);
      if ($q->have_posts()) $post = $q->posts[0];
      wp_reset_postdata();
    } elseif (ctype_digit($atts['issue'])) {
      $post = get_post((int)$atts['issue']);
    } else {
      $post = get_page_by_path(sanitize_title($atts['issue']), OBJECT, 'roro_mag_issue');
    }
    if (!$post) return '<div class="roro-mag-error">'.esc_html__('Issue not found.', 'roro-magazine').'</div>';

    $lang = in_array($atts['lang'], ['ja','en','zh','ko'], true) ? $atts['lang'] : 'ja';

    $raw   = (string) get_post_meta($post->ID, "_roro_mag_pages_{$lang}", true);
    // 未翻訳フォールバック：原文（ja）使用
    if ($raw === '' && $lang !== 'ja') {
      $raw = (string) get_post_meta($post->ID, "_roro_mag_pages_ja", true);
    }
    $pages = array_values(array_filter(array_map('trim', preg_split('/---PAGE---/u', $raw))));

    $adsRaw = (string) get_post_meta($post->ID, '_roro_mag_ads', true);
    $ads    = json_decode($adsRaw, true); if (!is_array($ads)) $ads=[];

    // ページと広告カードを合成
    $deck = [];
    foreach ($pages as $i => $html) {
      $deck[] = ['type'=>'page','html'=>wpautop($html)];
      foreach ($ads as $ad) {
        if (($ad['lang']??'')===$lang && intval($ad['insert_after']??0)===$i+1) {
          $deck[] = ['type'=>'ad','html'=>self::ad_card($ad)];
        }
      }
    }

    wp_enqueue_style('roro-mag-slider-css');
    wp_enqueue_script('roro-mag-slider-js');
    wp_localize_script('roro-mag-slider-js','RORO_MAG_SLIDER',[
      'height'=>(int)$atts['height'],
      'slides'=>$deck,
      'i18n'=>[
        'prev'=>__('Prev','roro-magazine'),
        'next'=>__('Next','roro-magazine'),
        'sponsored'=>__('Sponsored','roro-magazine'),
      ],
    ]);

    ob_start(); ?>
    <div class="roro-mag-slider" style="height:<?php echo esc_attr((int)$atts['height']); ?>px;">
      <div class="roro-mag-viewport"><div class="roro-mag-track"></div></div>
      <div class="roro-mag-nav">
        <button type="button" class="roro-mag-prev" aria-label="<?php echo esc_attr__('Prev','roro-magazine');?>">&larr; <?php echo esc_html__('Prev','roro-magazine');?></button>
        <button type="button" class="roro-mag-next" aria-label="<?php echo esc_attr__('Next','roro-magazine');?>"><?php echo esc_html__('Next','roro-magazine');?> &rarr;</button>
      </div>
    </div>
    <?php return ob_get_clean();
  }

  private static function ad_card(array $ad): string {
    $img = esc_url($ad['image'] ?? '');
    $ttl = esc_html($ad['title'] ?? '');
    $body= wp_kses_post($ad['body'] ?? '');
    $url = esc_url($ad['url'] ?? '');
    $lab = esc_html__('Sponsored', 'roro-magazine');

    $html = '<div class="roro-mag-adcard">';
    $html .= '<div class="roro-mag-adlabel">'.$lab.'</div>';
    if ($img) $html .= '<img src="'.$img.'" alt="'.esc_attr($ttl).'" style="max-width:100%;height:auto;display:block;margin:0 auto 8px;">';
    $html .= '<h3 style="margin:.2rem 0 .4rem 0;">'.$ttl.'</h3>';
    $html .= '<div class="roro-mag-adbody">'.$body.'</div>';
    if ($url) $html .= '<p><a class="button" href="'.$url.'" target="_blank" rel="noopener">'.esc_html__('Learn more','roro-magazine').'</a></p>';
    $html .= '</div>';
    return $html;
  }
}
endif;
RORO_Mag_Shortcode::boot();
