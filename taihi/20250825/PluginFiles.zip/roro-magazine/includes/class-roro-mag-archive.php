<?php
if (!defined('ABSPATH')) { exit; }

/**
 * 号アーカイブ（一覧）とウィジェット導線
 */
class Roro_Mag_Archive {
    public function __construct() {
        add_action('init', [$this, 'rewrite']);
        add_filter('query_vars', function ($vars) { $vars[] = 'roro_mag'; return $vars; });
        add_action('template_redirect', [$this, 'route']);
        add_action('widgets_init', [$this, 'widget']);
    }
    public function rewrite() {
        add_rewrite_rule('^magazine/?$', 'index.php?roro_mag=archive', 'top');
    }
    public function route() {
        if (get_query_var('roro_mag') === 'archive') {
            status_header(200);
            nocache_headers();
            $posts = get_posts(['post_type'=>'post','category_name'=>'magazine','numberposts'=>-1]);
            echo '<main class="roro-mag-archive"><h1>' . esc_html__('Magazine Archive', 'roro') . '</h1><ul>';
            foreach ($posts as $p) {
                printf('<li><a href="%s">%s</a></li>', esc_url(get_permalink($p)), esc_html(get_the_title($p)));
            }
            echo '</ul></main>';
            exit;
        }
    }
    public function widget() {
        register_widget(new class extends WP_Widget {
            public function __construct() {
                parent::__construct('roro_mag_widget', __('Roro Magazine (latest)', 'roro'));
            }
            public function widget($args, $instance) {
                echo $args['before_widget'] . $args['before_title'] . esc_html__('Latest Magazine', 'roro') . $args['after_title'];
                $p = get_posts(['post_type'=>'post','category_name'=>'magazine','numberposts'=>1]);
                if ($p) {
                    printf('<p><a href="%s">%s</a> · <a href="%s">%s</a></p>',
                        esc_url(get_permalink($p[0])),
                        esc_html(get_the_title($p[0])),
                        esc_url(home_url('/magazine')),
                        esc_html__('Archive', 'roro')
                    );
                }
                echo $args['after_widget'];
            }
        });
    }
}
new Roro_Mag_Archive();
