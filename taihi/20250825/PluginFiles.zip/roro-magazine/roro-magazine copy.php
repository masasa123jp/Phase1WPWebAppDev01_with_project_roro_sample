<?php
/**
 * Plugin Name: Roro Magazine
 * Description: 雑誌スライダー（A11y・スワイプ閾値・KB 操作）、未翻訳フォールバック、号アーカイブ＆ウィジェット。
 * Version: 0.5.0
 * Text Domain: roro
 */
if (!defined('ABSPATH')) { exit; }
define('RORO_MAG_DIR', plugin_dir_path(__FILE__));
define('RORO_MAG_URL', plugin_dir_url(__FILE__));

require_once RORO_MAG_DIR . 'includes/class-roro-mag-archive.php';

add_action('wp_enqueue_scripts', function () {
    wp_register_script('roro-mag-slider', RORO_MAG_URL . 'assets/js/slider.js', [], '0.5.0', true);
});

add_shortcode('roro_mag_slider', function ($atts) {
    wp_enqueue_script('roro-mag-slider');
    $posts = get_posts(['post_type'=>'post','category_name'=>'magazine','numberposts'=>12]);
    ob_start(); ?>
    <div class="roro-mag-slider" tabindex="0" aria-roledescription="carousel">
      <?php foreach ($posts as $p): ?>
        <a class="roro-mag-slide" href="<?php echo esc_url(get_permalink($p)); ?>">
          <span class="roro-mag-title"><?php echo esc_html(get_the_title($p)); ?></span>
        </a>
      <?php endforeach; ?>
    </div>
    <?php return ob_get_clean();
});

// 未翻訳フォールバック（タイトル/抜粋が空の場合は英語->既定言語の順で取得）
add_filter('the_title', function ($title, $id) {
    if ($title) return $title;
    // シンプルに英語版のポリグロットフィールドを探す（実運用は WPML/Polylang に合わせて調整）
    $fallback = get_post_meta($id, 'title_en', true);
    return $fallback ?: $title;
}, 10, 2);
