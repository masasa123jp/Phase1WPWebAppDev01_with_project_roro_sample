<?php
/**
 * Favorites list with cross-type sorting/filter
 *
 * @package roro-favorites
 */

defined('ABSPATH') || exit;

wp_enqueue_script(
    'roro-favorites',
    plugins_url('../assets/js/roro-favorites.js', __FILE__),
    ['jquery'],
    '1.0',
    true
);

wp_localize_script('roro-favorites', 'RORO_FAV_I18N', [
    'sort'      => __('Sort', 'roro'),
    'filter'    => __('Filter', 'roro'),
    'all'       => __('All', 'roro'),
    'event'     => __('Events', 'roro'),
    'spot'      => __('Spots', 'roro'),
    'noItems'   => __('No favorites yet.', 'roro'),
]);

?>
<div class="roro-fav" role="region" aria-label="<?php echo esc_attr__('Favorites', 'roro'); ?>">
  <div class="roro-fav__toolbar">
    <label>
      <?php echo esc_html__('Filter', 'roro'); ?>
      <select id="fav-filter">
        <option value="all"><?php echo esc_html__('All', 'roro'); ?></option>
        <option value="event"><?php echo esc_html__('Events', 'roro'); ?></option>
        <option value="spot"><?php echo esc_html__('Spots', 'roro'); ?></option>
      </select>
    </label>
    <label>
      <?php echo esc_html__('Sort', 'roro'); ?>
      <select id="fav-sort">
        <option value="date_desc"><?php echo esc_html__('Newest', 'roro'); ?></option>
        <option value="date_asc"><?php echo esc_html__('Oldest', 'roro'); ?></option>
        <option value="title_asc"><?php echo esc_html__('Title A–Z', 'roro'); ?></option>
      </select>
    </label>
  </div>
  <div id="fav-list" role="list"></div>
</div>
