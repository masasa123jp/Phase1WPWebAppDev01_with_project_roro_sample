<?php
/**
 * お気に入り一覧（AJAXトグル＋地図ジャンプ）
 * Text Domain: roro-favorites
 */
defined('ABSPATH') || exit;

$user_id = get_current_user_id();
if (!$user_id) {
    echo '<div class="notice notice-warning"><p>'.esc_html__('Please log in to see your favorites.', 'roro-favorites').'</p></div>';
    return;
}

// サービス層から一覧を取得（既存クラス想定）
if (!class_exists('RORO_Favorites_Service')) {
    echo '<div class="notice notice-error"><p>'.esc_html__('Service not available.', 'roro-favorites').'</p></div>';
    return;
}
$svc  = new RORO_Favorites_Service();
$list = $svc->get_user_favorites($user_id, ['limit'=>200,'offset'=>0]);

$nonce = wp_create_nonce('wp_rest');
wp_enqueue_script('roro-favorites-js', plugins_url('../assets/js/favorites.js', __FILE__), [], '1.1.0', true);
wp_localize_script('roro-favorites-js', 'RORO_FAV_CONFIG', [
  'rest' => [
    'add'    => esc_url_raw(rest_url('roro/v1/favorites/add')),
    'remove' => esc_url_raw(rest_url('roro/v1/favorites/remove')),
    'nonce'  => $nonce,
  ],
  'i18n' => [
    'added'   => __('Added to favorites', 'roro-favorites'),
    'removed' => __('Removed from favorites', 'roro-favorites'),
    'error'   => __('Operation failed. Please try again.', 'roro-favorites'),
    'openmap' => __('Open on Map', 'roro-favorites'),
  ]
]);

?>
<div class="roro-fav">
  <h2><?php echo esc_html__('My Favorites', 'roro-favorites'); ?></h2>
  <?php if (empty($list)): ?>
    <p><?php echo esc_html__('No favorites yet.', 'roro-favorites'); ?></p>
  <?php else: ?>
    <ul class="roro-fav-list" style="list-style:none;padding:0;margin:0;">
      <?php foreach ($list as $row):
        $type = $row['target'] ?? 'event';
        $id   = (int)($row['target_id'] ?? 0);
        $ttl  = (string)($row['title'] ?? '');
        $map  = add_query_arg(['highlight_'.$type => $id], home_url('/map/'));
      ?>
      <li class="roro-fav-item" data-target="<?php echo esc_attr($type); ?>" data-id="<?php echo esc_attr($id); ?>" style="border:1px solid #eee;border-radius:10px;padding:12px;margin:10px 0;">
        <div class="roro-fav-row" style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
          <div class="roro-fav-col">
            <span style="font-size:12px;color:#666;"><?php echo esc_html(strtoupper($type)); ?></span>
            <h3 style="margin:.25rem 0 0 0;"><?php echo esc_html($ttl); ?></h3>
          </div>
          <div class="roro-fav-ops" style="display:flex;gap:8px;">
            <a class="button" href="<?php echo esc_url($map); ?>">🗺️ <?php echo esc_html__('Open on Map','roro-favorites'); ?></a>
            <button type="button" class="roro-fav-toggle button button-secondary" aria-pressed="true" title="<?php echo esc_attr__('Remove from favorites','roro-favorites'); ?>">★</button>
          </div>
        </div>
      </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
  <div id="roro-fav-toast" style="position:fixed;right:16px;bottom:16px;display:none;background:#111;color:#fff;padding:8px 12px;border-radius:8px;">OK</div>
</div>
