<?php
/**
 * Plugin Name: RORO Favorites Enhancements
 * Description: 種別横断の並び替え/絞り込み、アクセシビリティ改善（トースト/フォーカス）を実装。
 * Version: 1.0.0
 * Text Domain: roro
 */

if (!defined('ABSPATH')) { exit; }

class RORO_Favorites {
    const META = 'roro_favorites'; // array of [id,type,ts]

    public function __construct() {
        add_action('rest_api_init', [$this,'register_rest']);
        add_shortcode('roro_favorites', [$this,'sc_list']);
        add_action('wp_enqueue_scripts', [$this,'enqueue']);
    }

    public function enqueue() {
        $h='roro-fav';
        wp_register_script($h, plugins_url('assets/js/favorites.js', __FILE__), ['wp-i18n'], '1.0.0', true);
        wp_localize_script($h, 'roroFav', [
            'rest'=>esc_url_raw(rest_url('roro/v1')), 'nonce'=>wp_create_nonce('wp_rest')
        ]);
        wp_set_script_translations($h,'roro',plugin_dir_path(__FILE__).'languages');
    }

    public function register_rest() {
        register_rest_route('roro/v1','/favorites', [
            [
                'methods'=>'GET',
                'permission_callback'=>function(){ return is_user_logged_in(); },
                'callback'=>[$this,'rest_get'],
                'args'=>[
                    'type'=>['required'=>false,'default'=>'all'],
                    'orderby'=>['required'=>false,'default'=>'newest'], // newest|oldest
                ],
            ],
            [
                'methods'=>'POST',
                'permission_callback'=>function(){ return is_user_logged_in(); },
                'callback'=>[$this,'rest_add'],
                'args'=>['id'=>['required'=>true],'type'=>['required'=>true]],
            ],
        ]);
        register_rest_route('roro/v1','/favorites/(?P<id>\d+)', [
            'methods'=>'DELETE',
            'permission_callback'=>function(){ return is_user_logged_in(); },
            'callback'=>[$this,'rest_remove'],
        ]);
    }

    private function read($uid) {
        $arr = get_user_meta($uid,self::META,true);
        return is_array($arr) ? $arr : [];
    }
    private function write($uid,$arr) {
        update_user_meta($uid,self::META,array_values($arr));
    }

    public function rest_get(WP_REST_Request $req){
        $uid = get_current_user_id();
        $type = sanitize_key($req['type']);
        $orderby = sanitize_key($req['orderby']);
        $items = array_filter($this->read($uid), function($it) use ($type){
            return $type==='all' ? true : ($it['type'] === $type);
        });
        usort($items, function($a,$b) use ($orderby){
            return ($orderby==='oldest') ? $a['ts'] <=> $b['ts'] : $b['ts'] <=> $a['ts'];
        });
        // hydrate minimal info
        $out = array_map(function($it){
            $p = get_post($it['id']);
            return [
                'id'=>$it['id'],
                'type'=>$it['type'],
                'title'=>$p ? get_the_title($p) : '',
                'url'=>$p ? get_permalink($p) : '',
                'ts'=>$it['ts'],
            ];
        }, $items);
        return ['items'=>$out];
    }

    public function rest_add(WP_REST_Request $req){
        $uid = get_current_user_id();
        $items = $this->read($uid);
        $id = intval($req['id']); $type=sanitize_key($req['type']);
        foreach ($items as $it){ if ($it['id']===$id && $it['type']===$type) { return ['ok'=>true]; } }
        $items[] = ['id'=>$id,'type'=>$type,'ts'=>time()];
        $this->write($uid,$items);
        return ['ok'=>true,'message'=>__('Added to favorites','roro')];
    }

    public function rest_remove(WP_REST_Request $req){
        $uid = get_current_user_id();
        $id  = intval($req['id']);
        $items = array_filter($this->read($uid), function($it) use ($id){ return intval($it['id']) !== $id; });
        $this->write($uid,$items);
        return ['ok'=>true,'message'=>__('Removed from favorites','roro')];
    }

    public function sc_list() {
        wp_enqueue_script('roro-fav');
        ob_start(); ?>
        <div class="roro-fav" aria-live="polite">
            <h3><?php echo esc_html(__('My favorites','roro')); ?></h3>
            <div class="controls">
                <label><?php echo esc_html(__('Type','roro')); ?>
                    <select id="fav-type">
                        <option value="all"><?php echo esc_html(__('All types','roro')); ?></option>
                        <option value="roro_event"><?php echo esc_html(__('Event','roro')); ?></option>
                        <option value="roro_place"><?php echo esc_html(__('Place','roro')); ?></option>
                        <option value="roro_mag_issue"><?php echo esc_html(__('Magazine','roro')); ?></option>
                    </select>
                </label>
                <label><?php echo esc_html(__('Sort by','roro')); ?>
                    <select id="fav-orderby">
                        <option value="newest"><?php echo esc_html(__('Newest','roro')); ?></option>
                        <option value="oldest"><?php echo esc_html(__('Oldest','roro')); ?></option>
                    </select>
                </label>
            </div>
            <div id="fav-list" role="list"></div>
            <div id="fav-toast" class="screen-reader-text" aria-live="assertive"></div>
        </div>
        <?php return ob_get_clean();
    }
}
new RORO_Favorites();
