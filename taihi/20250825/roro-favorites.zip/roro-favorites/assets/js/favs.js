/* global wp */
(function () {
  const { __ } = wp.i18n;
  const $ = (s, c = document) => c.querySelector(s);

  async function loadList(root) {
    const endpoint = root.dataset.endpoint;
    const type = $('select[data-key="type"]', root).value;
    const sort = $('select[data-key="sort"]', root).value;
    const url = new URL(endpoint);
    if (type) url.searchParams.set('type', type);
    if (sort) url.searchParams.set('sort', sort);

    const list = $('.roro-favs__list', root);
    list.setAttribute('aria-busy', 'true');
    list.textContent = __('Loading...', 'roro');
    try {
      const res = await fetch(url.toString(), { credentials: 'same-origin' });
      if (!res.ok) throw new Error('network');
      const json = await res.json();
      if (!json.items?.length) {
        list.textContent = __('No favorites yet.', 'roro');
      } else {
        list.innerHTML = json.items.map((i) => `
          <article class="roro-card">
            <h3><a href="${i.permalink}">${i.title}</a></h3>
            <p>${i.type}</p>
          </article>`).join('');
        // A11y: 先頭カードにフォーカスを移し操作の結果を明確化
        const firstLink = list.querySelector('a');
        firstLink?.focus();
      }
      toast(root, __('Updated.', 'roro'));
    } catch (e) {
      list.textContent = __('Failed to load favorites.', 'roro');
      toast(root, __('Error occurred.', 'roro'));
    } finally {
      list.setAttribute('aria-busy', 'false');
    }
  }

  function toast(root, msg) {
    const t = root.querySelector('.roro-toast');
    t.textContent = msg;
    t.classList.add('is-visible');
    setTimeout(() => t.classList.remove('is-visible'), 1800);
  }

  function init() {
    const root = document.querySelector('.roro-favs');
    if (!root) return;
    root.addEventListener('change', (e) => {
      if (e.target.matches('select')) {
        loadList(root);
      }
    });
    loadList(root);
  }

  document.addEventListener('DOMContentLoaded', init);
})();
