/* global roroFav, wp */
(function(){
  const { __ } = wp.i18n;
  const root = document.querySelector('.roro-fav');
  if (!root) return;

  const list = root.querySelector('#fav-list');
  const type = root.querySelector('#fav-type');
  const orderby = root.querySelector('#fav-orderby');
  const toast = root.querySelector('#fav-toast');

  async function load(){
    const params = new URLSearchParams({ type: type.value, orderby: orderby.value });
    list.textContent = __('Loading...', 'roro');
    try {
      const res = await fetch(`${roroFav.rest}/favorites?${params.toString()}`, {
        headers: { 'X-WP-Nonce': roroFav.nonce }
      });
      const json = await res.json();
      render(json.items || []);
    } catch (e) {
      list.textContent = __('Network error', 'roro');
    }
  }

  function render(items){
    list.innerHTML = '';
    if (!items.length) { list.textContent = __('No favorites yet', 'roro'); return; }
    items.forEach(it=>{
      const div = document.createElement('div');
      div.setAttribute('role','listitem');
      div.innerHTML = `
        <a href="${it.url}">${escapeHtml(it.title)}</a>
        <button class="button remove" data-id="${it.id}">${__('Remove','roro')}</button>
      `;
      list.appendChild(div);
    });
    list.querySelectorAll('.remove').forEach(b => b.addEventListener('click', remove));
  }

  async function remove(e){
    const id = e.currentTarget.dataset.id;
    try {
      const res = await fetch(`${roroFav.rest}/favorites/${id}`, {
        method:'DELETE', headers:{ 'X-WP-Nonce': roroFav.nonce }
      });
      const json = await res.json();
      toast.textContent = (json && json.message) || __('Removed from favorites','roro');
      load();
    } catch (err) {
      toast.textContent = __('Network error','roro');
    }
  }

  type.addEventListener('change', load);
  orderby.addEventListener('change', load);
  load();

  function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }
})();
