<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Chat サービス
 * - /roro/v1/chat から呼び出される
 * - roro-core-wp の設定に応じて Dify API / OpenAI API に振り分け
 * - 会話履歴（直近N件）をメッセージに同梱し文脈維持
 */
final class RORO_Chat_Service {

  const HISTORY_LIMIT = 8; // 直近8メッセージ分を同梱

  /** ユーザーの入力を処理し、AI応答を返す */
  public function handle_user_message(string $message, int $conv_id = 0, int $user_id = 0) : array {
    if (trim($message) === '') {
      return ['error'=>'empty_message'];
    }

    // 設定読込
    $opts = (array) get_option('roro_core_settings', []);
    $mode = $opts['chat_mode'] ?? 'dify_embed';

    // 埋め込みモードの場合はAPI呼び出し不要（UI側に任せる）
    if ($mode === 'dify_embed') {
      return ['error'=>'embed_mode_only'];
    }

    // 会話ID確保
    $conv_id = $this->ensure_conversation($conv_id, $user_id);

    // 履歴取得（直近）
    $history = $this->get_recent_history($conv_id);

    // メッセージ保存（ユーザー発話）
    $this->log_message($conv_id, 'user', $message);

    // 実呼び出し
    if ($mode === 'dify_api') {
      $res = $this->call_dify_api($message, $history, $opts);
    } else {
      $res = $this->call_openai_api($message, $history, $opts);
    }

    // 保存（AI応答）
    if (!empty($res['reply'])) {
      $this->log_message($conv_id, 'assistant', $res['reply']);
    }

    return [
      'conversation_id' => $conv_id,
      'reply' => $res['reply'] ?? '',
      'meta'  => $res['meta']  ?? [],
    ];
  }

  /** 会話IDを保証（無ければ新規作成） */
  private function ensure_conversation(int $conv_id, int $user_id) : int {
    global $wpdb;
    if ($conv_id > 0) return $conv_id;
    $wpdb->insert('RORO_AI_CONVERSATION', [
      'customer_id' => $this->current_customer_id($user_id),
      'title'       => 'Chat',
      'created_at'  => current_time('mysql', 1),
    ], ['%d','%s','%s']);
    return intval($wpdb->insert_id);
  }
  private function current_customer_id(int $user_id) : ?int {
    global $wpdb;
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return null;
    return intval($wpdb->get_var( $wpdb->prepare("SELECT customer_id FROM RORO_USER_LINK_WP WHERE wp_user_id=%d", $user_id) ));
  }

  /** 直近履歴の取得 */
  private function get_recent_history(int $conv_id) : array {
    global $wpdb;
    $rows = $wpdb->get_results(
      $wpdb->prepare("SELECT role, content FROM RORO_AI_MESSAGE WHERE conversation_id=%d ORDER BY id DESC LIMIT %d",
        $conv_id, self::HISTORY_LIMIT
      ), ARRAY_A
    );
    $rows = array_reverse($rows); // 古い順に
    $messages = [];
    foreach ($rows as $r) {
      $messages[] = ['role'=>$r['role'], 'content'=>$r['content']];
    }
    return $messages;
  }

  /** メッセージ保存 */
  private function log_message(int $conv_id, string $role, string $content) : void {
    global $wpdb;
    $wpdb->insert('RORO_AI_MESSAGE', [
      'conversation_id' => $conv_id,
      'role'            => $role,
      'content'         => $content,
      'created_at'      => current_time('mysql', 1),
    ], ['%d','%s','%s','%s']);
  }

  /** Dify API 呼び出し */
  private function call_dify_api(string $message, array $history, array $opts) : array {
    $base = rtrim((string)($opts['dify_api_base'] ?? ''), '/');
    $key  = (string)($opts['dify_api_key'] ?? '');
    if ($base==='' || $key==='') return ['reply'=>'','meta'=>['error'=>'invalid_dify_setting']];

    $endpoint = $base . '/v1/chat-messages'; // Difyのエンドポイント例（要アプリ毎の仕様に合わせ調整）
    $payload = [
      'inputs'   => new \stdClass(), // アプリが要求する入力（必要に応じて入れる）
      'query'    => $message,
      'response_mode' => 'blocking',
      'user'     => (string)get_current_user_id(),
      'conversation_id' => null,
      'files'    => [],
      'metadata' => [],
      // 履歴を"history"的なキーで渡す仕様のアプリもある。必要に応じてアプリ側に合わせる
    ];

    $args = [
      'headers' => [
        'Authorization' => 'Bearer '.$key,
        'Content-Type'  => 'application/json',
      ],
      'timeout' => 20,
      'body'    => wp_json_encode($payload),
    ];
    $res = wp_remote_post($endpoint, $args);
    if (is_wp_error($res)) {
      return ['reply'=>'','meta'=>['error'=>$res->get_error_message()]];
    }
    $code = wp_remote_retrieve_response_code($res);
    $body = wp_remote_retrieve_body($res);
    $json = json_decode($body, true);
    if ($code >= 200 && $code < 300 && is_array($json)) {
      $reply = $json['answer'] ?? ($json['output_text'] ?? '');
      return ['reply'=>(string)$reply, 'meta'=>$json];
    }
    return ['reply'=>'','meta'=>['error'=>'http_'.$code, 'raw'=>$body]];
  }

  /** OpenAI API 呼び出し（Chat Completions） */
  private function call_openai_api(string $message, array $history, array $opts) : array {
    $key = (string)($opts['openai_api_key'] ?? '');
    if ($key==='') return ['reply'=>'','meta'=>['error'=>'invalid_openai_key']];

    $endpoint = 'https://api.openai.com/v1/chat/completions';
    $messages = array_merge(
      [['role'=>'system','content'=>'You are a helpful pet-care assistant. Avoid medical or legal advice.']],
      $history,
      [['role'=>'user','content'=>$message]]
    );
    $payload = [
      'model'    => 'gpt-4o-mini', // 例：適宜変更可
      'messages' => $messages,
      'temperature'=> 0.7,
    ];
    $args = [
      'headers' => [
        'Authorization' => 'Bearer '.$key,
        'Content-Type'  => 'application/json',
      ],
      'timeout' => 20,
      'body'    => wp_json_encode($payload),
    ];
    $res = wp_remote_post($endpoint, $args);
    if (is_wp_error($res)) return ['reply'=>'','meta'=>['error'=>$res->get_error_message()]];
    $code = wp_remote_retrieve_response_code($res);
    $body = wp_remote_retrieve_body($res);
    $json = json_decode($body, true);
    if ($code >= 200 && $code < 300 && is_array($json)) {
      $reply = $json['choices'][0]['message']['content'] ?? '';
      return ['reply'=>(string)$reply, 'meta'=>$json];
    }
    return ['reply'=>'','meta'=>['error'=>'http_'.$code, 'raw'=>$body]];
  }
}
