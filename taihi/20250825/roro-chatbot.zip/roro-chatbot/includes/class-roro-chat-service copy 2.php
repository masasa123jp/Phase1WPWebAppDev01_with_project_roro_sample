<?php
/**
 * Chatサービス（Dify/OpenAI 切替・履歴同梱）
 * Text Domain: roro-chatbot
 */
defined('ABSPATH') || exit;

if (!class_exists('RORO_Chat_Service')):
final class RORO_Chat_Service {

  const HISTORY_LIMIT = 8;

  public function handle_user_message(string $message, int $conv_id=0, int $user_id=0): array {
    if (trim($message) === '') return ['error'=>'empty_message'];

    $opts = (array) get_option('roro_core_settings', []);
    $mode = $opts['chat_mode'] ?? 'dify_embed';
    if ($mode === 'dify_embed') {
      // 埋め込みモードではサーバ呼び出しを行わない
      return ['error'=>'embed_mode_only'];
    }

    $conv_id = $this->ensure_conversation($conv_id, $user_id);
    $history = $this->get_recent_history($conv_id);

    $this->log_message($conv_id, 'user', $message);

    $res = ($mode === 'dify_api')
      ? $this->call_dify($message, $history, $opts)
      : $this->call_openai($message, $history, $opts);

    if (!empty($res['reply'])) {
      $this->log_message($conv_id, 'assistant', $res['reply']);
    }

    return [
      'conversation_id' => $conv_id,
      'reply' => $res['reply'] ?? '',
      'meta'  => $res['meta']  ?? [],
    ];
  }

  private function ensure_conversation(int $conv_id, int $user_id): int {
    if ($conv_id > 0) return $conv_id;
    global $wpdb;
    $customer_id = null;
    if (!$user_id) $user_id = get_current_user_id();
    if ($user_id) {
      $customer_id = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT customer_id FROM RORO_USER_LINK_WP WHERE wp_user_id=%d", $user_id
      ));
    }
    $wpdb->insert('RORO_AI_CONVERSATION', [
      'customer_id' => $customer_id ?: null,
      'title'       => 'Chat',
      'created_at'  => current_time('mysql', 1),
    ], ['%d','%s','%s']);
    return (int)$wpdb->insert_id;
  }

  private function get_recent_history(int $conv_id): array {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT role, content FROM RORO_AI_MESSAGE WHERE conversation_id=%d ORDER BY id DESC LIMIT %d",
      $conv_id, self::HISTORY_LIMIT
    ), ARRAY_A);
    $rows = array_reverse($rows);
    $messages = [];
    foreach ($rows as $r) {
      $messages[] = ['role'=>$r['role'], 'content'=>$r['content']];
    }
    return $messages;
  }

  private function log_message(int $conv_id, string $role, string $content): void {
    global $wpdb;
    $wpdb->insert('RORO_AI_MESSAGE', [
      'conversation_id'=>$conv_id,
      'role'=>$role,
      'content'=>$content,
      'created_at'=>current_time('mysql',1),
    ], ['%d','%s','%s','%s']);
  }

  /** Dify API 呼び出し（アプリ仕様に合わせて適宜調整） */
  private function call_dify(string $message, array $history, array $opts): array {
    $base = rtrim((string)($opts['dify_api_base'] ?? ''), '/');
    $key  = (string)($opts['dify_api_key'] ?? '');
    if ($base==='' || $key==='') return ['reply'=>'','meta'=>['error'=>'invalid_dify_setting']];

    $endpoint = $base.'/v1/chat-messages'; // 例
    $payload = [
      'inputs' => new \stdClass(),
      'query'  => $message,
      'response_mode'=>'blocking',
      'user'   => (string)get_current_user_id(),
      // 必要なら履歴もアプリに渡す（アプリ側の仕様に依存）
    ];
    $args = [
      'headers'=>[
        'Authorization'=>'Bearer '.$key, 'Content-Type'=>'application/json'
      ],
      'timeout'=> 20,
      'body'   => wp_json_encode($payload),
    ];
    $res = wp_remote_post($endpoint, $args);
    if (is_wp_error($res)) return ['reply'=>'','meta'=>['error'=>$res->get_error_message()]];
    $code = wp_remote_retrieve_response_code($res);
    $body = wp_remote_retrieve_body($res);
    $json = json_decode($body, true);
    if ($code>=200 && $code<300 && is_array($json)) {
      $reply = $json['answer'] ?? ($json['output_text'] ?? '');
      return ['reply'=>(string)$reply, 'meta'=>$json];
    }
    return ['reply'=>'','meta'=>['error'=>'http_'.$code, 'raw'=>$body]];
  }

  /** OpenAI Chat Completions */
  private function call_openai(string $message, array $history, array $opts): array {
    $key = (string)($opts['openai_api_key'] ?? '');
    if ($key==='') return ['reply'=>'','meta'=>['error'=>'invalid_openai_key']];

    $endpoint = 'https://api.openai.com/v1/chat/completions';
    $messages = array_merge(
      [['role'=>'system','content'=>'You are a helpful pet-care assistant. Avoid medical or legal advice.']],
      $history,
      [['role'=>'user','content'=>$message]]
    );
    $payload = ['model'=>'gpt-4o-mini','messages'=>$messages,'temperature'=>0.7];

    $res = wp_remote_post($endpoint, [
      'headers'=>['Authorization'=>'Bearer '.$key,'Content-Type'=>'application/json'],
      'timeout'=>20,
      'body'=> wp_json_encode($payload),
    ]);
    if (is_wp_error($res)) return ['reply'=>'','meta'=>['error'=>$res->get_error_message()]];
    $code = wp_remote_retrieve_response_code($res);
    $body = wp_remote_retrieve_body($res);
    $json = json_decode($body, true);
    if ($code>=200 && $code<300 && is_array($json)) {
      $reply = $json['choices'][0]['message']['content'] ?? '';
      return ['reply'=>(string)$reply,'meta'=>$json];
    }
    return ['reply'=>'','meta'=>['error'=>'http_'.$code,'raw'=>$body]];
  }
}
endif;
