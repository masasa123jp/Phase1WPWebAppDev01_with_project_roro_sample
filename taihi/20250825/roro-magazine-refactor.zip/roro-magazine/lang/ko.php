<?php
$roro_mag_messages = array(
  'magazine'     => '온라인 매거진',
  'view_issue'   => '이 호 보기',
  'read_more'    => '더 보기',
  'read_less'    => '닫기',
  'back_to_list' => '호 목록으로',
  'no_issues'    => '아직 발행된 호가 없습니다.',
  'no_articles'  => '아직 기사가 없습니다.',
  'issue_key'    => '호수 (YYYY-MM)',
  // 슬라이더와 광고 카드에서 사용되는 추가 UI 라벨
  'prev'         => '이전',
  'next'         => '다음',
  'sponsored'    => '스폰서',
  'learn_more'   => '자세히 보기',
);
