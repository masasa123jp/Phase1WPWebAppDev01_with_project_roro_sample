<?php
$roro_mag_messages = array(
  'magazine'     => '线上杂志',
  'view_issue'   => '阅读本期',
  'read_more'    => '展开阅读',
  'read_less'    => '收起',
  'back_to_list' => '返回期刊列表',
  'no_issues'    => '尚未发布期刊。',
  'no_articles'  => '暂无文章。',
  'issue_key'    => '期号（YYYY-MM）',
  // 滑动组件和广告卡的额外用户界面标签
  'prev'         => '上一页',
  'next'         => '下一页',
  'sponsored'    => '赞助',
  'learn_more'   => '了解更多',
);
