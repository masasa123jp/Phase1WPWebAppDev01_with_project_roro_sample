<?php
if (!defined('ABSPATH')) { exit; }

/**
 * RORO Magazine 管理UI拡張
 * - 言語別ページ入力（ja/en/zh/ko）
 * - 広告カード（別枠）: 画像URL / 見出し / 本文 / リンク / 挿入位置(ページ番号)
 *
 * 保存形式:
 *  - _roro_mag_pages_{lang} : 1ページ1行、"---PAGE---" 区切りで複数ページを保存
 *  - _roro_mag_ads : JSON (配列) [{lang, image, title, body, url, insert_after}]
 */
final class RORO_Mag_Admin {

  public static function boot() {
    add_action('add_meta_boxes', [__CLASS__, 'add_boxes']);
    add_action('save_post', [__CLASS__, 'save'], 10, 2);
  }

  public static function add_boxes() {
    add_meta_box(
      'roro_mag_pages_box',
      __('Magazine Pages (Multilingual)', 'roro-magazine'),
      [__CLASS__, 'render_pages_box'],
      'roro_mag_issue',
      'normal',
      'default'
    );
    add_meta_box(
      'roro_mag_ads_box',
      __('Ad Cards (separate blocks)', 'roro-magazine'),
      [__CLASS__, 'render_ads_box'],
      'roro_mag_issue',
      'normal',
      'default'
    );
  }

  public static function render_pages_box(\WP_Post $post) {
    wp_nonce_field('roro_mag_save', '_roro_mag_nonce');

    $langs = ['ja','en','zh','ko'];
    echo '<p>'.esc_html__('Use "---PAGE---" as a page delimiter. One page per line is also OK.', 'roro-magazine').'</p>';
    echo '<style>.roro-mag-lang-rows textarea{width:100%;min-height:120px;font-family:monospace}</style>';
    echo '<div class="roro-mag-lang-rows">';
    foreach ($langs as $lg) {
      $val = (string) get_post_meta($post->ID, "_roro_mag_pages_{$lg}", true);
      echo '<p><label><strong>'.esc_html( strtoupper($lg) ).'</strong></label><br/>';
      echo '<textarea name="roro_mag_pages_'.$lg.'" placeholder="Page1 ... ---PAGE--- Page2 ...">'.esc_textarea($val).'</textarea></p>';
    }
    echo '</div>';
  }

  public static function render_ads_box(\WP_Post $post) {
    $raw = (string) get_post_meta($post->ID, '_roro_mag_ads', true);
    $ads = json_decode($raw, true);
    if (!is_array($ads)) $ads = [];
    // 1行 = 1カード
    echo '<p>'.esc_html__('One line per card (CSV): lang,image_url,title,body,url,insert_after_page', 'roro-magazine').'</p>';
    echo '<textarea name="roro_mag_ads_csv" style="width:100%;min-height:120px;font-family:monospace;">';
    foreach ($ads as $a) {
      $line = implode(',', [
        $a['lang']??'',
        $a['image']??'',
        str_replace([",","\n"], ['、',' '], $a['title']??''),
        str_replace([",","\n"], ['、',' '], $a['body']??''),
        $a['url']??'',
        intval($a['insert_after']??0)
      ]);
      echo esc_html($line)."\n";
    }
    echo '</textarea>';
  }

  public static function save($post_id, $post) {
    if ($post->post_type !== 'roro_mag_issue') return;
    if (!isset($_POST['_roro_mag_nonce']) || !wp_verify_nonce($_POST['_roro_mag_nonce'], 'roro_mag_save')) return;
    if (!current_user_can('edit_post', $post_id)) return;

    // 言語別ページ保存
    foreach (['ja','en','zh','ko'] as $lg) {
      $k = 'roro_mag_pages_'.$lg;
      if (isset($_POST[$k])) {
        $val = wp_kses_post( (string) $_POST[$k] );
        update_post_meta($post_id, "_roro_mag_pages_{$lg}", $val);
      }
    }

    // 広告CSV → JSON保存
    if (isset($_POST['roro_mag_ads_csv'])) {
      $csv = (string) $_POST['roro_mag_ads_csv'];
      $lines = preg_split('/\r?\n/', $csv);
      $ads = [];
      foreach ($lines as $line) {
        $line = trim($line);
        if ($line==='') continue;
        $cols = str_getcsv($line);
        $ads[] = [
          'lang'  => sanitize_text_field($cols[0] ?? ''),
          'image' => esc_url_raw($cols[1] ?? ''),
          'title' => sanitize_text_field($cols[2] ?? ''),
          'body'  => wp_kses_post($cols[3] ?? ''),
          'url'   => esc_url_raw($cols[4] ?? ''),
          'insert_after' => intval($cols[5] ?? 0),
        ];
      }
      update_post_meta($post_id, '_roro_mag_ads', wp_json_encode($ads));
    }
  }
}
RORO_Mag_Admin::boot();
