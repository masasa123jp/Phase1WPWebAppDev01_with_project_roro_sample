<?php
$roro_mag_messages = array(
  'magazine'     => '月刊マガジン',
  'view_issue'   => 'この号を読む',
  'read_more'    => 'もっと読む',
  'read_less'    => '閉じる',
  'back_to_list' => '号の一覧へ戻る',
  'no_issues'    => '公開されている号はまだありません。',
  'no_articles'  => 'この記事はまだ追加されていません。',
  'issue_key'    => '号（YYYY-MM）',
);
