/* global wp */
(function(){
  const { __ } = wp.i18n;
  const root = document.querySelector('.roro-mag-slider');
  if (!root) return;
  const track = root.querySelector('.track');
  const slides = Array.from(root.querySelectorAll('.slide'));
  const prev = root.querySelector('.prev');
  const next = root.querySelector('.next');

  let idx = 0;
  const threshold = 30; // px swipe threshold

  function update() {
    slides.forEach((s,i)=>{ s.style.display = (i===idx)?'block':'none'; });
    track.focus(); // keyboard users keep focus
  }
  update();

  prev.addEventListener('click', ()=>{ idx = (idx-1+slides.length)%slides.length; update(); });
  next.addEventListener('click', ()=>{ idx = (idx+1)%slides.length; update(); });

  track.addEventListener('keydown', (e)=>{
    if (e.key === 'ArrowLeft') { prev.click(); }
    if (e.key === 'ArrowRight'){ next.click(); }
  });

  // swipe
  let startX=0, moved=0;
  track.addEventListener('pointerdown', (e)=>{ startX = e.clientX; moved=0; track.setPointerCapture(e.pointerId); });
  track.addEventListener('pointermove', (e)=>{ moved = e.clientX - startX; });
  track.addEventListener('pointerup', ()=>{ if (Math.abs(moved) > threshold) { (moved<0?next:prev).click(); } });

  // Focus ring visible via CSS :focus-visible (browser support OK). No hard-coded styles here.
})();
