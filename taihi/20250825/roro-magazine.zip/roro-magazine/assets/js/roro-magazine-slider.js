(function(){
  'use strict';

  var root = document.querySelector('.roro-magazine');
  if (!root) return;

  var pages = Array.prototype.slice.call(root.querySelectorAll('.roro-page'));
  var idx = 0;
  var threshold = 40; // スワイプ閾値（px）

  function show(i){
    idx = Math.max(0, Math.min(pages.length - 1, i));
    pages.forEach(function(el, n){
      el.style.display = (n === idx) ? 'block' : 'none';
      if (n === idx) el.setAttribute('tabindex', '-1');
    });
    pages[idx].focus();
  }

  var startX = 0;
  root.addEventListener('touchstart', function(e){
    startX = e.changedTouches[0].clientX;
  }, {passive:true});
  root.addEventListener('touchend', function(e){
    var dx = e.changedTouches[0].clientX - startX;
    if (dx > threshold) show(idx - 1);
    if (dx < -threshold) show(idx + 1);
  }, {passive:true});

  // キーボード操作
  root.addEventListener('keydown', function(e){
    if (e.key === 'ArrowLeft')  show(idx - 1);
    if (e.key === 'ArrowRight') show(idx + 1);
  });

  // 初期表示
  show(0);
})();
