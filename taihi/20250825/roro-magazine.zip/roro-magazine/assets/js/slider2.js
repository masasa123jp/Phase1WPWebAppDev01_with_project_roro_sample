(function () {
  // スワイプ閾値・キーボード左右・フォーカスリング（:focus-visible 相当）
  const root = document.querySelector('.roro-mag-slider');
  if (!root) return;
  let startX = 0, scrollX = 0, isDown = false;

  const applyFocusRing = (on) => {
    root.classList.toggle('focus-ring', on);
  };

  root.addEventListener('pointerdown', (e) => {
    isDown = true;
    startX = e.clientX;
    scrollX = root.scrollLeft;
    root.setPointerCapture(e.pointerId);
  });
  root.addEventListener('pointermove', (e) => {
    if (!isDown) return;
    const dx = e.clientX - startX;
    root.scrollLeft = scrollX - dx;
  });
  root.addEventListener('pointerup', (e) => {
    isDown = false;
    const dx = Math.abs(e.clientX - startX);
    // スワイプ閾値：64px 以上でカード 1 枚分スクロール（簡易）
    if (dx > 64) {
      const dir = (e.clientX - startX) < 0 ? 1 : -1;
      root.scrollBy({ left: dir * root.clientWidth * 0.8, behavior: 'smooth' });
    }
  });

  root.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight' || e.key === 'Right') {
      root.scrollBy({ left: root.clientWidth * 0.8, behavior: 'smooth' });
      e.preventDefault();
      applyFocusRing(true);
    } else if (e.key === 'ArrowLeft' || e.key === 'Left') {
      root.scrollBy({ left: -root.clientWidth * 0.8, behavior: 'smooth' });
      e.preventDefault();
      applyFocusRing(true);
    }
  });

  // フォーカスリング制御
  document.addEventListener('mousedown', () => applyFocusRing(false));
  document.addEventListener('keydown', (e) => { if (e.key === 'Tab') applyFocusRing(true); });
})();
