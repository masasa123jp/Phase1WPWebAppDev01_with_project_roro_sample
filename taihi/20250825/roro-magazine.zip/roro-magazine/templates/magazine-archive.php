<?php
/**
 * Magazine archive with i18n fallback
 *
 * @package roro-magazine
 */

defined('ABSPATH') || exit;

$current_lang = determine_locale(); // wp 5.0+
$issues = new WP_Query([
    'post_type' => 'roro_mag_issue',
    'posts_per_page' => 12,
    'post_status' => 'publish',
]);

echo '<div class="roro-mag-archive" role="list">';
if ($issues->have_posts()) {
    while ($issues->have_posts()) {
        $issues->the_post();
        $title = get_the_title();
        $title_i18n = get_post_meta(get_the_ID(), '_roro_title_' . substr($current_lang, 0, 2), true);
        $title = $title_i18n ?: $title; // 未翻訳フォールバック

        echo '<article class="roro-mag-card" role="listitem">';
        echo '<h3><a href="' . esc_url(get_permalink()) . '">' . esc_html($title) . '</a></h3>';
        echo '</article>';
    }
    wp_reset_postdata();
} else {
    echo '<p>' . esc_html__('No issues yet.', 'roro') . '</p>';
}
echo '</div>';

// ウィジェット導線（シンプルなリンク）
echo '<p><a href="' . esc_url(home_url('/magazine')) . '" class="button">'
   . esc_html__('Open Magazine', 'roro') . '</a></p>';
