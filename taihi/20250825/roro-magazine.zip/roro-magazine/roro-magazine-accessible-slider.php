<?php
/**
 * Plugin Name: RORO Magazine Accessible Slider
 * Description: 雑誌スライダーのアクセシビリティ対応、未翻訳フォールバック、アーカイブ導線、ウィジェット。
 * Version: 1.0.0
 * Text Domain: roro
 */

if (!defined('ABSPATH')) { exit; }

class RORO_Magazine {
    const CPT = 'roro_mag_issue';

    public function __construct() {
        add_action('init', [$this,'load_textdomain']);
        add_action('init', [$this,'register_cpt']);
        add_action('widgets_init', [$this,'register_widget']);
        add_shortcode('roro_mag_slider', [$this,'sc_slider']);
        add_shortcode('roro_mag_archive', [$this,'sc_archive']);
        add_action('wp_enqueue_scripts', [$this,'enqueue']);
    }
    public function load_textdomain(){ load_plugin_textdomain('roro', false, dirname(plugin_basename(__FILE__)).'/languages'); }

    public function register_cpt() {
        register_post_type(self::CPT, [
            'label'=>__('Magazine','roro'),
            'public'=>true,
            'has_archive'=>true,
            'show_in_rest'=>true,
            'supports'=>['title','editor','thumbnail','excerpt']
        ]);
    }

    public function enqueue() {
        $h='roro-mag-slider';
        wp_register_script($h, plugins_url('assets/js/roro-mag-slider.js', __FILE__), ['wp-i18n'], '1.0.0', true);
        wp_set_script_translations($h,'roro',plugin_dir_path(__FILE__).'languages');
    }

    public function sc_slider() {
        wp_enqueue_script('roro-mag-slider');
        $q = new WP_Query(['post_type'=>self::CPT,'posts_per_page'=>5]);
        if (!$q->have_posts()) return '<p>'.esc_html(__('No results','roro')).'</p>';
        ob_start(); ?>
        <div class="roro-mag-slider" role="region" aria-label="<?php echo esc_attr(__('Latest issue','roro')); ?>">
            <div class="track" tabindex="0">
                <?php while($q->have_posts()): $q->the_post(); ?>
                    <article class="slide" aria-roledescription="slide">
                        <h3><?php the_title(); ?></h3>
                        <div class="excerpt"><?php the_excerpt(); ?></div>
                        <a class="button" href="<?php the_permalink(); ?>"><?php echo esc_html(__('Read more','roro')); ?></a>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
            <div class="nav">
                <button class="prev button" aria-label="<?php echo esc_attr(__('Previous','roro')); ?>">&lt;</button>
                <button class="next button" aria-label="<?php echo esc_attr(__('Next','roro')); ?>">&gt;</button>
                <a class="button" href="<?php echo esc_url( get_post_type_archive_link(self::CPT) ); ?>"><?php echo esc_html(__('View all issues','roro')); ?></a>
            </div>
        </div>
        <?php return ob_get_clean();
    }

    public function sc_archive() {
        $q = new WP_Query(['post_type'=>self::CPT,'posts_per_page'=>12]);
        ob_start(); ?>
        <div class="roro-mag-archive" role="list">
            <?php if (!$q->have_posts()): ?>
                <p><?php echo esc_html(__('No results','roro')); ?></p>
            <?php else: while($q->have_posts()): $q->the_post(); ?>
                <article class="issue" role="listitem">
                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                    <div class="excerpt"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
        <?php return ob_get_clean();
    }

    public function register_widget() { register_widget('RORO_Mag_Widget'); }
}

class RORO_Mag_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct('roro_mag_widget', __('Magazine (latest)','roro'));
    }
    public function widget($args,$instance){
        echo $args['before_widget'];
        echo $args['before_title'].esc_html(__('Latest issue','roro')).$args['after_title'];
        echo do_shortcode('[roro_mag_slider]');
        echo $args['after_widget'];
    }
}

new RORO_Magazine();
