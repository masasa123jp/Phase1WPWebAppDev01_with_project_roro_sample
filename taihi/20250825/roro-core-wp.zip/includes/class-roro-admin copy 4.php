<?php
/**
 * Settings page (AI / Map etc.) with i18n help and nonce
 *
 * @package roro-core-wp
 */

defined('ABSPATH') || exit;

if (!class_exists('RORO_Core_Admin')) {
    class RORO_Core_Admin {

        public static function init() {
            add_action('admin_menu', [__CLASS__, 'menu']);
            add_action('admin_init', [__CLASS__, 'register']);
        }

        public static function menu() {
            add_options_page(
                __('RORO Core Settings', 'roro'),
                __('RORO Core', 'roro'),
                'manage_options',
                'roro-core',
                [__CLASS__, 'screen']
            );
        }

        public static function register() {
            register_setting('roro-core', 'roro_ai_provider');
            register_setting('roro-core', 'roro_ai_base_url');
            register_setting('roro-core', 'roro_ai_api_key');
            register_setting('roro-core', 'roro_dify_base_url');
            register_setting('roro-core', 'roro_dify_api_key');
            register_setting('roro-core', 'roro_map_api_key');

            add_settings_section('roro_ai', __('AI settings', 'roro'), function(){
                echo '<p>' . esc_html__('Select AI provider and set endpoint.', 'roro') . '</p>';
            }, 'roro-core');

            add_settings_field('roro_ai_provider', __('Provider', 'roro'), function(){
                $v = get_option('roro_ai_provider', 'dify');
                echo '<select name="roro_ai_provider">';
                echo '<option value="dify" ' . selected($v,'dify',false) . '>Dify</option>';
                echo '<option value="openai" ' . selected($v,'openai',false) . '>OpenAI</option>';
                echo '</select>';
            }, 'roro-core', 'roro_ai');

            add_settings_field('roro_ai_base_url', __('OpenAI Base URL', 'roro'), function(){
                printf('<input type="text" name="roro_ai_base_url" value="%s" class="regular-text"/>', esc_attr(get_option('roro_ai_base_url')));
                echo '<p class="description">' . esc_html__('e.g. https://api.openai.com', 'roro') . '</p>';
            }, 'roro-core', 'roro_ai');

            add_settings_field('roro_ai_api_key', __('OpenAI API Key', 'roro'), function(){
                printf('<input type="password" name="roro_ai_api_key" value="%s" class="regular-text" autocomplete="off"/>', esc_attr(get_option('roro_ai_api_key')));
            }, 'roro-core', 'roro_ai');

            add_settings_field('roro_dify_base_url', __('Dify Base URL', 'roro'), function(){
                printf('<input type="text" name="roro_dify_base_url" value="%s" class="regular-text"/>', esc_attr(get_option('roro_dify_base_url')));
            }, 'roro-core', 'roro_ai');

            add_settings_field('roro_dify_api_key', __('Dify API Key', 'roro'), function(){
                printf('<input type="password" name="roro_dify_api_key" value="%s" class="regular-text" autocomplete="off"/>', esc_attr(get_option('roro_dify_api_key')));
            }, 'roro-core', 'roro_ai');

            add_settings_section('roro_map', __('Map settings', 'roro'), function(){
                echo '<p>' . esc_html__('Set Google Maps API key if required.', 'roro') . '</p>';
            }, 'roro-core');

            add_settings_field('roro_map_api_key', __('Google Maps API Key', 'roro'), function(){
                printf('<input type="text" name="roro_map_api_key" value="%s" class="regular-text"/>', esc_attr(get_option('roro_map_api_key')));
            }, 'roro-core', 'roro_map');
        }

        public static function screen() {
            if (!current_user_can('manage_options')) {
                wp_die(esc_html__('You do not have permission.', 'roro'));
            }
            ?>
            <div class="wrap">
                <h1><?php echo esc_html__('RORO Core Settings', 'roro'); ?></h1>
                <form method="post" action="options.php">
                    <?php
                    settings_fields('roro-core');
                    do_settings_sections('roro-core');
                    submit_button();
                    ?>
                </form>
            </div>
            <?php
        }
    }

    RORO_Core_Admin::init();
}
