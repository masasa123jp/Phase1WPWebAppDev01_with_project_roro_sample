<?php
/**
 * Plugin Name: RORO Core WP Settings
 * Description: 共通設定画面（i18nヘルプ、セクション分割、nonce/権限最終確認）。
 * Version: 1.0.0
 * Text Domain: roro
 */

if (!defined('ABSPATH')) { exit; }

class RORO_Core_Settings {
    public function __construct() {
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_init', [$this,'settings']);
        add_action('init', [$this,'load_textdomain']);
    }
    public function load_textdomain(){ load_plugin_textdomain('roro', false, dirname(plugin_basename(__FILE__)).'/languages'); }

    public function menu() {
        add_options_page(__('RORO Settings','roro'), __('RORO Settings','roro'), 'manage_options', 'roro-core', [$this,'render']);
    }

    public function settings() {
        // General
        register_setting('roro_core', 'roro_site_locale', ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>get_locale()]);
        add_settings_section('roro_general', __('General','roro'), function(){
            echo '<p>'.esc_html(__('Global settings for language and help texts.', 'roro')).'</p>';
        }, 'roro-core');

        add_settings_field('roro_site_locale', __('Default locale','roro'), function(){
            $val = esc_attr(get_option('roro_site_locale', get_locale()));
            echo '<input type="text" name="roro_site_locale" value="'.$val.'" class="regular-text" aria-describedby="roro_site_locale_help">';
            echo '<p id="roro_site_locale_help" class="description">'.esc_html(__('e.g., en_US, ja, zh_CN, ko_KR', 'roro')).'</p>';
        }, 'roro-core', 'roro_general');

        // Auth section (help text only; actual settings in roro-auth plugin option keys)
        add_settings_section('roro_auth', __('Authentication','roro'), function(){
            echo '<p>'.esc_html(__('Set Google/LINE credentials under each plugin option (client id/secret, redirect URI). Ensure redirect URIs match provider settings.', 'roro')).'</p>';
        }, 'roro-core');

        // Chatbot section (help-only; actual in roro-chatbot)
        add_settings_section('roro_chat', __('Chatbot','roro'), function(){
            echo '<p>'.esc_html(__('Choose Dify or OpenAI and provide API key and endpoint in Chatbot settings page.', 'roro')).'</p>';
        }, 'roro-core');

        // Recommendations section
        add_settings_section('roro_reco', __('Recommendations','roro'), function(){
            echo '<p>'.esc_html(__('A/B segment is assigned via cookie. You may adjust weighting by customizing the plugin.', 'roro')).'</p>';
        }, 'roro-core');
    }

    public function render() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'roro'));
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(__('RORO Settings','roro')); ?></h1>
            <form method="post" action="options.php">
                <?php
                    settings_fields('roro_core');
                    do_settings_sections('roro-core');
                    submit_button(__('Save changes','roro'));
                ?>
            </form>
        </div>
        <?php
    }
}
new RORO_Core_Settings();
