<?php
/**
 * Plugin Name: Roro Core WP
 * Description: 共通設定（説明/i18n ヘルプ、セクション分割、nonce/権限確認）。
 * Version: 0.3.0
 * Text Domain: roro
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function () {
    add_options_page(__('Roro Core','roro'), __('Roro Core','roro'), 'manage_options', 'roro-core', function () {
        if (!current_user_can('manage_options')) { wp_die(__('Insufficient permissions.', 'roro')); }
        if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'roro_core')) {
            update_option('roro_core_locale', sanitize_text_field($_POST['locale'] ?? 'auto'));
            echo '<div class="notice notice-success"><p>'.esc_html__('Saved.', 'roro').'</p></div>';
        }
        $locale = get_option('roro_core_locale', 'auto');
        ?>
        <div class="wrap">
          <h1><?php echo esc_html__('Roro Core Settings', 'roro'); ?></h1>

          <h2 class="title"><?php echo esc_html__('Internationalization', 'roro'); ?></h2>
          <p class="description">
            <?php echo esc_html__('Select how the site language is determined. "Auto" follows WordPress locale.','roro'); ?>
          </p>
          <form method="post">
            <?php wp_nonce_field('roro_core'); ?>
            <table class="form-table" role="presentation">
              <tr>
                <th scope="row"><?php echo esc_html__('Language mode', 'roro'); ?></th>
                <td>
                  <select name="locale">
                    <option value="auto"<?php selected($locale,'auto'); ?>><?php echo esc_html__('Auto (WordPress locale)', 'roro'); ?></option>
                    <option value="ja"<?php selected($locale,'ja'); ?>>日本語</option>
                    <option value="en"<?php selected($locale,'en'); ?>>English</option>
                    <option value="zh"<?php selected($locale,'zh'); ?>>中文</option>
                    <option value="ko"<?php selected($locale,'ko'); ?>>한국어</option>
                  </select>
                </td>
              </tr>
            </table>
            <?php submit_button(); ?>
          </form>

          <hr />
          <h2 class="title"><?php echo esc_html__('Help', 'roro'); ?></h2>
          <p><?php echo esc_html__('These settings affect common behaviors across Roro plugins (e.g., language fallback).', 'roro'); ?></p>
        </div>
        <?php
    });
});
