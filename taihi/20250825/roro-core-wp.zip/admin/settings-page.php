<?php
/**
 * roro-core-wp 設定画面。
 *
 * セクションごとに分け、各項目の説明と i18n ヘルプを提供します。
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function roro_core_wp_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Roro Core 設定', 'roro-core-wp' ); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields( 'roro-core-wp' );
            do_settings_sections( 'roro-core-wp' );
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function roro_core_wp_settings_init() {
    register_setting( 'roro-core-wp', 'roro_core_wp_options' );

    add_settings_section(
        'roro_core_wp_general',
        __( '一般設定', 'roro-core-wp' ),
        function() {
            echo '<p>' . esc_html__( '基本的な設定を行います。', 'roro-core-wp' ) . '</p>';
        },
        'roro-core-wp'
    );

    add_settings_field(
        'roro_core_wp_enable_feature',
        __( '機能Aの有効化', 'roro-core-wp' ),
        'roro_core_wp_render_enable_feature',
        'roro-core-wp',
        'roro_core_wp_general'
    );

    // セクション追加例
    add_settings_section(
        'roro_core_wp_security',
        __( 'セキュリティ', 'roro-core-wp' ),
        function() {
            echo '<p>' . esc_html__( 'nonceや権限を最終確認するための設定。', 'roro-core-wp' ) . '</p>';
        },
        'roro-core-wp'
    );
}

function roro_core_wp_render_enable_feature() {
    $options = get_option( 'roro_core_wp_options' );
    ?>
    <input type="checkbox" name="roro_core_wp_options[enable_feature]" value="1"
        <?php checked( $options['enable_feature'] ?? 0, 1 ); ?> />
    <p class="description"><?php esc_html_e( 'この機能を有効にします。', 'roro-core-wp' ); ?></p>
    <?php
}

add_action( 'admin_menu', function() {
    add_options_page(
        __( 'Roro Core 設定', 'roro-core-wp' ),
        __( 'Roro Core', 'roro-core-wp' ),
        'manage_options',
        'roro-core-wp',
        'roro_core_wp_settings_page'
    );
} );

add_action( 'admin_init', 'roro_core_wp_settings_init' );
