<?php
/**
 * Social link management (list/unlink)
 *
 * @package roro-auth
 */

defined('ABSPATH') || exit;

if (!class_exists('RORO_Auth_Social')) {
    class RORO_Auth_Social {

        public static function init() {
            add_shortcode('roro_social_links', [__CLASS__, 'render_links']);
            add_action('admin_post_roro_unlink_social', [__CLASS__, 'handle_unlink']);
            add_action('wp_loaded', [__CLASS__, 'maybe_enqueue_styles']);
        }

        public static function maybe_enqueue_styles() {
            if (is_user_logged_in()) {
                wp_register_style('roro-auth-social', plugins_url('../assets/css/roro-auth-social.css', __FILE__), [], '1.0');
                wp_enqueue_style('roro-auth-social');
            }
        }

        public static function render_links() {
            if (!is_user_logged_in()) {
                return '<p>' . esc_html__('Please sign in to manage connected accounts.', 'roro') . '</p>';
            }
            $uid = get_current_user_id();
            $providers = [
                'google' => [
                    'label' => esc_html__('Google', 'roro'),
                    'meta'  => 'roro_social_google_sub',
                ],
                'line' => [
                    'label' => esc_html__('LINE', 'roro'),
                    'meta'  => 'roro_social_line_sub',
                ],
            ];

            ob_start();
            echo '<div class="roro-social-list" role="region" aria-label="' . esc_attr__('Connected accounts', 'roro') . '">';
            foreach ($providers as $key => $def) {
                $connected = get_user_meta($uid, $def['meta'], true);
                echo '<div class="roro-social-item">';
                echo '<span class="roro-social-name">' . esc_html($def['label']) . '</span>';
                if ($connected) {
                    $last = (int) get_user_meta($uid, "roro_social_{$key}_last_login", true);
                    echo '<span class="roro-social-status">' . esc_html__('Connected', 'roro');
                    if ($last) {
                        echo ' / ' . esc_html(sprintf(__('Last login: %s', 'roro'), date_i18n(get_option('date_format'), $last)));
                    }
                    echo '</span>';
                    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="roro-unlink-form">';
                    wp_nonce_field('roro_unlink_' . $key, '_wpnonce', false, true);
                    echo '<input type="hidden" name="action" value="roro_unlink_social" />';
                    echo '<input type="hidden" name="provider" value="' . esc_attr($key) . '"/>';
                    echo '<button type="submit" class="button button-secondary" aria-label="' . esc_attr(sprintf(__('Unlink %s', 'roro'), $def['label'])) . '">';
                    echo esc_html__('Unlink', 'roro') . '</button>';
                    echo '</form>';
                } else {
                    echo '<span class="roro-social-status roro-social-status--off">' . esc_html__('Not connected', 'roro') . '</span>';
                }
                echo '</div>';
            }
            echo '</div>';
            return ob_get_clean();
        }

        public static function handle_unlink() {
            if (!is_user_logged_in()) {
                wp_die(esc_html__('You must be signed in.', 'roro'));
            }
            $uid = get_current_user_id();
            $provider = isset($_POST['provider']) ? sanitize_key(wp_unslash($_POST['provider'])) : '';
            if (!in_array($provider, ['google', 'line'], true)) {
                wp_die(esc_html__('Invalid provider.', 'roro'));
            }
            check_admin_referer('roro_unlink_' . $provider);

            $meta = 'roro_social_' . $provider . '_sub';
            delete_user_meta($uid, $meta);
            delete_user_meta($uid, 'roro_social_' . $provider . '_last_login');

            wp_safe_redirect(wp_get_referer() ?: wp_login_url());
            exit;
        }
    }

    RORO_Auth_Social::init();
}
