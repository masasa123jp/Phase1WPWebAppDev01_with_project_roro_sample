<?php
if (!defined('ABSPATH')) { exit; }

/**
 * 管理画面：認証設定＋連携一覧（解除ボタンは CSRF 対応）
 */
class Roro_Auth_Admin {
    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'settings']);
        add_action('admin_notices', [$this, 'notices']);
    }
    public function menu() {
        add_options_page(
            __('Roro Auth', 'roro'),
            __('Roro Auth', 'roro'),
            'manage_options',
            'roro-auth',
            [$this, 'render']
        );
    }
    public function settings() {
        register_setting('roro_auth', 'roro_auth_settings', [
            'type' => 'array',
            'sanitize_callback' => function ($input) {
                $out = [];
                $out['google_client_id']     = sanitize_text_field($input['google_client_id'] ?? '');
                $out['google_client_secret'] = sanitize_text_field($input['google_client_secret'] ?? '');
                $out['line_channel_id']      = sanitize_text_field($input['line_channel_id'] ?? '');
                $out['line_channel_secret']  = sanitize_text_field($input['line_channel_secret'] ?? '');
                $out['redirect_uri']         = esc_url_raw($input['redirect_uri'] ?? '');
                return $out;
            },
            'default' => [],
        ]);

        add_settings_section('roro_auth_main', __('OAuth Settings', 'roro'), function () {
            echo '<p>' . esc_html__('Configure OAuth credentials for Google and LINE.', 'roro') . '</p>';
        }, 'roro_auth');

        $fields = [
            'google_client_id'     => __('Google Client ID', 'roro'),
            'google_client_secret' => __('Google Client Secret', 'roro'),
            'line_channel_id'      => __('LINE Channel ID', 'roro'),
            'line_channel_secret'  => __('LINE Channel Secret', 'roro'),
            'redirect_uri'         => __('Redirect URI (callback)', 'roro'),
        ];
        foreach ($fields as $key => $label) {
            add_settings_field($key, esc_html($label), function () use ($key) {
                $opt = get_option('roro_auth_settings', []);
                $val = esc_attr($opt[$key] ?? '');
                printf(
                    '<input type="text" name="roro_auth_settings[%1$s]" value="%2$s" class="regular-text" />',
                    esc_attr($key),
                    $val
                );
            }, 'roro_auth', 'roro_auth_main');
        }
    }
    public function notices() {
        if (!empty($_GET['roro_notice']) && $_GET['roro_notice'] === 'disconnected') {
            echo '<div class="notice notice-success is-dismissible"><p>' .
                esc_html__('Account disconnected.', 'roro') . '</p></div>';
        }
    }
    public function render() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Roro Auth', 'roro'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('roro_auth');
                do_settings_sections('roro_auth');
                submit_button(__('Save Changes', 'roro'));
                ?>
            </form>
            <?php if (is_user_logged_in()): ?>
                <hr />
                <h2><?php echo esc_html__('Linked Accounts (current user)', 'roro'); ?></h2>
                <?php
                $uid = get_current_user_id();
                $accounts = (array) get_user_meta($uid, 'roro_auth_accounts', true);
                if (!$accounts) {
                    echo '<p>' . esc_html__('No linked accounts.', 'roro') . '</p>';
                } else {
                    echo '<ul>';
                    foreach ($accounts as $provider => $info) {
                        $u = wp_nonce_url(
                            add_query_arg(['action' => 'roro_auth_disconnect', 'provider' => $provider], admin_url('admin-post.php')),
                            'roro_auth_disconnect'
                        );
                        printf(
                            '<li><strong>%1$s</strong> — %2$s <a class="button button-secondary" href="%3$s">%4$s</a></li>',
                            esc_html(ucfirst($provider)),
                            !empty($info['name']) ? esc_html($info['name']) : esc_html__('Unknown user', 'roro'),
                            esc_url($u),
                            esc_html__('Disconnect', 'roro')
                        );
                    }
                    echo '</ul>';
                }
                ?>
            <?php endif; ?>
        </div>
        <?php
    }
}
new Roro_Auth_Admin();
