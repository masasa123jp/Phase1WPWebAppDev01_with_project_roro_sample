<?php
if (!defined('ABSPATH')) { exit; }

/**
 * ユーザーのペット情報（配列）と代表ペット ID を管理。REST 経由で CRUD。
 * データ構造:
 *   user_meta 'roro_pets' = [
 *     ['id'=>'p_xxx','name'=>'...','breed'=>'...','age'=>3,'notes'=>'...'],
 *     ...
 *   ]
 *   user_meta 'roro_rep_pet_id' = 'p_xxx'
 */
class Roro_Auth_User {

    public static function get_pets(int $user_id): array {
        $pets = get_user_meta($user_id, 'roro_pets', true);
        return is_array($pets) ? array_values($pets) : [];
    }

    public static function save_pets(int $user_id, array $pets): void {
        // 最低限のバリデーション／正規化
        $norm = [];
        foreach ($pets as $p) {
            $norm[] = [
                'id'    => sanitize_text_field($p['id'] ?? ('p_' . wp_generate_password(8, false))),
                'name'  => sanitize_text_field($p['name'] ?? ''),
                'breed' => sanitize_text_field($p['breed'] ?? ''),
                'age'   => isset($p['age']) ? max(0, intval($p['age'])) : 0,
                'notes' => sanitize_textarea_field($p['notes'] ?? ''),
            ];
        }
        update_user_meta($user_id, 'roro_pets', $norm);
    }

    public static function set_representative(int $user_id, string $pet_id): void {
        // 実在確認
        $exists = false;
        foreach (self::get_pets($user_id) as $p) {
            if ($p['id'] === $pet_id) { $exists = true; break; }
        }
        if (!$exists) {
            throw new RuntimeException(__('Selected pet not found.', 'roro'));
        }
        update_user_meta($user_id, 'roro_rep_pet_id', $pet_id);
    }
}
