<?php
if (!defined('ABSPATH')) { exit; }

class Roro_Auth_REST {
    public function register_routes() {
        // 犬種候補
        register_rest_route('roro/v1', '/breeds', [
            [
                'methods'  => 'GET',
                'callback' => [$this, 'breeds'],
                'permission_callback' => '__return_true',
                'args' => [
                    'locale' => ['type'=>'string','required'=>false],
                ],
            ],
        ]);

        // ペット CRUD（ログイン必須）
        register_rest_route('roro/v1', '/pets', [
            [
                'methods'  => 'GET',
                'callback' => function (WP_REST_Request $req) {
                    if (!is_user_logged_in()) { return new WP_Error('forbidden', __('Sign-in required.', 'roro'), ['status' => 401]); }
                    return Roro_Auth_User::get_pets(get_current_user_id());
                },
                'permission_callback' => '__return_true',
            ],
            [
                'methods'  => 'POST',
                'callback' => function (WP_REST_Request $req) {
                    if (!is_user_logged_in()) { return new WP_Error('forbidden', __('Sign-in required.', 'roro'), ['status' => 401]); }
                    if (!wp_verify_nonce($req->get_header('X-WP-Nonce') ?: '', 'wp_rest')) {
                        return new WP_Error('forbidden', __('Invalid nonce.', 'roro'), ['status' => 403]);
                    }
                    $body = $req->get_json_params();
                    $pets = is_array($body['pets'] ?? null) ? $body['pets'] : [];
                    Roro_Auth_User::save_pets(get_current_user_id(), $pets);
                    return ['ok' => true];
                },
                'permission_callback' => '__return_true',
            ],
        ]);

        // 代表ペット切替
        register_rest_route('roro/v1', '/pets/representative', [
            'methods'  => 'POST',
            'callback' => function (WP_REST_Request $req) {
                if (!is_user_logged_in()) { return new WP_Error('forbidden', __('Sign-in required.', 'roro'), ['status' => 401]); }
                if (!wp_verify_nonce($req->get_header('X-WP-Nonce') ?: '', 'wp_rest')) {
                    return new WP_Error('forbidden', __('Invalid nonce.', 'roro'), ['status' => 403]);
                }
                $pet_id = sanitize_text_field($req->get_param('pet_id') ?: '');
                if (!$pet_id) { return new WP_Error('bad_request', __('pet_id is required.', 'roro'), ['status' => 400]); }
                try {
                    Roro_Auth_User::set_representative(get_current_user_id(), $pet_id);
                } catch (Throwable $e) {
                    return new WP_Error('bad_request', $e->getMessage(), ['status' => 400]);
                }
                return ['ok' => true, 'rep_pet_id' => $pet_id];
            },
            'permission_callback' => '__return_true',
        ]);

        // 連携一覧（現在ユーザー向け、UI 用）
        register_rest_route('roro/v1', '/accounts', [
            'methods'  => 'GET',
            'callback' => function () {
                if (!is_user_logged_in()) { return new WP_Error('forbidden', __('Sign-in required.', 'roro'), ['status' => 401]); }
                return (array) get_user_meta(get_current_user_id(), 'roro_auth_accounts', true);
            },
            'permission_callback' => '__return_true',
        ]);
    }

    public function breeds(WP_REST_Request $req) {
        $locale = sanitize_text_field($req->get_param('locale') ?: get_locale());
        $lang = substr($locale, 0, 2);
        $map = [
            'ja' => 'breeds-ja.json',
            'en' => 'breeds-en.json',
            'zh' => 'breeds-zh.json',
            'ko' => 'breeds-ko.json',
        ];
        $file = RORO_AUTH_DIR . 'assets/data/' . ($map[$lang] ?? 'breeds-en.json');
        if (!file_exists($file)) {
            $file = RORO_AUTH_DIR . 'assets/data/breeds-en.json';
        }
        $json = file_get_contents($file);
        $list = json_decode($json, true);
        if (!is_array($list)) { $list = []; }
        return $list;
    }
}
