<?php
/**
 * OAuth ハンドラー
 *
 * Google/LINE 向けの state/nonce 発行・検証、例外処理を提供します。
 * 連携解除時の CSRF 対策等にも利用されます。
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Roro_Auth_OAuth {

    /**
     * OAuth 認証開始時に state パラメータと nonce を生成してセッションに保存します。
     *
     * @param string $provider 認証プロバイダー名 (google|line)
     * @return array ['state' => ..., 'nonce' => ...]
     */
    public static function generate_state_and_nonce( $provider ) {
        $state = wp_generate_password( 32, false, false );
        $nonce = wp_generate_password( 32, false, false );

        // セッションに保存してコールバック時に検証する
        if ( ! session_id() ) {
            session_start();
        }
        $_SESSION[ "roro_auth_{$provider}_state" ] = $state;
        $_SESSION[ "roro_auth_{$provider}_nonce" ] = $nonce;

        return array(
            'state' => $state,
            'nonce' => $nonce,
        );
    }

    /**
     * コールバック時に state と nonce を検証し、正当なリクエストか確認します。
     *
     * @param string $provider 認証プロバイダー名
     * @param string $state クエリパラメータから渡された state
     * @param string $nonce ID トークン内の nonce
     * @throws Exception 検証失敗時には例外を投げます。
     */
    public static function verify_state_and_nonce( $provider, $state, $nonce ) {
        if ( ! session_id() ) {
            session_start();
        }
        $expected_state = isset( $_SESSION[ "roro_auth_{$provider}_state" ] ) ? $_SESSION[ "roro_auth_{$provider}_state" ] : '';
        $expected_nonce = isset( $_SESSION[ "roro_auth_{$provider}_nonce" ] ) ? $_SESSION[ "roro_auth_{$provider}_nonce" ] : '';

        if ( empty( $state ) || $state !== $expected_state ) {
            throw new Exception( __( '認証処理に失敗しました（state 不一致）。', 'roro-auth' ) );
        }
        if ( empty( $nonce ) || $nonce !== $expected_nonce ) {
            throw new Exception( __( '認証処理に失敗しました（nonce 不一致）。', 'roro-auth' ) );
        }

        // 検証後は破棄
        unset( $_SESSION[ "roro_auth_{$provider}_state" ], $_SESSION[ "roro_auth_{$provider}_nonce" ] );
    }

    /**
     * 例外ハンドリング用ヘルパー。
     *
     * @param Exception $e
     */
    public static function handle_oauth_exception( $e ) {
        error_log( $e->getMessage() );
        // ユーザーには汎用的なエラーメッセージを表示。i18n 対応。
        wp_die(
            esc_html__( 'ソーシャルログインに失敗しました。時間をおいて再試行してください。', 'roro-auth' ),
            esc_html__( 'ログインエラー', 'roro-auth' ),
            array( 'response' => 401 )
        );
    }
}
