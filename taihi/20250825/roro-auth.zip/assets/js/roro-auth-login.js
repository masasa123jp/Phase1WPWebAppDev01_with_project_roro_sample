/**
 * ログイン画面用の最小限のスクリプト
 * - 必要に応じて自動フォーカスやバリデーションを追加可能
 */
(function () {
  // ここではデバッグ用に読み込み確認のみ
  // console.log('RORO Auth: login script loaded');
})();
