/* global roroAuth, wp */
(function(){
  const { __ } = wp.i18n;
  const rest = roroAuth.rest;
  const headers = { 'X-WP-Nonce': roroAuth.nonce, 'Content-Type': 'application/json' };

  // Profile form
  const $profileForm = document.getElementById('roro-profile-form');
  if ($profileForm) {
    $profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData($profileForm);
      const display_name = fd.get('display_name').trim();
      const user_email = fd.get('user_email').trim();
      const status = $profileForm.querySelector('.roro-profile-status');
      status.textContent = __('Loading...', 'roro');

      // Simple validation
      if (!display_name) {
        status.textContent = __('Name is required.', 'roro');
        return;
      }
      try {
        // Update via WP REST Users endpoint
        const res = await wp.apiFetch({
          path: `/wp/v2/users/me`,
          method: 'POST',
          headers,
          data: { name: display_name, email: user_email }
        });
        status.textContent = __('Settings saved', 'roro');
      } catch (err) {
        status.textContent = __('Unknown error', 'roro');
      }
    });
  }

  // Linked accounts: unlink buttons
  document.querySelectorAll('.roro-unlink').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm(__('Are you sure you want to unlink this account?', 'roro'))) return;
      btn.disabled = true;
      try {
        const res = await fetch(`${rest}/auth/connection/${btn.dataset.provider}?_wpnonce=${encodeURIComponent(roroAuth.unlinkNonce)}`, {
          method: 'DELETE',
          headers: { 'X-WP-Nonce': roroAuth.nonce }
        });
        const json = await res.json();
        if (json && json.ok) {
          location.reload();
        } else {
          alert(__('Unknown error', 'roro'));
        }
      } catch (e) {
        alert(__('Network error', 'roro'));
      } finally {
        btn.disabled = false;
      }
    });
  });

  // Pets UI
  const petsRoot = document.getElementById('roro-pets');
  const editor   = document.getElementById('roro-pet-editor');
  const addBtn   = document.getElementById('roro-add-pet');
  const petForm  = document.getElementById('roro-pet-form');
  const breedInput = petForm ? petForm.querySelector('input[name="breed"]') : null;
  const breedList  = document.getElementById('roro-breed-suggest');

  async function loadPets() {
    if (!petsRoot) return;
    const res = await fetch(`${rest}/auth/pets`, { headers: { 'X-WP-Nonce': roroAuth.nonce }});
    const json = await res.json();
    petsRoot.innerHTML = '';
    const primary = json.primary;
    (json.items || []).forEach(p => {
      const li = document.createElement('div');
      li.className = 'roro-pet-row';
      li.innerHTML = `
        <strong>${escapeHtml(p.name)}</strong>
        <span>${escapeHtml(p.breed || '')}</span>
        <span>${escapeHtml(p.age || '')}</span>
        <span>${p.id === primary ? __('Primary', 'roro') : ''}</span>
        <div class="actions">
          <button class="button edit" data-id="${p.id}">${__('Edit', 'roro')}</button>
          <button class="button make-primary" data-id="${p.id}">${__('Primary pet', 'roro')}</button>
        </div>
      `;
      petsRoot.appendChild(li);
    });
    petsRoot.querySelectorAll('.edit').forEach(b => b.addEventListener('click', () => openEditor(b.dataset.id, json.items)));
    petsRoot.querySelectorAll('.make-primary').forEach(b => b.addEventListener('click', () => setPrimary(b.dataset.id)));
  }

  function openEditor(id, items) {
    editor.hidden = false;
    const p = (items || []).find(x => x.id === id);
    petForm.reset();
    petForm.querySelector('input[name="id"]').value = p ? p.id : '';
    petForm.querySelector('input[name="name"]').value = p ? (p.name||'') : '';
    petForm.querySelector('input[name="breed"]').value = p ? (p.breed||'') : '';
    petForm.querySelector('input[name="age"]').value = p ? (p.age||'') : '';
    petForm.querySelector('input[name="primary"]').checked = false;
  }

  async function setPrimary(id) {
    const res = await fetch(`${rest}/auth/pets/primary`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ id, _wpnonce: roroAuth.petNonce })
    });
    const json = await res.json();
    if (json && json.ok) {
      loadPets();
    } else {
      alert(__('Unknown error', 'roro'));
    }
  }

  if (addBtn) addBtn.addEventListener('click', () => { openEditor(null, []); });

  if (petForm) petForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(petForm);
    const data = Object.fromEntries(fd.entries());
    data.primary = !!fd.get('primary');
    const status = petForm.querySelector('.roro-pet-status');
    status.textContent = __('Loading...', 'roro');
    try {
      const res = await fetch(`${rest}/auth/pets`, {
        method: 'POST',
        headers,
        body: JSON.stringify(data)
      });
      const json = await res.json();
      if (json && json.ok) {
        status.textContent = __('Settings saved', 'roro');
        editor.hidden = true;
        loadPets();
      } else {
        status.textContent = (json && json.message) || __('Unknown error', 'roro');
      }
    } catch (e) {
      status.textContent = __('Network error', 'roro');
    }
  });

  // Breed suggests
  if (breedInput && breedList) {
    let timer = null;
    breedInput.addEventListener('input', () => {
      const q = breedInput.value.trim();
      clearTimeout(timer);
      if (!q) { breedList.hidden = true; breedList.innerHTML=''; return; }
      timer = setTimeout(async () => {
        const res = await fetch(`${rest}/auth/breeds?q=${encodeURIComponent(q)}&limit=10`);
        const json = await res.json();
        breedList.innerHTML = '';
        (json.items || []).forEach(item => {
          const li = document.createElement('li');
          li.role='option';
          li.tabIndex = 0;
          li.textContent = item.label;
          li.addEventListener('click', () => { breedInput.value = item.label; breedList.hidden = true; });
          li.addEventListener('keydown', (e) => { if (e.key === 'Enter') { breedInput.value = item.label; breedList.hidden = true; }});
          breedList.appendChild(li);
        });
        breedList.hidden = !(json.items||[]).length;
      }, 250);
    });
  }

  function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }

  // initial load
  loadPets();
})();
