/* global RORO_AUTH, wp */
(function () {
  const { __ } = wp.i18n;

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  const toast = (msg) => {
    const el = $('.roro-toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('is-visible');
    setTimeout(() => el.classList.remove('is-visible'), 2500);
  };

  async function fetchBreeds() {
    const url = new URL(RORO_AUTH.rest.breeds);
    url.searchParams.set('locale', document.documentElement.lang || 'en');
    const res = await fetch(url.toString(), { credentials: 'same-origin' });
    if (!res.ok) throw new Error('breeds');
    return res.json();
  }

  function renderBreedOptions(select, list, initValue) {
    select.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = __('Select a breed', 'roro');
    select.appendChild(opt0);
    list.forEach((b) => {
      const o = document.createElement('option');
      o.value = b;
      o.textContent = b;
      select.appendChild(o);
    });
    if (initValue) select.value = initValue;
  }

  function buildEmptyPet() {
    const id = 'p_' + Math.random().toString(36).slice(2, 8);
    const fs = document.createElement('fieldset');
    fs.className = 'roro-pet';
    fs.dataset.id = id;
    fs.innerHTML = `
      <legend>${__('Pet', 'roro')}: <span class="roro-pet__name">${__('(No name)', 'roro')}</span></legend>
      <label>${__('Name', 'roro')}<input name="name" required aria-required="true"></label>
      <label>${__('Breed', 'roro')}<select name="breed" class="roro-breed-select"></select></label>
      <label>${__('Age', 'roro')}<input type="number" name="age" min="0" value="0"></label>
      <label>${__('Notes', 'roro')}<textarea name="notes"></textarea></label>
      <div class="roro-pet__actions">
        <button type="button" class="button roro-make-rep" data-pet="${id}">${__('Make representative', 'roro')}</button>
        <button type="button" class="button button-link-delete roro-delete-pet">${__('Delete', 'roro')}</button>
      </div>
    `;
    return fs;
  }

  async function init() {
    const root = $('#roro-profile');
    if (!root) return;

    let breeds = [];
    try {
      breeds = await fetchBreeds();
    } catch (e) {
      console.warn('Failed to load breeds', e);
    }
    $$('.roro-breed-select', root).forEach((sel) => {
      renderBreedOptions(sel, breeds, sel.dataset.init || '');
    });

    root.addEventListener('input', (e) => {
      const fs = e.target.closest('.roro-pet');
      if (!fs) return;
      if (e.target.name === 'name') {
        $('.roro-pet__name', fs).textContent = e.target.value || __('(No name)', 'roro');
      }
    });

    // 代表ペット
    root.addEventListener('click', async (e) => {
      if (e.target.classList.contains('roro-make-rep')) {
        const petId = e.target.dataset.pet;
        try {
          const res = await fetch(RORO_AUTH.rest.pets + '/representative', {
            method: 'POST',
            headers: { 'X-WP-Nonce': RORO_AUTH.nonce, 'Content-Type': 'application/json' },
            body: JSON.stringify({ pet_id: petId })
          });
          if (!res.ok) throw new Error('rep');
          toast(__('Representative pet updated.', 'roro'));
          // 表示更新
          $$('.roro-pet .roro-pill', root).forEach((el) => el.remove());
          const fs = $(`.roro-pet[data-id="${petId}"]`, root);
          if (fs) {
            const pill = document.createElement('span');
            pill.className = 'roro-pill';
            pill.textContent = __('Representative', 'roro');
            $('.roro-pet__name', fs).after(pill);
          }
        } catch (err) {
          toast(__('Failed to update representative pet.', 'roro'));
        }
      }
      if (e.target.classList.contains('roro-delete-pet')) {
        const fs = e.target.closest('.roro-pet');
        fs?.remove();
      }
      if (e.target.classList.contains('roro-add-pet')) {
        const list = $('.roro-pets-list', root);
        const fs = buildEmptyPet();
        list.appendChild(fs);
        const select = $('select[name="breed"]', fs);
        renderBreedOptions(select, breeds, '');
        select.focus();
      }
    });

    // 保存
    $('#roro-pets-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      // バリデーション（過不足なし）
      const pets = $$('.roro-pet', root).map((fs) => {
        const rec = {
          id: fs.dataset.id,
          name: $('input[name="name"]', fs)?.value.trim(),
          breed: $('select[name="breed"]', fs)?.value,
          age: parseInt($('input[name="age"]', fs)?.value || '0', 10) || 0,
          notes: $('textarea[name="notes"]', fs)?.value || ''
        };
        if (!rec.name) {
          $('input[name="name"]', fs).focus();
          toast(__('Name is required.', 'roro'));
          throw new Error('validation');
        }
        return rec;
      });
      try {
        const res = await fetch(RORO_AUTH.rest.pets, {
          method: 'POST',
          headers: { 'X-WP-Nonce': RORO_AUTH.nonce, 'Content-Type': 'application/json' },
          body: JSON.stringify({ pets })
        });
        if (!res.ok) throw new Error('save');
        toast(__('Saved.', 'roro'));
      } catch (err) {
        toast(__('Failed to save.', 'roro'));
      }
    });

    // 連携一覧ロード
    try {
      const res = await fetch(RORO_AUTH.rest.accounts, { credentials: 'same-origin' });
      const box = $('#roro-accounts');
      if (!res.ok) {
        box.textContent = __('Failed to load accounts.', 'roro');
      } else {
        const json = await res.json();
        const list = Object.keys(json);
        if (!list.length) {
          box.textContent = __('No linked accounts.', 'roro');
        } else {
          const ul = document.createElement('ul');
          list.forEach((prov) => {
            const li = document.createElement('li');
            li.textContent = prov.charAt(0).toUpperCase() + prov.slice(1);
            ul.appendChild(li);
          });
          box.innerHTML = '';
          box.appendChild(ul);
        }
      }
    } catch (e) {
      console.warn(e);
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
