<?php
/**
 * Plugin Name: RORO Auth Enhancements
 * Description: Google/LINE OAuthのstate/nonce強化、連携解除CSRF対策、プロフィール/ペット編集、犬種候補RESTなど未完部分を実装。
 * Version: 1.0.0
 * Author: Project RORO
 * Text Domain: roro
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) { exit; }

final class RORO_Auth_Enhancements {
    const STATE_TTL = 15 * MINUTE_IN_SECONDS;
    const META_LINK_PREFIX = 'roro_auth_';
    const META_PETS = 'roro_pets';
    const META_PRIMARY_PET = 'roro_primary_pet_id';
    const TAX_BREED = 'roro_dog_breed';

    public static function instance() {
        static $inst = null;
        if (!$inst) { $inst = new self(); }
        return $inst;
    }

    private function __construct() {
        add_action('init', [$this, 'load_textdomain']);
        add_action('init', [$this, 'maybe_route_oauth']);
        add_action('init', [$this, 'register_taxonomies']);
        add_action('rest_api_init', [$this, 'register_rest']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_shortcode('roro_auth_login', [$this, 'sc_login_buttons']);
        add_shortcode('roro_profile', [$this, 'sc_profile']);
    }

    public function load_textdomain() {
        load_plugin_textdomain('roro', false, dirname(plugin_basename(__FILE__)).'/languages');
    }

    /** Register dog breed taxonomy used by breed candidates API (fallback if terms not seeded) */
    public function register_taxonomies() {
        register_taxonomy(self::TAX_BREED, 'user', [
            'public' => false,
            'hierarchical' => false,
            'labels' => [
                'name' => __('Dog Breeds', 'roro'),
                'singular_name' => __('Dog Breed', 'roro'),
            ],
            'show_ui' => false,
            'show_in_rest' => false,
        ]);
        // Ensure minimal fallback terms for UX even if seeder not applied
        $fallback = ['Shiba Inu','Golden Retriever','Toy Poodle','Chihuahua','Dachshund','French Bulldog','Pomeranian','Shih Tzu','Labrador Retriever','Siberian Husky'];
        foreach ($fallback as $name) {
            if (!term_exists($name, self::TAX_BREED)) {
                wp_insert_term($name, self::TAX_BREED);
            }
        }
    }

    /** OAuth entry/callback router via query vars (?roro_auth=login|callback&provider=google|line) */
    public function maybe_route_oauth() {
        if (!isset($_GET['roro_auth']) || !isset($_GET['provider'])) { return; }
        $action   = sanitize_key($_GET['roro_auth']);
        $provider = sanitize_key($_GET['provider']);

        if ($action === 'login') {
            $redirect = isset($_GET['redirect']) ? esc_url_raw($_GET['redirect']) : home_url('/');
            $url = $this->build_auth_url($provider, $redirect);
            if (is_wp_error($url)) {
                wp_die(esc_html($url->get_error_message()), __('Authentication error', 'roro'));
            }
            wp_redirect($url); exit;
        }

        if ($action === 'callback') {
            $result = $this->handle_callback($provider);
            if (is_wp_error($result)) {
                $msg = $result->get_error_message();
                wp_die(esc_html($msg), __('Authentication error', 'roro'));
            }
            // Redirect to stored redirect or profile
            $redirect = isset($result['redirect']) ? $result['redirect'] : home_url('/profile');
            wp_safe_redirect($redirect); exit;
        }
    }

    /** Build provider auth URL with state + nonce */
    private function build_auth_url($provider, $redirect) {
        $conf = $this->get_provider_conf($provider);
        if (!$conf) {
            return new WP_Error('roro_conf_missing', __('Provider configuration missing.', 'roro'));
        }
        $state = wp_generate_uuid4();
        $nonce = wp_generate_password(16, false);
        set_transient('roro_state_'.$state, [
            'provider' => $provider,
            'redirect' => $redirect,
            'nonce'    => $nonce,
            'time'     => time(),
        ], self::STATE_TTL);

        $common = [
            'response_type' => 'code',
            'redirect_uri'  => $conf['redirect_uri'],
            'state'         => $state,
            'scope'         => $conf['scope'],
            'nonce'         => $nonce,
        ];

        if ($provider === 'google') {
            $url = add_query_arg(array_merge($common, [
                'client_id' => $conf['client_id'],
                // Google requires space delimited scope; add openid/email/profile
            ]), 'https://accounts.google.com/o/oauth2/v2/auth');
            return $url;
        }
        if ($provider === 'line') {
            $url = add_query_arg(array_merge($common, [
                'client_id' => $conf['client_id'],
                // LINE scopes: openid profile email
            ]), 'https://access.line.me/oauth2/v2.1/authorize');
            return $url;
        }
        return new WP_Error('roro_provider_unknown', __('Unsupported provider.', 'roro'));
    }

    /** Exchange code, verify state/nonce, create/link account, login */
    private function handle_callback($provider) {
        $conf = $this->get_provider_conf($provider);
        if (!$conf) { return new WP_Error('roro_conf_missing', __('Provider configuration missing.', 'roro')); }

        $code  = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $state = isset($_GET['state']) ? sanitize_text_field($_GET['state']) : '';
        $err   = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';

        if ($err) {
            return new WP_Error('roro_auth_denied', sprintf(__('Provider returned an error: %s', 'roro'), $err));
        }
        $st = get_transient('roro_state_'.$state);
        delete_transient('roro_state_'.$state);
        if (!$st) {
            return new WP_Error('roro_state_failed', __('State verification failed. Session expired.', 'roro'));
        }
        $token = $this->token_exchange($provider, $conf, $code);
        if (is_wp_error($token)) { return $token; }

        // Verify id_token and nonce using provider verify endpoints
        $verified = $this->verify_id_token($provider, $token, $st['nonce'], $conf);
        if (is_wp_error($verified)) { return $verified; }

        $sub   = $verified['sub'];
        $email = isset($verified['email']) ? $verified['email'] : '';
        $name  = isset($verified['name']) ? $verified['name'] : '';

        $user_id = $this->link_or_create_user($provider, $sub, $email, $name);
        if (is_wp_error($user_id)) { return $user_id; }

        wp_set_auth_cookie($user_id, true);
        do_action('roro_auth_logged_in', $user_id, $provider, $verified);

        return ['redirect' => $st['redirect']];
    }

    private function token_exchange($provider, $conf, $code) {
        $body = [
            'grant_type'   => 'authorization_code',
            'code'         => $code,
            'redirect_uri' => $conf['redirect_uri'],
            'client_id'    => $conf['client_id'],
            'client_secret'=> $conf['client_secret'],
        ];
        $endpoint = $provider === 'google'
            ? 'https://oauth2.googleapis.com/token'
            : 'https://api.line.me/oauth2/v2.1/token';
        $res = wp_remote_post($endpoint, [
            'timeout' => 15,
            'headers' => ['Content-Type'=>'application/x-www-form-urlencoded'],
            'body'    => $body,
        ]);
        if (is_wp_error($res)) { return new WP_Error('roro_token_http', __('Network error during token exchange.', 'roro')); }
        $code = wp_remote_retrieve_response_code($res);
        $json = json_decode(wp_remote_retrieve_body($res), true);
        if ($code !== 200 || !is_array($json)) {
            return new WP_Error('roro_token_bad', __('Token exchange failed.', 'roro'));
        }
        return $json;
    }

    private function verify_id_token($provider, $token_json, $expected_nonce, $conf) {
        if (!empty($token_json['id_token'])) {
            if ($provider === 'google') {
                $verify = add_query_arg(['id_token'=>$token_json['id_token']], 'https://oauth2.googleapis.com/tokeninfo');
                $res = wp_remote_get($verify, ['timeout'=>10]);
                if (is_wp_error($res)) { return new WP_Error('roro_verify_http', __('Network error during token verification.', 'roro')); }
                $data = json_decode(wp_remote_retrieve_body($res), true);
                if (!is_array($data) || empty($data['aud']) || $data['aud'] !== $conf['client_id']) {
                    return new WP_Error('roro_verify_aud', __('Audience mismatch.', 'roro'));
                }
                if (empty($data['nonce']) || $data['nonce'] !== $expected_nonce) {
                    return new WP_Error('roro_verify_nonce', __('Nonce verification failed.', 'roro'));
                }
                return [
                    'sub'   => $data['sub'],
                    'email' => isset($data['email']) ? $data['email'] : '',
                    'name'  => isset($data['name']) ? $data['name'] : '',
                ];
            }
            if ($provider === 'line') {
                // LINE: verify ID token endpoint
                $res = wp_remote_post('https://api.line.me/oauth2/v2.1/verify', [
                    'timeout' => 10,
                    'headers' => ['Content-Type'=>'application/x-www-form-urlencoded'],
                    'body' => [
                        'id_token'   => $token_json['id_token'],
                        'client_id'  => $conf['client_id'],
                    ],
                ]);
                if (is_wp_error($res)) { return new WP_Error('roro_verify_http', __('Network error during token verification.', 'roro')); }
                $data = json_decode(wp_remote_retrieve_body($res), true);
                if (!is_array($data) || empty($data['sub'])) {
                    return new WP_Error('roro_verify_bad', __('Token verification failed.', 'roro'));
                }
                if (empty($data['nonce']) || $data['nonce'] !== $expected_nonce) {
                    return new WP_Error('roro_verify_nonce', __('Nonce verification failed.', 'roro'));
                }
                return [
                    'sub'   => $data['sub'],
                    'email' => isset($data['email']) ? $data['email'] : '',
                    'name'  => isset($data['name']) ? $data['name'] : '',
                ];
            }
        }
        // Fallback if provider didn’t return id_token (shouldn't happen with openid)
        return new WP_Error('roro_missing_id_token', __('Missing ID token', 'roro'));
    }

    private function link_or_create_user($provider, $sub, $email, $name) {
        $meta_key = self::META_LINK_PREFIX.$provider.'_sub';

        // If sub is already linked, log that user in
        $user = $this->get_user_by_meta($meta_key, $sub);
        if ($user) { return $user->ID; }

        // Otherwise, find by email then link
        if ($email) {
            $by_email = get_user_by('email', $email);
            if ($by_email) {
                update_user_meta($by_email->ID, $meta_key, $sub);
                return $by_email->ID;
            }
        }

        // Create new user
        if (!get_option('users_can_register')) {
            return new WP_Error('roro_no_signup', __('Signups are disabled.', 'roro'));
        }
        $login = sanitize_user($email ? current(explode('@', $email)) : 'roro_'.$provider.'_'.$sub, true);
        $suffix = 1;
        $base   = $login;
        while (username_exists($login)) { $login = $base . $suffix++; }

        $password = wp_generate_password(20, true);
        $user_id = wp_create_user($login, $password, $email ?: '');
        if (is_wp_error($user_id)) {
            return new WP_Error('roro_user_create_failed', __('Could not create user account.', 'roro'));
        }
        if ($name) {
            wp_update_user(['ID'=>$user_id,'display_name'=>sanitize_text_field($name)]);
        }
        update_user_meta($user_id, $meta_key, $sub);
        return $user_id;
    }

    private function get_user_by_meta($key, $value) {
        $args = [
            'meta_key'   => $key,
            'meta_value' => $value,
            'number'     => 1,
            'count_total'=> false,
            'fields'     => 'all_with_meta',
        ];
        $users = get_users($args);
        return $users ? $users[0] : null;
    }

    public function register_rest() {
        register_rest_route('roro/v1', '/auth/connection/(?P<provider>[a-z0-9_]+)', [
            [
                'methods'  => 'DELETE',
                'callback' => [$this, 'rest_unlink'],
                'permission_callback' => function() { return is_user_logged_in(); },
                'args' => [
                    '_wpnonce' => [
                        'required' => true,
                        'validate_callback' => function($param) { return wp_verify_nonce($param, 'roro_unlink'); }
                    ]
                ]
            ]
        ]);

        register_rest_route('roro/v1', '/auth/breeds', [
            'methods'  => 'GET',
            'callback' => [$this, 'rest_breeds'],
            'permission_callback' => '__return_true',
            'args' => [
                'q' => ['required'=>false],
                'limit' => ['required'=>false, 'default'=>10],
            ],
        ]);

        register_rest_route('roro/v1', '/auth/pets', [
            [
                'methods'  => 'GET',
                'callback' => [$this, 'rest_get_pets'],
                'permission_callback' => function() { return is_user_logged_in(); },
            ],
            [
                'methods'  => 'POST',
                'callback' => [$this, 'rest_save_pet'],
                'permission_callback' => function() { return is_user_logged_in(); },
                'args' => [
                    '_wpnonce' => ['required'=>true, 'validate_callback'=>function($n){ return wp_verify_nonce($n, 'roro_pet'); }],
                    'id'       => ['required'=>false],
                    'name'     => ['required'=>true],
                    'breed'    => ['required'=>false],
                    'age'      => ['required'=>false],
                    'primary'  => ['required'=>false],
                ],
            ],
        ]);

        register_rest_route('roro/v1', '/auth/pets/primary', [
            'methods'  => 'POST',
            'callback' => [$this, 'rest_set_primary_pet'],
            'permission_callback' => function() { return is_user_logged_in(); },
            'args' => [
                '_wpnonce' => ['required'=>true, 'validate_callback'=>function($n){ return wp_verify_nonce($n, 'roro_pet'); }],
                'id'       => ['required'=>true],
            ],
        ]);
    }

    public function rest_unlink(WP_REST_Request $req) {
        $provider = sanitize_key($req['provider']);
        $meta_key = self::META_LINK_PREFIX.$provider.'_sub';
        $uid = get_current_user_id();
        if (!$uid) { return new WP_Error('roro_not_logged_in', __('You must be logged in.', 'roro')); }
        if (!current_user_can('read', $uid)) { return new WP_Error('roro_forbidden', __('Permission denied.', 'roro')); }

        delete_user_meta($uid, $meta_key);
        return ['ok'=>true, 'message'=>__('Unlinked successfully.', 'roro')];
    }

    public function rest_breeds(WP_REST_Request $req) {
        $q = sanitize_text_field($req->get_param('q'));
        $limit = max(1, min(50, intval($req->get_param('limit'))));
        $terms = get_terms([
            'taxonomy' => self::TAX_BREED,
            'hide_empty' => false,
            'number' => 0,
        ]);
        $names = array_map(function($t){ return $t->name; }, is_array($terms) ? $terms : []);
        if ($q) {
            $names = array_values(array_filter($names, function($n) use ($q){
                return (mb_stripos($n, $q) !== false);
            }));
        }
        $names = array_slice($names, 0, $limit);
        return ['items'=>array_map(function($n){ return ['label'=>$n,'value'=>$n]; }, $names)];
    }

    public function rest_get_pets() {
        $uid = get_current_user_id();
        $pets = get_user_meta($uid, self::META_PETS, true);
        if (!is_array($pets)) { $pets = []; }
        $primary = get_user_meta($uid, self::META_PRIMARY_PET, true);
        return ['items'=>$pets, 'primary'=>$primary];
    }

    public function rest_save_pet(WP_REST_Request $req) {
        $uid = get_current_user_id();
        $pets = get_user_meta($uid, self::META_PETS, true);
        if (!is_array($pets)) { $pets = []; }
        $id    = sanitize_text_field($req->get_param('id')) ?: wp_generate_uuid4();
        $name  = sanitize_text_field($req->get_param('name'));
        if ($name === '') { return new WP_Error('roro_name_required', __('Name is required.', 'roro')); }
        $breed = sanitize_text_field($req->get_param('breed'));
        $age   = sanitize_text_field($req->get_param('age'));
        $primary = (bool)$req->get_param('primary');

        $found = false;
        foreach ($pets as &$p) {
            if ($p['id'] === $id) {
                $p['name'] = $name;
                $p['breed']= $breed;
                $p['age']  = $age;
                $found = true;
                break;
            }
        }
        if (!$found) {
            $pets[] = ['id'=>$id,'name'=>$name,'breed'=>$breed,'age'=>$age];
        }
        update_user_meta($uid, self::META_PETS, array_values($pets));
        if ($primary) {
            update_user_meta($uid, self::META_PRIMARY_PET, $id);
        }
        return ['ok'=>true,'id'=>$id];
    }

    public function rest_set_primary_pet(WP_REST_Request $req) {
        $uid = get_current_user_id();
        $id  = sanitize_text_field($req->get_param('id'));
        $pets = get_user_meta($uid, self::META_PETS, true);
        if (!is_array($pets)) { return new WP_Error('roro_no_pet', __('No pets found.', 'roro')); }
        $exists = false;
        foreach ($pets as $p) { if ($p['id'] === $id) { $exists = true; break; } }
        if (!$exists) { return new WP_Error('roro_pet_not_found', __('Pet not found.', 'roro')); }
        update_user_meta($uid, self::META_PRIMARY_PET, $id);
        return ['ok'=>true];
    }

    public function enqueue_assets() {
        $handle = 'roro-auth-profile';
        wp_register_script($handle, plugins_url('assets/js/roro-auth-profile.js', __FILE__), ['wp-i18n','wp-api-fetch'], '1.0.0', true);
        wp_localize_script($handle, 'roroAuth', [
            'rest'   => esc_url_raw( rest_url('roro/v1') ),
            'nonce'  => wp_create_nonce('wp_rest'),
            'unlinkNonce' => wp_create_nonce('roro_unlink'),
            'petNonce'    => wp_create_nonce('roro_pet'),
        ]);
        wp_set_script_translations($handle, 'roro', plugin_dir_path(__FILE__).'languages');
    }

    /** [roro_auth_login] – Google/LINEボタン */
    public function sc_login_buttons($atts = []) {
        $atts = shortcode_atts(['redirect'=>home_url('/')], $atts);
        $redirect = esc_url($atts['redirect']);
        $g = esc_url(add_query_arg(['roro_auth'=>'login','provider'=>'google','redirect'=>$redirect], home_url('/')));
        $l = esc_url(add_query_arg(['roro_auth'=>'login','provider'=>'line','redirect'=>$redirect], home_url('/')));
        ob_start(); ?>
        <div class="roro-auth-buttons" aria-live="polite">
            <a class="button button-primary" href="<?php echo $g; ?>">
                <?php echo esc_html(__('Sign in with Google', 'roro')); ?>
            </a>
            <a class="button" href="<?php echo $l; ?>">
                <?php echo esc_html(__('Sign in with LINE', 'roro')); ?>
            </a>
        </div>
        <?php
        return ob_get_clean();
    }

    /** [roro_profile] – プロフィール＋ペット編集 + 連携解除UI */
    public function sc_profile() {
        if (!is_user_logged_in()) {
            return '<p>'.esc_html(__('You must be logged in.', 'roro')).'</p>';
        }
        wp_enqueue_script('roro-auth-profile');
        $uid = get_current_user_id();

        $providers = [
            'google' => __('Google', 'roro'),
            'line'   => __('LINE', 'roro'),
        ];
        $links = [];
        foreach (array_keys($providers) as $p) {
            $meta_key = self::META_LINK_PREFIX.$p.'_sub';
            $links[$p] = (bool) get_user_meta($uid, $meta_key, true);
        }

        ob_start();
        ?>
        <section class="roro-profile" data-rest="<?php echo esc_attr( rest_url('roro/v1') ); ?>">
            <h2><?php echo esc_html(__('Profile', 'roro')); ?></h2>
            <form id="roro-profile-form" novalidate>
                <label>
                    <?php echo esc_html(__('Name', 'roro')); ?>
                    <input type="text" name="display_name" value="<?php echo esc_attr(wp_get_current_user()->display_name); ?>" required>
                </label>
                <label>
                    <?php echo esc_html(__('Email', 'roro')); ?>
                    <input type="email" name="user_email" value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>">
                </label>
                <button type="submit" class="button button-primary"><?php echo esc_html(__('Save', 'roro')); ?></button>
                <span class="roro-profile-status" aria-live="polite"></span>
            </form>

            <hr>
            <h3><?php echo esc_html(__('Linked accounts', 'roro')); ?></h3>
            <ul class="roro-linked-accounts">
                <?php foreach ($providers as $key=>$label): ?>
                    <li>
                        <span><?php echo esc_html($label); ?>:</span>
                        <?php if ($links[$key]): ?>
                            <button type="button"
                                    class="button roro-unlink"
                                    data-provider="<?php echo esc_attr($key); ?>"
                                    data-nonce="<?php echo esc_attr( wp_create_nonce('roro_unlink') ); ?>">
                                <?php echo esc_html(__('Unlink', 'roro')); ?>
                            </button>
                        <?php else: ?>
                            <a class="button"
                               href="<?php echo esc_url(add_query_arg(['roro_auth'=>'login','provider'=>$key,'redirect'=>home_url('/profile')], home_url('/'))); ?>">
                                <?php echo esc_html(__('Connect', 'roro')); ?>
                            </a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <hr>
            <h3><?php echo esc_html(__('Pets', 'roro')); ?></h3>
            <div id="roro-pets"></div>
            <button id="roro-add-pet" type="button" class="button"><?php echo esc_html(__('Add pet', 'roro')); ?></button>
            <div id="roro-pet-editor" hidden>
                <form id="roro-pet-form" novalidate>
                    <input type="hidden" name="id" value="">
                    <label>
                        <?php echo esc_html(__('Name', 'roro')); ?>
                        <input type="text" name="name" required>
                    </label>
                    <label>
                        <?php echo esc_html(__('Breed', 'roro')); ?>
                        <input type="text" name="breed" autocomplete="off" placeholder="<?php echo esc_attr(__('Search breed', 'roro')); ?>">
                        <ul id="roro-breed-suggest" role="listbox" hidden></ul>
                    </label>
                    <label>
                        <?php echo esc_html(__('Age', 'roro')); ?>
                        <input type="text" name="age" inputmode="numeric">
                    </label>
                    <label>
                        <input type="checkbox" name="primary">
                        <?php echo esc_html(__('Primary pet', 'roro')); ?>
                    </label>
                    <button type="submit" class="button button-primary"><?php echo esc_html(__('Save', 'roro')); ?></button>
                    <button id="roro-cancel-pet" type="button" class="button"><?php echo esc_html(__('Cancel', 'roro')); ?></button>
                    <span class="roro-pet-status" aria-live="polite"></span>
                    <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce('roro_pet') ); ?>">
                </form>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private function get_provider_conf($provider) {
        // 例： roro_auth_google = [client_id, client_secret, redirect_uri, scope]
        $opt = get_option('roro_auth_'.$provider);
        if (!$opt || !is_array($opt)) { return null; }
        // Ensure defaults
        $opt += [
            'scope' => ($provider==='google') ? 'openid email profile' : 'openid profile email',
        ];
        return $opt;
    }
}

RORO_Auth_Enhancements::instance();
