<?php
/**
 * ログインユーザー向けプロフィール UI（ペット編集・代表切替／犬種ドロップダウン）
 * i18n は PHP 側テキストは __()、JS 文言は wp-i18n を利用。
 */
if (!defined('ABSPATH')) { exit; }
$uid   = get_current_user_id();
$pets  = get_user_meta($uid, 'roro_pets', true);
$pets  = is_array($pets) ? $pets : [];
$repId = get_user_meta($uid, 'roro_rep_pet_id', true);
wp_enqueue_script('roro-auth-profile');
?>
<div id="roro-profile" class="roro-profile">
  <h2><?php echo esc_html__('My Pets', 'roro'); ?></h2>

  <form id="roro-pets-form" class="roro-pets-form" aria-describedby="roro-pets-help">
    <p id="roro-pets-help" class="screen-reader-text">
      <?php echo esc_html__('Use the form below to add or edit your pets. Required fields are marked.', 'roro'); ?>
    </p>

    <div class="roro-pets-list" data-rep="<?php echo esc_attr($repId); ?>">
      <?php foreach ($pets as $p): ?>
        <fieldset class="roro-pet" data-id="<?php echo esc_attr($p['id']); ?>">
          <legend>
            <?php echo esc_html__('Pet', 'roro'); ?>:
            <span class="roro-pet__name"><?php echo esc_html($p['name'] ?: __('(No name)', 'roro')); ?></span>
            <?php if ($repId === $p['id']): ?>
                <span class="roro-pill" aria-label="<?php echo esc_attr__('Representative pet', 'roro'); ?>">
                    <?php echo esc_html__('Representative', 'roro'); ?>
                </span>
            <?php endif; ?>
          </legend>
          <label>
            <?php echo esc_html__('Name', 'roro'); ?>
            <input name="name" value="<?php echo esc_attr($p['name'] ?? ''); ?>" required aria-required="true">
          </label>
          <label>
            <?php echo esc_html__('Breed', 'roro'); ?>
            <select name="breed" class="roro-breed-select" data-init="<?php echo esc_attr($p['breed'] ?? ''); ?>"></select>
          </label>
          <label>
            <?php echo esc_html__('Age', 'roro'); ?>
            <input type="number" name="age" min="0" value="<?php echo esc_attr((string)($p['age'] ?? 0)); ?>">
          </label>
          <label>
            <?php echo esc_html__('Notes', 'roro'); ?>
            <textarea name="notes"><?php echo esc_textarea($p['notes'] ?? ''); ?></textarea>
          </label>
          <div class="roro-pet__actions">
            <button type="button" class="button roro-make-rep" data-pet="<?php echo esc_attr($p['id']); ?>">
              <?php echo esc_html__('Make representative', 'roro'); ?>
            </button>
            <button type="button" class="button button-link-delete roro-delete-pet">
              <?php echo esc_html__('Delete', 'roro'); ?>
            </button>
          </div>
        </fieldset>
      <?php endforeach; ?>
    </div>

    <button type="button" class="button roro-add-pet">
      <?php echo esc_html__('Add pet', 'roro'); ?>
    </button>

    <div class="roro-actions">
      <button type="submit" class="button button-primary">
        <?php echo esc_html__('Save', 'roro'); ?>
      </button>
      <span class="roro-toast" role="status" aria-live="polite" aria-atomic="true"></span>
    </div>
  </form>

  <hr />
  <h2><?php echo esc_html__('Linked Accounts', 'roro'); ?></h2>
  <div id="roro-accounts" class="roro-accounts" data-endpoint="<?php echo esc_attr(rest_url('roro/v1/accounts')); ?>">
    <p><?php echo esc_html__('Loading...', 'roro'); ?></p>
  </div>
  <p class="roro-disconnect-hint">
    <?php
      printf(
          /* translators: %s: profile page url */
          esc_html__('You can disconnect a linked account from %s (admin).', 'roro'),
          '<code>' . esc_html(admin_url('options-general.php?page=roro-auth')) . '</code>'
      );
    ?>
  </p>
</div>
