<?php
/**
 * Plugin Name: Roro Auth
 * Description: Google/LINE の OAuth 2.0 / OIDC ログイン、プロフィール編集（ペット編集・代表切替）、犬種候補 REST を提供。
 * Version: 0.9.0
 * Author: Project Roro
 * Text Domain: roro
 */

if (!defined('ABSPATH')) { exit; }

define('RORO_AUTH_VERSION', '0.9.0');
define('RORO_AUTH_DIR', plugin_dir_path(__FILE__));
define('RORO_AUTH_URL', plugin_dir_url(__FILE__));

require_once RORO_AUTH_DIR . 'includes/class-roro-auth-state.php';
require_once RORO_AUTH_DIR . 'includes/class-roro-auth-service.php';
require_once RORO_AUTH_DIR . 'includes/class-roro-auth-admin.php';
require_once RORO_AUTH_DIR . 'includes/class-roro-auth-rest.php';
require_once RORO_AUTH_DIR . 'includes/class-roro-auth-user.php';

add_action('init', function () {
    // 翻訳ロード
    load_plugin_textdomain('roro', false, dirname(plugin_basename(__FILE__)) . '/languages');

    // ショートコード：プロフィール編集 UI（ペット編集・代表切替含む）
    add_shortcode('roro_profile', function ($atts = []) {
        if (!is_user_logged_in()) {
            return '<div class="roro-auth__login-hint">' .
                esc_html__('Please sign in to edit your profile.', 'roro') .
                '</div>';
        }
        ob_start();
        include RORO_AUTH_DIR . 'templates/profile-form.php';
        return ob_get_clean();
    });
});

/**
 * 認可開始（プロバイダ別）: /wp-admin/admin-post.php?action=roro_auth_redirect&provider=google|line
 */
add_action('admin_post_nopriv_roro_auth_redirect', function () {
    $provider = isset($_GET['provider']) ? sanitize_key($_GET['provider']) : '';
    $redirect_to = isset($_GET['redirect_to']) ? esc_url_raw($_GET['redirect_to']) : '';
    try {
        $auth = new Roro_Auth_Service();
        $auth_url = $auth->build_auth_url($provider, $redirect_to);
        wp_safe_redirect($auth_url);
        exit;
    } catch (Exception $e) {
        wp_die(esc_html(sprintf(
            /* translators: %s: error message */
            __('Authentication initialization failed: %s', 'roro'), $e->getMessage()
        )));
    }
});

/**
 * コールバック: /wp-admin/admin-post.php?action=roro_auth_callback&provider=google|line
 */
add_action('admin_post_nopriv_roro_auth_callback', function () {
    $provider = isset($_GET['provider']) ? sanitize_key($_GET['provider']) : '';
    try {
        $auth = new Roro_Auth_Service();
        $auth->handle_callback($provider);
        // 成功時はプロフィールへ
        wp_safe_redirect(home_url('/'));
        exit;
    } catch (Exception $e) {
        // ローカライズされた安全なメッセージ
        $msg = sprintf(
            /* translators: %s: provider name */
            __('Sign-in failed (%s). Please try again or use another method.', 'roro'),
            $provider ? esc_html(ucfirst($provider)) : esc_html__('Unknown', 'roro')
        );
        // 例外詳細はログへ
        error_log('[roro-auth] callback error: ' . $e->getMessage());
        wp_die(esc_html($msg));
    }
});

/**
 * 連携解除（ログイン中ユーザーのみ）
 * /wp-admin/admin-post.php?action=roro_auth_disconnect&provider=google|line&_wpnonce=...
 */
add_action('admin_post_roro_auth_disconnect', function () {
    if (!is_user_logged_in()) {
        wp_die(esc_html__('You must be signed in.', 'roro'));
    }
    check_admin_referer('roro_auth_disconnect');
    $provider = isset($_GET['provider']) ? sanitize_key($_GET['provider']) : '';
    if (!$provider) {
        wp_die(esc_html__('Invalid provider.', 'roro'));
    }
    $uid = get_current_user_id();
    $accounts = (array) get_user_meta($uid, 'roro_auth_accounts', true);
    unset($accounts[$provider]);
    update_user_meta($uid, 'roro_auth_accounts', $accounts);
    wp_safe_redirect(add_query_arg(['roro_notice' => 'disconnected'], wp_get_referer() ?: admin_url('profile.php')));
    exit;
});

// REST（犬種候補・ペット CRUD・連携一覧）
add_action('rest_api_init', function () {
    (new Roro_Auth_REST())->register_routes();
});

// プロフィール画面などで利用するスクリプト
add_action('wp_enqueue_scripts', function () {
    if (is_user_logged_in()) {
        wp_register_script(
            'roro-auth-profile',
            RORO_AUTH_URL . 'assets/js/profile.js',
            ['wp-i18n', 'wp-api-fetch'],
            RORO_AUTH_VERSION,
            true
        );
        wp_localize_script('roro-auth-profile', 'RORO_AUTH', [
            'rest' => [
                'breeds' => esc_url_raw(rest_url('roro/v1/breeds')),
                'pets'   => esc_url_raw(rest_url('roro/v1/pets')),
                'accounts' => esc_url_raw(rest_url('roro/v1/accounts')),
            ],
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
        wp_set_script_translations('roro-auth-profile', 'roro');
    }
});

register_activation_hook(__FILE__, function () {
    // 将来のマイグレーション用。現時点では noop。
});

register_deactivation_hook(__FILE__, function () {
    // 状態トークンなどは transient で TTL 管理しているため特段の後処理は不要。
});
