(function(){
    function $(sel, ctx){ return (ctx||document).querySelector(sel); }

    async function fetchToday(){
        const loading = $('.roro-rec-loading');
        const errorEl = $('.roro-rec-error');
        const content = $('.roro-rec-content');
        loading.style.display = 'block';
        errorEl.style.display = 'none';
        content.style.display = 'none';
        try {
            const res = await fetch(roroRecommend.restBase + '/recommend/today?lang=' + encodeURIComponent(roroRecommend.lang), {
                headers: {
                    'X-WP-Nonce': roroRecommend.nonce
                }
            });
            if(!res.ok){ throw new Error('HTTP ' + res.status); }
            const data = await res.json();
            // 描画
            $('.roro-rec-advice-text').textContent = data.advice.text || '';
            $('.roro-rec-spot-name').textContent = data.spot.name || '';
            $('.roro-rec-spot-address').textContent = data.spot.address || '';
            $('.roro-rec-spot-desc').textContent = data.spot.desc || '';

            // お気に入り登録のための属性
            const favBtn = $('.roro-rec-fav');
            favBtn.dataset.spotId = data.spot.id;

            loading.style.display = 'none';
            content.style.display = 'block';
        } catch(e){
            console.error(e);
            loading.style.display = 'none';
            errorEl.style.display = 'block';
        }
    }

    async function regen(){
        const btn = $('.roro-rec-refresh');
        btn.disabled = true;
        try{
            const res = await fetch(roroRecommend.restBase + '/recommend/regen', {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': roroRecommend.nonce,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ lang: roroRecommend.lang })
            });
            if(!res.ok){ throw new Error('HTTP ' + res.status); }
            await fetchToday();
        }catch(e){
            console.error(e);
            alert(roroRecommend.i18n.error_generic || 'Error');
        } finally {
            btn.disabled = false;
        }
    }

    function addFavorite(){
        const id = this.dataset.spotId;
        if(!id){ return; }
        // roro-favorites 連携（存在すればクエリベースで登録）
        // 仕様: ?roro_fav_add=spot&spot_id=123 などを roro-favorites が解釈する想定
        const url = new URL(window.location.href);
        url.searchParams.set('roro_fav_add', 'spot');
        url.searchParams.set('spot_id', id);
        window.location.href = url.toString();
    }

    document.addEventListener('click', function(e){
        if(e.target && e.target.classList.contains('roro-rec-refresh')){
            regen();
        }
        if(e.target && e.target.classList.contains('roro-rec-fav')){
            addFavorite.call(e.target);
        }
    });

    document.addEventListener('DOMContentLoaded', fetchToday);
})();