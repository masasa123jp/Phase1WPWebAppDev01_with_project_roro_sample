<?php
/**
 * Plugin Name: RORO Recommend (今日のおすすめ)
 * Description: 日次レコメンド（今日のおすすめ）を表示。DBの RORO_* マスタを利用し、ログ保存、REST API、ショートコードを提供します。
 * Version: 1.0.0
 * Author: Project RORO
 * Text Domain: roro-recommend
 * Domain Path: /lang
 *
 * 要件:
 * - RORO_ONE_POINT_ADVICE_MASTER / RORO_TRAVEL_SPOT_MASTER / RORO_CATEGORY_DATA_LINK_MASTER / RORO_RECOMMENDATION_LOG の基本スキーマ
 * - ログインユーザー毎に「本日分」を生成し RORO_RECOMMENDATION_LOG に保存（再生成APIあり）
 * - REST: GET /roro/v1/recommend/today, POST /roro/v1/recommend/regen
 * - ショートコード: [roro_recommend]
 * - 多言語: ja / en / zh / ko を内蔵辞書でサポート
 */

if (!defined('ABSPATH')) { exit; }

define('RORO_RECOMMEND_VERSION', '1.0.0');
define('RORO_RECOMMEND_PATH', plugin_dir_path(__FILE__));
define('RORO_RECOMMEND_URL',  plugin_dir_url(__FILE__));

// クラス読み込み
require_once RORO_RECOMMEND_PATH . 'includes/class-roro-recommend-service.php';
require_once RORO_RECOMMEND_PATH . 'includes/class-roro-recommend-rest.php';
require_once RORO_RECOMMEND_PATH . 'includes/class-roro-recommend-admin.php';

// 有効化フック: スキーマ作成＋初期データ（空の場合のみ）投入
register_activation_hook(__FILE__, function () {
    $svc = new RORO_Recommend_Service();
    $svc->install_schema();
    $svc->maybe_seed();
});

// 初期化: REST登録、ショートコード登録、スクリプト登録
add_action('init', function () {
    // ショートコード
    add_shortcode('roro_recommend', function ($atts = []) {
        $svc = new RORO_Recommend_Service();
        $lang = $svc->detect_lang();
        $messages = $svc->load_lang($lang);

        // フロントJS登録
        wp_register_script(
            'roro-recommend-js',
            RORO_RECOMMEND_URL . 'assets/js/recommend.js',
            ['wp-api-fetch'],
            RORO_RECOMMEND_VERSION,
            true
        );
        wp_localize_script('roro-recommend-js', 'roroRecommend', [
            'restBase' => esc_url_raw( rest_url('roro/v1') ),
            'nonce'    => wp_create_nonce('wp_rest'),
            'lang'     => esc_js($lang),
            'i18n'     => $messages,
        ]);
        wp_enqueue_script('roro-recommend-js');

        ob_start();
        $data = [
            'lang'     => $lang,
            'messages' => $messages,
        ];
        // テンプレート描画
        include RORO_RECOMMEND_PATH . 'templates/recommend-widget.php';
        return ob_get_clean();
    });
});

// REST ルート
add_action('rest_api_init', function () {
    $rest = new RORO_Recommend_REST();
    $rest->register_routes();
});

// 管理画面
add_action('admin_menu', function () {
    $admin = new RORO_Recommend_Admin();
    $admin->register_menu();
});
