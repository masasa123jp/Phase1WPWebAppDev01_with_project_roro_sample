<?php
/**
 * RESTエンドポイント: /roro/v1/recommend/*
 */
if (!defined('ABSPATH')) { exit; }

class RORO_Recommend_REST {

    public function register_routes() {
        register_rest_route('roro/v1', '/recommend/today', [
            'methods'  => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_today'],
            'permission_callback' => function () { return is_user_logged_in(); },
            'args' => [
                'lang' => [
                    'description' => '言語 (ja|en|zh|ko)',
                    'type' => 'string',
                    'required' => false,
                ],
            ],
        ]);

        register_rest_route('roro/v1', '/recommend/regen', [
            'methods'  => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'post_regen'],
            'permission_callback' => function () { return is_user_logged_in(); },
        ]);
    }

    public function get_today(WP_REST_Request $req) {
        $svc  = new RORO_Recommend_Service();
        $lang = $req->get_param('lang') ?: $svc->detect_lang();

        $payload = $svc->get_today(get_current_user_id(), $lang);
        if (is_wp_error($payload)) {
            return new WP_REST_Response(['error' => $payload->get_error_message()], 500);
        }
        return new WP_REST_Response($payload, 200);
    }

    public function post_regen(WP_REST_Request $req) {
        $svc  = new RORO_Recommend_Service();
        $lang = $req->get_param('lang') ?: $svc->detect_lang();

        $payload = $svc->regen_today(get_current_user_id(), $lang);
        if (is_wp_error($payload)) {
            return new WP_REST_Response(['error' => $payload->get_error_message()], 500);
        }
        return new WP_REST_Response($payload, 200);
    }
}
