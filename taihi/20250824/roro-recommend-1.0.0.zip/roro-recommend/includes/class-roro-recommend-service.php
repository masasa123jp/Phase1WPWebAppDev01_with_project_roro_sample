<?php
/**
 * レコメンドの業務ロジック層
 */
if (!defined('ABSPATH')) { exit; }

class RORO_Recommend_Service {

    /** @var wpdb */
    private $db;
    private $charset;

    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->charset = $wpdb->get_charset_collate();
    }

    /**
     * 使用するテーブル名を返す（WP接頭辞対応）
     */
    public function tables() {
        $p = $this->db->prefix;
        return [
            'advice' => "{$p}RORO_ONE_POINT_ADVICE_MASTER",
            'spot'   => "{$p}RORO_TRAVEL_SPOT_MASTER",
            'link'   => "{$p}RORO_CATEGORY_DATA_LINK_MASTER",
            'log'    => "{$p}RORO_RECOMMENDATION_LOG",
        ];
    }

    /**
     * サイト/ユーザーの言語設定から内部言語コードを推定
     */
    public function detect_lang() {
        // ユーザーメタまたはクッキー/GET優先、次にWPロケール
        $lang = '';
        if (isset($_GET['roro_lang'])) {
            $lang = sanitize_text_field($_GET['roro_lang']);
        } elseif (isset($_COOKIE['roro_lang'])) {
            $lang = sanitize_text_field($_COOKIE['roro_lang']);
        } else {
            $locale = determine_locale(); // WP 5.0+
            if (strpos($locale, 'ja') === 0) $lang = 'ja';
            elseif (strpos($locale, 'zh') === 0) $lang = 'zh';
            elseif (strpos($locale, 'ko') === 0) $lang = 'ko';
            else $lang = 'en';
        }
        if (!in_array($lang, ['ja','en','zh','ko'], true)) $lang = 'en';
        return $lang;
    }

    /**
     * 言語辞書を読み込み
     */
    public function load_lang($lang) {
        $file = RORO_RECOMMEND_PATH . "lang/{$lang}.php";
        if (file_exists($file)) {
            /** @noinspection PhpIncludeInspection */
            require $file;
            if (isset($roro_recommend_messages) && is_array($roro_recommend_messages)) {
                return $roro_recommend_messages;
            }
        }
        // フォールバック（英語）
        /** @noinspection PhpIncludeInspection */
        require RORO_RECOMMEND_PATH . "lang/en.php";
        return $roro_recommend_messages;
    }

    /**
     * スキーマ作成（存在しない場合のみ）
     * 注意: 実運用では DDL_20250822.sql をソース・オブ・トゥルースとし、
     * ここでは必要最小限の CREATE IF NOT EXISTS を実施します。
     */
    public function install_schema() {
        $t = $this->tables();
        // アドバイス
        $sql1 = "CREATE TABLE IF NOT EXISTS {$t['advice']} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            advice_key VARCHAR(64) NOT NULL UNIQUE,
            content_ja TEXT NOT NULL,
            content_en TEXT NOT NULL,
            content_zh TEXT NOT NULL,
            content_ko TEXT NOT NULL,
            category VARCHAR(64) NOT NULL DEFAULT 'general',
            active TINYINT(1) NOT NULL DEFAULT 1,
            weight INT NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) {$this->charset};";

        // スポット
        $sql2 = "CREATE TABLE IF NOT EXISTS {$t['spot']} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            spot_key VARCHAR(64) UNIQUE,
            name_ja TEXT,
            name_en TEXT,
            name_zh TEXT,
            name_ko TEXT,
            description_ja TEXT,
            description_en TEXT,
            description_zh TEXT,
            description_ko TEXT,
            category VARCHAR(64) NOT NULL DEFAULT 'pet_friendly',
            lat DECIMAL(10,7),
            lng DECIMAL(10,7),
            address_ja TEXT,
            address_en TEXT,
            address_zh TEXT,
            address_ko TEXT,
            prefecture_code VARCHAR(4) DEFAULT NULL,
            rating DECIMAL(3,2) DEFAULT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) {$this->charset};";

        // カテゴリリンク
        $sql3 = "CREATE TABLE IF NOT EXISTS {$t['link']} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            category VARCHAR(64) NOT NULL,
            advice_id BIGINT UNSIGNED NULL,
            spot_id BIGINT UNSIGNED NULL,
            KEY idx_cat (category),
            KEY idx_ad (advice_id),
            KEY idx_sp (spot_id)
        ) {$this->charset};";

        // ログ
        $sql4 = "CREATE TABLE IF NOT EXISTS {$t['log']} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            recommend_date DATE NOT NULL,
            advice_id BIGINT UNSIGNED NOT NULL,
            spot_id BIGINT UNSIGNED NOT NULL,
            lang VARCHAR(8) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_user_date (user_id, recommend_date),
            KEY idx_user (user_id)
        ) {$this->charset};";

        $this->db->query($sql1);
        $this->db->query($sql2);
        $this->db->query($sql3);
        $this->db->query($sql4);
    }

    /**
     * 初期データ投入（空テーブル時のみ）
     */
    public function maybe_seed() {
        $t = $this->tables();
        $advice_count = (int)$this->db->get_var("SELECT COUNT(*) FROM {$t['advice']}");
        $spot_count   = (int)$this->db->get_var("SELECT COUNT(*) FROM {$t['spot']}");

        if ($advice_count === 0) {
            $this->db->query($this->db->prepare(
                "INSERT INTO {$t['advice']} (advice_key, content_ja, content_en, content_zh, content_ko, category, active, weight)
                 VALUES 
                (%s,%s,%s,%s,%s,%s,1,3),
                (%s,%s,%s,%s,%s,%s,1,1),
                (%s,%s,%s,%s,%s,%s,1,2)",
                'hydration',
                '散歩前後の水分補給を忘れずに。夏場は特に意識！',
                'Make sure to hydrate before and after walks—especially in summer.',
                '散步前后请注意补充水分，夏季尤其重要。',
                '산책 전후 수분 보충을 잊지 마세요. 여름에는 특히 중요합니다.',
                'health',
                'cooling',
                'クールマットで快適に。留守番時は直射日光を避けて！',
                'Use a cooling mat and avoid direct sunlight when your pet is home alone.',
                '使用降温垫更舒适，独自在家时请避免直射阳光。',
                '쿨링 매트를 사용하고 혼자 있을 때는 직사광선을 피하세요.',
                'lifestyle',
                'manners',
                '公共の場ではリードを短めに。苦手な子への配慮も忘れずに。',
                'Keep the leash short in public and be mindful of pets that feel anxious.',
                '公共场合请缩短牵引绳，并照顾到害怕的宠物。',
                '공공장소에서는 리드를 짧게 하고, 불편한 반려동물을 배려하세요.',
                'manners'
            ));
        }

        if ($spot_count === 0) {
            $this->db->query($this->db->prepare(
                "INSERT INTO {$t['spot']} 
                (spot_key, name_ja, name_en, name_zh, name_ko, description_ja, description_en, description_zh, description_ko, category, lat, lng, address_ja, address_en, address_zh, address_ko, prefecture_code, rating, active)
                 VALUES
                (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%f,%f,%s,%s,%s,%s,%s,%f,1),
                (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%f,%f,%s,%s,%s,%s,%s,%f,1)",
                'hachioji-cafe',
                'はちおうじドッグカフェ',
                'Hachioji Dog Café',
                '八王子狗狗咖啡馆',
                '하치오지 도그 카페',
                '店内わんこOKのドッグカフェ。テラス席は日陰が多め。',
                'Dog-friendly café with shaded terrace seats.',
                '允许携带犬只的咖啡馆，露台座位有充足阴影。',
                '반려견 동반 가능한 카페, 그늘진 테라스 좌석이 있습니다.',
                'pet_cafe',
                35.6550000, 139.3380000,
                '東京都八王子市中心部',
                'Central Hachioji, Tokyo',
                '东京都八王子市中心',
                '도쿄도 하치오지 중심가',
                '13', 4.5,
                'tama-park',
                '多摩中央公園ドッグラン',
                'Tama Central Park Dog Run',
                '多摩中央公园狗狗乐园',
                '다마 중앙공원 도그런',
                '広々としたドッグラン。週末はイベントも開催。',
                'Spacious dog run with weekend events.',
                '宽敞的狗狗乐园，周末常有活动。',
                '넓은 도그런, 주말에는 이벤트도 열립니다.',
                'park',
                35.6255000, 139.4250000,
                '東京都多摩市落合',
                'Ochiai, Tama City, Tokyo',
                '东京都多摩市落合',
                '도쿄도 다마시 오치아이',
                '13', 4.2
            ));
        }
    }

    /**
     * 本日のレコメンドを取得（未生成なら生成）
     */
    public function get_today($user_id, $lang) {
        $t = $this->tables();
        // WPの現在時刻（日付）を使用（サイトTZ）
        $today = gmdate('Y-m-d', current_time('timestamp'));

        // 既存ログ
        $row = $this->db->get_row($this->db->prepare(
            "SELECT l.*, a.*, s.*,
                a.id as advice_id, s.id as spot_id
             FROM {$t['log']} l
             JOIN {$t['advice']} a ON a.id = l.advice_id
             JOIN {$t['spot']} s   ON s.id = l.spot_id
             WHERE l.user_id = %d AND l.recommend_date = %s AND l.lang = %s",
            $user_id, $today, $lang
        ), ARRAY_A);

        if ($row) {
            return $this->format_payload($row, $lang, $today);
        }

        // 新規生成
        $advice = $this->db->get_row(
            "SELECT * FROM {$t['advice']} WHERE active = 1 ORDER BY (RAND() * (2.0 / GREATEST(weight,1))) LIMIT 1",
            ARRAY_A
        );
        if (!$advice) {
            return new WP_Error('roro_no_advice', 'No advice master rows.');
        }

        // TODO: ユーザー属性/地域連動。現状は東京都(13)優先→無ければ全体からランダム
        $spot = $this->db->get_row($this->db->prepare(
            "SELECT * FROM {$t['spot']} 
             WHERE active = 1 AND (prefecture_code = %s OR prefecture_code IS NULL) 
             ORDER BY rating DESC, RAND() LIMIT 1",
            '13'
        ), ARRAY_A);
        if (!$spot) {
            $spot = $this->db->get_row("SELECT * FROM {$t['spot']} WHERE active = 1 ORDER BY rating DESC, RAND() LIMIT 1", ARRAY_A);
        }
        if (!$spot) {
            return new WP_Error('roro_no_spot', 'No spot master rows.');
        }

        // ログ保存（ユニーク制約あり）
        $ins = $this->db->insert($t['log'], [
            'user_id'        => $user_id,
            'recommend_date' => $today,
            'advice_id'      => intval($advice['id']),
            'spot_id'        => intval($spot['id']),
            'lang'           => $lang,
            'created_at'     => current_time('mysql')
        ], [
            '%d','%s','%d','%d','%s','%s'
        ]);

        if (!$ins) {
            // レース時の二重生成は既存を再読込
            $row = $this->db->get_row($this->db->prepare(
                "SELECT l.*, a.*, s.*,
                    a.id as advice_id, s.id as spot_id
                 FROM {$t['log']} l
                 JOIN {$t['advice']} a ON a.id = l.advice_id
                 JOIN {$t['spot']} s   ON s.id = l.spot_id
                 WHERE l.user_id = %d AND l.recommend_date = %s AND l.lang = %s",
                $user_id, $today, $lang
            ), ARRAY_A);
            if ($row) {
                return $this->format_payload($row, $lang, $today);
            }
            return new WP_Error('roro_log_fail', 'Failed to create today log.');
        }

        // 正常
        $row = array_merge($advice, $spot, [
            'advice_id' => $advice['id'],
            'spot_id'   => $spot['id']
        ]);
        return $this->format_payload($row, $lang, $today);
    }

    /**
     * 当日ログを削除し、再生成する
     */
    public function regen_today($user_id, $lang) {
        $t = $this->tables();
        $today = gmdate('Y-m-d', current_time('timestamp'));
        $this->db->delete($t['log'], [
            'user_id' => $user_id,
            'recommend_date' => $today,
            'lang' => $lang
        ], ['%d','%s','%s']);
        return $this->get_today($user_id, $lang);
    }

    /**
     * API応答用に共通整形
     */
    private function format_payload($row, $lang, $dateStr) {
        // 言語別フィールド抽出
        $advice_text = isset($row["content_{$lang}"]) ? $row["content_{$lang}"] : $row["content_en"];
        $spot_name   = isset($row["name_{$lang}"]) ? $row["name_{$lang}"] : $row["name_en"];
        $spot_addr   = isset($row["address_{$lang}"]) ? $row["address_{$lang}"] : $row["address_en"];
        $spot_desc   = isset($row["description_{$lang}"]) ? $row["description_{$lang}"] : $row["description_en"];

        return [
            'date'   => $dateStr,
            'lang'   => $lang,
            'advice' => [
                'id'   => intval($row['advice_id']),
                'text' => $advice_text,
                'category' => isset($row['category']) ? $row['category'] : 'general'
            ],
            'spot' => [
                'id'      => intval($row['spot_id']),
                'name'    => $spot_name,
                'lat'     => isset($row['lat']) ? floatval($row['lat']) : null,
                'lng'     => isset($row['lng']) ? floatval($row['lng']) : null,
                'address' => $spot_addr,
                'desc'    => $spot_desc,
                'category'=> isset($row['category']) ? $row['category'] : 'pet_friendly',
                'rating'  => isset($row['rating']) ? floatval($row['rating']) : null
            ]
        ];
    }
}
