<?php
/**
 * 管理画面（設定 + 初期データ投入）
 */
if (!defined('ABSPATH')) { exit; }

class RORO_Recommend_Admin {

    public function register_menu() {
        add_menu_page(
            'RORO Recommend',
            'RORO Recommend',
            'manage_options',
            'roro-recommend',
            [$this, 'render_page'],
            'dashicons-thumbs-up',
            56
        );
    }

    public function render_page() {
        if (!current_user_can('manage_options')) return;
        $svc = new RORO_Recommend_Service();
        $lang = $svc->detect_lang();
        $messages = $svc->load_lang($lang);

        // シード実行
        if (isset($_POST['roro_seed']) && check_admin_referer('roro_recommend_seed')) {
            $svc->maybe_seed();
            echo '<div class="updated"><p>' . esc_html($messages['seed_done']) . '</p></div>';
        }

        // テーブル件数
        $t = $svc->tables();
        global $wpdb;
        $c1 = intval($wpdb->get_var("SELECT COUNT(*) FROM {$t['advice']}"));
        $c2 = intval($wpdb->get_var("SELECT COUNT(*) FROM {$t['spot']}"));
        $c3 = intval($wpdb->get_var("SELECT COUNT(*) FROM {$t['log']}"));

        ?>
        <div class="wrap">
            <h1>RORO Recommend</h1>
            <p><?php echo esc_html($messages['admin_desc']); ?></p>

            <h2><?php echo esc_html($messages['admin_stats']); ?></h2>
            <ul>
                <li><?php echo esc_html($messages['stat_advice']); ?>: <?php echo intval($c1); ?></li>
                <li><?php echo esc_html($messages['stat_spot']); ?>: <?php echo intval($c2); ?></li>
                <li><?php echo esc_html($messages['stat_logs']); ?>: <?php echo intval($c3); ?></li>
            </ul>

            <form method="post">
                <?php wp_nonce_field('roro_recommend_seed'); ?>
                <p><button class="button button-primary" name="roro_seed" value="1"><?php echo esc_html($messages['btn_seed']); ?></button></p>
            </form>

            <p style="margin-top:2em;color:#666;">
                <?php echo esc_html($messages['admin_note']); ?>
            </p>
        </div>
        <?php
    }
}
