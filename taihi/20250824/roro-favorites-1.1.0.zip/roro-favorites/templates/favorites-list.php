<?php
/**
 * [roro_favorites] 用テンプレート
 */
if (!defined('ABSPATH')) { exit; }
$M = $data['messages'];
?>
<div class="roro-fav-container" data-lang="<?php echo esc_attr($data['lang']); ?>">
    <?php if (isset($_GET['roro_fav_status'])): ?>
        <?php
        $s = sanitize_text_field($_GET['roro_fav_status']);
        $msg = '';
        if ($s === 'added') $msg = $M['notice_added'];
        elseif ($s === 'duplicate') $msg = $M['notice_duplicate'];
        elseif ($s === 'removed') $msg = $M['notice_removed'];
        elseif ($s === 'error') $msg = $M['notice_error'];
        ?>
        <?php if ($msg): ?>
            <div class="notice notice-success is-dismissible"><p><?php echo esc_html($msg); ?></p></div>
        <?php endif; ?>
    <?php endif; ?>

    <h3 class="roro-fav-title"><?php echo esc_html($M['fav_title']); ?></h3>
    <div class="roro-fav-empty" style="display:none;"><?php echo esc_html($M['empty']); ?></div>
    <ul class="roro-fav-list"></ul>

    <style>
        .roro-fav-list { list-style: none; padding-left: 0; }
        .roro-fav-item { border:1px solid #e5e5e5; padding:8px 10px; border-radius:6px; margin:8px 0; display:flex; justify-content:space-between; gap:10px; align-items:center; }
        .roro-fav-meta { font-size: 0.92em; color:#555; }
        .roro-fav-actions { display:flex; gap:8px; }
        .roro-fav-type { font-size: 0.8em; color:#888; margin-right:6px; }
        .button-link { background:none; border:none; color:#0073aa; text-decoration:underline; cursor:pointer; padding:0; }
        .button-link:hover { color:#005177; }
    </style>
</div>
