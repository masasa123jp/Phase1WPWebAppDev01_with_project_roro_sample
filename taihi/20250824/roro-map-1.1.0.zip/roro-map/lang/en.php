<?php
$roro_events_messages = array(
  'search' => 'Search',
  'reset'  => 'Reset',
  'search_placeholder' => 'Keyword (title, description, address)',
  'use_my_location' => 'Use my location',
  'no_results' => 'No events match your filters. Try adjusting your criteria.',
  'geo_not_supported' => 'Geolocation is not supported.',
  'geo_fetching' => 'Fetching your location…',
  'geo_ok' => 'Location set.',
  'geo_denied' => 'Permission denied for geolocation.'
);
