<?php
$roro_fav_messages = array(
    'fav_title'      => '收藏列表',
    'empty'          => '还没有任何收藏。请从地图或推荐中添加。',
    'btn_remove'     => '删除',
    'notice_added'   => '已加入收藏。',
    'notice_duplicate' => '已在收藏中。',
    'notice_removed' => '已从收藏中移除。',
    'notice_error'   => '处理时发生错误。',
    'error_generic'  => '网络错误，请稍后再试。',

    // Admin
    'admin_desc'     => '查看用户收藏的统计信息。',
    'admin_stats'    => '统计信息',
    'stat_total'     => '收藏总数',
    'stat_spot'      => '地点收藏',
    'stat_event'     => '活动收藏',
    'admin_note'     => '生产环境请与 DDL_20250822.sql 的数据库结构保持一致。'
);
