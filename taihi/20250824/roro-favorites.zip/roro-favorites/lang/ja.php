<?php
$roro_fav_messages = array(
    'fav_title'      => 'お気に入り一覧',
    'empty'          => 'お気に入りはまだありません。地図やおすすめから追加してください。',
    'btn_remove'     => '削除',
    'notice_added'   => 'お気に入りに追加しました。',
    'notice_duplicate' => 'すでにお気に入りに登録済みです。',
    'notice_removed' => 'お気に入りを削除しました。',
    'notice_error'   => '処理中にエラーが発生しました。',
    'error_generic'  => '通信エラーが発生しました。時間をおいて再度お試しください。',

    // Admin
    'admin_desc'     => 'ユーザーのお気に入り登録状況を確認できます。',
    'admin_stats'    => '統計情報',
    'stat_total'     => '総お気に入り数',
    'stat_spot'      => 'スポットお気に入り',
    'stat_event'     => 'イベントお気に入り',
    'admin_note'     => '本番運用では DDL_20250822.sql のスキーマに合わせて整備してください。'
);
