<?php
if (!defined('ABSPATH')) exit;

class RORO_Auth_Admin {
    public static function register_menu() {
        add_options_page(
            'RORO Auth',
            'RORO Auth',
            'manage_options',
            'roro-auth',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        register_setting(RORO_AUTH_OPTION_KEY, RORO_AUTH_OPTION_KEY, [
            'type'              => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize'],
            'default'           => RORO_Auth_Utils::default_settings(),
        ]);
    }

    public static function sanitize($input) {
        $defaults = RORO_Auth_Utils::default_settings();
        $out = $defaults;

        $out['enabled_providers']['google'] = !empty($input['enabled_providers']['google']) ? 1 : 0;
        $out['enabled_providers']['line']   = !empty($input['enabled_providers']['line'])   ? 1 : 0;

        $out['google_client_id']     = isset($input['google_client_id']) ? sanitize_text_field($input['google_client_id']) : '';
        $out['google_client_secret'] = isset($input['google_client_secret']) ? sanitize_text_field($input['google_client_secret']) : '';
        $out['line_channel_id']      = isset($input['line_channel_id']) ? sanitize_text_field($input['line_channel_id']) : '';
        $out['line_channel_secret']  = isset($input['line_channel_secret']) ? sanitize_text_field($input['line_channel_secret']) : '';

        return $out;
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) return;
        $opt = RORO_Auth_Utils::get_settings();
        $redirect_google = RORO_Auth_Utils::redirect_uri('google');
        $redirect_line   = RORO_Auth_Utils::redirect_uri('line');
        ?>
        <div class="wrap">
            <h1>RORO Auth</h1>
            <p><?php echo esc_html(RORO_Auth_Utils::t('settings_description')); ?></p>
            <form method="post" action="options.php">
                <?php settings_fields(RORO_AUTH_OPTION_KEY); ?>
                <table class="form-table" role="presentation">
                    <tr><th colspan="2"><h2>Google</h2></th></tr>
                    <tr>
                        <th scope="row"><?php echo esc_html(RORO_Auth_Utils::t('enable_google')); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(RORO_AUTH_OPTION_KEY); ?>[enabled_providers][google]" value="1" <?php checked(1, $opt['enabled_providers']['google']); ?>> <?php echo esc_html(RORO_Auth_Utils::t('enable')); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Client ID</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(RORO_AUTH_OPTION_KEY); ?>[google_client_id]" value="<?php echo esc_attr($opt['google_client_id']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Client Secret</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(RORO_AUTH_OPTION_KEY); ?>[google_client_secret]" value="<?php echo esc_attr($opt['google_client_secret']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Redirect URI</th>
                        <td><code><?php echo esc_html($redirect_google); ?></code></td>
                    </tr>

                    <tr><th colspan="2"><h2>LINE</h2></th></tr>
                    <tr>
                        <th scope="row"><?php echo esc_html(RORO_Auth_Utils::t('enable_line')); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(RORO_AUTH_OPTION_KEY); ?>[enabled_providers][line]" value="1" <?php checked(1, $opt['enabled_providers']['line']); ?>> <?php echo esc_html(RORO_Auth_Utils::t('enable')); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Channel ID</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(RORO_AUTH_OPTION_KEY); ?>[line_channel_id]" value="<?php echo esc_attr($opt['line_channel_id']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Channel Secret</th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(RORO_AUTH_OPTION_KEY); ?>[line_channel_secret]" value="<?php echo esc_attr($opt['line_channel_secret']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Redirect URI</th>
                        <td><code><?php echo esc_html($redirect_line); ?></code></td>
                    </tr>
                </table>
                <?php submit_button(RORO_Auth_Utils::t('save_settings')); ?>
            </form>
            <p><small><?php echo esc_html(RORO_Auth_Utils::t('settings_note')); ?></small></p>
        </div>
        <?php
    }
}
