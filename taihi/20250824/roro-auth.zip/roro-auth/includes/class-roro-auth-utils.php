<?php
if (!defined('ABSPATH')) exit;

class RORO_Auth_Utils {
    private static $messages = [];
    private static $lang = 'ja';

    public static function default_settings() {
        return [
            'enabled_providers' => [
                'google' => 0,
                'line'   => 0,
            ],
            'google_client_id'     => '',
            'google_client_secret' => '',
            'line_channel_id'      => '',
            'line_channel_secret'  => '',
        ];
    }

    public static function get_settings() {
        $saved = get_option(RORO_AUTH_OPTION_KEY);
        if (!is_array($saved)) $saved = [];
        return array_merge(self::default_settings(), $saved);
    }

    /** 現在の言語コード（ja|en|zh|ko） */
    public static function current_lang() {
        if (isset($_GET['roro_lang'])) { // デバッグや強制切替用
            $code = sanitize_key($_GET['roro_lang']);
        } else {
            $locale = get_locale();
            if (str_starts_with($locale, 'ja')) $code = 'ja';
            elseif (str_starts_with($locale, 'ko')) $code = 'ko';
            elseif (str_starts_with($locale, 'zh')) $code = 'zh';
            else $code = 'en';
        }
        self::$lang = $code;
        return $code;
    }

    /** 言語メッセージ読込 */
    public static function load_messages() {
        $lang = self::current_lang();
        $files = [
            'ja' => RORO_AUTH_PLUGIN_DIR . 'lang/ja.php',
            'en' => RORO_AUTH_PLUGIN_DIR . 'lang/en.php',
            'zh' => RORO_AUTH_PLUGIN_DIR . 'lang/zh.php',
            'ko' => RORO_AUTH_PLUGIN_DIR . 'lang/ko.php',
        ];
        $file = isset($files[$lang]) ? $files[$lang] : $files['en'];
        $roro_auth_messages = [];
        if (file_exists($file)) include $file;
        self::$messages = is_array($roro_auth_messages) ? $roro_auth_messages : [];
    }

    public static function messages() { return self::$messages; }
    public static function messages_js() { return self::$messages; }

    public static function t($key) {
        $msg = self::$messages[$key] ?? $key;
        return $msg;
    }

    /** フラッシュ（セッション非依存で一時Cookie使用） */
    public static function flash($type, $message) {
        $payload = ['type' => $type, 'message' => $message, 'ts' => time()];
        setcookie('roro_auth_flash', wp_json_encode($payload), time()+60, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true);
    }
    public static function consume_flash() {
        if (!empty($_COOKIE['roro_auth_flash'])) {
            $json = stripslashes($_COOKIE['roro_auth_flash']);
            setcookie('roro_auth_flash', '', time()-3600, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true);
            $data = json_decode($json, true);
            if (is_array($data)) return $data;
        }
        return null;
    }

    /** state生成・保存（transient） */
    public static function generate_state($provider, $redirect_to) {
        $state = wp_generate_password(24, false, false);
        set_transient('roro_auth_state_' . $provider . '_' . $state, ['redirect_to' => $redirect_to], 15 * MINUTE_IN_SECONDS);
        return $state;
    }
    public static function consume_state($provider, $state) {
        if (!$state) return false;
        $key = 'roro_auth_state_' . $provider . '_' . $state;
        $val = get_transient($key);
        delete_transient($key);
        return $val ?: false;
    }

    /** Google リダイレクトURI */
    public static function redirect_uri($provider) {
        return add_query_arg([
            'roro_auth' => 'callback',
            'provider'  => $provider,
        ], home_url('/'));
    }

    /** JWT デコード（署名検証は別途。ここではpayload抽出に限定） */
    public static function jwt_decode_payload($jwt) {
        $parts = explode('.', $jwt);
        if (count($parts) < 2) return null;
        $payload = $parts[1];
        $payload = strtr($payload, '-_', '+/');
        $payload = base64_decode($payload . str_repeat('=', 3 - (3 + strlen($payload)) % 4));
        $json = json_decode($payload, true);
        return is_array($json) ? $json : null;
    }

    /** DBテーブル存在判定 */
    public static function table_exists($table) {
        global $wpdb;
        $like = $wpdb->esc_like($table);
        $found = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $like));
        return strtolower($found) === strtolower($table);
    }

    /** テーブルのカラム一覧取得 */
    public static function get_table_columns($table) {
        global $wpdb;
        $cols = [];
        $rows = $wpdb->get_results("DESCRIBE {$table}", ARRAY_A);
        if ($rows) foreach ($rows as $r) $cols[] = $r['Field'];
        return $cols;
    }

    /**
     * （任意）RORO_CUSTOMER / RORO_USER_LINK_WP へ安全に登録（存在するカラムのみ埋める）
     */
    public static function ensure_customer_link($wp_user_id, $email, $name) {
        global $wpdb;
        $prefix = $wpdb->prefix;
        $customer_table = $prefix . 'RORO_CUSTOMER';
        $link_table     = $prefix . 'RORO_USER_LINK_WP';

        // 既存メタでcustomer_idがあればスキップ
        $existing = get_user_meta($wp_user_id, 'roro_customer_id', true);
        if ($existing) return true;

        // RORO_CUSTOMER 存在チェック
        if (self::table_exists($customer_table)) {
            $cols = self::get_table_columns($customer_table);
            $data = [];
            $fmt  = [];

            // 汎用的に埋められそうな列名の候補
            $map = [
                'wp_user_id'   => $wp_user_id,
                'email'        => $email,
                'full_name'    => $name ?: '',
                'display_name' => $name ?: '',
                'lang'         => self::current_lang(),
                'created_at'   => current_time('mysql'),
                'updated_at'   => current_time('mysql'),
                'status'       => 'active',
            ];
            foreach ($map as $k => $v) {
                if (in_array($k, $cols, true)) {
                    $data[$k] = $v;
                    $fmt[] = is_int($v) ? '%d' : '%s';
                }
            }

            // 一意性: email がキーなら重複回避
            $customer_id = 0;
            if (!empty($data)) {
                // まず既存検索（email or wp_user_id がカラムにあれば）
                if (in_array('email', $cols, true) && $email) {
                    $customer_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$customer_table} WHERE email = %s LIMIT 1", $email));
                }
                if (!$customer_id && in_array('wp_user_id', $cols, true)) {
                    $customer_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$customer_table} WHERE wp_user_id = %d LIMIT 1", $wp_user_id));
                }
                if (!$customer_id) {
                    $ins = $wpdb->insert($customer_table, $data, $fmt);
                    if ($ins !== false) $customer_id = (int)$wpdb->insert_id;
                }
            }

            if ($customer_id) {
                update_user_meta($wp_user_id, 'roro_customer_id', $customer_id);

                // RORO_USER_LINK_WP 存在時リンク
                if (self::table_exists($link_table)) {
                    $link_cols = self::get_table_columns($link_table);
                    $lmap = [
                        'wp_user_id'   => $wp_user_id,
                        'customer_id'  => $customer_id,
                        'linked_at'    => current_time('mysql'),
                        'status'       => 'linked',
                    ];
                    $ldata = []; $lfmt = [];
                    foreach ($lmap as $k => $v) {
                        if (in_array($k, $link_cols, true)) {
                            $ldata[$k] = $v;
                            $lfmt[] = is_int($v) ? '%d' : '%s';
                        }
                    }
                    if (!empty($ldata)) {
                        // 重複チェック
                        $exists = true;
                        if (in_array('wp_user_id', $link_cols, true) && in_array('customer_id', $link_cols, true)) {
                            $exists = (bool)$wpdb->get_var($wpdb->prepare(
                                "SELECT 1 FROM {$link_table} WHERE wp_user_id=%d AND customer_id=%d LIMIT 1",
                                $wp_user_id, $customer_id
                            ));
                        } else {
                            $exists = false;
                        }
                        if (!$exists) $wpdb->insert($link_table, $ldata, $lfmt);
                    }
                }
            }
        }
        return true;
    }
}
