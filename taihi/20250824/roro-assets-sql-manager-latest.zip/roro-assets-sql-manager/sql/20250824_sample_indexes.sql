-- Sample index creation (adjust table prefix as needed)
CREATE INDEX IF NOT EXISTS idx_roro_events_start_time ON RORO_EVENTS_MASTER (start_time);
CREATE INDEX IF NOT EXISTS idx_roro_events_category ON RORO_EVENTS_MASTER (category);
