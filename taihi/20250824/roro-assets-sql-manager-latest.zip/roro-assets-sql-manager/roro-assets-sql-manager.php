<?php
/**
 * Plugin Name: RORO Assets SQL Manager
 * Description: プラグイン同梱の SQL を管理画面から実行。ファイル選択／貼り付け、トランザクション実行・ロールバック、実行ログ出力に対応。
 * Version: 1.0.1
 * Author: Project RORO
 * Text Domain: roro-assets-sql-manager
 * Domain Path: /lang
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_SQLM_VERSION', '1.0.1');
define('RORO_SQLM_PATH', plugin_dir_path(__FILE__));
define('RORO_SQLM_URL',  plugin_dir_url(__FILE__));

add_action('plugins_loaded', function(){
    load_plugin_textdomain('roro-assets-sql-manager', false, dirname(plugin_basename(__FILE__)) . '/lang');
});

add_action('admin_menu', function(){
    add_management_page('RORO SQL Manager', 'RORO SQL Manager', 'manage_options', 'roro-sql-manager', 'roro_sqlm_page');
});

function roro_sqlm_split_statements($sql){
    // 非常に単純なセミコロンスプリッタ（DELIMITERは未対応）
    $stmts = array_filter(array_map('trim', preg_split('/;\s*\n|;\s*$/m', $sql)));
    return $stmts;
}

function roro_sqlm_page(){
    if (!current_user_can('manage_options')) return;
    $M = array(
        'title'   => 'RORO SQL Manager',
        'run'     => '実行',
        'dry'     => 'ドライラン(構文のみ)',
        'sqlfile' => 'SQLファイル',
        'paste'   => 'SQL貼り付け',
        'result'  => '結果',
        'ok'      => '成功',
        'ng'      => '失敗',
        'confirm' => '本当に実行しますか？バックアップは取得済みですか？'
    );
    $notice = '';
    $files = glob(RORO_SQLM_PATH . 'sql/*.sql') ?: [];

    if (isset($_POST['roro_sqlm_exec']) && check_admin_referer('roro_sqlm')){
        global $wpdb;
        $dry  = !empty($_POST['dry_run']);
        $src  = sanitize_text_field($_POST['src'] ?? 'file'); // file|paste
        $sql  = '';

        if ($src === 'file' && !empty($_POST['sql_file'])) {
            $path = RORO_SQLM_PATH . 'sql/' . basename($_POST['sql_file']);
            if (file_exists($path)) $sql = file_get_contents($path);
        } else {
            $sql = wp_unslash($_POST['sql_paste'] ?? '');
        }

        if ($sql){
            $stmts = roro_sqlm_split_statements($sql);
            $results = [];
            if (!$dry) $wpdb->query('START TRANSACTION');
            try{
                foreach($stmts as $s){
                    if (!$s) continue;
                    if ($dry){
                        $results[] = ['sql'=>$s, 'res'=>'DRY'];
                        continue;
                    }
                    $r = $wpdb->query($s);
                    if ($r === false) { throw new Exception($wpdb->last_error); }
                    $results[] = ['sql'=>$s, 'res'=>$r];
                }
                if (!$dry) $wpdb->query('COMMIT');
                $notice = '<div class="updated notice"><p>SQLを実行しました。</p></div>';
            }catch(Exception $e){
                if (!$dry) $wpdb->query('ROLLBACK');
                $notice = '<div class="error notice"><p>エラー: ' . esc_html($e->getMessage()) . '</p></div>';
            }
        } else {
            $notice = '<div class="error notice"><p>SQLが空です。</p></div>';
        }
    }

    echo '<div class="wrap"><h1>'.esc_html($M['title']).'</h1>';
    echo $notice;
    echo '<form method="post" onsubmit="return confirm(''.esc_js($M['confirm']).'');">';
    wp_nonce_field('roro_sqlm');
    echo '<h2>'.$M['sqlfile'].'</h2>';
    echo '<select name="sql_file"><option value="">-- select --</option>';
    foreach($files as $f){
        echo '<option value="'.esc_attr(basename($f)).'">'.esc_html(basename($f)).'</option>';
    }
    echo '</select>';

    echo '<h2>'.$M['paste'].'</h2>';
    echo '<textarea name="sql_paste" rows="10" style="width:100%;"></textarea>';

    echo '<p><label><input type="radio" name="src" value="file" checked/> File</label> ';
    echo '<label><input type="radio" name="src" value="paste" /> Paste</label></p>';

    echo '<p><label><input type="checkbox" name="dry_run" value="1" /> '.$M['dry'].'</label></p>';

    echo '<p><button type="submit" name="roro_sqlm_exec" class="button button-primary">'.$M['run'].'</button></p>';
    echo '</form>';

    echo '</div>';
}
