(function(){
  function $(id){ return document.getElementById(id); }
  var log = $('roro-chat-log');
  var input = $('roro-chat-text');
  var btn = $('roro-chat-send');
  var conversation_id = 0;
  function addBubble(role, text){
    var div = document.createElement('div');
    div.className = 'roro-bubble ' + role;
    div.textContent = text;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
  }
  function send(){
    var msg = input.value.trim();
    if (!msg) return;
    addBubble('user', msg);
    input.value = '';
    var typing = document.createElement('div'); typing.className='roro-typing'; typing.textContent = RORO_CHAT_CFG.i18n.typing;
    log.appendChild(typing); log.scrollTop = log.scrollHeight;
    fetch(RORO_CHAT_CFG.restBase + 'chat', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-WP-Nonce': RORO_CHAT_CFG.nonce},
      body: JSON.stringify({message: msg, conversation_id: conversation_id})
    }).then(function(r){ return r.json(); }).then(function(j){
      typing.remove();
      conversation_id = j.conversation_id || conversation_id;
      addBubble('bot', j.reply || RORO_CHAT_CFG.i18n.empty_reply);
    }).catch(function(e){
      typing.remove();
      addBubble('bot', RORO_CHAT_CFG.i18n.error);
      console.error(e);
    });
  }
  if (btn) btn.addEventListener('click', send);
  if (input) input.addEventListener('keydown', function(e){ if (e.key === 'Enter'){ send(); }});
})();