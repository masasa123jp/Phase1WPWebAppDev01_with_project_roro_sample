<?php
$roro_chat_messages = array(
  'chat_title' => '聊天助理',
  'provider'   => '服务提供方',
  'placeholder'=> '请输入你的问题…',
  'send'       => '发送',
  'typing'     => '正在输入…',
  'saved'      => '设置已保存。',
  'save'       => '保存',
  'error'      => '发生错误，请稍后再试。',
  'empty_reply'=> '暂无回复。'
);
