<?php
$roro_adv_messages = array(
  'advice'   => 'ワンポイントアドバイス',
  'no_advice'=> 'アドバイスが見つかりませんでした。'
);
