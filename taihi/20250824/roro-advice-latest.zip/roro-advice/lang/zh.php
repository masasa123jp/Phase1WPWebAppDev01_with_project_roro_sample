<?php
$roro_adv_messages = array(
  'advice'   => '小贴士',
  'no_advice'=> '暂无建议。'
);
