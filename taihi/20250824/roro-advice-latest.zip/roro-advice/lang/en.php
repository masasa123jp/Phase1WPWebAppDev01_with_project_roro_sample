<?php
$roro_adv_messages = array(
  'advice'   => 'One-point Advice',
  'no_advice'=> 'No advice available.'
);
