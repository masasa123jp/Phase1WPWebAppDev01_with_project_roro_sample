=== Roro Chatbot ===
Contributors: Project Roro
Requires at least: 6.2
Tested up to: 6.6
Stable tag: 1.6.0-rc2
Requires PHP: 7.4
License: GPLv2 or later

最小のチャットボット埋め込み用プラグインです。ショートコード [roro_chatbot] を使ってページに表示できます。
