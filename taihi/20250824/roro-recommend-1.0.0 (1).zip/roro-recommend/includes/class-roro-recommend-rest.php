<?php
if (!defined('ABSPATH')) { exit; }

class RORO_Recommend_REST {
    public function register_routes(){
        register_rest_route('roro/v1', '/recommend/today', [
            'methods'  => WP_REST_Server::READABLE,
            'callback' => [$this, 'today'],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ]);
    }
    public function today(WP_REST_Request $req){
        $svc = new RORO_Recommend_Service();
        $user_id = get_current_user_id();
        $rec = $svc->recommend_today($user_id);
        return new WP_REST_Response(['recommendation'=>$rec], 200);
    }
}
