<?php
if (!defined('ABSPATH')) { exit; }

class RORO_Recommend_Service {

    public function detect_lang() {
        if (isset($_GET['roro_lang'])) {
            $l = sanitize_text_field($_GET['roro_lang']);
        } elseif (isset($_COOKIE['roro_lang'])) {
            $l = sanitize_text_field($_COOKIE['roro_lang']);
        } else {
            $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
            if (strpos($locale, 'ja') === 0) $l = 'ja';
            elseif (strpos($locale, 'zh') === 0) $l = 'zh';
            elseif (strpos($locale, 'ko') === 0) $l = 'ko';
            else $l = 'en';
        }
        return in_array($l, ['ja','en','zh','ko'], true) ? $l : 'en';
    }

    public function load_lang($lang) {
        $file = RORO_REC_PATH . "lang/{$lang}.php";
        if (file_exists($file)) { require $file; if(isset($roro_rec_messages)) return $roro_rec_messages; }
        require RORO_REC_PATH . "lang/en.php";
        return $roro_rec_messages;
    }

    /**
     * 今日のおすすめを生成
     * - 1ユーザー1日1レコードに固着（同じ日付で同じ候補を返す）
     * - 既にお気に入りのスポットは除外し、近隣（任意）を優先
     */
    public function recommend_today($user_id){
        global $wpdb;
        $log_tbl   = $wpdb->prefix . 'RORO_RECOMMENDATION_LOG';
        $spot_tbl  = $wpdb->prefix . 'RORO_TRAVEL_SPOT_MASTER';
        $ad_tbl    = $wpdb->prefix . 'RORO_ONE_POINT_ADVICE_MASTER';
        $fav_tbl   = $wpdb->prefix . 'RORO_MAP_FAVORITE';

        $today = current_time('Y-m-d');

        // 既存ログ（同日）があれば取得して返す
        $row = $wpdb->get_row($wpdb->prepare("SELECT spot_id, advice_id FROM {$log_tbl} WHERE user_id=%d AND rec_date=%s LIMIT 1", $user_id, $today), ARRAY_A);
        if ($row){
            $spot = $this->get_spot($row['spot_id']);
            $ad   = $this->get_advice($row['advice_id']);
            if ($spot && $ad) return ['spot'=>$spot, 'advice'=>$ad];
        }

        // 除外: 既にお気に入りに入っているスポット
        $fav_spot_ids = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT ref_id FROM {$fav_tbl} WHERE user_id=%d AND ref_type=%s", $user_id, 'event_spot'));
        $fav_spot_ids = array_map('intval', $fav_spot_ids ?: []);
        $excl_sql = '';
        if (!empty($fav_spot_ids)) {
            $in = implode(',', array_map('intval', $fav_spot_ids));
            $excl_sql = " AND s.id NOT IN ({$in}) ";
        }

        // 候補スポット（簡易スコア: rating DESC, popular DESC, id DESC が存在すれば使用／なければランダム）
        $sql = "SELECT s.id FROM {$spot_tbl} s WHERE 1=1 {$excl_sql} ORDER BY COALESCE(s.rating,0) DESC, COALESCE(s.popular,0) DESC, s.id DESC LIMIT 100";
        $candidates = $wpdb->get_col($sql);
        if (!$candidates) {
            // フォールバック: 何でもOK
            $candidates = $wpdb->get_col("SELECT s.id FROM {$spot_tbl} s ORDER BY s.id DESC LIMIT 100");
        }
        if (!$candidates) return null;

        // ランダムに1件
        $spot_id = intval($candidates[array_rand($candidates)]);

        // アドバイスはランダム1件
        $advice_id = intval($wpdb->get_var("SELECT id FROM {$ad_tbl} ORDER BY RAND() LIMIT 1"));

        // ログ保存（同一日で重複しないよう UNIQUE(user_id, rec_date) 前提）
        $wpdb->replace($log_tbl, [
            'user_id'  => intval($user_id),
            'rec_date' => $today,
            'spot_id'  => $spot_id,
            'advice_id'=> $advice_id,
            'created_at'=> current_time('mysql'),
        ]);

        return ['spot'=>$this->get_spot($spot_id), 'advice'=>$this->get_advice($advice_id)];
    }

    private function get_spot($id){
        global $wpdb;
        $tbl = $wpdb->prefix . 'RORO_TRAVEL_SPOT_MASTER';
        $r = $wpdb->get_row($wpdb->prepare("SELECT id, name, address, latitude, longitude FROM {$tbl} WHERE id=%d", $id), ARRAY_A);
        return $r ? ['id'=>intval($r['id']),'name'=>$r['name'],'address'=>$r['address'],'latitude'=>floatval($r['latitude']),'longitude'=>floatval($r['longitude'])] : null;
    }
    private function get_advice($id){
        global $wpdb;
        $tbl = $wpdb->prefix . 'RORO_ONE_POINT_ADVICE_MASTER';
        $r = $wpdb->get_row($wpdb->prepare("SELECT id, advice_text FROM {$tbl} WHERE id=%d", $id), ARRAY_A);
        return $r ? ['id'=>intval($r['id']),'text'=>$r['advice_text']] : null;
    }
}
