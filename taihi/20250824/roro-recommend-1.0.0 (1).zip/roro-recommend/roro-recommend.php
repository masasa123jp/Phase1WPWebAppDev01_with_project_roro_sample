<?php
/**
 * Plugin Name: RORO Recommend
 * Description: ユーザーごとの「今日のおすすめ」を生成し表示します（スポット＋ワンポイントアドバイス）。結果はログに保存します。
 * Version: 1.0.0
 * Author: Project RORO
 * Text Domain: roro-recommend
 * Domain Path: /lang
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_REC_VERSION', '1.0.0');
define('RORO_REC_PATH', plugin_dir_path(__FILE__));
define('RORO_REC_URL',  plugin_dir_url(__FILE__));

require_once RORO_REC_PATH . 'includes/class-roro-recommend-service.php';
require_once RORO_REC_PATH . 'includes/class-roro-recommend-rest.php';

add_action('plugins_loaded', function(){
    load_plugin_textdomain('roro-recommend', false, dirname(plugin_basename(__FILE__)) . '/lang');
});

// ショートコード: [roro_recommend_today]
add_shortcode('roro_recommend_today', function($atts){
    $svc = new RORO_Recommend_Service();
    $lang = $svc->detect_lang();
    $M    = $svc->load_lang($lang);
    $user_id = get_current_user_id();

    $rec = $svc->recommend_today($user_id);
    ob_start();
    ?>
    <div class="roro-rec">
      <h3><?php echo esc_html($M['today_recommend']); ?></h3>
      <?php if (!$rec): ?>
        <div class="roro-rec-empty"><?php echo esc_html($M['no_recommend']); ?></div>
      <?php else: ?>
        <div class="roro-rec-spot">
          <div class="roro-rec-spot-title"><?php echo esc_html($rec['spot']['name']); ?></div>
          <?php if(!empty($rec['spot']['address'])): ?>
            <div class="roro-rec-spot-addr"><?php echo esc_html($rec['spot']['address']); ?></div>
          <?php endif; ?>
        </div>
        <div class="roro-rec-advice">
          <strong><?php echo esc_html($M['one_point']); ?>:</strong>
          <span><?php echo esc_html($rec['advice']['text']); ?></span>
        </div>
      <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
});

add_action('rest_api_init', function(){
    (new RORO_Recommend_REST())->register_routes();
});
