<?php
$roro_rec_messages = array(
  'today_recommend' => 'Today's Recommendation',
  'no_recommend'    => 'No recommendation yet.',
  'one_point'       => 'One-point Advice'
);
