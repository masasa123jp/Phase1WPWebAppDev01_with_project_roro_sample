<?php
$roro_rec_messages = array(
  'today_recommend' => '오늘의 추천',
  'no_recommend'    => '오늘의 추천이 없습니다.',
  'one_point'       => '한마디 팁'
);
