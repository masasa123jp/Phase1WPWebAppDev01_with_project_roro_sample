<?php
$roro_rec_messages = array(
  'today_recommend' => '今日推荐',
  'no_recommend'    => '今日暂无推荐。',
  'one_point'       => '小贴士'
);
