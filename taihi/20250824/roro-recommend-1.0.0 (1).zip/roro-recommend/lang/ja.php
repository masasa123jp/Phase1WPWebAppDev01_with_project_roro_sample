<?php
$roro_rec_messages = array(
  'today_recommend' => '今日のおすすめ',
  'no_recommend'    => '本日のおすすめはまだありません。',
  'one_point'       => 'ワンポイントアドバイス'
);
