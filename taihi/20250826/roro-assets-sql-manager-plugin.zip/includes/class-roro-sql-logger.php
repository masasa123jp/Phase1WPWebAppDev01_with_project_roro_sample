<?php
/**
 * SQL Logger column translations for Roro Assets.
 *
 * This class hooks into the roro SQL manager plugin to translate column
 * labels for SQL logging. It relies on the roro-assets-sql-manager text
 * domain and translation files to render the proper language. If other
 * plugins provide the SQL manager functionality, this class will simply
 * override the column labels via filter hooks.
 *
 * @package RoroAssetsSQLManager
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Roro_SQL_Logger
 */
class Roro_SQL_Logger {

    /**
     * Initialize the logger hooks.
     *
     * This function attaches our filter callback to the `roro_sql_logger_columns`
     * filter, which is used by the underlying SQL manager plugin when
     * building the log table. The filter allows modification of column
     * definitions so that we can internationalize the labels.
     */
    public static function init() {
        // Only hook the filter if the function exists; otherwise bail out
        if ( function_exists( 'add_filter' ) ) {
            add_filter( 'roro_sql_logger_columns', [ __CLASS__, 'filter_columns' ] );
        }
    }

    /**
     * Filter the SQL logger columns to provide translated labels.
     *
     * @param array $columns The original column definitions.
     * @return array Modified column definitions with translated labels.
     */
    public static function filter_columns( $columns ) {
        // Ensure we have an array to work with
        if ( ! is_array( $columns ) ) {
            $columns = [];
        }

        // Override column labels with localized strings. If the column keys
        // exist, replace them; otherwise set defaults.
        $columns['query']       = __( 'Query', 'roro-assets-sql-manager' );
        $columns['duration']    = __( 'Execution Time (ms)', 'roro-assets-sql-manager' );
        $columns['executed_at'] = __( 'Executed At', 'roro-assets-sql-manager' );

        return $columns;
    }
}