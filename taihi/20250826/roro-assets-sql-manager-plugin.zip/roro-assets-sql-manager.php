<?php
/**
 * Plugin Name: RORO Assets SQL Manager
 * Description: WordPress SQL ログ UI の多言語対応版プラグインです。クエリログの列名を各言語（日本語、英語、中国語、韓国語）で表示します。
 * Version: 1.0.0
 * Author: Project Roro
 * Text Domain: roro-assets-sql-manager
 * Domain Path: /languages
 */

// 安全のため、WordPress 外から直接実行されないようにします。
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * プラグインの多言語ファイルをロードします。
 */
function roro_assets_sql_manager_load_textdomain() {
    load_plugin_textdomain( 'roro-assets-sql-manager', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'roro_assets_sql_manager_load_textdomain' );

// SQL ロガークラスを読み込み、初期化
require_once __DIR__ . '/includes/class-roro-sql-logger.php';

// 初期化処理を呼び出します。
Roro_SQL_Logger::init();