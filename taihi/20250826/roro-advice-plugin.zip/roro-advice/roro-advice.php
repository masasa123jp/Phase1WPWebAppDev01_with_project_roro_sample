<?php
/*
 * Plugin Name: RORO Advice
 * Description: Provides random one‑point advice about pets. Use the shortcode [roro_advice] to display a random tip. Supports categories and four languages (Japanese, English, Chinese, Korean).
 * Version: 1.0.0
 * Author: Roro Team
 * Text Domain: roro-advice
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Load plugin text domain (not strictly needed here because we handle translation via arrays, but retained for extensibility).
 */
function roro_advice_load_textdomain() {
    load_plugin_textdomain( 'roro-advice', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'roro_advice_load_textdomain' );

/**
 * Retrieve a random advice message based on category and locale.
 *
 * @param string $category Advice category key (e.g. 'general', 'health', 'training', 'diet').
 * @param string $locale   Two‑letter language code (e.g. 'ja', 'en', 'zh', 'ko').
 *
 * @return string Advice message.
 */
function roro_advice_get_random_message( $category = 'general', $locale = 'ja' ) {
    // Define advice messages per category and language. Add more categories/messages as needed.
    $advices = array(
        'general' => array(
            'ja' => array(
                '毎日少しだけでも愛犬と遊ぶ時間を取ることで、信頼関係が深まります。',
                '散歩中は周囲の環境に気を配りながら、安全に楽しみましょう。',
                '犬に十分な休息を与え、落ち着ける場所を用意してあげましょう。',
            ),
            'en' => array(
                'Spending even a little playtime with your dog each day will strengthen your bond.',
                'During walks, pay attention to the surroundings to ensure safety and fun.',
                'Provide your dog with plenty of rest and a calm, comfortable space.',
            ),
            'zh' => array(
                '每天花一点时间陪狗狗玩耍，可以增进彼此的信任。',
                '散步时要注意周围环境，确保安全并享受乐趣。',
                '给狗狗充足的休息时间，并提供一个安静舒适的空间。',
            ),
            'ko' => array(
                '매일 조금씩이라도 반려견과 놀이 시간을 갖는 것은 신뢰를 쌓는 데 도움이 됩니다.',
                '산책 중에는 주변 환경을 잘 살펴 안전하게 즐기세요.',
                '반려견이 편안하게 쉴 수 있는 공간과 충분한 휴식을 제공하세요.',
            ),
        ),
        'health' => array(
            'ja' => array(
                '健康維持のために定期的な運動と適切な体重管理を心がけましょう。',
                'フィラリア予防やワクチン接種など定期的な健康チェックを忘れずに行いましょう。',
            ),
            'en' => array(
                'Regular exercise and proper weight management are essential for your dog’s health.',
                'Don’t forget regular health checks such as heartworm prevention and vaccinations.',
            ),
            'zh' => array(
                '定期运动和保持适当体重对狗狗的健康非常重要。',
                '不要忘记定期进行心丝虫预防和疫苗接种等健康检查。',
            ),
            'ko' => array(
                '정기적인 운동과 적절한 체중 관리는 반려견 건강에 필수적입니다.',
                '심장사상충 예방과 백신 접종 등 정기적인 건강 검진을 잊지 마세요.',
            ),
        ),
        'training' => array(
            'ja' => array(
                'しつけは短い時間を繰り返すことで効果が上がります。楽しく行いましょう。',
                '褒めるタイミングを大切にし、成功体験を積み重ねさせてあげましょう。',
            ),
            'en' => array(
                'Short, frequent training sessions are more effective. Keep it fun and rewarding.',
                'Praise your dog at the right moment to build positive experiences.',
            ),
            'zh' => array(
                '短而多次的训练效果更好，要保持有趣的氛围。',
                '在正确的时机表扬狗狗，帮助它累积成功的经验。',
            ),
            'ko' => array(
                '짧고 자주 하는 훈련이 더 효과적입니다. 재미있고 보람 있게 진행하세요.',
                '적절한 시기에 칭찬하여 긍정적인 경험을 쌓게 해주세요.',
            ),
        ),
        'diet' => array(
            'ja' => array(
                'バランスの取れた食事は健康の基本です。質の良いフードを選びましょう。',
                '急激な食事の変更は胃腸に負担をかけるので、少しずつ切り替えましょう。',
            ),
            'en' => array(
                'A balanced diet is the foundation of good health. Choose high‑quality food.',
                'Introduce new foods gradually to avoid stomach upset.',
            ),
            'zh' => array(
                '均衡的饮食是健康的基础，选择高品质的食物。',
                '不要突然更换饮食，应逐渐过渡以免肠胃不适。',
            ),
            'ko' => array(
                '균형 잡힌 식단은 건강의 기본입니다. 좋은 품질의 사료를 선택하세요.',
                '갑작스러운 식단 변경은 위장에 부담이 될 수 있으니 천천히 전환하세요.',
            ),
        ),
    );

    // Fallback category
    if ( ! isset( $advices[ $category ] ) ) {
        $category = 'general';
    }
    // Fallback locale to Japanese if unsupported
    if ( ! isset( $advices[ $category ][ $locale ] ) ) {
        $locale = 'ja';
    }
    $messages = $advices[ $category ][ $locale ];
    return $messages[ array_rand( $messages ) ];
}

/**
 * Shortcode callback for [roro_advice].
 *
 * Usage: [roro_advice category="health"]
 *
 * @param array $atts Shortcode attributes.
 *
 * @return string HTML output with advice.
 */
function roro_advice_shortcode( $atts = array() ) {
    $atts = shortcode_atts( array(
        'category' => 'general',
    ), $atts, 'roro_advice' );

    // Determine two‑letter language code from current locale
    $locale = substr( get_locale(), 0, 2 );
    $message = roro_advice_get_random_message( $atts['category'], $locale );
    return '<div class="roro-advice">' . esc_html( $message ) . '</div>';
}
add_shortcode( 'roro_advice', 'roro_advice_shortcode' );