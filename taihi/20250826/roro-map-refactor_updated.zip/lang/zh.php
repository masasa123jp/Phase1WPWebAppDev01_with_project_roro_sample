<?php
// Simplified Chinese translation dictionary for the front‑end JavaScript.
$roro_events_messages = array(
  'search'             => '搜索',
  'reset'              => '重置',
  'search_placeholder' => '关键词（名称/说明/地址）',
  'use_my_location'    => '基于当前位置搜索',
  'no_results'         => '没有符合条件的活动，请调整筛选后重试。',
  'geo_not_supported'  => '不支持定位功能。',
  'geo_fetching'       => '正在获取当前位置…',
  'geo_ok'             => '已使用当前位置。',
  'geo_denied'         => '定位权限被拒绝。',
);