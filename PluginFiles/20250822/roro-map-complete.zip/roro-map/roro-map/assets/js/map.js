/* eslint-disable no-console */
/**
 * Front‑end script for the Roro Map plugin.
 *
 * This script is executed after the DOM has loaded and is responsible for
 * initialising the map. In a real implementation you would load the Google
 * Maps API or another mapping library here and populate the map with
 * markers retrieved via AJAX or embedded data attributes.
 */
/* global roroMap */
( function ( $ ) {
    'use strict';
    $( function () {
        $( '.roro-map-container' ).each( function () {
            var $container = $( this );
            // Set a light background to denote loading state.
            $container.css( 'background-color', '#f0f0f0' );
            // Fetch map data via AJAX.
            $.get( roroMap.ajaxUrl, {
                action: 'roro_map_data',
                nonce:  roroMap.nonce
            }, function ( response ) {
                if ( response.success ) {
                    var html = '<h4>Events</h4><ul class="roro-map-events">';
                    if ( response.data.events && response.data.events.length ) {
                        $.each( response.data.events, function ( i, ev ) {
                            html += '<li>' + ev.name + ' (' + ev.latitude + ', ' + ev.longitude + ')</li>';
                        } );
                    } else {
                        html += '<li>No events found.</li>';
                    }
                    html += '</ul><h4>Spots</h4><ul class="roro-map-spots">';
                    if ( response.data.spots && response.data.spots.length ) {
                        $.each( response.data.spots, function ( i, sp ) {
                            html += '<li>' + sp.name + ' (' + sp.latitude + ', ' + sp.longitude + ')</li>';
                        } );
                    } else {
                        html += '<li>No spots found.</li>';
                    }
                    html += '</ul>';
                    $container.html( html );
                } else {
                    $container.text( response.data && response.data.message ? response.data.message : 'Error loading map data.' );
                }
            }, 'json' );
        } );
    } );
} )( jQuery );