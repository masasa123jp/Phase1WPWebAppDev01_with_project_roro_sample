<?php

/**
 * Map functionality for the Roro project.
 *
 * This class registers a shortcode that outputs a container for your map and
 * enqueues a JavaScript file that handles the front‑end map logic. To
 * integrate with Google Maps or other providers, modify the enqueue method
 * to register the appropriate API scripts and implement the JavaScript
 * accordingly.
 *
 * @since 1.0.0
 */
class Roro_Map_Plugin {
    /**
     * Register shortcode and enqueue scripts.
     */
    public function run() {
        add_shortcode( 'roro_map', array( $this, 'render_map' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        // Register AJAX handler for fetching map data (events and spots).
        add_action( 'wp_ajax_roro_map_data', array( $this, 'ajax_map_data' ) );
        add_action( 'wp_ajax_nopriv_roro_map_data', array( $this, 'ajax_map_data' ) );
    }

    /**
     * Output the map container. You may output additional controls here.
     *
     * @return string HTML for the map container.
     */
    public function render_map() {
        $id = 'roro-map-container-' . wp_rand( 1000, 9999 );
        return '<div id="' . esc_attr( $id ) . '" class="roro-map-container" style="width:100%;height:400px;"></div>';
    }

    /**
     * Enqueue front‑end JavaScript and styles.
     */
    public function enqueue_scripts() {
        // Enqueue our own script that handles map initialisation.
        wp_enqueue_script( 'roro-map-js', RORO_MAP_URL . 'assets/js/map.js', array( 'jquery' ), '1.1.0', true );
        // Localise script with AJAX information
        wp_localize_script( 'roro-map-js', 'roroMap', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'roro_map_data' ),
        ) );
        // Optionally enqueue CSS for styling the map container.
        wp_enqueue_style( 'roro-map-css', RORO_MAP_URL . 'assets/css/map.css', array(), '1.1.0' );
    }

    /**
     * AJAX callback to output map data (events and spots) in JSON form.
     */
    public function ajax_map_data() {
        check_ajax_referer( 'roro_map_data', 'nonce' );
        // Ensure the DB class is available.
        if ( ! class_exists( 'Roro_Core_Wp_DB' ) ) {
            if ( defined( 'RORO_CORE_WP_DIR' ) ) {
                $db_file = trailingslashit( RORO_CORE_WP_DIR ) . 'includes/class-roro-db.php';
                if ( file_exists( $db_file ) ) {
                    require_once $db_file;
                }
            }
        }
        if ( ! class_exists( 'Roro_Core_Wp_DB' ) ) {
            wp_send_json_error( array( 'message' => __( 'Core plugin missing.', 'roro-map' ) ), 500 );
        }
        // Return a combined list of events and spots.
        $events = Roro_Core_Wp_DB::get_events();
        $spots  = Roro_Core_Wp_DB::get_spots();
        wp_send_json_success( array( 'events' => $events, 'spots' => $spots ) );
    }
}