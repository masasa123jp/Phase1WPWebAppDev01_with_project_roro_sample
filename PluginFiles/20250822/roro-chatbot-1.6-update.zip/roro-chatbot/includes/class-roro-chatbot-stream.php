<?php
// roro-chatbot/includes/class-roro-chatbot-stream.php
if (!defined('ABSPATH')) { exit; }

class Roro_Chatbot_Stream {
  public static function init() { add_action('rest_api_init', [__CLASS__, 'routes']); }
  public static function routes() {
    register_rest_route('roro-chatbot/v1', '/stream', [
      'methods'  => 'POST',
      'permission_callback' => function(){ return is_user_logged_in(); },
      'callback' => [__CLASS__, 'handle_stream']
    ]);
  }
  public static function handle_stream(WP_REST_Request $req) {
    $opt_endpoint = get_option('roro_dify_stream_endpoint', '');
    $opt_api_key  = get_option('roro_dify_api_key', '');
    $endpoint = $req->get_param('endpoint') ?: $opt_endpoint;
    $payload  = $req->get_param('payload');
    if (!$endpoint || !$opt_api_key || !$payload) {
      return new WP_REST_Response(['error'=>'missing_config_or_payload'], 400);
    }
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-transform');
    header('X-Accel-Buffering: no');
    nocache_headers();
    $ch = curl_init($endpoint);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $opt_api_key, 'Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, wp_json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $chunk){ echo $chunk; @ob_flush(); flush(); return strlen($chunk); });
    curl_setopt($ch, CURLOPT_TIMEOUT, 0);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_exec($ch);
    curl_close($ch);
    exit;
  }
}
Roro_Chatbot_Stream::init();
