(function(){
  async function startStream(cfg) {
    const el = document.querySelector(cfg.targetEl);
    if (!el) return;
    const res = await fetch(cfg.restUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
      body: JSON.stringify({ endpoint: cfg.endpoint || '', payload: cfg.payload || {} })
    });
    if (!res.ok || !res.body) {
      el.insertAdjacentHTML('beforeend', '<div class="roro-chat-error">通信エラー</div>');
      return;
    }
    const reader = res.body.getReader(); const decoder = new TextDecoder(); let buffer = '';
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx; while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx).trim(); buffer = buffer.slice(idx + 1);
        if (!line) continue; const sse = line.startsWith('data:') ? line.slice(5).trim() : line;
        try {
          const obj = JSON.parse(sse);
          if (obj.event === 'message' || obj.output) {
            const text = obj.output || obj.message || '';
            if (text) { el.insertAdjacentHTML('beforeend', `<span class="roro-typing">${escapeHtml(text)}</span>`); }
          }
          if (obj.event === 'end') { el.insertAdjacentHTML('beforeend', '<br/>'); }
        } catch(e) { el.insertAdjacentText('beforeend', sse); }
      }
    }
  }
  function escapeHtml(s){ return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  window.RoroChatStream = { startStream };
})();
