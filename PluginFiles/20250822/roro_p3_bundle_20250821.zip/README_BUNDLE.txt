RORO P3 Release Candidate - Bundle (2025-08-21)
------------------------------------------------
同梱物:
  - roro_p3_chatbot.zip      : Roro Chatbot プラグイン（P3 RC／UIチップ/カード込み）
  - roro_assets_samples.zip  : roro-core-wp への画像/SQL の格納サンプル（ダミーファイル）
  - roro-auth-1.6-update.zip : (存在時) 認証モジュール差分
  - roro-map-1.6-update.zip  : (存在時) 地図モジュール差分
  - roro-chatbot-1.6-update.zip: (存在時) チャットボット差分
  - roro_patch_20250821.zip  : (存在時) まとめパッチ

使い方:
  1) roro_p3_chatbot.zip を WordPress の「プラグインを追加」からアップロード/有効化
  2) roro_assets_samples.zip を解凍し、roro-core-wp/assets/ 配下へ上書き配置
  3) 管理画面: ツール → Roro DB Importer → schema/seed を実行
  4) roro-chatbot の設定（Dify Endpoint / API Key）を投入
  5) 固定ページ等に [roro_chat_ui endpoint="..."] を挿入し、動作を確認
