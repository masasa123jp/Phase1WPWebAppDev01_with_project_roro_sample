<?php
/**
 * Plugin Name: Roro Core WP
 * Plugin URI: https://example.com/roro
 * Description: RORO の共通スキーマ/初期データを管理。有効化時に DDL を実行し、管理画面から seed SQL の再投入ができます。
 * Version: 1.6.0-rc.2
 * Requires at least: 6.3
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Author: RORO Project
 * Text Domain: roro-core-wp
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) { exit; }

if (!defined('RORO_CORE_WP_VERSION')) define('RORO_CORE_WP_VERSION', '1.6.0-rc.2');
if (!defined('RORO_CORE_WP_DIR'))     define('RORO_CORE_WP_DIR', plugin_dir_path(__FILE__));
if (!defined('RORO_CORE_WP_URL'))     define('RORO_CORE_WP_URL', plugin_dir_url(__FILE__));

add_action('plugins_loaded', function(){
    load_plugin_textdomain('roro-core-wp', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

require_once __DIR__ . '/includes/schema.php';

register_activation_hook(__FILE__, function(){
    if (class_exists('Roro_Core_Schema')) {
        Roro_Core_Schema::run_on_activation();
    }
});

add_action('admin_menu', function () {
    add_management_page(
        'Roro DB Importer',
        'Roro DB Importer',
        'manage_options',
        'roro-db-importer',
        'roro_core_wp_render_db_importer'
    );
});

function roro_core_wp_render_db_importer() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    $action  = isset($_POST['roro_action']) ? sanitize_text_field($_POST['roro_action']) : '';
    $message = '';
    if (!empty($action)) {
        check_admin_referer('roro_db_import');
        if ($action === 'run_schema') {
            Roro_Core_Schema::run_on_activation();
            $message = 'スキーマ（schema/*.sql）を再実行しました。';
        } elseif ($action === 'run_seed') {
            Roro_Core_Schema::run_seed_from_admin();
            $message = '初期データ（seed/*.sql）を投入しました。';
        }
    }
    ?>
    <div class="wrap">
      <h1>Roro DB Importer</h1>
      <?php if ($message): ?>
        <div id="message" class="notice notice-success is-dismissible"><p><?php echo esc_html($message); ?></p></div>
      <?php endif; ?>
      <p>下記ボタンで、プラグイン配下に配置した SQL を実行できます。</p>
      <ul>
        <li><code><?php echo esc_html( plugin_dir_path(__FILE__) . 'assets/sql/schema/*.sql'); ?></code> … スキーマ定義（テーブル／ビュー／トリガ）</li>
        <li><code><?php echo esc_html( plugin_dir_path(__FILE__) . 'assets/sql/seed/*.sql'); ?></code> … 初期データ投入（カテゴリ・犬種・スポット/イベント など）</li>
      </ul>
      <p><strong>注意:</strong> 本番環境では実行前に必ずバックアップを取得してください。</p>
      <form method="post" style="margin-top:20px;">
        <?php wp_nonce_field('roro_db_import'); ?>
        <input type="hidden" name="roro_action" value="run_schema"/>
        <button class="button button-primary">スキーマを再実行（schema/*.sql）</button>
      </form>
      <form method="post" style="margin-top:12px;">
        <?php wp_nonce_field('roro_db_import'); ?>
        <input type="hidden" name="roro_action" value="run_seed"/>
        <button class="button">初期データ投入（seed/*.sql）</button>
      </form>
    </div>
    <?php
}
