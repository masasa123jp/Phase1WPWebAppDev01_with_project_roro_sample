-- seed: events (デモ用)
INSERT INTO RORO_EVENTS_MASTER (event_id, name, date, location, venue, prefecture, city, lat, lon, source, url)
VALUES
  ('E20250901','DOGフェス寄居','2025-09-01','埼玉県寄居町','中央公園','埼玉県','寄居町',36.1182,139.1934,'local','https://example.com/e/1'),
  ('E20250910','わんカフェDAY','2025-09-10','東京都台東区','上野公園','東京都','台東区',35.712,139.78,'local','https://example.com/e/2')
ON DUPLICATE KEY UPDATE name=VALUES(name), date=VALUES(date), venue=VALUES(venue);
