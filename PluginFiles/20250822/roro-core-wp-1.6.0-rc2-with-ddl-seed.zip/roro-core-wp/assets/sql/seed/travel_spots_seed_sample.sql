-- seed: travel spots (デモ用)
INSERT INTO RORO_TRAVEL_SPOT_MASTER
  (TSM_ID, branch_no, prefecture, region, spot_area, genre, name, address, latitude, longitude, google_rating, english_support, isVisible)
VALUES
  ('TSM_0001',0,'埼玉県','関東','寄居','ドッグラン','寄居ドッグガーデン','埼玉県大里郡寄居町',36.1182,139.1934,4.5,1,1),
  ('TSM_0002',0,'東京都','関東','台東','カフェ','わんわんカフェ','東京都台東区',35.712,139.78,4.2,1,1)
ON DUPLICATE KEY UPDATE name=VALUES(name), address=VALUES(address), latitude=VALUES(latitude), longitude=VALUES(longitude);
