-- seed: categories
INSERT INTO RORO_CATEGORY_MASTER(category_code, category_name, sort_order) VALUES
  ('A','お出かけ',10),
  ('B','しつけ',20),
  ('C','防災',30),
  ('D','健康',40)
ON DUPLICATE KEY UPDATE category_name=VALUES(category_name), sort_order=VALUES(sort_order);
