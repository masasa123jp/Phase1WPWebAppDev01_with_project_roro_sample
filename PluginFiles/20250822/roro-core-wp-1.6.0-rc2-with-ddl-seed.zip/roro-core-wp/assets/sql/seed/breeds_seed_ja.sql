-- seed: breeds (少量サンプル)
INSERT INTO RORO_BREED_MASTER (BREEDM_ID, pet_type, breed_name, category_code) VALUES
  ('DOG_SHIBA','DOG','柴犬','A'),
  ('DOG_TOYPOO','DOG','トイプードル','A'),
  ('DOG_LAB','DOG','ラブラドール・レトリバー','A'),
  ('CAT_MIX','CAT','ミックス','A')
ON DUPLICATE KEY UPDATE breed_name=VALUES(breed_name), category_code=VALUES(category_code);
