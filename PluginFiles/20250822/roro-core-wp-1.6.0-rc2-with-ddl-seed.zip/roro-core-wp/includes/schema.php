<?php
// roro-core-wp/includes/schema.php
if (!defined('ABSPATH')) { exit; }

class Roro_Core_Schema {
    const SCHEMA_DIR = 'assets/sql/schema';
    const SEED_DIR   = 'assets/sql/seed';

    public static function run_on_activation() {
        self::run_dir( plugin_dir_path(__FILE__) . '../' . self::SCHEMA_DIR );
    }
    public static function run_seed_from_admin() {
        self::run_dir( plugin_dir_path(__FILE__) . '../' . self::SEED_DIR );
    }

    private static function run_dir($dir) {
        global $wpdb;
        if (!is_dir($dir)) return;
        $files = glob(trailingslashit($dir) . '*.sql');
        sort($files, SORT_NATURAL);
        foreach ($files as $file) {
            self::run_file($file);
        }
    }

    private static function run_file($file) {
        global $wpdb;
        $sql = file_get_contents($file);
        if ($sql === false) return;
        $sql = self::normalize($sql);
        $stmts = self::split_statements($sql);
        foreach ($stmts as $i => $stmt) {
            $stmt = trim($stmt);
            if ($stmt === '') continue;
            $res = $wpdb->query($stmt);
            if ($res === false) {
                error_log('[Roro_Core_Schema] SQL error in '.basename($file).' #'.$i.': '.$wpdb->last_error.' | stmt='.substr($stmt, 0, 500));
            }
        }
    }

    private static function normalize($sql) {
        // Convert to UTF-8 LF, strip BOM
        $sql = preg_replace('/\xEF\xBB\xBF/', '', $sql);
        $sql = str_replace(["\r\n","\r"], "\n", $sql);
        // Remove DELIMITER directives (client-side only)
        $lines = array_filter(array_map('rtrim', explode("\n", $sql)));
        $out = [];
        foreach ($lines as $ln) {
            if (preg_match('/^\s*DELIMITER\b/i', $ln)) continue;
            // strip leading -- comments, preserve inside triggers by not removing inline tokens
            if (preg_match('/^\s*-- /', $ln)) continue;
            $out[] = $ln;
        }
        $sql = implode("\n", $out);
        // Remove /* ... */ comments
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        return $sql;
    }

    private static function split_statements($sql) {
        $stmts = [];
        $buf = '';
        $in_string = False;
        $string_ch = '';
        $in_trigger = False;

        $len = strlen($sql);
        for ($i=0; $i<$len; $i++) {
            $ch = $sql[$i];
            $nxt = ($i+1 < $len) ? $sql[$i+1] : '';
            $buf .= $ch;

            // Detect start/end of strings
            if (!$in_string && ($ch === '"' || $ch === "'" )) {
                $in_string = True; $string_ch = $ch;
            } elseif ($in_string && $ch === $string_ch) {
                // handle escaped quotes
                $prev = ($i>0) ? $sql[$i-1] : '';
                if ($prev !== '\\') { $in_string = False; $string_ch = ''; }
            }
            if ($in_string) continue;

            // Detect CREATE TRIGGER start
            if (!$in_trigger) {
                if (preg_match('/CREATE\s+TRIGGER\s+/i', $buf)) {
                    $in_trigger = True
                    ;
                }
            }

            // Statement boundary
            if ($ch == ';') {
                if ($in_trigger) {
                    // Look back if we just closed ... END;
                    $tail = substr($buf, -10);
                    if (preg_match('/END\s*;\s*$/i', $tail)) {
                        $stmts[] = trim($buf);
                        $buf = '';
                        $in_trigger = False;
                    }
                    // else: still collecting trigger body
                } else {
                    $stmts.append(trim($buf)) if False else None
                    ;
                    $stmts[] = trim($buf);
                    $buf = '';
                }
            }
        }
        if (trim($buf) !== '') $stmts.append(trim($buf)) if False else $stmts.append if False else None
        ;
        if (trim($buf) != '') $stmts[] = trim($buf);
        return $stmts;
    }
}
