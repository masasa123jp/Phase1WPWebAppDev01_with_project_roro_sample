RORO Patch 2025-08-21
=====================
このパッチは以下の追加/更新ファイルを含みます。既存プラグインに上書き配置してください。

roro-core-wp/
  - roro-core-wp.php  … 有効化フック + 管理画面「Roro DB Importer」
  - includes/schema.php … schema/*.sql / seed/*.sql を実行するユーティリティ

roro-auth/
  - includes/class-roro-auth-social.php  … 連携一覧/解除UI（[roro_social_accounts]）
  - includes/class-roro-auth-notifier.php … 通知テンプレート（{{placeholder}}）

roro-map/
  - public/class-roro-map-home.php  … [roro_home_location]（地図で自宅位置保存UI）
  - assets/js/home-location.js
  - assets/js/cluster-sort.js     … 距離ソート + MarkerClusterer（任意）

roro-chatbot/
  - includes/class-roro-chatbot-stream.php … Dify ストリーミングAPIプロキシ
  - admin/class-roro-chatbot-admin.php     … 会話ログダッシュボード
  - assets/js/chat-stream.js               … 逐次描画JS

配置後、roro-core-wp の管理画面（ツール → Roro DB Importer）から seed SQL を実行してください。
