<?php
// roro-auth/includes/class-roro-auth-social.php
if (!defined('ABSPATH')) { exit; }

class Roro_Auth_Social {
  public static function init() {
    add_shortcode('roro_social_accounts', [__CLASS__, 'render_accounts']);
    add_action('admin_post_roro_auth_unlink', [__CLASS__, 'handle_unlink']);
  }
  public static function render_accounts() {
    if (!is_user_logged_in()) { return '<div class="roro-auth-msg">この機能を利用するにはログインが必要です。</div>'; }
    global $wpdb;
    $wp_user_id = get_current_user_id();
    $customer_id = $wpdb->get_var($wpdb->prepare("SELECT customer_id FROM RORO_USER_LINK_WP WHERE wp_user_id=%d", $wp_user_id));
    if (!$customer_id) { return '<div class="roro-auth-msg">アカウント連携情報が見つかりません。</div>'; }
    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT account_id, provider, email, email_verified, status, created_at, last_login_at
         FROM RORO_AUTH_ACCOUNT WHERE customer_id=%d ORDER BY provider='local' DESC, created_at ASC", $customer_id
    ), ARRAY_A);
    if (!$rows) { return '<div class="roro-auth-msg">連携中のアカウントはありません。</div>'; }
    $hasLocal=false; $socialCount=0;
    foreach ($rows as $r){ if ($r['provider']==='local') $hasLocal=true; else $socialCount++; }
    ob_start(); ?>
    <div class="roro-auth-social-list">
      <h3>連携中のアカウント</h3>
      <table class="wp-list-table widefat striped">
        <thead><tr><th>プロバイダ</th><th>メール</th><th>状態</th><th>最終ログイン</th><th>操作</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?php echo esc_html($r['provider']); ?></td>
            <td><?php echo esc_html($r['email'] ?: '（なし）'); ?></td>
            <td><?php $s=$r['status']; $ev=intval($r['email_verified'])?'検証済':'未検証'; echo esc_html("$s / $ev"); ?></td>
            <td><?php echo esc_html($r['last_login_at'] ?: '—'); ?></td>
            <td>
              <?php if ($r['provider'] !== 'local'): ?>
                <form method="post" onsubmit="return confirm('この連携を解除しますか？');" style="display:inline">
                  <?php wp_nonce_field('roro_auth_unlink'); ?>
                  <input type="hidden" name="action" value="roro_auth_unlink"/>
                  <input type="hidden" name="account_id" value="<?php echo esc_attr($r['account_id']); ?>"/>
                  <button class="button">解除</button>
                </form>
              <?php else: ?>—<?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php if (!$hasLocal && $socialCount===1): ?>
        <p class="description" style="color:#c00">
          ※ 現在、ソーシャルアカウントが唯一のログイン手段です。解除前に
          <a href="<?php echo esc_url(wp_lostpassword_url()); ?>">パスワード設定</a> を推奨します。
        </p>
      <?php endif; ?>
    </div>
    <?php return ob_get_clean();
  }
  public static function handle_unlink() {
    if (!is_user_logged_in()) { wp_die('ログインが必要です。'); }
    check_admin_referer('roro_auth_unlink');
    $account_id = isset($_POST['account_id']) ? intval($_POST['account_id']) : 0;
    if (!$account_id) { wp_die('アカウントが指定されていません。'); }
    global $wpdb;
    $wp_user_id = get_current_user_id();
    $customer_id = $wpdb->get_var($wpdb->prepare("SELECT customer_id FROM RORO_USER_LINK_WP WHERE wp_user_id=%d", $wp_user_id));
    if (!$customer_id) { wp_die('連携情報が見つかりません。'); }
    $acc = $wpdb->get_row($wpdb->prepare("SELECT * FROM RORO_AUTH_ACCOUNT WHERE account_id=%d AND customer_id=%d", $account_id, $customer_id), ARRAY_A);
    if (!$acc) { wp_die('対象が見つかりません。'); }
    if ($acc['provider']==='local') { wp_die('local アカウントは解除できません。'); }
    $other = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM RORO_AUTH_ACCOUNT WHERE customer_id=%d AND account_id<>%d", $customer_id, $account_id));
    if (intval($other)===0) { wp_die('唯一のログイン手段です。先にパスワード設定か別ソーシャル連携を追加してください。'); }
    $wpdb->delete('RORO_AUTH_ACCOUNT', ['account_id'=>$account_id], ['%d']);
    if (!empty($acc['email'])) {
      $to = $acc['email'];
      $subject = apply_filters('roro_auth_mail_subject_unlinked', '【RORO】ソーシャル連携を解除しました', $acc);
      $body = apply_filters('roro_auth_mail_body_unlinked',
        "このメールは通知専用です。\nアカウント（{$acc['provider']}）の連携を解除しました。\n必要に応じて別のログイン手段を設定してください。\n\n{site_name}", $acc);
      wp_mail($to, $subject, strtr($body, ['{site_name}' => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES)]));
    }
    wp_safe_redirect(wp_get_referer() ?: home_url('/'));
    exit;
  }
}
Roro_Auth_Social::init();
