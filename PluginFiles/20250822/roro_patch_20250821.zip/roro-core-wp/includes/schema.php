<?php
// roro-core-wp/includes/schema.php
if (!defined('ABSPATH')) { exit; }

class Roro_Core_Schema {
  public static function run_on_activation() {
    $base = plugin_dir_path(__FILE__) . '../assets/sql/schema';
    self::run_dir($base);
  }
  public static function run_seed_from_admin() {
    $base = plugin_dir_path(__FILE__) . '../assets/sql/seed';
    self::run_dir($base);
  }
  private static function run_dir($dir) {
    if (!is_dir($dir)) return;
    $files = glob(trailingslashit($dir) . '*.sql');
    sort($files, SORT_NATURAL);
    foreach ($files as $f) { self::run_sql_file($f); }
  }
  private static function run_sql_file($file) {
    global $wpdb;
    $sql = file_get_contents($file);
    if ($sql === false) return;

    // コメント・空行の基本除去
    $sql = preg_replace('#/\*.*?\*/#s', '', $sql);
    $lines = preg_split("/\r\n|\r|\n/", $sql);

    // ステートメント分割（CREATE TRIGGER/VIEW を1文扱い）
    $stmts = []; $buf = '';
    $in_big = false; // CREATE TRIGGER/VIEW 等
    foreach ($lines as $ln) {
      $trim = trim($ln);
      if ($trim === '' || strpos($trim, '--') === 0) continue;
      $upper = strtoupper($trim);
      if (!$in_big && (str_starts_with($upper,'CREATE TRIGGER') || str_starts_with($upper,'CREATE VIEW') || str_starts_with($upper,'CREATE OR REPLACE VIEW'))) {
        $in_big = true;
      }
      $buf .= $ln . "\n";
      if ($in_big) {
        if (preg_match('/\bEND\s*;$/i', $trim) || (preg_match('/;$/', $trim) && str_contains($buf, 'CREATE VIEW'))) {
          $stmts[] = $buf; $buf = ''; $in_big = false;
        }
      } else {
        if (preg_match('/;$/', $trim)) { $stmts[] = $buf; $buf = ''; }
      }
    }
    if (trim($buf) !== '') $stmts[] = $buf;

    // 実行
    $wpdb->query('SET NAMES utf8mb4');
    $wpdb->query('SET FOREIGN_KEY_CHECKS=1');
    foreach ($stmts as $s) {
      $s = trim($s);
      if ($s !== '') { $wpdb->query($s); }
    }
  }
}
