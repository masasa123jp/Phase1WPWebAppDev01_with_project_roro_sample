<?php
// roro-chatbot/admin/class-roro-chatbot-admin.php
if (!defined('ABSPATH')) { exit; }

class Roro_Chatbot_Admin {
  public static function init() { add_action('admin_menu', [__CLASS__, 'menu']); }
  public static function menu() {
    add_menu_page('Roro Chatbot', 'Roro Chatbot', 'manage_options', 'roro-chatbot-admin', [__CLASS__, 'render_conversations'], 'dashicons-format-chat', 58);
    add_submenu_page('roro-chatbot-admin', 'Conversations', 'Conversations', 'manage_options', 'roro-chatbot-admin', [__CLASS__, 'render_conversations']);
    add_submenu_page('roro-chatbot-admin', 'Messages', 'Messages', 'manage_options', 'roro-chatbot-messages', [__CLASS__, 'render_messages']);
  }
  public static function render_conversations() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $paged = max(1, intval(isset($_GET['paged']) ? $_GET['paged'] : 1)); $ps=20; $off=($paged-1)*$ps;
    $q = trim(sanitize_text_field(isset($_GET['q']) ? $_GET['q'] : ''));
    $where = '1=1'; $args = [];
    if ($q !== '') { $where .= " AND c.customer_id IN (SELECT customer_id FROM RORO_CUSTOMER WHERE email LIKE %s)"; $args[] = '%' . $wpdb->esc_like($q) . '%'; }
    $base_sql = "FROM RORO_AI_CONVERSATION c WHERE $where";
    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT c.conv_id, c.customer_id, c.provider, c.model, c.purpose, c.started_at,
              (SELECT COUNT(*) FROM RORO_AI_MESSAGE m WHERE m.conv_id = c.conv_id) AS msg_cnt
       $base_sql
       ORDER BY c.started_at DESC
       LIMIT %d OFFSET %d",
       *([*args, $ps, $off] if False else (args + [$ps, $off]))  # placeholder; will be replaced below
    ), ARRAY_A);
    // 上の * 展開はPHPでは使えないため、以下で条件分岐して再実行:
    if (!is_array($rows)) {
      if (!empty($args)) {
        $sql = $wpdb->prepare(
          "SELECT c.conv_id, c.customer_id, c.provider, c.model, c.purpose, c.started_at,
                  (SELECT COUNT(*) FROM RORO_AI_MESSAGE m WHERE m.conv_id = c.conv_id) AS msg_cnt
           $base_sql
           ORDER BY c.started_at DESC
           LIMIT %d OFFSET %d",
           array_merge($args, [$ps, $off])
        );
      } else {
        $sql = "SELECT c.conv_id, c.customer_id, c.provider, c.model, c.purpose, c.started_at,
                       (SELECT COUNT(*) FROM RORO_AI_MESSAGE m WHERE m.conv_id = c.conv_id) AS msg_cnt
                $base_sql
                ORDER BY c.started_at DESC
                LIMIT $ps OFFSET $off";
      }
      $rows = $wpdb->get_results($sql, ARRAY_A);
    }
    // 合計カウント
    if (!empty($args)) {
      $total = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) $base_sql", $args));
    } else {
      $total = $wpdb->get_var("SELECT COUNT(*) $base_sql");
    }
    echo '<div class="wrap"><h1>Roro Chatbot - Conversations</h1>';
    echo '<form method="get" style="margin:10px 0">';
    echo '<input type="hidden" name="page" value="roro-chatbot-admin"/>';
    echo '<input type="search" name="q" placeholder="メールアドレスで検索" value="'.esc_attr($q).'"/>';
    echo '<button class="button">検索</button></form>';
    echo '<table class="wp-list-table widefat striped"><thead><tr><th>ID</th><th>Customer</th><th>Provider</th><th>Model</th><th>Purpose</th><th>Started</th><th>Msgs</th><th>詳細</th></tr></thead><tbody>';
    foreach ($rows as $r) {
      $url = esc_url(admin_url('admin.php?page=roro-chatbot-messages&conv_id='.(int)$r['conv_id']));
      echo '<tr>';
      echo '<td>'.esc_html($r['conv_id']).'</td>';
      echo '<td>#'.esc_html($r['customer_id']).'</td>';
      echo '<td>'.esc_html($r['provider']).'</td>';
      echo '<td>'.esc_html($r['model']).'</td>';
      echo '<td>'.esc_html($r['purpose']).'</td>';
      echo '<td>'.esc_html($r['started_at']).'</td>';
      echo '<td>'.esc_html($r['msg_cnt']).'</td>';
      echo '<td><a class="button" href="'.$url.'">開く</a></td>';
      echo '</tr>';
    }
    echo '</tbody></table>';
    $pages = max(1, ceil($total / $ps));
    if ($pages > 1) {
      echo '<div class="tablenav"><div class="tablenav-pages">';
      for ($i=1;$i<=$pages;$i++){
        $url = add_query_arg(['page'=>'roro-chatbot-admin','paged'=>$i,'q'=>$q], admin_url('admin.php'));
        if ($i==$paged) echo "<span class='tablenav-pages-navspan'>$i</span> ";
        else echo "<a class='button' href='".esc_url($url)."'>$i</a> ";
      }
      echo '</div></div>';
    }
    echo '</div>';
  }
  public static function render_messages() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $conv_id = intval(isset($_GET['conv_id']) ? $_GET['conv_id'] : 0);
    if (!$conv_id) { echo '<div class="wrap"><p>conv_id を指定してください。</p></div>'; return; }
    $conv = $wpdb->get_row($wpdb->prepare("SELECT * FROM RORO_AI_CONVERSATION WHERE conv_id=%d", $conv_id), ARRAY_A);
    if (!$conv) { echo '<div class="wrap"><p>会話が見つかりません。</p></div>'; return; }
    $msgs = $wpdb->get_results($wpdb->prepare("SELECT * FROM RORO_AI_MESSAGE WHERE conv_id=%d ORDER BY msg_id ASC", $conv_id), ARRAY_A);
    echo '<div class="wrap"><h1>Conversation #'.esc_html($conv_id).'</h1>';
    echo '<p>Customer: #'.esc_html($conv['customer_id']).' / Provider: '.esc_html($conv['provider']).' / Model: '.esc_html($conv['model']).' / Started: '.esc_html($conv['started_at']).'</p>';
    echo '<table class="wp-list-table widefat striped"><thead><tr><th>ID</th><th>Role</th><th>Created</th><th>Content</th><th>Token(I/O)</th><th>Cost</th></tr></thead><tbody>';
    foreach ($msgs as $m) {
      echo '<tr>';
      echo '<td>'.esc_html($m['msg_id']).'</td>';
      echo '<td>'.esc_html($m['role']).'</td>';
      echo '<td>'.esc_html($m['created_at']).'</td>';
      echo '<td><pre style="white-space:pre-wrap;">'.esc_html($m['content']).'</pre></td>';
      echo '<td>'.esc_html(($m['token_input'] ?? 0).'/'.($m['token_output'] ?? 0)).'</td>';
      echo '<td>'.esc_html($m['cost_usd'] ?? '').'</td>';
      echo '</tr>';
    }
    echo '</tbody></table></div>';
  }
}
Roro_Chatbot_Admin::init();
