<?php
/**
 * Plugin Name: Roro Chatbot
 * Description: Dify 連携のストリーミング描画と会話ログ管理
 * Version: 1.6.0-rc.1
 * Requires at least: 6.3
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Text Domain: roro-chatbot
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/class-roro-chatbot-stream.php';
require_once __DIR__ . '/admin/class-roro-chatbot-admin.php';
// 前面JS（必要ページのみで enqueue する運用でも可）
add_action('wp_enqueue_scripts', function(){
  wp_register_script('roro-chat-stream', plugins_url('assets/js/chat-stream.js', __FILE__), [], '1.0.0', true);
});
