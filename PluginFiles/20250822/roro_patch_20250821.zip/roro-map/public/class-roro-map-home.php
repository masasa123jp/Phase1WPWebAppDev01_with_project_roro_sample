<?php
// roro-map/public/class-roro-map-home.php
if (!defined('ABSPATH')) { exit; }

class Roro_Map_Home {
  public static function init() {
    add_shortcode('roro_home_location', [__CLASS__, 'render']);
    add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
  }
  public static function assets() {
    wp_register_script('roro-home-location', plugins_url('assets/js/home-location.js', dirname(__FILE__)), ['jquery'], '1.0.0', true);
    wp_localize_script('roro-home-location', 'RoroHomeCfg', [
      'restUrl' => esc_url_raw( rest_url('roro/v1/me/home') ),
      'nonce'   => wp_create_nonce('wp_rest'),
      'mapKey'  => get_option('roro_map_api_key', ''),
      'i18n'    => [ 'clickToSet' => '地図をクリックして自宅位置をセット', 'saving' => '保存中…', 'saved' => '自宅位置を保存しました', 'error' => '保存に失敗しました' ],
    ]);
    wp_register_style('roro-home-location', plugins_url('assets/css/home-location.css', dirname(__FILE__)), [], '1.0.0');
  }
  public static function render() {
    if (!is_user_logged_in()) { return '<div class="roro-map-msg">ログイン後にご利用ください。</div>'; }
    wp_enqueue_style('roro-home-location');
    wp_enqueue_script('roro-home-location');
    $key = esc_attr(get_option('roro_map_api_key', ''));
    if ($key) {
      wp_enqueue_script('google-maps-js', 'https://maps.googleapis.com/maps/api/js?key=' . $key, [], null, true);
    }
    ob_start(); ?>
    <div class="roro-home-wrapper">
      <div class="roro-home-instruction"><?php echo esc_html('地図をクリックして自宅位置をセット'); ?></div>
      <div id="roro-home-map" style="width:100%;height:380px;background:#f4f4f4"></div>
      <div class="roro-home-actions">
        <button id="roro-home-save" class="button button-primary" disabled>この位置を保存</button>
        <span id="roro-home-status"></span>
      </div>
    </div>
    <?php return ob_get_clean();
  }
}
Roro_Map_Home::init();
