<?php
/**
 * Plugin Name:       Roro Map
 * Plugin URI:        https://example.com/roro-map
 * Description:       Displays Roro-specific locations and events on an interactive map.
 *                    This plugin registers a shortcode to output a map container and
 *                    enqueues the necessary JavaScript. Extend the included class
 *                    to fetch data from your database and integrate with mapping
 *                    APIs such as Google Maps.
 * Version:           1.5.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-map
 * Domain Path:       /languages
 *
 * @package RoroMap
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_MAP_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_MAP_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_MAP_DIR . 'includes/class-roro-map.php';

/**
 * Create database tables for map events and spots on activation.
 */
function roro_map_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $events_table = $wpdb->prefix . 'roro_events';
    $spots_table  = $wpdb->prefix . 'roro_spots';
    $sql_events = "CREATE TABLE $events_table (\n"
               . "id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n"
               . "title VARCHAR(255) NOT NULL,\n"
               . "description TEXT NOT NULL,\n"
               . "latitude DOUBLE NOT NULL,\n"
               . "longitude DOUBLE NOT NULL,\n"
               . "event_date DATE NULL,\n"
               . "PRIMARY KEY  (id)\n"
               . ") $charset_collate;";
    $sql_spots = "CREATE TABLE $spots_table (\n"
              . "id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n"
              . "name VARCHAR(255) NOT NULL,\n"
              . "category VARCHAR(100) DEFAULT '',\n"
              . "latitude DOUBLE NOT NULL,\n"
              . "longitude DOUBLE NOT NULL,\n"
              . "description TEXT NOT NULL,\n"
              . "PRIMARY KEY  (id)\n"
              . ") $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql_events );
    dbDelta( $sql_spots );
    // Insert sample data if tables are empty
    if ( 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM $events_table" ) ) {
        $wpdb->insert( $events_table, array(
            'title'       => 'Sample Event',
            'description' => 'A sample event for demonstration.',
            'latitude'    => 35.6804,
            'longitude'   => 139.7690,
            'event_date'  => current_time( 'mysql' ),
        ), array( '%s', '%s', '%f', '%f', '%s' ) );
    }
    if ( 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM $spots_table" ) ) {
        $wpdb->insert( $spots_table, array(
            'name'        => 'Sample Spot',
            'category'    => 'cafe',
            'latitude'    => 35.6895,
            'longitude'   => 139.6917,
            'description' => 'A sample spot for demonstration.',
        ), array( '%s', '%s', '%f', '%f', '%s' ) );
    }
}

register_activation_hook( __FILE__, 'roro_map_activate' );

function roro_map_run() {
    $map = new Roro_Map_Plugin();
    $map->run();
}
add_action( 'plugins_loaded', 'roro_map_run' );