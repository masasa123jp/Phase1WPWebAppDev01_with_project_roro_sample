/* eslint-disable no-console */
/**
 * Front‑end script for the Roro Map plugin.
 *
 * This script is executed after the DOM has loaded and is responsible for
 * initialising the map. In a real implementation you would load the Google
 * Maps API or another mapping library here and populate the map with
 * markers retrieved via AJAX or embedded data attributes.
 */
/* global roroMap, jQuery */
( function ( $ ) {
    'use strict';
    $( function () {
        $( '.roro-map-container' ).each( function () {
            var $container   = $( this );
            // Next element to output list of events/spots
            var $listContainer = $container.next( '.roro-map-list' );
            // For demonstration purposes, set background colour
            $container.css( 'backgroundColor', '#e0e0e0' );
            // Fetch map data via AJAX
            $.post( roroMap.ajaxUrl, {
                action: 'roro_map_data',
                nonce:  roroMap.nonce
            }, function ( response ) {
                if ( response.success ) {
                    var html = '<ul class="roro-map-items">';
                    // Events
                    if ( response.data.events && response.data.events.length ) {
                        html += '<li><strong>Events</strong><ul>';
                        $.each( response.data.events, function ( i, event ) {
                            html += '<li>' +
                                '<span>' + event.title + '</span> ' +
                                '<button class="roro-fav-toggle" data-item-id="' + event.id + '" data-item-type="event">❤️</button>' +
                                '</li>';
                        } );
                        html += '</ul></li>';
                    }
                    // Spots
                    if ( response.data.spots && response.data.spots.length ) {
                        html += '<li><strong>Spots</strong><ul>';
                        $.each( response.data.spots, function ( i, spot ) {
                            html += '<li>' +
                                '<span>' + spot.name + '</span> ' +
                                '<button class="roro-fav-toggle" data-item-id="' + spot.id + '" data-item-type="spot">❤️</button>' +
                                '</li>';
                        } );
                        html += '</ul></li>';
                    }
                    html += '</ul>';
                    $listContainer.html( html );
                } else {
                    $listContainer.html( '<p>Error loading map data.</p>' );
                }
            } );
        } );
    } );
} )( jQuery );