<?php

/**
 * Map functionality for the Roro project.
 *
 * This class registers a shortcode that outputs a container for your map and
 * enqueues a JavaScript file that handles the front‑end map logic. To
 * integrate with Google Maps or other providers, modify the enqueue method
 * to register the appropriate API scripts and implement the JavaScript
 * accordingly.
 *
 * @since 1.0.0
 */
class Roro_Map_Plugin {
    /**
     * Register shortcode and enqueue scripts.
     */
    public function run() {
        add_shortcode( 'roro_map', array( $this, 'render_map' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        // Register AJAX endpoints for fetching map data.
        add_action( 'wp_ajax_roro_map_data', array( $this, 'ajax_get_map_data' ) );
        add_action( 'wp_ajax_nopriv_roro_map_data', array( $this, 'ajax_get_map_data' ) );
    }

    /**
     * Output the map container. You may output additional controls here.
     *
     * @return string HTML for the map container.
     */
    public function render_map() {
        $id = 'roro-map-container-' . wp_rand( 1000, 9999 );
        // Include a container for the map and a list for events/spots
        $output  = '<div id="' . esc_attr( $id ) . '" class="roro-map-container" style="width:100%;height:400px;"></div>';
        $output .= '<div class="roro-map-list"></div>';
        return $output;
    }

    /**
     * Enqueue front‑end JavaScript and styles.
     */
    public function enqueue_scripts() {
        // Enqueue our own script that handles map initialisation.
        wp_enqueue_script( 'roro-map-js', RORO_MAP_URL . 'assets/js/map.js', array( 'jquery' ), '1.0.0', true );
        // Optionally enqueue CSS for styling the map container.
        wp_enqueue_style( 'roro-map-css', RORO_MAP_URL . 'assets/css/map.css', array(), '1.0.0' );

        // Localize script with AJAX settings
        wp_localize_script( 'roro-map-js', 'roroMap', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'roro_map_nonce' ),
        ) );
    }

    /**
     * Handle AJAX request to fetch map data (events and spots).
     */
    public function ajax_get_map_data() {
        check_ajax_referer( 'roro_map_nonce', 'nonce' );
        global $wpdb;
        $events_table = $wpdb->prefix . 'roro_events';
        $spots_table  = $wpdb->prefix . 'roro_spots';
        // Fetch data
        $events = $wpdb->get_results( "SELECT id, title, description, latitude, longitude, event_date FROM $events_table", ARRAY_A );
        $spots  = $wpdb->get_results( "SELECT id, name, category, description, latitude, longitude FROM $spots_table", ARRAY_A );
        wp_send_json_success( array( 'events' => $events, 'spots' => $spots ) );
    }
}