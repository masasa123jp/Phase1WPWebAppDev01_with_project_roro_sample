<?php

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since 1.0.0
 * @package RoroCoreWp
 */
class Roro_Core_Wp_Activator {

    /**
     * Method to execute when the plugin is activated.
     * Creates the necessary database tables and sets default options.
     *
     * @since 1.0.0
     */
    public static function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Example of creating a table. Replace with actual SQL as required.
        $table_name = $wpdb->prefix . 'roro_example';
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (\n"
             . " id mediumint(9) NOT NULL AUTO_INCREMENT,\n"
             . " time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,\n"
             . " text varchar(255) NOT NULL,\n"
             . " PRIMARY KEY  (id)\n"
             . ") $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Method to execute when the plugin is deactivated.
     * Generally used to clear scheduled events or temporary data.
     *
     * @since 1.0.0
     */
    public static function deactivate() {
        // Deactivation tasks (no-op for now).
    }
}