<?php

/**
 * Handle database-related operations for the Roro Core plugin.
 *
 * This class is a centralized location for defining the names of your custom
 * tables and encapsulates methods for reading and writing data to those
 * tables. As you flesh out your plugin's functionality you can add more
 * methods here (for example, CRUD functions for different entities).
 *
 * @since 1.0.0
 * @package RoroCoreWp
 */
class Roro_Core_Wp_DB {
    /**
     * Get the full table name for the given table identifier.
     *
     * @param string $name Short table name suffix.
     * @return string Full table name with WordPress prefix.
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'roro_' . $name;
    }

    /**
     * Example method for inserting data into a custom table.
     *
     * @param string $text Text to insert.
     * @return int|false Inserted row ID or false on failure.
     */
    public function insert_example( $text ) {
        global $wpdb;
        return $wpdb->insert(
            self::table( 'example' ),
            array( 'text' => sanitize_text_field( $text ) ),
            array( '%s' )
        );
    }

    /**
     * Example method for fetching data from a custom table.
     *
     * @return array Array of results.
     */
    public function get_examples() {
        global $wpdb;
        $table = self::table( 'example' );
        return $wpdb->get_results( "SELECT * FROM $table ORDER BY id DESC", ARRAY_A );
    }
}