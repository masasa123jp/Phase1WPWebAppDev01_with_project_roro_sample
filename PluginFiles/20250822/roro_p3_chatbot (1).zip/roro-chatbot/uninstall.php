<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
delete_option('roro_chat_provider');
delete_option('roro_chat_dify_base');
delete_option('roro_chat_dify_endpoint');
delete_option('roro_chat_dify_api_key');
delete_option('roro_chat_dify_app_id');
delete_option('roro_chat_save_logs');
// 既定では会話ログはユーザー資産として残します。削除したい場合は下記コメントアウトを外す:
/*
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}roro_ai_message");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}roro_ai_conversation");
*/
