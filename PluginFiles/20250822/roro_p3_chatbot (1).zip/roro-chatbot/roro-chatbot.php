<?php
/**
 * Plugin Name:       Roro Chatbot
 * Description:       AI対話（Dify連携 / 疑似AI 切替）＋推薦導線（雑誌記事・イベント・スポット）。会話保存、REST/AJAX、ショートコードUIを提供。
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Project RORO
 * License:           GPL-2.0-or-later
 * Text Domain:       roro-chatbot
 * Domain Path:       /languages
 */
if (!defined('ABSPATH')) { exit; }

define('RORO_CHAT_VERSION', '1.0.0');
define('RORO_CHAT_PATH', plugin_dir_path(__FILE__));
define('RORO_CHAT_URL',  plugin_dir_url(__FILE__));
define('RORO_CHAT_BASENAME', plugin_basename(__FILE__));

// i18n
add_action('plugins_loaded', function(){
    load_plugin_textdomain('roro-chatbot', false, dirname(RORO_CHAT_BASENAME) . '/languages');
});

// includes
require_once RORO_CHAT_PATH . 'includes/class-roro-chatbot-admin.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chatbot-service.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chatbot-rest.php';
require_once RORO_CHAT_PATH . 'includes/class-roro-chatbot-render.php';

// bootstrap
add_action('admin_menu', ['Roro_Chatbot_Admin','add_settings_page']);
add_action('admin_init', ['Roro_Chatbot_Admin','register_settings']);
add_action('rest_api_init', ['Roro_Chatbot_REST','register_routes']);
add_action('init', ['Roro_Chatbot_Render','register_shortcodes']);

// assets
add_action('wp_enqueue_scripts', function(){
    wp_register_script('roro-chatbot', RORO_CHAT_URL . 'assets/js/roro-chatbot.js', [], RORO_CHAT_VERSION, true);
    wp_localize_script('roro-chatbot', 'roroChat', [
        'restUrl' => esc_url_raw( get_rest_url(null, '/roro/v1/chat') ),
        'restNonce' => wp_create_nonce('wp_rest'),
        'nonce' => wp_create_nonce('roro_chat'),
        'strings' => [
            'placeholder' => __('Type a message...', 'roro-chatbot'),
            'send' => __('Send', 'roro-chatbot'),
            'thinking' => __('Thinking...', 'roro-chatbot'),
            'error' => __('Error occurred', 'roro-chatbot'),
            'loginToFav' => __('Log in to add favorites.', 'roro-chatbot'),
            'addFav' => __('Add Favorite', 'roro-chatbot'),
            'removeFav' => __('Remove Favorite', 'roro-chatbot'),
        ]
    ]);
    wp_enqueue_script('roro-chatbot');
    wp_enqueue_style('roro-chatbot', RORO_CHAT_URL . 'assets/css/roro-chatbot.css', [], RORO_CHAT_VERSION);
});

register_activation_hook(__FILE__, function(){
    Roro_Chatbot_Service::create_tables();
    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function(){
    flush_rewrite_rules();
});
