<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Chatbot_REST {

    public static function register_routes() {
        register_rest_route('roro/v1', '/chat/new', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('roro/v1', '/chat/(?P<id>\d+)/send', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'send'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('roro/v1', '/chat/(?P<id>\d+)/history', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'history'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function create($req) {
        // CSRF: optional check
        $nonce = $req->get_header('X-WP-Nonce') ?: $req->get_param('_wpnonce');
        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            // allow anon creation but mark as untrusted
        }
        $user_id = get_current_user_id() ?: null;
        $provider = get_option('roro_chat_provider', 'pseudo');
        $c = Roro_Chatbot_Service::create_conversation($user_id, $provider);
        return rest_ensure_response(['ok'=>true] + $c);
    }

    public static function send($req) {
        $id = (int)$req['id'];
        $msg = (string)$req->get_param('message');
        if (!$msg) return new WP_REST_Response(['ok'=>false, 'message'=>'empty'], 400);

        // CSRF: require plugin nonce for write
        $nonce = $req->get_header('X-WP-Nonce') ?: $req->get_param('nonce');
        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_REST_Response(['ok'=>false, 'message'=>'forbidden'], 403);
        }

        $res = Roro_Chatbot_Service::send_and_reply($id, $msg);
        if (!empty($res['error'])) {
            return new WP_REST_Response(['ok'=>false, 'message'=>$res['error']], 500);
        }
        return rest_ensure_response(['ok'=>true, 'reply_html'=>$res['reply_html'], 'recommendations'=>$res['recommendations']]);
    }

    public static function history($req) {
        $id = (int)$req['id'];
        $rows = Roro_Chatbot_Service::get_history($id, 100);
        return rest_ensure_response(['ok'=>true, 'messages'=>$rows]);
    }
}
