<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Chatbot_Service {

    /** Create DB tables */
    public static function create_tables(): void {
        global $wpdb;
        $conv = $wpdb->prefix . 'roro_ai_conversation';
        $msg  = $wpdb->prefix . 'roro_ai_message';
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql1 = "CREATE TABLE {$conv} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            session_key VARCHAR(64) NOT NULL,
            provider VARCHAR(32) NOT NULL DEFAULT 'pseudo',
            meta LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            UNIQUE KEY uniq_session (session_key),
            KEY idx_user (user_id, id)
        ) {$charset};";
        dbDelta($sql1);

        $sql2 = "CREATE TABLE {$msg} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conv_id BIGINT UNSIGNED NOT NULL,
            role VARCHAR(16) NOT NULL,
            content LONGTEXT NOT NULL,
            meta LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            KEY idx_conv (conv_id, id)
        ) {$charset};";
        dbDelta($sql2);
    }

    /** Create a conversation */
    public static function create_conversation(?int $user_id, string $provider=''): array {
        global $wpdb;
        $provider = $provider ?: get_option('roro_chat_provider', 'pseudo');
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $now = current_time('mysql', 1);
        $session = 'sess_' . wp_generate_uuid4();
        $meta = ['steps'=>[], 'external'=>[]];
        $wpdb->insert($conv_table, [
            'user_id' => $user_id ?: null,
            'session_key' => $session,
            'provider' => $provider,
            'meta' => wp_json_encode($meta),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $id = (int)$wpdb->insert_id;
        return ['id'=>$id, 'session_key'=>$session, 'provider'=>$provider];
    }

    /** Load conversation row */
    public static function get_conversation(int $conv_id): ?array {
        global $wpdb;
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$conv_table} WHERE id=%d", $conv_id), ARRAY_A);
        return $row ?: null;
    }

    /** Append message */
    public static function add_message(int $conv_id, string $role, string $content, array $meta=[]): int {
        global $wpdb;
        $msg_table = $wpdb->prefix . 'roro_ai_message';
        $wpdb->insert($msg_table, [
            'conv_id' => $conv_id,
            'role' => sanitize_key($role),
            'content' => wp_kses_post($content),
            'meta' => wp_json_encode($meta ?: new stdClass()),
            'created_at' => current_time('mysql', 1),
        ]);
        $id = (int)$wpdb->insert_id;
        // touch conversation
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $wpdb->update($conv_table, ['updated_at'=>current_time('mysql',1)], ['id'=>$conv_id]);
        return $id;
    }

    /** Get history */
    public static function get_history(int $conv_id, int $limit=50): array {
        global $wpdb;
        $msg_table = $wpdb->prefix . 'roro_ai_message';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT role, content, meta, created_at FROM {$msg_table} WHERE conv_id=%d ORDER BY id ASC LIMIT %d", $conv_id, max(1, min(500, $limit))), ARRAY_A);
        if (!$rows) return [];
        foreach ($rows as &$r) {
            $r['meta'] = $r['meta'] ? json_decode($r['meta'], true) : [];
        }
        return $rows;
    }

    /** Send user message and get assistant reply */
    public static function send_and_reply(int $conv_id, string $user_text): array {
        $conv = self::get_conversation($conv_id);
        if (!$conv) return ['error'=>'conversation_not_found'];
        $provider = $conv['provider'] ?: get_option('roro_chat_provider','pseudo');

        // Save user message
        self::add_message($conv_id, 'user', $user_text, []);

        // Router
        if ($provider === 'dify') {
            $res = self::reply_via_dify($conv, $user_text);
        } else {
            $res = self::reply_via_pseudo($conv, $user_text);
        }

        // Save assistant message
        if (empty($res['error'])) {
            $meta = ['provider'=>$provider, 'recommendations'=>$res['recommendations'] ?? []];
            self::add_message($conv_id, 'assistant', $res['reply_html'], $meta);
        }

        return $res;
    }

    /** Dify provider */
    private static function reply_via_dify(array $conv, string $user_text): array {
        $base = rtrim(get_option('roro_chat_dify_base','https://api.dify.ai'), '/');
        $ep   = '/' . ltrim(get_option('roro_chat_dify_endpoint','/v1/chat-messages'), '/');
        $url  = $base . $ep;
        $key  = get_option('roro_chat_dify_api_key','');
        $app  = get_option('roro_chat_dify_app_id','');

        if (!$key || !$url) {
            return ['error'=>'dify_not_configured', 'reply_html'=>'<p>Provider not configured.</p>'];
        }

        // Build payload (generic Dify chat-messages style)
        $payload = [
            'inputs' => new stdClass(), // appが要求する追加パラメータを管理画面に合わせて拡張可
            'query'  => $user_text,
            'user'   => get_current_user_id() ? ('wp-' . get_current_user_id()) : ('anon-' . self::session_hash()),
            'response_mode' => 'blocking',
        ];
        // カンバセーションIDがあればメタから送る
        $meta = $conv['meta'] ? json_decode($conv['meta'], true) : [];
        if (!empty($meta['external']['dify_conversation_id'])) {
            $payload['conversation_id'] = $meta['external']['dify_conversation_id'];
        }
        if ($app) {
            $payload['app_id'] = $app;
        }

        $args = [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ];
        $resp = wp_remote_post($url, $args);
        if (is_wp_error($resp)) {
            return ['error'=>'http_error', 'reply_html'=>'<p>Network error.</p>'];
        }
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        // Generic parse
        $answer = '';
        if (isset($body['answer'])) $answer = (string)$body['answer'];
        elseif (isset($body['data'])) $answer = is_string($body['data']) ? $body['data'] : wp_json_encode($body['data']);
        elseif (isset($body['message'])) $answer = (string)$body['message'];
        else $answer = wp_remote_retrieve_body($resp);

        // conversation_id 取得して保存
        if (!empty($body['conversation_id'])) {
            $meta['external']['dify_conversation_id'] = $body['conversation_id'];
            self::update_conv_meta((int)$conv['id'], $meta);
        }

        $reply_html = wpautop(esc_html($answer));
        return ['reply_html'=>$reply_html, 'recommendations'=>[]];
    }

    private static function session_hash(): string {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        return substr(md5($ip . '|' . $ua . '|' . time()), 0, 12);
    }

    /** Pseudo provider: guided dialog + WP検索による推薦 */
    private static function reply_via_pseudo(array $conv, string $user_text): array {
        // 1) 簡易ガイドフロー
        $meta = $conv['meta'] ? json_decode($conv['meta'], true) : ['steps'=>[]];
        $steps = $meta['steps'] ?? [];
        $state = [
            'pet_type' => $steps['pet_type'] ?? null,   // dog/cat/other
            'pet_age'  => $steps['pet_age'] ?? null,    // puppy/adult/senior
            'topic'    => $steps['topic'] ?? null,      // heat, travel, training, health, event
        ];

        $lower = strtolower(wp_strip_all_tags($user_text));
        // Extract simple keywords
        foreach (['dog','cat','puppy','kitten','senior','travel','trip','heat','summer','cool','training','walk','event','festival','park'] as $kw) {
            if (strpos($lower, $kw) !== false) {
                if (in_array($kw, ['dog','puppy'])) $state['pet_type'] = 'dog';
                if (in_array($kw, ['cat','kitten'])) $state['pet_type'] = 'cat';
                if ($kw === 'puppy') $state['pet_age'] = 'puppy';
                if ($kw === 'senior') $state['pet_age'] = 'senior';
                if (in_array($kw, ['travel','trip'])) $state['topic'] = 'travel';
                if (in_array($kw, ['heat','summer','cool'])) $state['topic'] = 'heat';
                if ($kw === 'training') $state['topic'] = 'training';
                if (in_array($kw, ['event','festival','park'])) $state['topic'] = 'event';
            }
        }
        // Japanese keywords (簡易)
        $jp = [
            '犬'=>'dog','猫'=>'cat','子犬'=>'puppy','子猫'=>'kitten','老犬'=>'senior','老猫'=>'senior',
            '旅行'=>'travel','おでかけ'=>'travel','熱中症'=>'heat','夏'=>'heat','涼'=>'heat','しつけ'=>'training','イベント'=>'event','公園'=>'event'
        ];
        foreach ($jp as $k=>$v) { if (mb_stripos($user_text, $k) !== false) {
            if (in_array($v, ['dog','cat'])) $state['pet_type'] = $v;
            if ($v === 'puppy') $state['pet_age'] = 'puppy';
            if ($v === 'senior') $state['pet_age'] = 'senior';
            if (in_array($v, ['travel','heat','training','event'])) $state['topic'] = $v;
        }}

        // Ask missing info
        if (!$state['pet_type']) {
            $reply = 'わんちゃん・ねこちゃん、どちら向けの情報をご希望ですか？（例：「犬」「猫」）';
            $meta['steps']['pet_type'] = null;
            self::update_conv_meta((int)$conv['id'], $meta);
            return ['reply_html'=>'<p>'.$reply.'</p>', 'recommendations'=>[]];
        }
        if (!$state['pet_age']) {
            $reply = '年齢層も教えてください。（例：「子犬／成犬／シニア」）';
            $meta['steps']['pet_type'] = $state['pet_type'];
            $meta['steps']['pet_age'] = null;
            self::update_conv_meta((int)$conv['id'], $meta);
            return ['reply_html'=>'<p>'.$reply.'</p>', 'recommendations'=>[]];
        }
        if (!$state['topic']) {
            $reply = '知りたいテーマは？（「熱中症対策」「おでかけ」「しつけ」「イベント」など）';
            $meta['steps']['pet_type'] = $state['pet_type'];
            $meta['steps']['pet_age'] = $state['pet_age'];
            $meta['steps']['topic'] = null;
            self::update_conv_meta((int)$conv['id'], $meta);
            return ['reply_html'=>'<p>'.$reply.'</p>', 'recommendations'=>[]];
        }

        // Save state
        $meta['steps'] = $state;
        self::update_conv_meta((int)$conv['id'], $meta);

        // 2) 検索（roro_mag_article 優先）
        $query_terms = [];
        $map = [
            'dog'=>'犬', 'cat'=>'猫', 'puppy'=>'子犬', 'senior'=>'シニア',
            'heat'=>'熱中症', 'travel'=>'おでかけ', 'training'=>'しつけ', 'event'=>'イベント',
        ];
        foreach (['pet_type','pet_age','topic'] as $k) {
            if (!empty($state[$k]) && !empty($map[$state[$k]])) $query_terms[] = $map[$state[$k]];
        }
        $q = implode(' ', $query_terms);
        $posts = get_posts([
            'post_type'=>'roro_mag_article',
            's' => $q ?: $user_text,
            'posts_per_page'=>5,
            'suppress_filters'=>false,
        ]);
        // fallback: general posts
        if (empty($posts)) {
            $posts = get_posts([
                'post_type'=>['roro_mag_article','post'],
                's'=>$q ?: $user_text,
                'posts_per_page'=>5,
                'suppress_filters'=>false,
            ]);
        }

        $recs = [];
        foreach ($posts as $p) {
            $recs[] = [
                'type' => 'article',
                'id'   => (int)$p->ID,
                'title'=> get_the_title($p),
                'url'  => get_permalink($p),
            ];
        }

        // 3) 返信整形
        $lines = [];
        $lines[] = sprintf('【条件】%s / %s / %s',
            $state['pet_type']==='dog'?'犬':'猫',
            $state['pet_age']==='puppy'?'子ども':'シニア' if ($state['pet_age']==='senior') else '成長期' if ($state['pet_age']==='puppy') else '成犬',
            ['heat'=>'熱中症','travel'=>'おでかけ','training'=>'しつけ','event'=>'イベント'][$state['topic']]
        );
        if ($recs) {
            $lines[] = 'おすすめ記事：';
            $i=1;
            foreach ($recs as $r) {
                $lines[] = sprintf('%d) %s', $i++, $r['title']);
            }
        } else {
            $lines[] = '該当する記事が見つかりませんでした。別のキーワードでもお試しください。';
        }

        $reply_html = '<p>' . esc_html(implode("\n", $lines)) . '</p>';
        return ['reply_html'=>$reply_html, 'recommendations'=>$recs];
    }

    /** Update conversation meta (merge) */
    private static function update_conv_meta(int $conv_id, array $meta): void {
        global $wpdb;
        $conv_table = $wpdb->prefix . 'roro_ai_conversation';
        $wpdb->update($conv_table, [
            'meta' => wp_json_encode($meta),
            ], ['id'=>$conv_id]);
    }
}
