<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Chatbot_Admin {

    public static function add_settings_page() {
        add_options_page(
            __('Roro Chatbot', 'roro-chatbot'),
            __('Roro Chatbot', 'roro-chatbot'),
            'manage_options',
            'roro-chatbot',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        register_setting('roro_chatbot', 'roro_chat_provider', [
            'type' => 'string',
            'sanitize_callback' => function($v){
                $v = strtolower(sanitize_text_field($v));
                return in_array($v, ['dify','pseudo'], true) ? $v : 'pseudo';
            },
            'default' => 'pseudo',
        ]);

        register_setting('roro_chatbot', 'roro_chat_dify_base', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => 'https://api.dify.ai',
        ]);

        register_setting('roro_chatbot', 'roro_chat_dify_endpoint', [
            'type' => 'string',
            'sanitize_callback' => function($v){ $v = trim(sanitize_text_field($v)); return $v ?: '/v1/chat-messages'; },
            'default' => '/v1/chat-messages',
        ]);

        register_setting('roro_chatbot', 'roro_chat_dify_api_key', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);

        register_setting('roro_chatbot', 'roro_chat_dify_app_id', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);

        register_setting('roro_chatbot', 'roro_chat_save_logs', [
            'type' => 'boolean',
            'sanitize_callback' => fn($v)=>(bool)$v,
            'default' => true,
        ]);
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) wp_die(esc_html__('You do not have permission', 'roro-chatbot'));
        ?>
        <div class="wrap">
          <h1><?php echo esc_html__('Roro Chatbot Settings', 'roro-chatbot'); ?></h1>
          <form method="post" action="options.php">
            <?php settings_fields('roro_chatbot'); ?>
            <h2><?php echo esc_html__('Provider', 'roro-chatbot'); ?></h2>
            <table class="form-table" role="presentation">
              <tr>
                <th scope="row"><?php echo esc_html__('Provider', 'roro-chatbot'); ?></th>
                <td>
                  <?php $p = get_option('roro_chat_provider','pseudo'); ?>
                  <select name="roro_chat_provider">
                    <option value="pseudo" <?php selected($p,'pseudo'); ?>>pseudo (built-in)</option>
                    <option value="dify" <?php selected($p,'dify'); ?>>Dify</option>
                  </select>
                </td>
              </tr>
            </table>
            <h2><?php echo esc_html__('Dify', 'roro-chatbot'); ?></h2>
            <table class="form-table" role="presentation">
              <tr><th>Base URL</th><td><input type="url" name="roro_chat_dify_base" class="regular-text" value="<?php echo esc_attr(get_option('roro_chat_dify_base','https://api.dify.ai')); ?>"></td></tr>
              <tr><th>Endpoint Path</th><td><input type="text" name="roro_chat_dify_endpoint" class="regular-text" value="<?php echo esc_attr(get_option('roro_chat_dify_endpoint','/v1/chat-messages')); ?>"><p class="description">例: /v1/chat-messages</p></td></tr>
              <tr><th>API Key</th><td><input type="password" name="roro_chat_dify_api_key" class="regular-text" value="<?php echo esc_attr(get_option('roro_chat_dify_api_key','')); ?>"></td></tr>
              <tr><th>App ID</th><td><input type="text" name="roro_chat_dify_app_id" class="regular-text" value="<?php echo esc_attr(get_option('roro_chat_dify_app_id','')); ?>"></td></tr>
            </table>
            <h2><?php echo esc_html__('Logging', 'roro-chatbot'); ?></h2>
            <table class="form-table" role="presentation">
              <tr><th><?php echo esc_html__('Save Conversation Logs', 'roro-chatbot'); ?></th><td><label><input type="checkbox" name="roro_chat_save_logs" value="1" <?php checked(get_option('roro_chat_save_logs',true)); ?>> <?php echo esc_html__('Store conversations in DB (PII注意)', 'roro-chatbot'); ?></label></td></tr>
            </table>
            <?php submit_button(); ?>
          </form>
        </div>
        <?php
    }
}
