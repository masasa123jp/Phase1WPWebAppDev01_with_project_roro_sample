<?php
if (!defined('ABSPATH')) { exit; }

final class Roro_Chatbot_Render {

    public static function register_shortcodes() {
        add_shortcode('roro_chat', [__CLASS__,'shortcode']);
    }

    public static function shortcode($atts) {
        $atts = shortcode_atts([
            'title' => __('AI アシスタント', 'roro-chatbot'),
            'welcome' => __('こんにちは！ペットの情報やお悩みを教えてください。最適な記事やスポットをおすすめします。', 'roro-chatbot'),
        ], $atts, 'roro_chat');

        ob_start();
        ?>
        <div class="roro-chat" data-provider="<?php echo esc_attr(get_option('roro_chat_provider','pseudo')); ?>">
          <div class="roro-chat__header">
            <h3><?php echo esc_html($atts['title']); ?></h3>
          </div>
          <div class="roro-chat__body js-chat-body">
            <div class="roro-chat__msg roro-chat__msg--assistant">
              <div class="roro-chat__bubble"><?php echo esc_html($atts['welcome']); ?></div>
            </div>
          </div>
          <div class="roro-chat__footer">
            <input type="text" class="js-chat-input" placeholder="<?php esc_attr_e('Type a message...', 'roro-chatbot'); ?>">
            <button class="js-chat-send"><?php esc_html_e('Send', 'roro-chatbot'); ?></button>
          </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
