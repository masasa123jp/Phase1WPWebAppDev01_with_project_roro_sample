(function(){
  'use strict';
  function h(html){ return html; } // server-side escapes
  function el(sel, root){ return (root||document).querySelector(sel); }
  function ce(tag, cls){ const e=document.createElement(tag); if(cls)e.className=cls; return e; }

  function appendMsg(body, role, html){
    const wrap = ce('div', 'roro-chat__msg roro-chat__msg--' + role);
    const bubble = ce('div', 'roro-chat__bubble');
    bubble.innerHTML = h(html);
    wrap.appendChild(bubble);
    body.appendChild(wrap);
    body.scrollTop = body.scrollHeight;
  }

  function appendRecommendations(body, recs){
    if (!recs || !recs.length) return;
    const list = ce('div', 'roro-chat__recs');
    const title = ce('div', 'roro-chat__recs__title'); title.textContent = 'おすすめ';
    list.appendChild(title);
    recs.forEach(function(r){
      const item = ce('div', 'roro-chat__recs__item');
      const a = ce('a'); a.href = r.url; a.textContent = r.title; a.target = '_blank';
      item.appendChild(a);
      // favorite button (article only)
      if (r.type === 'article' && window.roroMagazine) {
        const b = ce('button'); b.textContent = roroChat.strings.addFav; b.className = 'roro-chat__fav';
        b.addEventListener('click', function(ev){
          ev.preventDefault();
          // Use roro-magazine AJAX to toggle
          const fd = new FormData();
          fd.append('action', 'roro_mag_toggle_fav');
          fd.append('nonce', roroMagazine.nonce);
          fd.append('post_id', r.id);
          fetch(roroMagazine.ajaxUrl, {method:'POST', credentials:'same-origin', body:fd})
            .then(r=>r.json()).then(function(j){
              if (j && j.success && j.data) {
                b.textContent = j.data.favorited ? roroChat.strings.removeFav : roroChat.strings.addFav;
              } else if (j && j.data && j.data.message) {
                alert(j.data.message);
              } else {
                alert(roroChat.strings.error);
              }
            }).catch(function(){ alert(roroChat.strings.error); });
        });
        item.appendChild(b);
      }
      list.appendChild(item);
    });
    body.appendChild(list);
  }

  function init(root){
    const body = el('.js-chat-body', root);
    const input = el('.js-chat-input', root);
    const sendBtn = el('.js-chat-send', root);
    let convId = null;

    function ensureConversation(){
      if (convId) return Promise.resolve(convId);
      return fetch(roroChat.restUrl + '/new', {
        method:'POST',
        headers: {'X-WP-Nonce': roroChat.restNonce}
      }).then(r=>r.json()).then(function(j){
        if (j && j.ok && j.id) { convId = j.id; return convId; }
        throw new Error('conv create failed');
      });
    }

    function send(){
      const text = (input.value || '').trim();
      if (!text) return;
      appendMsg(body, 'user', text.replace(/[&<>]/g, s=>({ '&':'&amp;','<':'&lt;','>':'&gt;' }[s])));
      input.value = '';
      const wait = ce('div','roro-chat__msg roro-chat__msg--assistant');
      const bubble = ce('div','roro-chat__bubble'); bubble.textContent = roroChat.strings.thinking; wait.appendChild(bubble); body.appendChild(wait); body.scrollTop=body.scrollHeight;

      ensureConversation().then(function(){
        return fetch(roroChat.restUrl + '/' + convId + '/send', {
          method:'POST',
          headers: {'Content-Type':'application/json','X-WP-Nonce': roroChat.restNonce},
          body: JSON.stringify({message:text, nonce: roroChat.restNonce})
        });
      }).then(r=>r.json()).then(function(j){
        wait.remove();
        if (j && j.ok) {
          appendMsg(body, 'assistant', j.reply_html || '');
          appendRecommendations(body, j.recommendations || []);
        } else {
          appendMsg(body, 'assistant', '<p>' + roroChat.strings.error + '</p>');
        }
      }).catch(function(){
        wait.remove();
        appendMsg(body, 'assistant', '<p>' + roroChat.strings.error + '</p>');
      });
    }

    sendBtn.addEventListener('click', function(e){ e.preventDefault(); send(); });
    input.addEventListener('keydown', function(e){ if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
  }

  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.roro-chat').forEach(init);
  });
})();
