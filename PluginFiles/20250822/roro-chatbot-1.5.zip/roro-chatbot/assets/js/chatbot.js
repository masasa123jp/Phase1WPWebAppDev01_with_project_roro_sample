/* global roroChatbot, jQuery */
/* global roroChatbot, jQuery */
( function ( $ ) {
    'use strict';
    $( function () {
        var $chatbot      = $( '.roro-chatbot' );
        if ( ! $chatbot.length ) {
            return;
        }
        // Store conversation ID in memory
        var conversationId = null;
        $chatbot.on( 'submit', '.roro-chatbot-form', function ( e ) {
            e.preventDefault();
            var $form   = $( this );
            var message = $form.find( '.roro-chatbot-input' ).val();
            if ( ! message ) {
                return;
            }
            var $messages = $chatbot.find( '.roro-chatbot-messages' );
            // Append user message
            $messages.append( '<div class="roro-chatbot-message user-message">' + message + '</div>' );
            $form.find( '.roro-chatbot-input' ).val( '' );
            var data = {
                action:  'roro_chat',
                nonce:   roroChatbot.nonce,
                message: message
            };
            if ( conversationId ) {
                data.conversation_id = conversationId;
            }
            $.post( roroChatbot.ajaxUrl, data, function ( response ) {
                if ( response.success ) {
                    // If conversation id returned, store it
                    if ( response.data.conversation_id ) {
                        conversationId = response.data.conversation_id;
                    }
                    $messages.append( '<div class="roro-chatbot-message bot-message">' + response.data.reply + '</div>' );
                } else {
                    var error = ( response.data && response.data.message ) ? response.data.message : 'Error';
                    $messages.append( '<div class="roro-chatbot-message error-message">' + error + '</div>' );
                }
            } );
        } );
    } );
} )( jQuery );