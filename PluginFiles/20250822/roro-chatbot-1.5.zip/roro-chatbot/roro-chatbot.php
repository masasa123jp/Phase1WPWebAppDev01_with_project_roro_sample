<?php
/**
 * Plugin Name:       Roro Chatbot
 * Plugin URI:        https://example.com/roro-chatbot
 * Description:       Integrates an AI chatbot into your WordPress site via a shortcode.
 *                    This skeleton implementation defines the shortcode and
 *                    necessary AJAX callbacks. To complete the integration you
 *                    should connect to your chosen AI provider using wp_remote_post()
 *                    and handle authentication securely.
 * Version:           1.5.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-chatbot
 * Domain Path:       /languages
 *
 * @package RoroChatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_CHATBOT_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_CHATBOT_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_CHATBOT_DIR . 'includes/class-roro-chatbot.php';

/**
 * Perform setup tasks when the plugin is activated.
 *
 * Creates custom tables for AI conversation and messages.
 */
function roro_chatbot_activate() {
    global $wpdb;
    $charset_collate     = $wpdb->get_charset_collate();
    $conversations_table = $wpdb->prefix . 'roro_ai_conversations';
    $messages_table      = $wpdb->prefix . 'roro_ai_messages';
    $sql_conv            = "CREATE TABLE $conversations_table (\n"
                         . "id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n"
                         . "user_id BIGINT(20) UNSIGNED DEFAULT NULL,\n"
                         . "created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,\n"
                         . "PRIMARY KEY (id)\n"
                         . ") $charset_collate;";
    $sql_messages        = "CREATE TABLE $messages_table (\n"
                         . "id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n"
                         . "conversation_id BIGINT(20) UNSIGNED NOT NULL,\n"
                         . "user_id BIGINT(20) UNSIGNED DEFAULT NULL,\n"
                         . "role VARCHAR(20) NOT NULL,\n"
                         . "content TEXT NOT NULL,\n"
                         . "created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,\n"
                         . "PRIMARY KEY (id),\n"
                         . "KEY convo (conversation_id)\n"
                         . ") $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql_conv );
    dbDelta( $sql_messages );
}

register_activation_hook( __FILE__, 'roro_chatbot_activate' );

function roro_chatbot_run() {
    $bot = new Roro_Chatbot_Plugin();
    $bot->run();
}
add_action( 'plugins_loaded', 'roro_chatbot_run' );