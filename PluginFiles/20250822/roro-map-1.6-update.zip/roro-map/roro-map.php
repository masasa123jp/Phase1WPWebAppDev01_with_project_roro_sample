<?php
/**
 * Plugin Name: Roro Map
 * Description: 地図UI、ホーム位置保存、クラスタリング/距離ソート補助
 * Version: 1.6.0-rc.1
 * Requires at least: 6.3
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Text Domain: roro-map
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/public/class-roro-map-home.php';
