window.RoroMapCluster = (function(){
  function haversine(a, b) {
    const toRad = d => d * Math.PI / 180;
    const R = 6371;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const s1 = Math.sin(dLat/2), s2 = Math.sin(dLng/2);
    const h = s1*s1 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * s2*s2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }
  function sortByDistance(markers, origin) {
    return markers.slice().sort((m1, m2) => {
      const p1 = m1.getPosition(), p2 = m2.getPosition();
      const d1 = haversine({lat:origin.lat, lng:origin.lng}, {lat:p1.lat(), lng:p1.lng()});
      const d2 = haversine({lat:origin.lat, lng:origin.lng}, {lat:p2.lat(), lng:p2.lng()});
      return d1 - d2;
    });
  }
  function init(map, markers, opts) {
    opts = opts || {};
    const home = opts.home || null;
    if (home) {
      const sorted = sortByDistance(markers, home);
      const order = sorted.map(m => m.__roro_id || null).filter(Boolean);
      document.dispatchEvent(new CustomEvent('roroMap:sortedByDistance', { detail: { order, home } }));
    }
    if (window.MarkerClusterer && markers && markers.length) {
      const clusterer = new MarkerClusterer({ map, markers });
      return clusterer;
    } else { return null; }
  }
  return { init, sortByDistance, haversine };
})();
