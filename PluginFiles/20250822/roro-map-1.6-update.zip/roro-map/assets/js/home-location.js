(function(){
  let map, marker, picked = null;
  function initMap() {
    const el = document.getElementById('roro-home-map');
    if (!el) return;
    const center = { lat: 35.681236, lng: 139.767125 };
    map = new google.maps.Map(el, { center, zoom: 11, mapTypeControl: false });
    map.addListener('click', (ev) => {
      const pos = { lat: ev.latLng.lat(), lng: ev.latLng.lng() };
      if (!marker) { marker = new google.maps.Marker({ position: pos, map }); }
      else { marker.setPosition(pos); }
      picked = pos;
      document.getElementById('roro-home-save').disabled = false;
      setStatus('');
    });
    setStatus(RoroHomeCfg.i18n.clickToSet);
  }
  function setStatus(msg) {
    const s = document.getElementById('roro-home-status');
    if (s) s.textContent = msg || '';
  }
  function save() {
    if (!picked) return;
    setStatus(RoroHomeCfg.i18n.saving);
    fetch(RoroHomeCfg.restUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': RoroHomeCfg.nonce },
      body: JSON.stringify({ lat: picked.lat, lng: picked.lng })
    }).then(r => { if (!r.ok) throw new Error('bad'); return r.json(); })
      .then(() => { setStatus(RoroHomeCfg.i18n.saved); })
      .catch(() => { setStatus(RoroHomeCfg.i18n.error); });
  }
  document.addEventListener('click', (e) => { if (e.target && e.target.id === 'roro-home-save') save(); });
  if (window.google && google.maps) { window.addEventListener('load', initMap); }
  else {
    document.addEventListener('DOMContentLoaded', () => {
      if (window.google && google.maps) initMap();
      else {
        const timer = setInterval(() => { if (window.google && google.maps) { clearInterval(timer); initMap(); } }, 250);
      }
    });
  }
})();
