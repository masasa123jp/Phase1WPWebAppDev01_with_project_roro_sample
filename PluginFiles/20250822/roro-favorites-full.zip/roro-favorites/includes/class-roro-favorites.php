<?php

/**
 * Favourites functionality for Roro.
 *
 * Registers AJAX handlers for adding and removing favourites and a shortcode
 * to display the current user’s favourites. This implementation stores
 * favourites in user meta as a proof of concept. You may want to migrate
 * the data to a custom table for better performance and flexibility.
 *
 * @since 1.0.0
 */
class Roro_Favorites_Plugin {
    /**
     * Kick things off by registering hooks and AJAX actions.
     */
    public function run() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_ajax_roro_fav_toggle', array( $this, 'toggle_favorite' ) );
        add_action( 'wp_ajax_nopriv_roro_fav_toggle', array( $this, 'auth_required' ) );
        add_shortcode( 'roro_favorites', array( $this, 'render_favorites' ) );
    }

    /**
     * Enqueue JavaScript for handling favourite toggles.
     */
    public function enqueue_scripts() {
        wp_enqueue_script( 'roro-favorites-js', RORO_FAVORITES_URL . 'assets/js/favorites.js', array( 'jquery' ), '1.0.0', true );
        wp_localize_script( 'roro-favorites-js', 'roroFavorites', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'roro_fav_toggle' ),
        ) );
    }

    /**
     * AJAX callback to add or remove a favourite.
     */
    public function toggle_favorite() {
        check_ajax_referer( 'roro_fav_toggle', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'roro-favorites' ) ), 401 );
        }
        $user_id = get_current_user_id();
        $item_id = absint( $_POST['item_id'] ?? 0 );
        if ( ! $item_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid item.', 'roro-favorites' ) ), 400 );
        }
        $favs = get_user_meta( $user_id, '_roro_favorites', true );
        if ( ! is_array( $favs ) ) {
            $favs = array();
        }
        if ( in_array( $item_id, $favs, true ) ) {
            // Remove
            $favs = array_diff( $favs, array( $item_id ) );
            $action = 'removed';
        } else {
            $favs[] = $item_id;
            $action  = 'added';
        }
        update_user_meta( $user_id, '_roro_favorites', $favs );
        wp_send_json_success( array( 'action' => $action, 'favorites' => $favs ) );
    }

    /**
     * Respond to unauthenticated AJAX requests.
     */
    public function auth_required() {
        wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'roro-favorites' ) ), 401 );
    }

    /**
     * Render the user’s favourites as a list.
     *
     * @return string HTML output.
     */
    public function render_favorites() {
        if ( ! is_user_logged_in() ) {
            return '<p>' . esc_html__( 'Please log in to view your favourites.', 'roro-favorites' ) . '</p>';
        }
        $user_id = get_current_user_id();
        $favs    = get_user_meta( $user_id, '_roro_favorites', true );
        if ( empty( $favs ) || ! is_array( $favs ) ) {
            return '<p>' . esc_html__( 'You have no favourites.', 'roro-favorites' ) . '</p>';
        }
        $output = '<ul class="roro-favorites-list">';
        foreach ( $favs as $fav_id ) {
            $output .= '<li>' . esc_html( $fav_id ) . '</li>';
        }
        $output .= '</ul>';
        return $output;
    }
}