roro-core-wp/assets 配下の格納サンプル
--------------------------------------
1) 画像: roro-core-wp/assets/images/…
   例) logo_roro.png, icon_map.png など

2) SQL:
   - スキーマ: roro-core-wp/assets/sql/schema/DDL_20250822_sample.sql
   - 初期データ: roro-core-wp/assets/sql/seed/initial_data_sample.sql

※ 実運用では sample を決定版DDL/seed に置き換え、
   WP管理「ツール → Roro DB Importer」で実行してください。
