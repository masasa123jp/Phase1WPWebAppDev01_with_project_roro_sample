-- initial_data_sample.sql (サンプル)
INSERT INTO RORO_CATEGORY_MASTER(category_code, category_name, sort_order) VALUES
  ('A','お出かけ',10),('B','しつけ',20),('C','防災',30);
