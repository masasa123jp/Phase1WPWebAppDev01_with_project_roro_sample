<?php
/**
 * Plugin Name:       Roro Authentication
 * Plugin URI:        https://example.com/roro-auth
 * Description:       Handles registration and login synchronization between WordPress and
 *                    the Roro platform. This plugin demonstrates how to hook into
 *                    WordPress user actions and synchronise data to a custom database
 *                    schema. It includes basic shortcodes for registration and login
 *                    forms. Security best practices such as nonce verification and
 *                    sanitization are observed where applicable.
 * Version:           1.5.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-auth
 * Domain Path:       /languages
 *
 * @package RoroAuth
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_AUTH_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_AUTH_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_AUTH_DIR . 'includes/class-roro-auth.php';

/**
 * Perform setup tasks when the plugin is activated.
 *
 * Creates custom tables for storing user profile data and pet information.
 */
function roro_auth_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $profiles_table = $wpdb->prefix . 'roro_profiles';
    $pets_table     = $wpdb->prefix . 'roro_pets';

    // Table for storing extended profile information.
    $sql_profiles = "CREATE TABLE $profiles_table (\n"
                 . "id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n"
                 . "user_id BIGINT(20) UNSIGNED NOT NULL,\n"
                 . "first_name VARCHAR(100) NOT NULL,\n"
                 . "last_name VARCHAR(100) NOT NULL,\n"
                 . "address VARCHAR(255) DEFAULT '',\n"
                 . "PRIMARY KEY  (id),\n"
                 . "KEY user_id (user_id)\n"
                 . ") $charset_collate;";

    // Table for storing user pets. Each row represents one pet for a user.
    $sql_pets = "CREATE TABLE $pets_table (\n"
             . "id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n"
             . "profile_id BIGINT(20) UNSIGNED NOT NULL,\n"
             . "pet_name VARCHAR(100) NOT NULL,\n"
             . "PRIMARY KEY  (id),\n"
             . "KEY profile_id (profile_id)\n"
             . ") $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql_profiles );
    dbDelta( $sql_pets );
}

register_activation_hook( __FILE__, 'roro_auth_activate' );

// Initialize plugin after all plugins loaded.
function roro_auth_run() {
    $roro_auth = new Roro_Auth_Plugin();
    $roro_auth->run();
}
add_action( 'plugins_loaded', 'roro_auth_run' );