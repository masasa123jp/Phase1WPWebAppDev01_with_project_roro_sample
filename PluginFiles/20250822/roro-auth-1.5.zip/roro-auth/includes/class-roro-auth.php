<?php

/**
 * Authentication integration for the Roro platform.
 *
 * This class hooks into WordPress user actions such as registration and login
 * to keep data in sync with the Roro-specific tables. It also registers
 * shortcodes for frontend forms. The actual storage logic has been left
 * intentionally minimal; you should extend the methods with calls to your
 * custom tables via $wpdb->insert/update() or your own data abstraction.
 *
 * @since 1.0.0
 */
class Roro_Auth_Plugin {
    /**
     * Register hooks and shortcodes.
     */
    public function run() {
        add_action( 'user_register', array( $this, 'on_user_register' ), 10, 1 );
        add_action( 'wp_login', array( $this, 'on_user_login' ), 10, 2 );

        add_shortcode( 'roro_register_form', array( $this, 'render_registration_form' ) );
        add_shortcode( 'roro_login_form', array( $this, 'render_login_form' ) );

        // Profile edit form shortcode for logged‑in users.
        add_shortcode( 'roro_profile_form', array( $this, 'render_profile_form' ) );
    }

    /**
     * Synchronise newly created users to the Roro system.
     *
     * @param int $user_id ID of the newly registered user.
     */
    public function on_user_register( $user_id ) {
        // Example: Insert mapping row into custom table
        // global $wpdb;
        // $wpdb->insert( $wpdb->prefix . 'roro_user_link', array( 'wp_user_id' => $user_id ), array( '%d' ) );

        // When a user registers via our form, save extended profile information
        if ( isset( $_POST['first_name'], $_POST['last_name'] ) ) {
            global $wpdb;
            $profiles_table = $wpdb->prefix . 'roro_profiles';
            $first_name     = sanitize_text_field( $_POST['first_name'] );
            $last_name      = sanitize_text_field( $_POST['last_name'] );
            $address        = isset( $_POST['address'] ) ? sanitize_text_field( $_POST['address'] ) : '';
            $wpdb->insert( $profiles_table, array(
                'user_id'    => $user_id,
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'address'    => $address,
            ), array( '%d', '%s', '%s', '%s' ) );
            $profile_id = $wpdb->insert_id;
            // Save the pet if provided
            if ( ! empty( $_POST['pet_name'] ) ) {
                $pet_name   = sanitize_text_field( $_POST['pet_name'] );
                $pets_table = $wpdb->prefix . 'roro_pets';
                $wpdb->insert( $pets_table, array(
                    'profile_id' => $profile_id,
                    'pet_name'   => $pet_name,
                ), array( '%d', '%s' ) );
            }
        }
    }

    /**
     * Handle user login events.
     *
     * @param string $user_login Username.
     * @param WP_User $user User object.
     */
    public function on_user_login( $user_login, $user ) {
        // Placeholder for login synchronisation logic.
    }

    /**
     * Render a simple registration form.
     *
     * @return string HTML output.
     */
    public function render_registration_form() {
        if ( is_user_logged_in() ) {
            return '<p>' . esc_html__( 'You are already registered.', 'roro-auth' ) . '</p>';
        }

        if ( isset( $_POST['roro_register_nonce'] ) && wp_verify_nonce( $_POST['roro_register_nonce'], 'roro_register_action' ) ) {
            // Process registration. For a production plugin you should add validation and error handling.
            $username    = sanitize_user( $_POST['username'] ?? '' );
            $email       = sanitize_email( $_POST['email'] ?? '' );
            $password    = $_POST['password'] ?? '';
            $first_name  = sanitize_text_field( $_POST['first_name'] ?? '' );
            $last_name   = sanitize_text_field( $_POST['last_name'] ?? '' );
            $address     = sanitize_text_field( $_POST['address'] ?? '' );
            $pet_name    = sanitize_text_field( $_POST['pet_name'] ?? '' );
            $user_id = wp_create_user( $username, $password, $email );
            if ( ! is_wp_error( $user_id ) ) {
                // Optionally log the user in and redirect.
                wp_set_current_user( $user_id );
                wp_set_auth_cookie( $user_id );
                $this->on_user_register( $user_id );
                return '<p>' . esc_html__( 'Registration successful.', 'roro-auth' ) . '</p>';
            } else {
                return '<p>' . esc_html( $user_id->get_error_message() ) . '</p>';
            }
        }

        ob_start();
        ?>
        <form method="post" class="roro-register-form">
            <p>
                <label for="roro-username"><?php esc_html_e( 'Username', 'roro-auth' ); ?></label><br />
                <input type="text" name="username" id="roro-username" required />
            </p>
            <p>
                <label for="roro-email"><?php esc_html_e( 'Email', 'roro-auth' ); ?></label><br />
                <input type="email" name="email" id="roro-email" required />
            </p>
            <p>
                <label for="roro-password"><?php esc_html_e( 'Password', 'roro-auth' ); ?></label><br />
                <input type="password" name="password" id="roro-password" required />
            </p>
            <p>
                <label for="roro-first-name"><?php esc_html_e( 'First Name', 'roro-auth' ); ?></label><br />
                <input type="text" name="first_name" id="roro-first-name" required />
            </p>
            <p>
                <label for="roro-last-name"><?php esc_html_e( 'Last Name', 'roro-auth' ); ?></label><br />
                <input type="text" name="last_name" id="roro-last-name" required />
            </p>
            <p>
                <label for="roro-address"><?php esc_html_e( 'Address', 'roro-auth' ); ?></label><br />
                <input type="text" name="address" id="roro-address" />
            </p>
            <p>
                <label for="roro-pet-name"><?php esc_html_e( 'Pet Name', 'roro-auth' ); ?></label><br />
                <input type="text" name="pet_name" id="roro-pet-name" />
            </p>
            <?php wp_nonce_field( 'roro_register_action', 'roro_register_nonce' ); ?>
            <p><input type="submit" value="<?php echo esc_attr__( 'Register', 'roro-auth' ); ?>" /></p>
        </form>
        <?php
        return ob_get_clean();
    }

    /**
     * Render a simple login form.
     *
     * @return string HTML output.
     */
    public function render_login_form() {
        if ( is_user_logged_in() ) {
            return '<p>' . esc_html__( 'You are already logged in.', 'roro-auth' ) . '</p>';
        }

        if ( isset( $_POST['roro_login_nonce'] ) && wp_verify_nonce( $_POST['roro_login_nonce'], 'roro_login_action' ) ) {
            $creds = array(
                'user_login'    => sanitize_user( $_POST['username'] ?? '' ),
                'user_password' => $_POST['password'] ?? '',
                'remember'      => true,
            );
            $user = wp_signon( $creds, false );
            if ( ! is_wp_error( $user ) ) {
                $this->on_user_login( $creds['user_login'], $user );
                return '<p>' . esc_html__( 'Login successful.', 'roro-auth' ) . '</p>';
            } else {
                return '<p>' . esc_html( $user->get_error_message() ) . '</p>';
            }
        }

        ob_start();
        ?>
        <form method="post" class="roro-login-form">
            <p>
                <label for="roro-login-username"><?php esc_html_e( 'Username', 'roro-auth' ); ?></label><br />
                <input type="text" name="username" id="roro-login-username" required />
            </p>
            <p>
                <label for="roro-login-password"><?php esc_html_e( 'Password', 'roro-auth' ); ?></label><br />
                <input type="password" name="password" id="roro-login-password" required />
            </p>
            <?php wp_nonce_field( 'roro_login_action', 'roro_login_nonce' ); ?>
            <p><input type="submit" value="<?php echo esc_attr__( 'Login', 'roro-auth' ); ?>" /></p>
        </form>
        <?php
        return ob_get_clean();
    }

    /**
     * Render and handle user profile form for logged‑in users.
     *
     * Allows the user to update their first name, last name, address, and pet name. If no
     * profile exists, one will be created.
     *
     * @return string HTML output.
     */
    public function render_profile_form() {
        if ( ! is_user_logged_in() ) {
            return '<p>' . esc_html__( 'Please log in to update your profile.', 'roro-auth' ) . '</p>';
        }
        $user_id = get_current_user_id();
        global $wpdb;
        $profiles_table = $wpdb->prefix . 'roro_profiles';
        $pets_table     = $wpdb->prefix . 'roro_pets';
        // Fetch existing profile and pet if available.
        $profile = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $profiles_table WHERE user_id = %d", $user_id ), ARRAY_A );
        $pet     = null;
        if ( $profile ) {
            $pet = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $pets_table WHERE profile_id = %d", $profile['id'] ), ARRAY_A );
        }
        if ( isset( $_POST['roro_profile_nonce'] ) && wp_verify_nonce( $_POST['roro_profile_nonce'], 'roro_profile_action' ) ) {
            // Sanitize inputs
            $first_name = sanitize_text_field( $_POST['first_name'] ?? '' );
            $last_name  = sanitize_text_field( $_POST['last_name'] ?? '' );
            $address    = sanitize_text_field( $_POST['address'] ?? '' );
            $pet_name   = sanitize_text_field( $_POST['pet_name'] ?? '' );
            if ( $profile ) {
                // Update profile
                $wpdb->update( $profiles_table, array(
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'address'    => $address,
                ), array( 'id' => $profile['id'] ), array( '%s', '%s', '%s' ), array( '%d' ) );
                // Update or insert pet
                if ( $pet ) {
                    $wpdb->update( $pets_table, array( 'pet_name' => $pet_name ), array( 'id' => $pet['id'] ), array( '%s' ), array( '%d' ) );
                } elseif ( ! empty( $pet_name ) ) {
                    $wpdb->insert( $pets_table, array( 'profile_id' => $profile['id'], 'pet_name' => $pet_name ), array( '%d', '%s' ) );
                }
            } else {
                // Create profile
                $wpdb->insert( $profiles_table, array(
                    'user_id'    => $user_id,
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'address'    => $address,
                ), array( '%d', '%s', '%s', '%s' ) );
                $profile_id = $wpdb->insert_id;
                if ( ! empty( $pet_name ) ) {
                    $wpdb->insert( $pets_table, array( 'profile_id' => $profile_id, 'pet_name' => $pet_name ), array( '%d', '%s' ) );
                }
            }
            // Fetch updated values
            $profile = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $profiles_table WHERE user_id = %d", $user_id ), ARRAY_A );
            $pet     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $pets_table WHERE profile_id = %d", $profile['id'] ), ARRAY_A );
            echo '<p>' . esc_html__( 'Profile updated.', 'roro-auth' ) . '</p>';
        }
        // Prepare form values
        $first_name_val = $profile['first_name'] ?? '';
        $last_name_val  = $profile['last_name'] ?? '';
        $address_val    = $profile['address'] ?? '';
        $pet_name_val   = $pet['pet_name'] ?? '';
        ob_start();
        ?>
        <form method="post" class="roro-profile-form">
            <p>
                <label for="roro-profile-first-name"><?php esc_html_e( 'First Name', 'roro-auth' ); ?></label><br />
                <input type="text" name="first_name" id="roro-profile-first-name" value="<?php echo esc_attr( $first_name_val ); ?>" required />
            </p>
            <p>
                <label for="roro-profile-last-name"><?php esc_html_e( 'Last Name', 'roro-auth' ); ?></label><br />
                <input type="text" name="last_name" id="roro-profile-last-name" value="<?php echo esc_attr( $last_name_val ); ?>" required />
            </p>
            <p>
                <label for="roro-profile-address"><?php esc_html_e( 'Address', 'roro-auth' ); ?></label><br />
                <input type="text" name="address" id="roro-profile-address" value="<?php echo esc_attr( $address_val ); ?>" />
            </p>
            <p>
                <label for="roro-profile-pet-name"><?php esc_html_e( 'Pet Name', 'roro-auth' ); ?></label><br />
                <input type="text" name="pet_name" id="roro-profile-pet-name" value="<?php echo esc_attr( $pet_name_val ); ?>" />
            </p>
            <?php wp_nonce_field( 'roro_profile_action', 'roro_profile_nonce' ); ?>
            <p><input type="submit" value="<?php echo esc_attr__( 'Update Profile', 'roro-auth' ); ?>" /></p>
        </form>
        <?php
        return ob_get_clean();
    }
}