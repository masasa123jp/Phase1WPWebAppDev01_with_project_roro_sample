<?php

/**
 * Favourites functionality for Roro.
 *
 * Registers AJAX handlers for adding and removing favourites and a shortcode
 * to display the current user’s favourites. This implementation stores
 * favourites in user meta as a proof of concept. You may want to migrate
 * the data to a custom table for better performance and flexibility.
 *
 * @since 1.0.0
 */
class Roro_Favorites_Plugin {
    /**
     * Kick things off by registering hooks and AJAX actions.
     */
    public function run() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_ajax_roro_fav_toggle', array( $this, 'toggle_favorite' ) );
        add_action( 'wp_ajax_nopriv_roro_fav_toggle', array( $this, 'auth_required' ) );
        add_shortcode( 'roro_favorites', array( $this, 'render_favorites' ) );
    }

    /**
     * Enqueue JavaScript for handling favourite toggles.
     */
    public function enqueue_scripts() {
        wp_enqueue_script( 'roro-favorites-js', RORO_FAVORITES_URL . 'assets/js/favorites.js', array( 'jquery' ), '1.1.0', true );
        wp_localize_script( 'roro-favorites-js', 'roroFavorites', array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'roro_fav_toggle' ),
            'selector'  => '.roro-fav-toggle',
        ) );
    }

    /**
     * AJAX callback to add or remove a favourite.
     */
    public function toggle_favorite() {
        check_ajax_referer( 'roro_fav_toggle', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'roro-favorites' ) ), 401 );
        }
        $user_id = get_current_user_id();
        $item_id   = absint( $_POST['item_id'] ?? 0 );
        $item_type = sanitize_key( $_POST['item_type'] ?? 'spot' );
        if ( ! $item_id || ! in_array( $item_type, array( 'event', 'spot' ), true ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid item.', 'roro-favorites' ) ), 400 );
        }
        if ( ! class_exists( 'Roro_Core_Wp_DB' ) ) {
            if ( defined( 'RORO_CORE_WP_DIR' ) ) {
                // Attempt to load the core DB class from the core plugin.
                $db_file = trailingslashit( RORO_CORE_WP_DIR ) . 'includes/class-roro-db.php';
                if ( file_exists( $db_file ) ) {
                    require_once $db_file;
                }
            }
        }
        if ( ! class_exists( 'Roro_Core_Wp_DB' ) ) {
            wp_send_json_error( array( 'message' => __( 'Required core plugin not loaded.', 'roro-favorites' ) ), 500 );
        }
        $result = Roro_Core_Wp_DB::toggle_favourite( $user_id, $item_id, $item_type );
        $favs   = Roro_Core_Wp_DB::get_favourites_for_user( $user_id );
        wp_send_json_success( array( 'action' => $result['action'], 'favorites' => $favs ) );
    }

    /**
     * Respond to unauthenticated AJAX requests.
     */
    public function auth_required() {
        wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'roro-favorites' ) ), 401 );
    }

    /**
     * Render the user’s favourites as a list.
     *
     * @return string HTML output.
     */
    public function render_favorites() {
        if ( ! is_user_logged_in() ) {
            return '<p>' . esc_html__( 'Please log in to view your favourites.', 'roro-favorites' ) . '</p>';
        }
        $user_id = get_current_user_id();
        if ( ! class_exists( 'Roro_Core_Wp_DB' ) ) {
            if ( defined( 'RORO_CORE_WP_DIR' ) ) {
                $db_file = trailingslashit( RORO_CORE_WP_DIR ) . 'includes/class-roro-db.php';
                if ( file_exists( $db_file ) ) {
                    require_once $db_file;
                }
            }
        }
        if ( ! class_exists( 'Roro_Core_Wp_DB' ) ) {
            return '<p>' . esc_html__( 'Core plugin missing. Please activate Roro Core.', 'roro-favorites' ) . '</p>';
        }
        $favs    = Roro_Core_Wp_DB::get_favourites_for_user( $user_id );
        if ( empty( $favs ) ) {
            return '<p>' . esc_html__( 'You have no favourites.', 'roro-favorites' ) . '</p>';
        }
        global $wpdb;
        $output = '<ul class="roro-favorites-list">';
        foreach ( $favs as $fav ) {
            $item_id   = absint( $fav['item_id'] );
            $item_type = $fav['item_type'];
            $name      = '';
            if ( 'event' === $item_type ) {
                $table = $wpdb->prefix . 'roro_event_master';
                $name  = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM $table WHERE id = %d", $item_id ) );
            } elseif ( 'spot' === $item_type ) {
                $table = $wpdb->prefix . 'roro_travel_spot_master';
                $name  = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM $table WHERE id = %d", $item_id ) );
            }
            if ( ! $name ) {
                $name = sprintf( __( '%1$s #%2$d', 'roro-favorites' ), ucfirst( $item_type ), $item_id );
            }
            $output .= '<li>' . esc_html( $name ) . '</li>';
        }
        $output .= '</ul>';
        return $output;
    }
}