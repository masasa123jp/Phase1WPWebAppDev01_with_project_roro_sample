<?php
/**
 * Plugin Name:       Roro Favorites
 * Plugin URI:        https://example.com/roro-favorites
 * Description:       Provides a favourites system for Roro content. Users can save
 *                    and remove favourite items via AJAX and view their saved
 *                    items via a shortcode. This skeleton implementation defines
 *                    the necessary hooks and endpoints but leaves the persistence
 *                    details for you to implement.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Roro Team
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       roro-favorites
 * Domain Path:       /languages
 *
 * @package RoroFavorites
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RORO_FAVORITES_DIR', plugin_dir_path( __FILE__ ) );
define( 'RORO_FAVORITES_URL', plugin_dir_url( __FILE__ ) );

require_once RORO_FAVORITES_DIR . 'includes/class-roro-favorites.php';

function roro_favorites_run() {
    $fav = new Roro_Favorites_Plugin();
    $fav->run();
}
add_action( 'plugins_loaded', 'roro_favorites_run' );