<?php
/**
 * Plugin Name: Roro Auth
 * Description: ユーザー認証・ソーシャル連携・通知テンプレート
 * Version: 1.6.0-rc.1
 * Requires at least: 6.3
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Text Domain: roro-auth
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/class-roro-auth-social.php';
require_once __DIR__ . '/includes/class-roro-auth-notifier.php';
