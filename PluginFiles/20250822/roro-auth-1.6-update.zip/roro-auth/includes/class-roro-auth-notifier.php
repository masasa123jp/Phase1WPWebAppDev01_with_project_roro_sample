<?php
// roro-auth/includes/class-roro-auth-notifier.php
if (!defined('ABSPATH')) { exit; }

class Roro_Auth_Notifier {
  public static function send_verify_email($to, $verify_link, $user_name='') {
    $subject = apply_filters('roro_auth_mail_subject_verify', '【RORO】メールアドレスの確認をお願いします', $to);
    $tpl = apply_filters('roro_auth_mail_body_verify', self::tpl_verify(), $to, $verify_link, $user_name);
    $body = self::render($tpl, [
      'site_name'   => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
      'verify_link' => $verify_link,
      'user_name'   => $user_name,
    ]);
    return wp_mail($to, $subject, $body);
  }
  public static function send_password_reset($to, $reset_link, $user_name='') {
    $subject = apply_filters('roro_auth_mail_subject_reset', '【RORO】パスワード再設定のご案内', $to);
    $tpl = apply_filters('roro_auth_mail_body_reset', self::tpl_reset(), $to, $reset_link, $user_name);
    $body = self::render($tpl, [
      'site_name'  => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
      'reset_link' => $reset_link,
      'user_name'  => $user_name,
    ]);
    return wp_mail($to, $subject, $body);
  }
  private static function render($tpl, array $vars) {
    return preg_replace_callback('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/', function($m) use ($vars){
      $key = $m[1];
      return isset($vars[$key]) ? $vars[$key] : $m[0];
    }, $tpl);
  }
  private static function tpl_verify() {
    return <<<TXT
{{user_name}} 様

ご登録ありがとうございます。
以下のリンクから、メールアドレスの確認を完了してください。

確認用リンク：
{{verify_link}}

※このメールに心当たりがない場合は破棄してください。
— {{site_name}}
TXT;
  }
  private static function tpl_reset() {
    return <<<TXT
{{user_name}} 様

パスワード再設定のご依頼を受け付けました。
以下のリンクから再設定を行ってください。

再設定リンク：
{{reset_link}}

※このメールに心当たりがない場合は破棄してください。
— {{site_name}}
TXT;
  }
}
