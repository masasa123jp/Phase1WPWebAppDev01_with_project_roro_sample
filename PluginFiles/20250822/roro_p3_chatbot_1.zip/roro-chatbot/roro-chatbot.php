<?php
/**
 * Plugin Name: Roro Chatbot
 * Description: Dify 連携のストリーミング描画と会話ログ管理（P3 RC）。チップ/カードUIを同梱。
 * Version: 1.6.0-rc.2
 * Requires at least: 6.3
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Text Domain: roro-chatbot
 */
if (!defined('ABSPATH')) { exit; }

// REST: Difyストリーミングのリバースプロキシ
require_once __DIR__ . '/includes/class-roro-chatbot-stream.php';
// 管理: 会話ログダッシュボード
require_once __DIR__ . '/admin/class-roro-chatbot-admin.php';

// アセット登録（必要時にenqueue）
add_action('wp_enqueue_scripts', function(){
  wp_register_style('roro-chat-ui', plugins_url('assets/css/chat-ui.css', __FILE__), [], '1.0.0');
  wp_register_script('roro-chat-stream', plugins_url('assets/js/chat-stream.js', __FILE__), [], '1.0.0', true);
  wp_register_script('roro-chat-ui', plugins_url('assets/js/chat-ui.js', __FILE__), ['roro-chat-stream'], '1.0.0', true);
});

// ショートコード: [roro_chat_ui endpoint="https://dify.example.com/v1/chat-messages"]
add_shortcode('roro_chat_ui', function($atts){
  $atts = shortcode_atts(['endpoint' => ''], $atts);
  wp_enqueue_style('roro-chat-ui');
  wp_enqueue_script('roro-chat-stream');
  wp_enqueue_script('roro-chat-ui');
  $nonce = wp_create_nonce('wp_rest');
  $rest  = esc_url_raw( rest_url('roro-chatbot/v1/stream') );
  $endpoint = esc_attr($atts['endpoint']);
  ob_start(); ?>
  <div class="roro-chat-container" data-rest="<?php echo esc_attr($rest); ?>" data-nonce="<?php echo esc_attr($nonce); ?>" data-endpoint="<?php echo $endpoint; ?>">
    <div class="roro-chat-log card"></div>
    <div class="roro-chat-input-row">
      <input class="roro-chat-input" type="text" placeholder="質問を入力..."/>
      <button class="roro-chip send">送信</button>
    </div>
  </div>
  <?php return ob_get_clean();
});
