(function(){
  async function startStream(cfg) {
    const log = document.querySelector(cfg.targetLog);
    if (!log) return;
    const res = await fetch(cfg.restUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
      body: JSON.stringify({ endpoint: cfg.endpoint || '', payload: cfg.payload || {} })
    });
    if (!res.ok || !res.body) {
      log.insertAdjacentHTML('beforeend', '<div class="chip error">通信エラー</div>');
      return;
    }
    const reader = res.body.getReader(); const decoder = new TextDecoder(); let buf = '';
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      buf += decoder.decode(value, { stream: true });
      let idx; while ((idx = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, idx).trim(); buf = buf.slice(idx + 1);
        if (!line) continue; const sse = line.startsWith('data:') ? line.slice(5).trim() : line;
        try {
          const obj = JSON.parse(sse);
          const text = obj.output || obj.message || '';
          if (text) appendMsg(log, text, 'assistant');
          if (obj.event === 'end') appendBreak(log);
        } catch(e) {
          appendMsg(log, sse, 'assistant');
        }
      }
    }
  }
  function appendMsg(log, text, role) {
    const card = document.createElement('div');
    card.className = 'card msg ' + role;
    card.innerHTML = '<div class="card-body">'+escapeHtml(text)+'</div>';
    log.appendChild(card);
    log.scrollTop = log.scrollHeight;
  }
  function appendBreak(log){ log.appendChild(document.createElement('hr')); }
  function escapeHtml(s){ return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  window.RoroChatStream = { startStream };
})();
