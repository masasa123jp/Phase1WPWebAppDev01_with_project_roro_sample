(function(){
  function boot() {
    document.querySelectorAll('.roro-chat-container').forEach(wrap => {
      const log = wrap.querySelector('.roro-chat-log');
      const input = wrap.querySelector('.roro-chat-input');
      const send = wrap.querySelector('.roro-chip.send');
      send?.addEventListener('click', () => {
        const text = (input?.value || '').trim();
        if (!text) return;
        // echo user
        const userCard = document.createElement('div');
        userCard.className = 'card msg user';
        userCard.innerHTML = '<div class="card-body">'+escapeHtml(text)+'</div>';
        log.appendChild(userCard);
        // start stream
        const payload = {
          inputs: { question: text },
          response_mode: 'streaming'
        };
        window.RoroChatStream.startStream({
          targetLog: '.roro-chat-container .roro-chat-log',
          restUrl: wrap.dataset.rest,
          nonce: wrap.dataset.nonce,
          endpoint: wrap.dataset.endpoint || '',
          payload
        });
        input.value = '';
      });
    });
  }
  function escapeHtml(s){ return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  document.addEventListener('DOMContentLoaded', boot);
})();
